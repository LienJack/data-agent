\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_21";
drop table if exists "falcon_db_21"."e_customers" cascade;
create table "falcon_db_21"."e_customers" ("CustomerID" bigint, "FirstName" text, "LastName" text, "Email" text, "Phone" text, "Address" text, "City" text, "ZipCode" bigint, "SignupDate" text);
copy "falcon_db_21"."e_customers" ("CustomerID", "FirstName", "LastName", "Email", "Phone", "Address", "City", "ZipCode", "SignupDate") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,Pat,Taylor,pat.taylor@example.com,727-686-2648,101 Elm St.,Marrakech,30000,2018-06-04
2,Eve,Lee,eve.lee@example.com,519-521-5199,456 Oak St.,Casablanca,20000,2018-08-26
3,Mallory,Taylor,mallory.taylor@example.com,951-353-3557,202 Birch St.,Marrakech,10000,2015-04-08
4,Pat,Smith,pat.smith@example.com,572-198-3200,202 Birch St.,Marrakech,10000,2015-02-24
5,Charlie,Johnson,charlie.johnson@example.com,960-995-5973,123 Maple St.,Casablanca,10000,2017-01-27
6,Sam,Davis,sam.davis@example.com,437-805-3869,202 Birch St.,Rabat,30000,2016-02-10
7,Mallory,Lee,mallory.lee@example.com,262-819-1956,123 Maple St.,Rabat,40000,2020-10-17
8,Mallory,Johnson,mallory.johnson@example.com,780-260-6699,101 Elm St.,Fes,40000,2018-08-05
9,Pat,White,pat.white@example.com,900-497-5911,456 Oak St.,Casablanca,10000,2019-11-21
10,Bob,Davis,bob.davis@example.com,603-995-2218,456 Oak St.,Fes,40000,2017-01-20
11,Charlie,Taylor,charlie.taylor@example.com,500-739-5555,123 Maple St.,Fes,40000,2019-10-29
12,Pat,Taylor,pat.taylor@example.com,982-569-4446,456 Oak St.,Fes,30000,2015-12-31
13,Charlie,Davis,charlie.davis@example.com,121-849-2693,202 Birch St.,Rabat,20000,2020-07-19
14,Charlie,Taylor,charlie.taylor@example.com,137-329-4436,789 Pine St.,Casablanca,10000,2016-04-26
15,Sam,Brown,sam.brown@example.com,662-537-6895,123 Maple St.,Fes,10000,2021-02-26
16,Mallory,Davis,mallory.davis@example.com,382-126-1225,456 Oak St.,Casablanca,30000,2015-06-03
17,Eve,Johnson,eve.johnson@example.com,376-897-8022,123 Maple St.,Casablanca,30000,2019-03-05
18,Sam,Davis,sam.davis@example.com,580-552-8996,123 Maple St.,Rabat,40000,2020-10-21
19,Sam,Lee,sam.lee@example.com,915-758-8683,789 Pine St.,Fes,10000,2021-06-01
20,Charlie,Taylor,charlie.taylor@example.com,646-291-8679,202 Birch St.,Fes,20000,2017-11-06
21,Oscar,Brown,oscar.brown@example.com,116-271-3205,123 Maple St.,Casablanca,30000,2019-07-23
22,Mallory,Brown,mallory.brown@example.com,576-145-4444,456 Oak St.,Marrakech,20000,2018-05-25
23,Bob,White,bob.white@example.com,617-198-2060,101 Elm St.,Rabat,20000,2015-03-02
24,Sam,Johnson,sam.johnson@example.com,379-448-1301,123 Maple St.,Rabat,10000,2017-07-27
25,Eve,Jones,eve.jones@example.com,280-706-4170,123 Maple St.,Rabat,10000,2019-06-28
26,Oscar,Jones,oscar.jones@example.com,799-215-1190,789 Pine St.,Rabat,30000,2020-09-20
27,Oscar,Davis,oscar.davis@example.com,352-260-4327,202 Birch St.,Fes,10000,2015-01-25
28,Bob,White,bob.white@example.com,422-227-2816,101 Elm St.,Fes,10000,2017-11-28
29,Sam,Smith,sam.smith@example.com,834-665-1569,456 Oak St.,Marrakech,10000,2015-05-11
30,Eve,Davis,eve.davis@example.com,422-971-3733,101 Elm St.,Rabat,20000,2018-06-06
31,Mallory,White,mallory.white@example.com,891-725-8455,456 Oak St.,Rabat,30000,2015-04-18
32,Alice,Johnson,alice.johnson@example.com,953-762-4009,202 Birch St.,Casablanca,40000,2015-06-21
33,Eve,Johnson,eve.johnson@example.com,738-254-2409,456 Oak St.,Fes,20000,2018-12-29
34,Bob,Johnson,bob.johnson@example.com,884-203-9096,789 Pine St.,Rabat,10000,2015-04-12
35,Oscar,Johnson,oscar.johnson@example.com,492-910-8343,789 Pine St.,Marrakech,20000,2021-05-11
36,Mallory,Johnson,mallory.johnson@example.com,138-576-6801,789 Pine St.,Marrakech,10000,2019-06-25
37,Eve,White,eve.white@example.com,858-637-6986,789 Pine St.,Fes,10000,2017-11-06
38,Alice,White,alice.white@example.com,917-507-9716,101 Elm St.,Marrakech,20000,2015-11-26
39,Alice,Brown,alice.brown@example.com,927-605-3950,202 Birch St.,Marrakech,30000,2019-03-01
40,Charlie,Lee,charlie.lee@example.com,924-135-5780,456 Oak St.,Fes,10000,2015-01-12
41,Charlie,Jones,charlie.jones@example.com,119-420-7655,456 Oak St.,Rabat,30000,2018-09-03
42,Pat,Taylor,pat.taylor@example.com,499-753-7002,789 Pine St.,Rabat,40000,2015-08-04
43,Bob,Johnson,bob.johnson@example.com,570-242-6919,789 Pine St.,Marrakech,10000,2015-12-05
44,Sam,Smith,sam.smith@example.com,826-953-5146,123 Maple St.,Marrakech,30000,2019-12-05
45,Eve,Taylor,eve.taylor@example.com,764-797-1574,202 Birch St.,Rabat,30000,2019-10-17
46,Eve,White,eve.white@example.com,289-224-7293,101 Elm St.,Fes,40000,2019-02-17
47,Sam,Smith,sam.smith@example.com,413-669-8509,456 Oak St.,Marrakech,30000,2021-08-18
48,Pat,Smith,pat.smith@example.com,404-791-5777,123 Maple St.,Casablanca,30000,2016-12-10
49,Oscar,Smith,oscar.smith@example.com,937-882-3491,123 Maple St.,Fes,40000,2018-05-08
50,Oscar,Brown,oscar.brown@example.com,712-363-4124,456 Oak St.,Marrakech,10000,2021-11-18
51,Pat,White,pat.white@example.com,671-719-1004,101 Elm St.,Marrakech,30000,2018-01-17
52,Oscar,Smith,oscar.smith@example.com,202-295-5869,123 Maple St.,Casablanca,30000,2018-07-15
53,Charlie,Johnson,charlie.johnson@example.com,976-983-5142,123 Maple St.,Casablanca,30000,2016-05-03
54,Eve,Davis,eve.davis@example.com,966-922-8079,202 Birch St.,Rabat,20000,2019-04-11
55,Pat,Smith,pat.smith@example.com,919-755-5465,101 Elm St.,Fes,40000,2015-02-16
56,Eve,Brown,eve.brown@example.com,735-205-2693,123 Maple St.,Fes,20000,2017-02-16
57,Sam,Taylor,sam.taylor@example.com,758-756-9311,101 Elm St.,Rabat,40000,2017-11-05
58,Alice,White,alice.white@example.com,930-886-6177,456 Oak St.,Fes,10000,2016-12-11
59,Charlie,Lee,charlie.lee@example.com,445-840-9308,789 Pine St.,Fes,10000,2016-02-05
60,Mallory,Brown,mallory.brown@example.com,929-890-2150,123 Maple St.,Fes,30000,2019-12-23
61,Charlie,Smith,charlie.smith@example.com,492-740-2081,202 Birch St.,Fes,40000,2015-09-07
62,Pat,White,pat.white@example.com,733-612-8805,456 Oak St.,Fes,10000,2016-01-26
63,Mallory,Davis,mallory.davis@example.com,217-659-4672,101 Elm St.,Casablanca,40000,2015-12-01
64,Alice,Smith,alice.smith@example.com,587-336-4343,456 Oak St.,Fes,10000,2016-09-20
65,Pat,Brown,pat.brown@example.com,288-803-1580,123 Maple St.,Casablanca,20000,2015-05-17
66,Bob,Jones,bob.jones@example.com,889-960-9130,101 Elm St.,Fes,10000,2019-03-02
67,Eve,Johnson,eve.johnson@example.com,175-253-2679,789 Pine St.,Rabat,20000,2017-04-06
68,Alice,Lee,alice.lee@example.com,534-185-3744,456 Oak St.,Marrakech,10000,2016-12-27
69,Eve,Taylor,eve.taylor@example.com,384-319-6188,123 Maple St.,Casablanca,30000,2019-02-09
70,Oscar,Brown,oscar.brown@example.com,146-193-7617,202 Birch St.,Fes,20000,2017-09-16
71,Bob,White,bob.white@example.com,531-440-8421,101 Elm St.,Rabat,10000,2021-08-16
72,Bob,Lee,bob.lee@example.com,833-456-6881,456 Oak St.,Marrakech,30000,2017-07-23
73,Alice,Lee,alice.lee@example.com,621-857-3849,456 Oak St.,Casablanca,20000,2016-02-06
74,Bob,Lee,bob.lee@example.com,279-322-7905,789 Pine St.,Marrakech,30000,2019-01-06
75,Mallory,Smith,mallory.smith@example.com,758-541-5611,789 Pine St.,Rabat,40000,2016-09-06
76,Bob,Johnson,bob.johnson@example.com,115-891-9527,202 Birch St.,Casablanca,40000,2018-07-20
77,Eve,Smith,eve.smith@example.com,858-357-7303,202 Birch St.,Marrakech,20000,2018-03-28
78,Eve,White,eve.white@example.com,574-951-2687,123 Maple St.,Fes,10000,2021-02-13
79,Pat,Smith,pat.smith@example.com,789-774-3427,123 Maple St.,Casablanca,20000,2018-01-26
80,Eve,Jones,eve.jones@example.com,644-790-6732,202 Birch St.,Marrakech,30000,2015-05-11
81,Pat,Johnson,pat.johnson@example.com,367-934-6536,202 Birch St.,Rabat,10000,2018-04-09
82,Eve,Johnson,eve.johnson@example.com,267-941-2066,101 Elm St.,Rabat,40000,2015-07-02
83,Mallory,White,mallory.white@example.com,655-384-5107,789 Pine St.,Casablanca,10000,2015-12-30
84,Sam,Taylor,sam.taylor@example.com,706-401-9945,123 Maple St.,Marrakech,40000,2015-02-08
85,Pat,Jones,pat.jones@example.com,134-826-9967,789 Pine St.,Casablanca,10000,2021-12-19
86,Charlie,Brown,charlie.brown@example.com,704-701-1417,789 Pine St.,Casablanca,10000,2018-10-04
87,Oscar,Smith,oscar.smith@example.com,214-716-4974,202 Birch St.,Marrakech,10000,2017-07-09
88,Alice,Davis,alice.davis@example.com,295-925-8668,101 Elm St.,Marrakech,30000,2015-01-16
89,Eve,Smith,eve.smith@example.com,725-592-1412,456 Oak St.,Fes,30000,2016-05-07
90,Bob,Lee,bob.lee@example.com,475-519-1728,101 Elm St.,Marrakech,20000,2018-12-20
91,Sam,Smith,sam.smith@example.com,376-860-9867,101 Elm St.,Rabat,20000,2018-02-05
92,Eve,Brown,eve.brown@example.com,493-968-3504,789 Pine St.,Casablanca,40000,2015-11-07
93,Bob,Smith,bob.smith@example.com,291-838-2122,101 Elm St.,Casablanca,30000,2017-01-08
94,Oscar,Jones,oscar.jones@example.com,647-195-7806,123 Maple St.,Rabat,40000,2016-06-29
95,Oscar,Jones,oscar.jones@example.com,289-835-4440,789 Pine St.,Marrakech,20000,2021-09-27
96,Oscar,Johnson,oscar.johnson@example.com,794-624-3914,123 Maple St.,Rabat,40000,2015-09-08
97,Bob,White,bob.white@example.com,972-897-9787,456 Oak St.,Rabat,20000,2017-01-28
98,Eve,Taylor,eve.taylor@example.com,979-828-2365,789 Pine St.,Fes,30000,2019-12-10
99,Oscar,Davis,oscar.davis@example.com,496-798-8186,456 Oak St.,Rabat,10000,2018-07-21
100,Mallory,Lee,mallory.lee@example.com,276-711-1395,789 Pine St.,Casablanca,30000,2019-06-20
101,Pat,Smith,pat.smith@example.com,544-332-9082,202 Birch St.,Rabat,40000,2020-03-29
102,Bob,Smith,bob.smith@example.com,175-364-3502,101 Elm St.,Casablanca,40000,2017-03-24
103,Bob,Brown,bob.brown@example.com,895-817-3782,202 Birch St.,Casablanca,30000,2015-01-29
104,Eve,White,eve.white@example.com,483-663-5946,456 Oak St.,Casablanca,30000,2017-08-15
105,Bob,Jones,bob.jones@example.com,605-466-9335,101 Elm St.,Marrakech,20000,2020-07-25
106,Bob,Davis,bob.davis@example.com,984-168-8266,789 Pine St.,Fes,40000,2016-04-21
107,Oscar,Johnson,oscar.johnson@example.com,495-124-6588,101 Elm St.,Casablanca,40000,2015-11-14
108,Eve,Jones,eve.jones@example.com,583-664-2167,123 Maple St.,Casablanca,30000,2015-09-02
109,Oscar,Lee,oscar.lee@example.com,668-138-3156,101 Elm St.,Marrakech,10000,2017-01-17
110,Pat,White,pat.white@example.com,792-141-6305,123 Maple St.,Casablanca,40000,2016-11-27
111,Sam,Lee,sam.lee@example.com,497-322-5729,101 Elm St.,Rabat,10000,2015-09-29
112,Pat,Taylor,pat.taylor@example.com,232-262-6334,123 Maple St.,Rabat,30000,2019-11-07
113,Sam,Johnson,sam.johnson@example.com,832-334-9010,456 Oak St.,Fes,30000,2018-06-16
114,Oscar,Taylor,oscar.taylor@example.com,757-850-7731,202 Birch St.,Casablanca,20000,2021-08-21
115,Pat,Brown,pat.brown@example.com,108-173-1953,789 Pine St.,Marrakech,40000,2015-09-23
116,Eve,Lee,eve.lee@example.com,591-352-2542,101 Elm St.,Rabat,10000,2017-07-09
117,Alice,Brown,alice.brown@example.com,273-752-2191,202 Birch St.,Marrakech,20000,2015-12-06
118,Oscar,Smith,oscar.smith@example.com,269-492-7938,789 Pine St.,Marrakech,40000,2016-01-24
119,Sam,Taylor,sam.taylor@example.com,733-293-2540,789 Pine St.,Rabat,20000,2020-08-12
120,Mallory,White,mallory.white@example.com,128-264-6541,123 Maple St.,Marrakech,30000,2018-03-11
121,Sam,Lee,sam.lee@example.com,438-747-2365,456 Oak St.,Rabat,40000,2016-01-11
122,Mallory,Davis,mallory.davis@example.com,599-756-9702,456 Oak St.,Marrakech,20000,2020-07-26
123,Bob,Johnson,bob.johnson@example.com,426-316-2324,202 Birch St.,Rabat,20000,2021-06-29
124,Pat,Jones,pat.jones@example.com,231-903-4141,456 Oak St.,Casablanca,10000,2015-05-26
125,Mallory,White,mallory.white@example.com,351-514-2810,101 Elm St.,Fes,20000,2020-06-04
126,Sam,White,sam.white@example.com,544-975-6301,456 Oak St.,Rabat,40000,2015-10-20
127,Bob,Brown,bob.brown@example.com,266-190-9905,202 Birch St.,Rabat,40000,2016-03-07
128,Alice,Taylor,alice.taylor@example.com,957-630-5268,456 Oak St.,Fes,10000,2016-12-05
129,Eve,Lee,eve.lee@example.com,752-853-4709,101 Elm St.,Rabat,40000,2020-06-21
130,Eve,Lee,eve.lee@example.com,157-759-7619,123 Maple St.,Rabat,30000,2016-02-03
131,Eve,Smith,eve.smith@example.com,555-928-4072,202 Birch St.,Marrakech,40000,2017-08-21
132,Mallory,Smith,mallory.smith@example.com,486-447-1504,123 Maple St.,Fes,40000,2021-02-12
133,Alice,Johnson,alice.johnson@example.com,290-607-8576,123 Maple St.,Casablanca,20000,2020-08-03
134,Mallory,Brown,mallory.brown@example.com,923-216-1133,123 Maple St.,Rabat,20000,2020-01-03
135,Pat,White,pat.white@example.com,157-655-7316,789 Pine St.,Fes,40000,2020-10-09
136,Mallory,Lee,mallory.lee@example.com,928-914-5175,789 Pine St.,Marrakech,10000,2017-07-27
137,Alice,Davis,alice.davis@example.com,985-312-6348,123 Maple St.,Casablanca,20000,2016-12-10
138,Alice,Brown,alice.brown@example.com,775-326-7190,202 Birch St.,Fes,10000,2017-03-17
139,Pat,Johnson,pat.johnson@example.com,332-404-6645,101 Elm St.,Casablanca,40000,2019-01-03
140,Alice,Johnson,alice.johnson@example.com,242-514-4584,101 Elm St.,Casablanca,40000,2018-08-18
141,Sam,Brown,sam.brown@example.com,472-665-9053,456 Oak St.,Casablanca,30000,2015-01-11
142,Alice,Johnson,alice.johnson@example.com,358-755-9662,202 Birch St.,Rabat,20000,2017-12-21
143,Eve,Brown,eve.brown@example.com,111-429-6063,789 Pine St.,Rabat,40000,2020-02-12
144,Sam,Jones,sam.jones@example.com,457-507-1667,123 Maple St.,Marrakech,30000,2021-03-23
145,Sam,Brown,sam.brown@example.com,472-107-7819,456 Oak St.,Marrakech,20000,2017-02-10
146,Pat,Taylor,pat.taylor@example.com,189-747-3745,101 Elm St.,Fes,40000,2019-05-14
147,Charlie,Brown,charlie.brown@example.com,415-277-1539,789 Pine St.,Marrakech,40000,2019-05-27
148,Charlie,Johnson,charlie.johnson@example.com,831-968-5835,789 Pine St.,Casablanca,20000,2018-08-26
149,Alice,Lee,alice.lee@example.com,803-601-8102,123 Maple St.,Casablanca,20000,2017-06-03
150,Sam,Taylor,sam.taylor@example.com,244-300-7132,101 Elm St.,Rabat,20000,2018-10-21
151,Charlie,Johnson,charlie.johnson@example.com,823-560-3779,202 Birch St.,Casablanca,40000,2015-08-14
152,Charlie,Smith,charlie.smith@example.com,851-657-8714,789 Pine St.,Fes,40000,2017-04-04
153,Alice,Smith,alice.smith@example.com,352-489-6713,123 Maple St.,Casablanca,30000,2021-03-15
154,Charlie,Lee,charlie.lee@example.com,982-355-5804,202 Birch St.,Casablanca,10000,2017-07-25
155,Mallory,Lee,mallory.lee@example.com,914-549-1009,101 Elm St.,Fes,20000,2021-12-28
156,Bob,Taylor,bob.taylor@example.com,923-897-8409,789 Pine St.,Marrakech,40000,2021-04-25
157,Pat,Jones,pat.jones@example.com,350-976-6124,202 Birch St.,Marrakech,40000,2020-03-26
158,Bob,Lee,bob.lee@example.com,218-900-3193,202 Birch St.,Fes,20000,2019-12-02
159,Alice,Smith,alice.smith@example.com,323-338-8449,202 Birch St.,Rabat,10000,2015-02-23
160,Eve,Brown,eve.brown@example.com,162-316-4925,789 Pine St.,Casablanca,20000,2016-12-27
161,Pat,Johnson,pat.johnson@example.com,926-894-5784,789 Pine St.,Fes,10000,2019-03-25
162,Alice,Smith,alice.smith@example.com,560-709-8266,456 Oak St.,Casablanca,40000,2017-11-09
163,Sam,Smith,sam.smith@example.com,610-484-1404,101 Elm St.,Rabat,10000,2020-03-28
164,Eve,Jones,eve.jones@example.com,922-617-3000,123 Maple St.,Casablanca,30000,2019-11-12
165,Bob,Taylor,bob.taylor@example.com,808-962-6989,202 Birch St.,Fes,40000,2019-05-16
166,Alice,Taylor,alice.taylor@example.com,870-536-8190,456 Oak St.,Casablanca,30000,2020-03-29
167,Sam,White,sam.white@example.com,664-776-5809,123 Maple St.,Marrakech,20000,2021-10-02
168,Pat,Jones,pat.jones@example.com,557-182-8245,456 Oak St.,Rabat,20000,2017-04-29
169,Pat,Brown,pat.brown@example.com,556-977-3048,789 Pine St.,Rabat,20000,2020-10-10
170,Oscar,Taylor,oscar.taylor@example.com,150-784-1716,202 Birch St.,Rabat,10000,2021-03-13
171,Sam,Johnson,sam.johnson@example.com,871-545-5544,123 Maple St.,Fes,40000,2015-01-03
172,Mallory,Lee,mallory.lee@example.com,980-587-4419,123 Maple St.,Rabat,20000,2015-06-09
173,Charlie,Jones,charlie.jones@example.com,194-171-1249,123 Maple St.,Marrakech,20000,2017-02-19
174,Eve,Lee,eve.lee@example.com,773-537-1770,123 Maple St.,Fes,40000,2017-06-11
175,Sam,Smith,sam.smith@example.com,990-405-5363,123 Maple St.,Marrakech,20000,2020-07-23
176,Oscar,Johnson,oscar.johnson@example.com,153-335-9580,456 Oak St.,Casablanca,30000,2021-07-04
177,Charlie,Johnson,charlie.johnson@example.com,833-862-7544,202 Birch St.,Casablanca,40000,2016-08-02
178,Charlie,Smith,charlie.smith@example.com,723-866-4374,789 Pine St.,Casablanca,40000,2020-04-17
179,Alice,Jones,alice.jones@example.com,306-328-7996,789 Pine St.,Casablanca,40000,2018-10-12
180,Charlie,Smith,charlie.smith@example.com,677-174-5530,789 Pine St.,Marrakech,30000,2018-07-14
181,Mallory,Lee,mallory.lee@example.com,202-521-7881,789 Pine St.,Fes,40000,2019-06-29
182,Pat,White,pat.white@example.com,905-405-7241,456 Oak St.,Fes,30000,2017-08-09
183,Oscar,Johnson,oscar.johnson@example.com,949-897-8002,101 Elm St.,Rabat,40000,2017-09-14
184,Charlie,Davis,charlie.davis@example.com,534-546-2331,202 Birch St.,Marrakech,10000,2018-05-03
185,Alice,Davis,alice.davis@example.com,348-265-8648,123 Maple St.,Casablanca,20000,2017-07-09
186,Mallory,Lee,mallory.lee@example.com,434-641-5854,101 Elm St.,Marrakech,10000,2018-09-17
187,Bob,Brown,bob.brown@example.com,205-662-3180,789 Pine St.,Rabat,20000,2015-06-19
188,Pat,Taylor,pat.taylor@example.com,896-237-7327,101 Elm St.,Rabat,30000,2016-06-04
189,Pat,Smith,pat.smith@example.com,500-429-3832,202 Birch St.,Marrakech,10000,2019-01-26
190,Oscar,Smith,oscar.smith@example.com,607-951-5164,123 Maple St.,Marrakech,40000,2015-02-09
191,Pat,Brown,pat.brown@example.com,645-873-6569,123 Maple St.,Marrakech,20000,2019-04-10
192,Charlie,Brown,charlie.brown@example.com,304-225-4818,202 Birch St.,Fes,20000,2018-11-19
193,Alice,Lee,alice.lee@example.com,142-851-2906,202 Birch St.,Casablanca,10000,2017-08-12
194,Pat,Lee,pat.lee@example.com,210-860-8830,789 Pine St.,Marrakech,30000,2017-09-10
195,Pat,Brown,pat.brown@example.com,282-947-7238,123 Maple St.,Marrakech,10000,2017-09-01
196,Bob,Johnson,bob.johnson@example.com,473-619-9472,101 Elm St.,Marrakech,30000,2015-02-07
197,Bob,Lee,bob.lee@example.com,294-963-4266,456 Oak St.,Rabat,30000,2021-07-03
198,Eve,White,eve.white@example.com,766-192-1671,456 Oak St.,Rabat,20000,2018-06-28
199,Mallory,Lee,mallory.lee@example.com,160-733-8570,202 Birch St.,Fes,10000,2018-04-14
200,Charlie,Smith,charlie.smith@example.com,888-104-6585,789 Pine St.,Casablanca,10000,2019-06-14
\.
analyze "falcon_db_21"."e_customers";
drop table if exists "falcon_db_21"."e_orders" cascade;
create table "falcon_db_21"."e_orders" ("OrderID" bigint, "CustomerID" bigint, "ProductID" bigint, "OrderDate" text, "Quantity" bigint, "OrderStatus" text, "TotalAmount" double precision);
copy "falcon_db_21"."e_orders" ("OrderID", "CustomerID", "ProductID", "OrderDate", "Quantity", "OrderStatus", "TotalAmount") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
101,146,1005,2020-07-16,2,Canceled,320.97
102,198,1005,2021-04-29,3,Delivered,60.32
103,37,1002,2022-12-18,4,Canceled,194.95
104,60,1003,2022-04-16,5,Delivered,336.42
105,176,1005,2022-10-05,2,Canceled,117.05
106,28,1001,2021-11-21,3,Shipped,362.94
107,197,1005,2022-11-01,2,Shipped,385.67
108,81,1002,2021-05-04,4,Shipped,491.89
109,114,1002,2020-10-02,2,Shipped,144.43
110,40,1003,2021-11-23,1,Shipped,421.31
111,45,1005,2020-08-29,3,Shipped,284.13
112,62,1001,2020-05-05,2,Delivered,218.06
113,93,1001,2020-08-04,4,Returned,105.07
114,115,1004,2022-11-28,4,Canceled,380.98
115,186,1001,2021-05-09,2,Shipped,156.14
116,67,1003,2021-03-02,4,Delivered,217.14
117,56,1003,2022-07-07,5,Delivered,78.14
118,40,1001,2020-05-30,5,Delivered,410.62
119,98,1001,2021-01-18,5,Returned,394.96
120,40,1004,2020-11-03,1,Canceled,380.13
121,91,1001,2022-01-15,2,Returned,184.75
122,33,1004,2022-06-10,1,Processing,128.07
123,6,1004,2021-01-09,4,Delivered,336.9
124,147,1001,2022-10-28,1,Processing,273.27
125,80,1002,2020-05-08,4,Shipped,130.21
126,168,1002,2022-10-11,4,Shipped,358.66
127,92,1004,2021-10-30,3,Returned,496.01
128,97,1001,2021-05-31,5,Canceled,386.25
129,59,1002,2020-03-26,4,Processing,382.99
130,59,1001,2020-11-06,3,Canceled,477.64
131,48,1001,2021-03-02,5,Returned,141.32
132,169,1001,2020-04-23,4,Shipped,304.5
133,13,1005,2020-10-29,4,Canceled,490.84
134,107,1001,2022-01-13,1,Canceled,124.38
135,45,1005,2021-08-10,1,Shipped,365.11
136,89,1004,2022-09-13,5,Processing,313.61
137,181,1002,2020-12-10,4,Shipped,313.92
138,170,1002,2022-03-24,2,Canceled,363.95
139,100,1002,2022-03-11,1,Processing,468.33
140,191,1002,2022-10-21,5,Processing,402.16
141,155,1002,2022-12-12,4,Shipped,75.26
142,166,1002,2022-12-28,4,Canceled,433.73
143,188,1002,2020-12-26,2,Returned,151.49
144,7,1004,2022-10-06,5,Canceled,219.61
145,133,1001,2021-12-04,4,Delivered,257.78
146,45,1003,2021-07-28,1,Returned,266.41
147,58,1005,2021-11-18,2,Processing,245.83
148,31,1003,2022-02-19,5,Returned,471.81
149,23,1003,2021-08-07,2,Processing,367.71
150,170,1001,2021-08-11,1,Processing,334.03
151,138,1001,2021-05-03,5,Returned,72.43
152,160,1001,2022-08-28,2,Processing,456.76
153,107,1002,2021-05-08,3,Processing,459.23
154,181,1004,2020-01-19,1,Delivered,401.1
155,158,1002,2021-01-31,1,Canceled,53.16
156,39,1004,2022-09-27,1,Canceled,75.78
157,159,1004,2022-04-30,3,Delivered,151.35
158,82,1003,2022-04-01,3,Returned,109.11
159,100,1003,2021-03-30,4,Shipped,229.48
160,2,1004,2021-12-25,2,Shipped,465.18
161,77,1004,2022-12-24,4,Shipped,262.43
162,12,1002,2021-12-11,2,Delivered,56.03
163,39,1002,2020-05-22,3,Delivered,177.24
164,194,1003,2022-07-05,3,Processing,70.07
165,13,1001,2022-04-07,4,Shipped,66.33
166,46,1004,2021-08-27,5,Returned,174.07
167,155,1002,2020-10-31,4,Returned,174.03
168,113,1003,2022-01-05,2,Shipped,404.21
169,17,1002,2020-10-17,4,Shipped,488.68
170,104,1004,2020-04-11,1,Shipped,217.04
171,98,1004,2022-05-16,2,Delivered,243.0
172,188,1005,2022-08-25,2,Delivered,430.16
173,192,1001,2022-08-31,5,Delivered,170.66
174,88,1005,2022-04-21,3,Canceled,120.37
175,109,1003,2022-08-19,2,Returned,433.89
176,163,1002,2022-07-30,3,Returned,70.93
177,70,1003,2022-10-23,4,Processing,328.86
178,158,1004,2020-03-25,1,Delivered,302.9
179,199,1005,2020-11-23,5,Canceled,205.66
180,74,1005,2022-03-26,3,Canceled,191.84
181,63,1005,2021-03-29,2,Returned,397.34
182,156,1003,2021-09-20,3,Delivered,88.89
183,60,1004,2021-10-26,2,Processing,156.55
184,79,1002,2020-01-12,3,Delivered,379.6
185,37,1002,2020-10-30,2,Shipped,296.74
186,22,1003,2022-09-01,4,Delivered,107.59
187,196,1005,2022-02-21,2,Shipped,446.96
188,148,1001,2020-02-12,2,Shipped,227.05
189,96,1003,2022-08-01,1,Processing,422.54
190,68,1003,2020-12-08,2,Returned,404.47
191,192,1004,2021-05-12,1,Delivered,330.99
192,17,1002,2020-12-29,5,Shipped,272.52
193,12,1003,2022-06-09,1,Delivered,490.8
194,150,1003,2021-03-02,4,Returned,115.23
195,145,1005,2022-10-01,1,Returned,376.32
196,138,1005,2020-01-21,5,Canceled,136.04
197,118,1001,2021-02-10,4,Returned,202.22
198,193,1004,2021-09-10,3,Processing,188.91
199,22,1001,2022-10-11,3,Shipped,476.17
200,120,1005,2020-12-01,1,Canceled,485.31
201,50,1002,2021-02-02,1,Processing,132.36
202,14,1005,2022-03-03,5,Delivered,59.92
203,192,1004,2021-12-15,5,Shipped,374.0
204,175,1005,2020-02-20,2,Returned,238.1
205,29,1004,2020-11-19,5,Shipped,89.98
206,164,1004,2022-02-27,2,Delivered,357.69
207,180,1004,2020-05-20,4,Canceled,295.3
208,125,1004,2021-04-14,1,Canceled,491.23
209,7,1004,2022-02-25,4,Canceled,152.33
210,29,1002,2022-08-21,5,Returned,231.79
211,139,1001,2022-10-04,4,Processing,294.15
212,33,1003,2021-01-07,4,Processing,406.26
213,134,1001,2021-05-08,4,Shipped,296.98
214,111,1004,2022-01-20,5,Returned,325.81
215,79,1002,2020-10-17,4,Canceled,151.77
216,160,1005,2020-04-15,2,Canceled,431.11
217,179,1002,2021-10-31,5,Delivered,242.88
218,58,1004,2020-01-02,4,Delivered,113.43
219,26,1002,2021-08-11,5,Canceled,348.88
220,174,1002,2021-10-05,3,Canceled,147.24
221,29,1004,2020-03-30,2,Returned,93.9
222,4,1002,2020-12-15,4,Processing,437.89
223,99,1003,2022-11-28,3,Delivered,257.07
224,141,1003,2022-06-27,3,Processing,387.18
225,39,1002,2020-06-07,5,Returned,180.76
226,15,1005,2022-08-16,3,Canceled,404.14
227,119,1004,2020-11-07,2,Processing,100.37
228,29,1003,2021-03-20,2,Canceled,210.19
229,157,1005,2020-10-24,1,Canceled,490.13
230,75,1002,2022-08-09,2,Shipped,407.3
231,116,1005,2020-02-05,3,Processing,273.77
232,32,1001,2021-07-12,2,Processing,202.9
233,130,1003,2022-06-09,5,Canceled,442.46
234,175,1002,2020-05-20,1,Returned,295.18
235,84,1004,2022-06-05,3,Shipped,391.29
236,22,1002,2021-12-26,1,Canceled,389.35
237,27,1004,2022-11-15,3,Delivered,58.08
238,195,1002,2021-06-04,5,Delivered,106.81
239,81,1005,2020-01-10,1,Shipped,346.83
240,126,1005,2022-09-10,4,Returned,122.73
241,184,1005,2021-01-12,3,Canceled,164.97
242,92,1001,2021-11-12,4,Processing,475.99
243,21,1004,2021-08-06,1,Shipped,302.08
244,47,1005,2020-05-31,4,Returned,387.83
245,101,1001,2021-12-20,4,Processing,301.09
246,187,1004,2022-12-08,1,Delivered,298.63
247,84,1002,2022-05-08,5,Delivered,92.37
248,6,1001,2020-02-19,4,Processing,204.65
249,147,1003,2021-10-25,4,Shipped,177.09
250,185,1001,2021-06-14,5,Delivered,225.83
251,197,1001,2022-12-19,4,Canceled,409.25
252,131,1004,2022-05-06,4,Processing,217.37
253,1,1002,2020-05-25,4,Processing,253.26
254,58,1003,2022-07-03,2,Delivered,228.82
255,124,1005,2022-09-19,5,Shipped,92.03
256,166,1005,2020-08-29,4,Canceled,248.48
257,15,1001,2021-08-03,5,Shipped,138.02
258,162,1004,2021-11-17,3,Returned,134.03
259,189,1004,2021-04-27,3,Returned,92.32
260,163,1005,2021-11-03,4,Delivered,210.5
261,64,1003,2021-09-22,5,Delivered,390.87
262,25,1002,2021-10-22,5,Delivered,174.4
263,24,1003,2021-10-23,5,Returned,190.56
264,12,1002,2022-03-15,2,Shipped,339.2
265,18,1005,2021-02-22,3,Shipped,138.13
266,15,1002,2022-09-14,5,Delivered,453.63
267,27,1004,2021-10-11,5,Canceled,284.09
268,72,1001,2022-08-26,2,Shipped,251.42
269,60,1001,2021-08-12,2,Returned,301.02
270,174,1005,2021-05-23,5,Processing,124.72
271,145,1004,2021-03-16,1,Processing,326.06
272,93,1003,2022-07-09,5,Processing,213.4
273,53,1004,2022-02-08,5,Canceled,453.73
274,8,1001,2020-09-19,2,Delivered,125.98
275,79,1001,2021-09-28,2,Returned,278.17
276,27,1004,2021-04-03,5,Canceled,319.15
277,174,1004,2022-09-25,5,Returned,65.02
278,50,1001,2021-11-30,5,Returned,213.66
279,199,1003,2020-10-28,2,Delivered,379.69
280,131,1005,2021-07-07,5,Processing,419.17
281,93,1005,2020-10-14,5,Delivered,190.92
282,192,1004,2021-09-12,4,Canceled,409.37
283,172,1005,2022-10-02,1,Canceled,485.49
284,181,1001,2020-02-05,3,Canceled,435.59
285,24,1001,2022-01-13,1,Delivered,102.94
286,60,1004,2020-12-18,4,Returned,382.88
287,122,1004,2020-03-13,3,Returned,193.85
288,131,1004,2021-10-09,5,Shipped,494.79
289,148,1003,2022-12-29,4,Canceled,268.41
290,46,1005,2021-02-28,5,Returned,105.1
291,15,1004,2022-09-25,2,Shipped,376.33
292,153,1002,2021-12-08,4,Returned,195.36
293,199,1002,2021-07-14,2,Canceled,498.69
294,17,1001,2022-04-07,4,Processing,490.9
295,126,1005,2022-08-13,4,Canceled,345.26
296,84,1004,2021-05-31,2,Delivered,108.42
297,9,1002,2021-03-03,3,Returned,359.09
298,166,1005,2020-06-08,1,Returned,91.86
299,176,1001,2020-05-28,5,Delivered,63.21
300,188,1003,2022-02-14,4,Delivered,420.33
\.
analyze "falcon_db_21"."e_orders";
drop table if exists "falcon_db_21"."e_products" cascade;
create table "falcon_db_21"."e_products" ("ProductID" bigint, "ProductName" text, "Category" text, "Price" double precision, "StockQuantity" bigint);
copy "falcon_db_21"."e_products" ("ProductID", "ProductName", "Category", "Price", "StockQuantity") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1001,Widget A,Widgets,100.0,10
1002,Widget B,Widgets,150.0,0
1003,Widget C,Gadgets,120.0,5
1004,Widget D,Gadgets,90.0,0
1005,Widget E,Tools,110.0,3
\.
analyze "falcon_db_21"."e_products";
commit;
