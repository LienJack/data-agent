\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_17";
drop table if exists "falcon_db_17"."ecommerce_customers" cascade;
create table "falcon_db_17"."ecommerce_customers" ("customer_id" text, "customer_zip_code_prefix" bigint, "customer_city" text, "customer_state" text);
copy "falcon_db_17"."ecommerce_customers" ("customer_id", "customer_zip_code_prefix", "customer_city", "customer_state") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
I74lXDOfoqsp,6020,goiania,GO
47TuLHF2s7X5,23020,viamao,RS
dQ0dqI8Qwlj8,75094,campinas,SP
iQCmWhNkIczb,89284,santana de parnaiba,SP
Dp2g6JH8tO5Z,39810,aripuana,MT
s18Fn5Tz7Jml,65790,sao jose do rio preto,SP
9rXAwNe0G0m5,25245,sao bento do sul,SC
o3yCAPMIPtLj,97560,sao paulo,SP
PHGrixjXAt4t,32430,barueri,SP
K6lNXbhXbvwg,8571,divinopolis,MG
WaitNYVtRT2x,8664,sao paulo,SP
WDjs7f3Yv8Va,26155,sao paulo,SP
ViMUFfeZLwv5,60120,rio de janeiro,RJ
ZdAOMosp5YDg,73805,guarulhos,SP
jVsS0bHgLHcJ,75440,palmas,TO
D1KiQOWblWjh,45037,presidente prudente,SP
I1orDozbJsZY,3953,brasilia,DF
bincH34GAiat,13213,criciuma,SC
J534NgM03SXi,33935,guarulhos,SP
11rzNuxGsM6E,7916,anapolis,GO
\.
analyze "falcon_db_17"."ecommerce_customers";
drop table if exists "falcon_db_17"."ecommerce_order_items" cascade;
create table "falcon_db_17"."ecommerce_order_items" ("order_id" text, "product_id" text, "seller_id" text, "price" double precision, "shipping_charges" double precision);
copy "falcon_db_17"."ecommerce_order_items" ("order_id", "product_id", "seller_id", "price", "shipping_charges") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
u6rPMRAYIGig,1slxdgbgWFax,3jwvL6ihC45G,24.1,20.9
ohY8f4FEbX19,77PgsiElQLeB,GlLj704QXlDB,42.89,12.28
I28liQek73i2,QVlD26X1y7NI,V3iKL8r9W9NR,50.21,67.11
bBG1T89mlY8W,yWlFGkKYfrpa,RNBdBKsXebna,89.1,62.05
CYxJJSQS8Lbo,h6MCbrwh5kiC,5Ja2lH0N2OZt,2139.99,9.41
kUkQCFPtDvrC,CApN1zdCu8Ad,smK689qrlIx3,84.55,20.65
eV98svHRmPNG,HOJj2KbHY8er,9hrosJpQLxRs,23.95,23.87
b2tsoISX5lnP,bKrL5OryV9HU,SSiPMxP6t9t9,692.0,44.59
O0D3th8M88nF,7ba9znpcLheP,WTbhLip6Y9IF,649.75,39.88
yBTGlSf8GGMV,TLhoqYaQLJ5g,ynoKalx03eHF,518.18,2.46
OoHJ0WBqlxln,EG4wDSpFyTth,TuPm19CMKvrM,58.1,26.26
qvrK7ROfp1w6,hoFRvSkFE7Xv,2jTASjIU2rIf,420.07,30.66
uNUwbkr3jhfD,YLYPEDYgvdfH,3e9JGBdDRF6C,318.33,27.73
j4hiZpWSGa1T,XnVJHXWoT9t9,Q2NwKBfUdtHW,34.0,60.03
6J3ZtW3UMsR9,cDHQRx6Mr5x7,XLxN4hdOlYco,52.0,42.76
CKtqZeTFa6Ov,cKboTGrWp54z,OfafuCsnlLjb,509.99,56.8
e7xeH7PfGWFM,MUIEAN159RuU,kYHploWLdvqh,820.05,47.55
y7ICBanZzdHp,W5lSpNbHbIjE,fsdM6QZEnGMM,692.0,46.76
bZFqy2PEMhhc,claM69kKTNfa,EZZCNVOVjDlq,74.89,131.63
ub5scd3uMflH,aUvBxYvPYgvN,l1pYW6GBnPMr,820.0,47.55
\.
analyze "falcon_db_17"."ecommerce_order_items";
drop table if exists "falcon_db_17"."ecommerce_orders" cascade;
create table "falcon_db_17"."ecommerce_orders" ("order_id" text, "customer_id" text, "order_purchase_timestamp" text, "order_approved_at" text);
copy "falcon_db_17"."ecommerce_orders" ("order_id", "customer_id", "order_purchase_timestamp", "order_approved_at") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
u6rPMRAYIGig,I74lXDOfoqsp,2017-11-18 12:29:57,2017-11-18 12:46:08
ohY8f4FEbX19,47TuLHF2s7X5,2018-06-02 17:13:12,2018-06-02 20:12:23
I28liQek73i2,dQ0dqI8Qwlj8,2018-01-08 11:01:30,2018-01-09 07:24:03
bBG1T89mlY8W,iQCmWhNkIczb,2017-03-10 10:24:46,2017-03-10 10:24:46
CYxJJSQS8Lbo,Dp2g6JH8tO5Z,2017-12-02 10:04:07,2017-12-05 04:13:30
kUkQCFPtDvrC,s18Fn5Tz7Jml,2018-07-26 21:40:10,2018-07-26 21:50:19
eV98svHRmPNG,9rXAwNe0G0m5,2018-02-13 06:49:11,2018-02-14 06:46:53
b2tsoISX5lnP,o3yCAPMIPtLj,2018-07-09 03:40:22,2018-07-09 03:50:07
O0D3th8M88nF,PHGrixjXAt4t,2018-05-28 23:23:31,2018-05-28 23:35:19
yBTGlSf8GGMV,K6lNXbhXbvwg,2017-02-28 17:28:52,2017-02-28 19:20:26
OoHJ0WBqlxln,WaitNYVtRT2x,2018-03-15 10:00:16,2018-03-15 10:15:35
qvrK7ROfp1w6,WDjs7f3Yv8Va,2017-05-13 22:52:45,2017-05-13 23:08:52
uNUwbkr3jhfD,ViMUFfeZLwv5,2018-04-04 12:42:36,2018-04-05 02:08:32
j4hiZpWSGa1T,ZdAOMosp5YDg,2018-03-01 14:58:33,2018-03-01 15:15:47
6J3ZtW3UMsR9,jVsS0bHgLHcJ,2017-03-06 13:56:19,2017-03-07 04:03:33
CKtqZeTFa6Ov,D1KiQOWblWjh,2018-08-12 12:16:53,2018-08-12 12:30:16
e7xeH7PfGWFM,I1orDozbJsZY,2018-03-02 17:58:09,2018-03-02 19:42:23
y7ICBanZzdHp,bincH34GAiat,2018-02-25 19:13:33,2018-02-25 19:27:55
bZFqy2PEMhhc,J534NgM03SXi,2018-01-20 19:51:16,2018-01-20 20:20:13
ub5scd3uMflH,11rzNuxGsM6E,2018-02-22 16:47:12,2018-02-22 17:10:44
\.
analyze "falcon_db_17"."ecommerce_orders";
drop table if exists "falcon_db_17"."ecommerce_payments" cascade;
create table "falcon_db_17"."ecommerce_payments" ("order_id" text, "payment_sequential" bigint, "payment_type" text, "payment_installments" bigint, "payment_value" double precision);
copy "falcon_db_17"."ecommerce_payments" ("order_id", "payment_sequential", "payment_type", "payment_installments", "payment_value") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
u6rPMRAYIGig,1,credit_card,2,155.77
ohY8f4FEbX19,1,credit_card,1,4.07
I28liQek73i2,1,wallet,1,381.59
bBG1T89mlY8W,1,credit_card,3,14.76
CYxJJSQS8Lbo,1,wallet,1,284.09
kUkQCFPtDvrC,1,credit_card,2,342.02
eV98svHRmPNG,1,credit_card,5,48.71
b2tsoISX5lnP,1,credit_card,1,204.4
O0D3th8M88nF,1,credit_card,3,997.37
yBTGlSf8GGMV,1,credit_card,3,204.62
OoHJ0WBqlxln,1,credit_card,2,57.57
qvrK7ROfp1w6,1,voucher,1,307.86
uNUwbkr3jhfD,1,wallet,1,21.55
j4hiZpWSGa1T,1,credit_card,3,4.18
6J3ZtW3UMsR9,1,wallet,1,257.42
CKtqZeTFa6Ov,1,credit_card,1,50.78
e7xeH7PfGWFM,1,credit_card,1,158.58
y7ICBanZzdHp,1,credit_card,4,162.62
bZFqy2PEMhhc,1,credit_card,1,159.82
ub5scd3uMflH,1,credit_card,1,277.25
\.
analyze "falcon_db_17"."ecommerce_payments";
drop table if exists "falcon_db_17"."ecommerce_products" cascade;
create table "falcon_db_17"."ecommerce_products" ("product_id" text, "product_category_name" text, "product_weight_g" double precision, "product_length_cm" double precision, "product_height_cm" double precision, "product_width_cm" double precision);
copy "falcon_db_17"."ecommerce_products" ("product_id", "product_category_name", "product_weight_g", "product_length_cm", "product_height_cm", "product_width_cm") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1slxdgbgWFax,toys,50.0,16.0,5.0,11.0
77PgsiElQLeB,electronics,200.0,21.0,7.0,14.0
QVlD26X1y7NI,furniture_decor,1000.0,100.0,5.0,20.0
yWlFGkKYfrpa,toys,8950.0,40.0,30.0,40.0
h6MCbrwh5kiC,toys,2301.0,32.0,35.0,34.0
CApN1zdCu8Ad,toys,400.0,22.0,27.0,27.0
HOJj2KbHY8er,toys,12850.0,36.0,56.0,56.0
bKrL5OryV9HU,toys,18800.0,60.0,40.0,42.0
7ba9znpcLheP,toys,375.0,16.0,8.0,11.0
TLhoqYaQLJ5g,toys,200.0,16.0,16.0,16.0
EG4wDSpFyTth,health_beauty,250.0,22.0,10.0,18.0
hoFRvSkFE7Xv,home_appliances,950.0,25.0,11.0,15.0
YLYPEDYgvdfH,toys,250.0,23.0,13.0,21.0
XnVJHXWoT9t9,toys,3100.0,30.0,30.0,30.0
cDHQRx6Mr5x7,toys,100.0,19.0,3.0,11.0
cKboTGrWp54z,toys,2600.0,17.0,17.0,60.0
MUIEAN159RuU,baby,450.0,30.0,7.0,20.0
W5lSpNbHbIjE,toys,1150.0,33.0,4.0,28.0
claM69kKTNfa,toys,450.0,27.0,16.0,27.0
aUvBxYvPYgvN,toys,350.0,17.0,4.0,12.0
\.
analyze "falcon_db_17"."ecommerce_products";
commit;
