\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_11";
drop table if exists "falcon_db_11"."bakery_price" cascade;
create table "falcon_db_11"."bakery_price" ("Name" text, "price" bigint);
copy "falcon_db_11"."bakery_price" ("Name", "price") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
angbutter,4800
plain bread,3500
jam,1500
ice coffe,4000
croissant,3500
ice coffe latter,4500
tiramisu croissant,4800
cacao deep,4000
pain au chocolat,3500
almond croissant,4000
ice milk tea,4500
gateau chocolat,4000
pandoro,4500
cheese cake,5000
lemon ade,4500
orange pound,4500
wiener,2500
valina latte,4500
berry ade,4500
tiramisu,4500
merinque cookies,4000
delivery fee,2000
\.
analyze "falcon_db_11"."bakery_price";
drop table if exists "falcon_db_11"."bakery_sales" cascade;
create table "falcon_db_11"."bakery_sales" ("datetime" text, "day_of_week" text, "total" bigint, "product_name" text, "amount" bigint);
copy "falcon_db_11"."bakery_sales" ("datetime", "day_of_week", "total", "product_name", "amount") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
2019/7/11 15:35,Thur,23800,angbutter,1
2019/7/11 16:10,Thur,15800,angbutter,1
2019/7/13 13:19,Sat,14800,angbutter,1
2019/7/13 13:22,Sat,15600,angbutter,2
2019/7/13 14:54,Sat,15800,angbutter,1
2019/7/13 15:08,Sat,15800,angbutter,1
2019/7/13 15:23,Sat,19100,angbutter,2
2019/7/13 16:32,Sat,22300,angbutter,1
2019/7/14 11:08,Sun,15300,angbutter,1
2019/7/14 11:15,Sun,27600,angbutter,2
2019/7/14 11:44,Sun,26300,angbutter,1
2019/7/14 11:59,Sun,19800,angbutter,1
2019/7/14 12:59,Sun,18300,angbutter,1
2019/7/14 13:05,Sun,15600,angbutter,2
2019/7/14 14:06,Sun,23600,angbutter,2
2019/7/14 14:41,Sun,20100,angbutter,2
2019/7/14 14:51,Sun,25600,angbutter,2
2019/7/14 15:02,Sun,19800,angbutter,1
2019/7/15 11:45,Mon,15100,angbutter,2
2019/7/15 16:21,Mon,15800,angbutter,1
2019/7/17 11:47,Wed,17800,angbutter,1
2019/7/17 13:23,Wed,14800,angbutter,3
2019/7/17 14:16,Wed,23400,angbutter,1
2019/7/17 16:32,Wed,18100,angbutter,1
2019/7/19 11:43,Fri,14800,angbutter,1
2019/7/19 12:11,Fri,15800,angbutter,1
2019/7/19 12:36,Fri,21800,angbutter,1
2019/7/19 12:44,Fri,20600,angbutter,2
2019/7/19 13:35,Fri,14800,angbutter,1
2019/7/19 13:50,Fri,15100,angbutter,2
2019/7/19 15:33,Fri,35900,angbutter,3
2019/7/20 11:19,Sat,15800,angbutter,1
2019/7/20 11:35,Sat,18800,angbutter,1
2019/7/20 11:40,Sat,22800,angbutter,1
2019/7/20 11:44,Sat,16400,angbutter,3
2019/7/20 12:08,Sat,15800,angbutter,1
2019/7/20 12:13,Sat,26300,angbutter,1
2019/7/20 12:31,Sat,14800,angbutter,1
2019/7/20 12:55,Sat,15800,angbutter,1
2019/7/20 13:44,Sat,18600,angbutter,2
2019/7/20 13:56,Sat,17800,angbutter,1
2019/7/21 11:07,Sun,18600,angbutter,1
2019/7/21 11:42,Sun,17300,angbutter,1
2019/7/21 12:12,Sun,17800,angbutter,1
2019/7/21 12:25,Sun,14800,angbutter,1
2019/7/21 12:29,Sun,16100,angbutter,2
2019/7/21 13:37,Sun,19300,angbutter,1
2019/7/21 13:45,Sun,22300,angbutter,1
2019/7/21 14:05,Sun,18300,angbutter,1
2019/7/21 14:53,Sun,15300,angbutter,1
2019/7/21 15:21,Sun,15100,angbutter,1
2019/7/22 11:38,Mon,15600,angbutter,2
2019/7/22 12:16,Mon,19300,angbutter,1
2019/7/22 12:24,Mon,18300,angbutter,1
2019/7/22 12:41,Mon,18300,angbutter,1
2019/7/22 13:28,Mon,16600,angbutter,2
2019/7/22 13:44,Mon,14800,angbutter,1
2019/7/22 14:47,Mon,26000,angbutter,5
2019/7/22 15:37,Mon,19600,angbutter,1
2019/7/22 16:54,Mon,18600,angbutter,1
2019/7/24 11:29,Wed,16400,angbutter,3
2019/7/24 11:56,Wed,27100,angbutter,2
2019/7/24 13:24,Wed,18800,angbutter,1
2019/7/24 14:25,Wed,25400,angbutter,3
2019/7/24 14:28,Wed,26300,angbutter,1
2019/7/24 15:36,Wed,16100,angbutter,2
2019/7/24 15:40,Wed,16100,angbutter,2
2019/7/24 16:02,Wed,16400,angbutter,3
2019/7/25 11:49,Thur,18600,angbutter,1
2019/7/25 11:57,Thur,26800,angbutter,1
2019/7/25 12:35,Thur,38000,angbutter,5
2019/7/25 13:01,Thur,23100,angbutter,2
2019/7/25 13:40,Thur,19600,angbutter,2
2019/7/25 13:42,Thur,15300,angbutter,1
2019/7/25 14:12,Thur,16100,angbutter,2
2019/7/25 15:09,Thur,14300,angbutter,1
2019/7/25 15:57,Thur,15100,angbutter,1
2019/7/26 11:26,Fri,25300,angbutter,1
2019/7/26 11:23,Fri,73200,angbutter,4
2019/7/26 11:31,Fri,22800,angbutter,1
2019/7/26 11:36,Fri,1293000,angbutter,6
2019/7/26 11:55,Fri,20800,angbutter,1
2019/7/26 13:19,Fri,25900,angbutter,3
2019/7/26 13:24,Fri,28100,angbutter,2
2019/7/26 14:05,Fri,15800,angbutter,1
2019/7/26 14:24,Fri,35000,angbutter,5
2019/7/26 14:52,Fri,22100,angbutter,1
2019/7/26 14:56,Fri,16100,angbutter,2
2019/7/27 11:29,Sat,18800,angbutter,1
2019/7/27 11:57,Sat,21800,angbutter,1
2019/7/27 12:00,Sat,18600,angbutter,1
2019/7/27 12:07,Sat,33200,angbutter,2
2019/7/27 12:20,Sat,22800,angbutter,1
2019/7/27 12:26,Sat,17000,angbutter,1
2019/7/27 12:43,Sat,16400,angbutter,1
2019/7/27 13:50,Sat,14800,angbutter,1
2019/7/27 14:05,Sat,32600,angbutter,1
2019/7/28 11:17,Sun,17300,angbutter,1
2019/7/28 12:10,Sun,14800,angbutter,1
2019/7/28 12:21,Sun,14800,angbutter,1
2019/7/28 12:47,Sun,14300,angbutter,1
2019/7/28 12:48,Sun,14800,angbutter,1
2019/7/28 13:13,Sun,25600,angbutter,2
2019/7/29 11:08,Mon,24800,angbutter,1
2019/7/29 11:12,Mon,24100,angbutter,2
2019/7/28 11:14,Mon,15800,angbutter,1
2019/7/29 11:39,Mon,14800,angbutter,1
2019/7/29 12:02,Mon,14800,angbutter,1
2019/7/29 12:15,Mon,18300,angbutter,1
2019/7/29 12:22,Mon,27900,angbutter,3
2019/7/29 12:54,Mon,15800,angbutter,1
2019/7/29 13:25,Mon,18100,angbutter,1
2019/7/31 11:09,Wed,15600,angbutter,2
2019/7/31 11:25,Wed,30100,angbutter,2
2019/7/31 11:38,Wed,23300,angbutter,1
2019/7/31 11:44,Wed,30200,angbutter,2
2019/7/31 12:48,Wed,15100,angbutter,2
2019/7/31 13:18,Wed,27300,angbutter,1
2019/7/31 13:19,Wed,15300,angbutter,1
2019/7/31 13:29,Wed,16100,angbutter,1
2019/7/31 13:54,Wed,15100,angbutter,1
2019/7/31 13:58,Wed,15800,angbutter,1
2019/8/1 11:17,Thur,13100,angbutter,2
2019/8/1 11:25,Thur,16100,angbutter,2
2019/8/1 11:50,Thur,14800,angbutter,1
2019/8/1 12:02,Thur,21100,angbutter,2
2019/8/1 12:15,Thur,20600,angbutter,2
2019/8/1 12:24,Thur,32600,angbutter,1
2019/8/1 13:37,Thur,15100,angbutter,2
2019/8/1 14:17,Thur,14800,angbutter,1
2019/8/2 11:03,Fri,19900,angbutter,3
2019/8/2 11:04,Fri,14100,angbutter,1
2019/8/2 11:06,Fri,18000,angbutter,3
2019/8/2 11:19,Fri,16400,angbutter,3
2019/8/2 11:31,Fri,17300,angbutter,1
2019/8/2 11:57,Fri,30800,angbutter,6
2019/8/2 12:21,Fri,15800,angbutter,1
2019/8/2 12:31,Fri,19900,angbutter,2
2019/8/2 12:51,Fri,15800,angbutter,1
2019/8/3 11:02,Sat,26000,angbutter,5
2019/8/3 11:03,Sat,26100,angbutter,2
2019/8/3 11:05,Sat,29100,angbutter,1
2019/8/3 11:06,Sat,16800,angbutter,1
2019/8/3 11:20,Sat,16600,angbutter,1
2019/8/3 11:53,Sat,18800,angbutter,1
2019/8/3 12:06,Sat,16400,angbutter,3
2019/8/3 12:44,Sat,19300,angbutter,1
2019/8/3 13:06,Sat,16400,angbutter,3
2019/8/3 13:18,Sat,18300,angbutter,1
2019/8/3 13:20,Sat,16300,angbutter,1
2019/8/3 13:42,Sat,15800,angbutter,1
2019/8/3 15:07,Sat,17900,angbutter,3
2019/8/3 15:53,Sat,16400,angbutter,3
2019/8/4 11:02,Sun,34800,angbutter,1
2019/8/4 11:04,Sun,31600,angbutter,2
2019/8/4 11:07,Sun,16400,angbutter,3
2019/8/4 11:07,Sun,19300,angbutter,1
2019/8/4 11:41,Sun,24300,angbutter,1
2019/8/4 11:52,Sun,22100,angbutter,2
2019/8/4 12:27,Sun,14800,angbutter,1
2019/8/4 12:35,Sun,20600,angbutter,2
2019/8/5 11:11,Mon,16300,angbutter,1
2019/8/5 11:16,Mon,23100,angbutter,2
2019/8/5 11:18,Mon,31400,angbutter,2
2019/8/5 11:59,Mon,22300,angbutter,1
2019/8/5 12:14,Mon,26600,angbutter,2
2019/8/5 12:14,Mon,14800,angbutter,1
2019/8/5 12:42,Mon,19600,angbutter,2
2019/8/5 12:49,Mon,49300,angbutter,1
2019/8/5 13:54,Mon,19800,angbutter,1
2019/8/5 14:25,Mon,20800,angbutter,1
2019/8/5 14:53,Mon,16300,angbutter,1
2019/8/7 11:03,Wed,16300,angbutter,1
2019/8/7 11:10,Wed,21200,angbutter,4
2019/8/7 12:20,Wed,27300,angbutter,1
2019/8/7 12:28,Wed,16100,angbutter,2
2019/8/7 13:28,Wed,17600,angbutter,1
2019/8/7 13:59,Wed,14800,angbutter,1
2019/8/7 14:06,Wed,14100,angbutter,2
2019/8/7 14:50,Wed,23800,angbutter,1
2019/8/8 11:07,Thur,16100,angbutter,2
2019/8/8 11:09,Thur,16400,angbutter,3
2019/8/8 11:22,Thur,20300,angbutter,1
2019/8/8 12:13,Thur,15100,angbutter,2
2019/8/8 12:39,Thur,15300,angbutter,1
2019/8/8 13:22,Thur,15800,angbutter,1
2019/8/8 13:26,Thur,17300,angbutter,1
2019/8/8 13:36,Thur,33200,angbutter,2
2019/8/8 13:57,Thur,32400,angbutter,3
2019/8/8 14:11,Thur,16100,angbutter,2
2019/8/9 12:31,Fri,18600,angbutter,1
2019/8/9 15:22,Fri,26000,angbutter,5
2019/8/9 15:22,Fri,35800,angbutter,6
2019/8/9 15:30,Fri,15100,angbutter,1
2019/8/10 11:01,Sat,19600,angbutter,2
2019/8/10 11:02,Sat,15300,angbutter,1
2019/8/10 11:03,Sat,19100,angbutter,1
2019/8/10 11:05,Sat,28600,angbutter,2
2019/8/10 11:09,Sat,17300,angbutter,1
2019/8/10 11:27,Sat,36800,angbutter,1
2019/8/10 11:38,Sat,25300,angbutter,1
2019/8/10 12:17,Sat,46200,angbutter,4
2019/8/10 13:09,Sat,30200,angbutter,4
2019/8/10 13:15,Sat,16600,angbutter,1
2019/8/10 13:22,Sat,21200,angbutter,4
2019/8/10 13:31,Sat,24400,angbutter,3
2019/8/11 11:01,Sun,21800,angbutter,1
2019/8/11 11:02,Sun,16800,angbutter,1
2019/8/11 11:08,Sun,22800,angbutter,1
2019/8/11 11:08,Sun,17800,angbutter,1
2019/8/11 11:37,Sun,15800,angbutter,1
2019/8/11 11:40,Sun,38900,angbutter,3
2019/8/11 11:46,Sun,19600,angbutter,2
2019/8/11 11:50,Sun,15300,angbutter,1
2019/8/11 11:58,Sun,27900,angbutter,3
2019/8/11 12:58,Sun,15800,angbutter,1
2019/8/11 13:14,Sun,19300,angbutter,1
2019/8/11 13:21,Sun,23100,angbutter,2
2019/8/11 13:27,Sun,17300,angbutter,1
2019/8/12 11:05,Mon,28400,angbutter,2
2019/8/12 11:08,Mon,20800,angbutter,1
2019/8/12 11:48,Mon,16300,angbutter,1
2019/8/12 12:39,Mon,24300,angbutter,1
2019/8/12 12:41,Mon,15800,angbutter,1
2019/8/12 12:48,Mon,14800,angbutter,1
2019/8/12 12:53,Mon,16300,angbutter,1
2019/8/12 13:27,Mon,18300,angbutter,1
2019/8/12 13:56,Mon,19100,angbutter,2
2019/8/12 14:08,Mon,32100,angbutter,1
2019/8/12 15:01,Mon,26000,angbutter,5
2019/8/14 11:03,Wed,41200,angbutter,4
2019/8/14 11:03,Wed,17800,angbutter,1
2019/8/14 11:04,Wed,18300,angbutter,1
2019/8/14 11:07,Wed,17300,angbutter,1
2019/8/14 11:16,Wed,65600,angbutter,6
2019/8/14 11:25,Wed,27300,angbutter,1
2019/8/14 11:31,Wed,22300,angbutter,1
2019/8/14 11:41,Wed,14300,angbutter,1
2019/8/14 12:15,Wed,16400,angbutter,3
2019/8/15 11:03,Thur,24100,angbutter,2
2019/8/15 11:06,Thur,17300,angbutter,1
2019/8/15 11:15,Thur,16100,angbutter,2
2019/8/15 11:23,Thur,22100,angbutter,2
2019/8/15 11:49,Thur,15100,angbutter,1
2019/8/15 12:00,Thur,18900,angbutter,2
2019/8/15 12:18,Thur,16400,angbutter,3
2019/8/16 11:05,Fri,14800,angbutter,1
2019/8/16 11:54,Fri,17800,angbutter,1
2019/8/16 11:54,Fri,15100,angbutter,1
2019/8/16 12:07,Fri,14100,angbutter,2
2019/8/16 12:49,Fri,18300,angbutter,1
2019/8/16 13:27,Fri,15800,angbutter,1
2019/8/17 11:01,Sat,20100,angbutter,2
2019/8/17 11:03,Sat,18300,angbutter,1
2019/8/17 11:17,Sat,24100,angbutter,2
2019/8/17 11:30,Sat,24300,angbutter,1
2019/8/17 12:29,Sat,14800,angbutter,1
2019/8/17 12:40,Sat,18800,angbutter,1
2019/8/17 12:57,Sat,29600,angbutter,2
2019/8/17 13:02,Sat,19800,angbutter,1
2019/8/17 13:19,Sat,20300,angbutter,1
2019/8/17 13:38,Sat,32600,angbutter,2
2019/8/18 11:01,Sun,17300,angbutter,1
2019/8/18 11:06,Sun,36900,angbutter,3
2019/8/18 11:09,Sun,26600,angbutter,2
2019/8/18 11:09,Sun,22800,angbutter,1
2019/8/18 11:23,Sun,17800,angbutter,1
2019/8/18 11:27,Sun,14100,angbutter,2
2019/8/18 12:50,Sun,23800,angbutter,1
2019/8/18 13:06,Sun,14300,angbutter,1
2019/8/18 13:29,Sun,14800,angbutter,1
2019/8/18 13:30,Sun,36100,angbutter,2
2019/8/18 12:40,Sun,16300,angbutter,1
2019/8/19 11:29,Mon,22800,angbutter,1
2019/8/19 11:59,Mon,16800,angbutter,1
2019/8/19 12:08,Mon,21300,angbutter,1
2019/8/19 12:10,Mon,19300,angbutter,1
2019/8/19 12:21,Mon,15800,angbutter,1
2019/8/19 12:34,Mon,23600,angbutter,1
2019/8/19 13:06,Mon,19300,angbutter,1
2019/8/19 13:24,Mon,14800,angbutter,1
2019/8/19 13:53,Mon,24300,angbutter,1
2019/8/19 14:16,Mon,23800,angbutter,1
2019/8/19 14:20,Mon,15300,angbutter,1
2019/8/19 15:27,Mon,21600,angbutter,2
2019/8/19 15:30,Mon,18800,angbutter,1
2019/8/21 11:02,Wed,19900,angbutter,3
2019/8/21 11:04,Wed,18800,angbutter,1
2019/8/21 11:07,Wed,15300,angbutter,1
2019/8/21 11:28,Wed,54000,angbutter,5
2019/8/21 12:13,Wed,18300,angbutter,1
2019/8/21 12:19,Wed,16100,angbutter,2
2019/8/21 12:29,Wed,19300,angbutter,1
2019/8/21 13:01,Wed,15800,angbutter,1
2019/8/21 13:26,Wed,15600,angbutter,1
2019/8/21 13:43,Wed,21100,angbutter,2
2019/8/22 11:48,Thur,14800,angbutter,1
2019/8/22 12:08,Thur,23300,angbutter,1
2019/8/22 12:12,Thur,15800,angbutter,1
2019/8/22 12:55,Thur,16400,angbutter,3
2019/8/22 13:07,Thur,26600,angbutter,2
2019/8/22 13:49,Thur,23400,angbutter,3
2019/8/22 14:17,Thur,20600,angbutter,2
2019/8/22 14:35,Thur,15800,angbutter,1
2019/8/23 11:28,Fri,42200,angbutter,4
2019/8/23 11:53,Fri,57700,angbutter,9
2019/8/23 12:42,Fri,14100,angbutter,1
2019/8/23 12:47,Fri,19800,angbutter,1
2019/8/24 11:09,Sat,20100,angbutter,1
2019/8/24 11:13,Sat,25600,angbutter,1
2019/8/24 11:14,Sat,23100,angbutter,2
2019/8/24 11:14,Sat,17300,angbutter,1
2019/8/24 11:18,Sat,24900,angbutter,3
2019/8/24 11:19,Sat,17300,angbutter,1
2019/8/24 11:42,Sat,14300,angbutter,1
2019/8/24 11:51,Sat,15600,angbutter,2
2019/8/24 12:28,Sat,15800,angbutter,1
2019/8/24 12:56,Sat,23300,angbutter,1
2019/8/24 13:07,Sat,14800,angbutter,1
2019/8/24 14:13,Sat,15300,angbutter,1
2019/8/25 11:02,Sun,16400,angbutter,3
2019/8/25 11:04,Sun,15300,angbutter,1
2019/8/25 11:06,Sun,17300,angbutter,1
2019/8/25 11:18,Sun,15300,angbutter,1
2019/8/25 11:53,Sun,15300,angbutter,1
2019/8/25 12:02,Sun,15800,angbutter,1
2019/8/25 12:05,Sun,22100,angbutter,2
2019/8/25 12:05,Sun,14100,angbutter,2
2019/8/25 12:23,Sun,25300,angbutter,1
2019/8/25 12:43,Sun,17400,angbutter,3
2019/8/25 12:48,Sun,15100,angbutter,1
2019/8/25 13:13,Sun,15600,angbutter,2
2019/8/26 11:16,Mon,17800,angbutter,1
2019/8/26 11:17,Mon,19900,angbutter,3
2019/8/26 12:05,Mon,14800,angbutter,1
2019/8/26 14:25,Mon,15300,angbutter,1
2019/8/26 15:48,Mon,21600,angbutter,2
2019/8/26 16:11,Mon,22800,angbutter,1
2019/8/28 11:19,Wed,16300,angbutter,1
2019/8/28 11:30,Wed,34100,angbutter,2
2019/8/28 12:20,Wed,30400,angbutter,3
2019/8/28 12:46,Wed,18600,angbutter,2
2019/8/28 13:42,Wed,14800,angbutter,1
2019/8/28 13:57,Wed,33400,angbutter,3
2019/8/28 14:05,Wed,19300,angbutter,1
2019/8/29 11:04,Thur,22300,angbutter,1
2019/8/29 12:25,Thur,18300,angbutter,1
2019/8/29 12:35,Thur,16100,angbutter,2
2019/8/29 13:28,Thur,53800,angbutter,6
2019/8/29 14:01,Thur,30800,angbutter,6
2019/8/29 16:45,Thur,24300,angbutter,1
2019/8/29 16:46,Thur,15100,angbutter,1
2019/8/30 11:10,Fri,16400,angbutter,3
2019/8/30 11:16,Fri,14800,angbutter,1
2019/8/30 11:18,Fri,39300,angbutter,6
2019/8/30 11:36,Fri,20600,angbutter,2
2019/8/30 13:10,Fri,14300,angbutter,1
2019/8/30 14:30,Fri,21200,angbutter,4
2019/8/30 15:00,Fri,23100,angbutter,2
2019/8/30 15:05,Fri,28800,angbutter,1
2019/8/30 15:25,Fri,28300,angbutter,1
2019/8/30 16:18,Fri,18800,angbutter,1
2019/8/31 11:15,Sat,18600,angbutter,1
2019/8/31 11:20,Sat,16300,angbutter,1
2019/8/31 11:37,Sat,14800,angbutter,1
2019/8/31 12:31,Sat,16300,angbutter,1
2019/8/31 12:34,Sat,14800,angbutter,1
2019/8/31 14:50,Sat,16100,angbutter,2
2019/8/31 15:27,Sat,14100,angbutter,2
2019/9/1 11:05,Sun,23300,angbutter,1
2019/9/1 11:22,Sun,14800,angbutter,1
2019/9/1 11:40,Sun,22100,angbutter,2
2019/9/1 12:04,Sun,19600,angbutter,2
2019/9/1 12:07,Sun,16600,angbutter,2
2019/9/1 12:25,Sun,22900,angbutter,2
2019/9/1 12:39,Sun,28300,angbutter,1
2019/9/1 14:05,Sun,33100,angbutter,1
2019/9/1 14:35,Sun,14800,angbutter,1
2019/9/1 14:43,Sun,15800,angbutter,1
2019/9/1 15:04,Sun,16100,angbutter,2
2019/9/2 12:12,Mon,31400,angbutter,3
2019/9/2 14:17,Mon,20300,angbutter,1
2019/9/2 14:30,Mon,24300,angbutter,1
2019/9/2 15:16,Mon,18300,angbutter,1
2019/9/4 12:04,Wed,14800,angbutter,1
2019/9/4 12:06,Wed,18600,angbutter,1
2019/9/4 12:31,Wed,18600,angbutter,1
2019/9/4 13:19,Wed,19300,angbutter,1
2019/9/4 13:31,Wed,15300,angbutter,1
2019/9/4 13:42,Wed,27700,angbutter,3
2019/9/4 13:53,Wed,22800,angbutter,1
2019/9/4 14:54,Wed,14800,angbutter,1
2019/9/4 15:26,Wed,41100,angbutter,2
2019/9/4 16:28,Wed,18600,angbutter,2
2019/9/5 11:15,Thur,27700,angbutter,4
2019/9/5 11:27,Thur,21800,angbutter,1
2019/9/5 11:47,Thur,15100,angbutter,2
2019/9/5 12:12,Thur,19600,angbutter,1
2019/9/5 12:21,Thur,16400,angbutter,3
2019/9/5 12:24,Thur,17600,angbutter,2
2019/9/5 13:30,Thur,15600,angbutter,2
2019/9/5 13:49,Thur,20900,angbutter,2
2019/9/5 14:30,Thur,29200,angbutter,4
2019/9/5 14:46,Thur,18800,angbutter,1
2019/9/5 15:39,Thur,16100,angbutter,2
2019/9/5 15:46,Thur,14800,angbutter,1
2019/9/5 15:50,Thur,14100,angbutter,2
2019/9/6 11:14,Fri,16300,angbutter,1
2019/9/6 11:30,Fri,14800,angbutter,1
2019/9/6 12:09,Fri,15300,angbutter,1
2019/9/6 13:46,Fri,19800,angbutter,1
2019/9/6 15:06,Fri,15800,angbutter,4
2019/9/6 16:29,Fri,39700,angbutter,2
2019/9/7 11:10,Sat,23600,angbutter,2
2019/9/7 11:15,Sat,19800,angbutter,1
2019/9/7 11:18,Sat,14100,angbutter,2
2019/9/7 11:40,Sat,14800,angbutter,1
2019/9/7 11:42,Sat,18800,angbutter,1
2019/9/7 12:00,Sat,15300,angbutter,1
2019/9/7 12:05,Sat,18600,angbutter,1
2019/9/7 12:39,Sat,15100,angbutter,2
2019/9/7 16:12,Sat,27500,angbutter,3
2019/9/7 16:23,Sat,27400,angbutter,3
2019/9/8 11:08,Sun,25100,angbutter,2
2019/9/8 11:27,Sun,14800,angbutter,1
2019/9/8 11:56,Sun,16400,angbutter,3
2019/9/9 11:12,Mon,23100,angbutter,1
2019/9/9 12:04,Mon,22600,angbutter,2
2019/9/9 13:01,Mon,14800,angbutter,1
2019/9/9 13:12,Mon,14800,angbutter,1
2019/9/9 14:17,Mon,18800,angbutter,1
2019/9/9 14:44,Mon,15100,angbutter,2
2019/9/9 14:49,Mon,24100,angbutter,3
2019/9/9 15:42,Mon,21800,angbutter,1
2019/9/9 15:42,Mon,20400,angbutter,3
2019/9/9 16:01,Mon,18600,angbutter,2
2019/9/11 11:13,Wed,42300,angbutter,6
2019/9/11 11:25,Wed,15600,angbutter,2
2019/9/11 13:06,Wed,14300,angbutter,1
2019/9/11 13:08,Wed,24400,angbutter,3
2019/9/11 13:21,Wed,33400,angbutter,3
2019/9/11 14:22,Wed,15300,angbutter,1
2019/9/11 14:48,Wed,16300,angbutter,1
2019/9/11 14:57,Wed,24600,angbutter,1
2019/9/11 15:28,Wed,16400,angbutter,3
2019/9/11 15:30,Wed,15100,angbutter,1
2019/9/12 11:16,Thur,15800,angbutter,1
2019/9/12 12:01,Thur,19800,angbutter,1
2019/9/12 12:26,Thur,16400,angbutter,3
2019/9/12 12:40,Thur,23300,angbutter,1
2019/9/12 12:00,Thur,14300,angbutter,1
2019/9/12 12:45,Thur,22100,angbutter,2
2019/9/12 13:25,Thur,15100,angbutter,2
2019/9/12 13:43,Thur,15800,angbutter,1
2019/9/12 13:51,Thur,27600,angbutter,2
2019/9/14 11:07,Sat,22800,angbutter,1
2019/9/14 11:35,Sat,25400,angbutter,3
2019/9/14 11:41,Sat,15100,angbutter,2
2019/9/14 12:06,Sat,19300,angbutter,1
2019/9/14 12:17,Sat,26300,angbutter,1
2019/9/15 11:07,Sun,32200,angbutter,4
2019/9/15 11:33,Sun,24600,angbutter,2
2019/9/15 12:06,Sun,15800,angbutter,1
2019/9/15 12:13,Sun,32600,angbutter,2
2019/9/15 13:08,Sun,16100,angbutter,2
2019/9/15 13:34,Sun,24400,angbutter,3
2019/9/15 13:38,Sun,25300,angbutter,1
2019/9/15 13:38,Sun,16300,angbutter,1
2019/9/15 14:54,Sun,15100,angbutter,1
2019/9/15 15:28,Sun,57900,angbutter,2
2019/9/18 11:26,Wed,19800,angbutter,1
2019/9/18 14:10,Wed,15300,angbutter,1
2019/9/18 14:37,Wed,14300,angbutter,1
2019/9/18 14:44,Wed,15300,angbutter,1
2019/9/18 11:26,Wed,19600,angbutter,2
2019/9/19 12:47,Thur,15300,angbutter,1
2019/9/19 13:24,Thur,15300,angbutter,1
2019/9/19 13:50,Thur,20900,angbutter,3
2019/9/19 14:07,Thur,23300,angbutter,1
2019/9/19 14:15,Thur,71800,angbutter,11
2019/9/19 15:53,Thur,23100,angbutter,2
2019/9/19 16:04,Thur,15600,angbutter,2
2019/9/19 16:27,Thur,34600,angbutter,2
2019/9/20 11:06,Fri,39700,angbutter,4
2019/9/20 11:32,Fri,16400,angbutter,3
2019/9/20 11:48,Fri,19300,angbutter,1
2019/9/20 12:59,Fri,15100,angbutter,1
2019/9/20 13:28,Fri,14800,angbutter,1
2019/9/20 13:44,Fri,40400,angbutter,8
2019/9/20 14:58,Fri,18300,angbutter,1
2019/9/21 11:06,Sat,17800,angbutter,1
2019/9/21 11:08,Sat,39300,angbutter,1
2019/9/21 11:19,Sat,23600,angbutter,1
2019/9/21 11:22,Sat,18300,angbutter,1
2019/9/21 11:39,Sat,21100,angbutter,1
2019/9/21 12:08,Sat,15800,angbutter,1
2019/9/21 12:16,Sat,17600,angbutter,2
2019/9/21 12:27,Sat,16100,angbutter,2
2019/9/21 12:28,Sat,37900,angbutter,2
2019/9/21 13:38,Sat,18800,angbutter,1
2019/9/21 13:56,Sat,25100,angbutter,2
2019/9/21 14:15,Sat,19300,angbutter,1
2019/9/22 11:09,Sun,14100,angbutter,1
2019/9/22 11:18,Sun,30900,angbutter,2
2019/9/22 11:46,Sun,18600,angbutter,2
2019/9/22 12:01,Sun,14100,angbutter,2
2019/9/22 12:06,Sun,22300,angbutter,1
2019/9/22 12:07,Sun,34100,angbutter,2
2019/9/22 12:08,Sun,17800,angbutter,1
2019/9/22 12:19,Sun,24300,angbutter,1
2019/9/22 12:33,Sun,15300,angbutter,1
2019/9/22 12:51,Sun,14800,angbutter,1
2019/9/22 12:54,Sun,21300,angbutter,1
2019/9/22 12:56,Sun,15100,angbutter,2
2019/9/23 11:25,Mon,16300,angbutter,1
2019/9/23 12:08,Mon,15800,angbutter,1
2019/9/23 13:22,Mon,18300,angbutter,1
2019/9/23 13:41,Mon,24600,angbutter,2
2019/9/23 14:02,Mon,16400,angbutter,3
2019/9/23 15:25,Mon,24900,angbutter,1
2019/9/23 16:13,Mon,22300,angbutter,1
2019/9/25 11:05,Wed,14800,angbutter,1
2019/9/25 13:12,Wed,49700,angbutter,9
2019/9/25 15:39,Wed,17800,angbutter,1
2019/9/25 16:10,Wed,17300,angbutter,1
2019/9/26 14:23,Thur,24800,angbutter,1
2019/9/26 14:45,Thur,14800,angbutter,1
2019/9/27 12:30,Fri,21300,angbutter,1
2019/9/27 13:07,Fri,15800,angbutter,1
2019/9/27 13:13,Fri,16400,angbutter,3
2019/9/27 14:35,Fri,19600,angbutter,2
2019/9/27 14:42,Fri,16400,angbutter,3
2019/9/27 15:42,Fri,14800,angbutter,1
2019/9/27 16:12,Fri,36100,angbutter,2
2019/9/28 11:11,Sat,28700,angbutter,4
2019/9/28 11:27,Sat,14300,angbutter,1
2019/9/28 12:27,Sat,21800,angbutter,1
2019/9/28 12:37,Sat,21800,angbutter,1
2019/9/28 12:41,Sat,22100,angbutter,2
2019/9/28 12:52,Sat,41400,angbutter,3
2019/9/28 13:36,Sat,14800,angbutter,1
2019/9/28 13:52,Sat,27100,angbutter,1
2019/9/28 14:07,Sat,25800,angbutter,1
2019/9/28 15:11,Sat,20100,angbutter,2
2019/9/28 16:01,Sat,15300,angbutter,1
2019/9/28 16:12,Sat,15800,angbutter,1
2019/9/29 11:03,Sun,24400,angbutter,2
2019/9/29 11:06,Sun,18800,angbutter,1
2019/9/29 11:17,Sun,14800,angbutter,1
2019/9/29 11:39,Sun,23100,angbutter,2
2019/9/29 11:49,Sun,17300,angbutter,1
2019/9/29 12:00,Sun,14800,angbutter,1
2019/9/29 12:13,Sun,23800,angbutter,1
2019/9/29 13:50,Sun,15300,angbutter,1
2019/9/29 13:59,Sun,15300,angbutter,1
2019/9/29 14:02,Sun,29900,angbutter,3
2019/9/29 15:05,Sun,19600,angbutter,1
2019/9/29 15:22,Sun,27800,angbutter,1
2019/9/29 15:31,Sun,14800,angbutter,1
2019/9/30 12:35,Mon,18600,angbutter,2
2019/9/30 12:47,Mon,17300,angbutter,1
2019/9/30 13:03,Mon,18600,angbutter,2
2019/9/30 13:43,Mon,27600,angbutter,2
2019/10/2 11:58,Wed,19300,angbutter,1
2019/10/3 11:07,Thur,17800,angbutter,1
2019/10/3 11:20,Thur,14300,angbutter,1
2019/10/3 11:53,Thur,18300,angbutter,1
2019/10/3 12:05,Thur,16100,angbutter,2
2019/10/3 12:12,Thur,22300,angbutter,1
2019/10/3 12:17,Thur,28300,angbutter,1
2019/10/3 12:28,Thur,15800,angbutter,1
2019/10/3 12:54,Thur,14300,angbutter,1
2019/10/3 13:42,Thur,18800,angbutter,1
2019/10/3 14:20,Thur,19600,angbutter,2
2019/10/3 14:25,Thur,22800,angbutter,1
2019/10/3 14:34,Thur,14800,angbutter,1
2019/10/3 14:50,Thur,21800,angbutter,1
2019/10/3 14:50,Thur,15400,angbutter,2
2019/10/4 12:29,Fri,15100,angbutter,2
2019/10/4 14:26,Fri,32900,angbutter,3
2019/10/5 12:39,Sat,31800,angbutter,1
2019/10/5 13:34,Sat,15300,angbutter,1
2019/10/5 14:19,Sat,15800,angbutter,1
2019/10/5 11:03,Sat,20900,angbutter,3
2019/10/6 11:25,Sun,21300,angbutter,1
2019/10/6 11:58,Sun,18300,angbutter,1
2019/10/6 12:05,Sun,15300,angbutter,1
2019/10/6 12:31,Sun,16300,angbutter,1
2019/10/6 12:51,Sun,25300,angbutter,1
2019/10/6 13:51,Sun,19300,angbutter,1
2019/10/7 11:12,Mon,19800,angbutter,1
2019/10/7 12:00,Mon,16100,angbutter,2
2019/10/7 12:24,Mon,17300,angbutter,1
2019/10/7 13:31,Mon,15100,angbutter,1
2019/10/7 15:41,Mon,15600,angbutter,2
2019/10/7 16:12,Mon,17300,angbutter,1
2019/10/7 16:49,Mon,16100,angbutter,2
2019/10/9 11:09,Wed,14300,angbutter,1
2019/10/9 11:18,Wed,16100,angbutter,1
2019/10/9 11:21,Wed,14800,angbutter,1
2019/10/10 12:02,Thur,15100,angbutter,2
2019/10/10 12:08,Thur,18300,angbutter,1
2019/10/10 12:49,Thur,18600,angbutter,2
2019/10/10 13:05,Thur,68100,angbutter,7
2019/10/10 14:32,Thur,16400,angbutter,3
2019/10/11 11:18,Fri,14800,angbutter,1
2019/10/11 11:24,Fri,17300,angbutter,1
2019/10/11 11:34,Fri,14800,angbutter,1
2019/10/11 12:38,Fri,15100,angbutter,1
2019/10/11 14:09,Fri,20800,angbutter,1
2019/10/12 11:40,Sat,15100,angbutter,2
2019/10/12 12:00,Sat,17300,angbutter,1
2019/10/12 12:38,Sat,15800,angbutter,1
2019/10/12 13:02,Sat,19300,angbutter,1
2019/10/12 13:11,Sat,23800,angbutter,1
2019/10/12 13:23,Sat,15300,angbutter,1
2019/10/12 15:22,Sat,26000,angbutter,5
2019/10/13 11:18,Sun,22800,angbutter,1
2019/10/13 13:01,Sun,14800,angbutter,1
2019/10/13 13:15,Sun,41100,angbutter,2
2019/10/13 14:32,Sun,15600,angbutter,1
2019/10/13 14:42,Sun,22800,angbutter,1
2019/10/13 14:48,Sun,21300,angbutter,1
2019/10/13 14:54,Sun,27600,angbutter,1
2019/10/14 11:26,Mon,26900,angbutter,3
2019/10/14 11:40,Mon,14800,angbutter,1
2019/10/14 12:09,Mon,14800,angbutter,1
2019/10/14 12:21,Mon,17300,angbutter,1
2019/10/14 13:47,Mon,18300,angbutter,1
2019/10/14 13:56,Mon,16400,angbutter,3
2019/10/16 11:09,Wed,22800,angbutter,1
2019/10/16 11:12,Wed,28900,angbutter,3
2019/10/16 13:03,Wed,23300,angbutter,1
2019/10/16 14:31,Wed,20300,angbutter,1
2019/10/16 15:01,Wed,15600,angbutter,2
2019/10/17 11:47,Thur,14800,angbutter,1
2019/10/17 12:35,Thur,14800,angbutter,1
2019/10/17 12:48,Thur,15800,angbutter,1
2019/10/17 12:49,Thur,15300,angbutter,1
2019/10/17 13:05,Thur,18300,angbutter,1
2019/10/17 13:16,Thur,24800,angbutter,1
2019/10/17 13:50,Thur,32300,angbutter,1
2019/10/17 14:45,Thur,16300,angbutter,1
2019/10/17 15:41,Thur,18600,angbutter,2
2019/10/17 16:00,Thur,15800,angbutter,1
2019/10/18 11:43,Fri,51900,angbutter,8
2019/10/18 13:57,Fri,15300,angbutter,1
2019/10/19 11:17,Sat,29100,angbutter,2
2019/10/19 11:24,Sat,16300,angbutter,1
2019/10/19 11:55,Sat,15800,angbutter,1
2019/10/19 12:00,Sat,18300,angbutter,1
2019/10/19 12:49,Sat,14800,angbutter,1
2019/10/19 14:45,Sat,14800,angbutter,1
2019/10/19 15:56,Sat,15800,angbutter,1
2019/10/19 16:20,Sat,15100,angbutter,1
2019/10/20 11:05,Sun,14800,angbutter,1
2019/10/20 11:18,Sun,18600,angbutter,2
2019/10/20 11:25,Sun,19800,angbutter,1
2019/10/20 11:34,Sun,28100,angbutter,2
2019/10/20 11:58,Sun,16300,angbutter,1
2019/10/20 12:03,Sun,17300,angbutter,1
2019/10/20 12:49,Sun,14300,angbutter,1
2019/10/20 12:52,Sun,16400,angbutter,3
2019/10/20 12:55,Sun,35200,angbutter,4
2019/10/20 14:24,Sun,16100,angbutter,2
2019/10/20 14:59,Sun,16400,angbutter,3
2019/10/21 11:19,Mon,18300,angbutter,1
2019/10/21 11:27,Mon,16300,angbutter,1
2019/10/21 11:34,Mon,22800,angbutter,1
2019/10/21 11:36,Mon,20800,angbutter,1
2019/10/21 11:27,Mon,17300,angbutter,1
2019/10/21 11:47,Mon,28600,angbutter,2
2019/10/21 11:58,Mon,47600,angbutter,2
2019/10/21 12:36,Mon,33700,angbutter,4
2019/10/21 12:48,Mon,15800,angbutter,1
2019/10/21 13:28,Mon,14800,angbutter,1
2019/10/21 13:47,Mon,54700,angbutter,9
2019/10/21 17:06,Mon,16400,angbutter,3
2019/10/23 11:06,Wed,15800,angbutter,1
2019/10/23 11:17,Wed,17300,angbutter,1
2019/10/23 13:12,Wed,23600,angbutter,2
2019/10/24 11:03,Thur,25300,angbutter,1
2019/10/24 11:18,Thur,18800,angbutter,1
2019/10/24 11:53,Thur,21800,angbutter,1
2019/10/24 12:35,Thur,28300,angbutter,1
2019/10/24 12:59,Thur,26900,angbutter,3
2019/10/24 13:35,Thur,17300,angbutter,1
2019/10/24 11:06,Thur,15100,angbutter,1
2019/10/24 14:06,Thur,15800,angbutter,1
2019/10/24 16:35,Thur,15300,angbutter,1
2019/10/24 17:18,Thur,14300,angbutter,1
2019/10/25 11:15,Fri,18300,angbutter,1
2019/10/25 11:16,Fri,27300,angbutter,1
2019/10/25 11:51,Fri,22800,angbutter,1
2019/10/25 12:31,Fri,14300,angbutter,1
2019/10/25 14:16,Fri,18600,angbutter,2
2019/10/26 11:03,Sat,14800,angbutter,1
2019/10/26 11:54,Sat,25800,angbutter,2
2019/10/26 12:07,Sat,14800,angbutter,1
2019/10/26 12:47,Sat,17300,angbutter,1
2019/10/26 12:47,Sat,20600,angbutter,2
2019/10/26 12:52,Sat,20100,angbutter,2
2019/10/26 13:04,Sat,15100,angbutter,2
2019/10/27 23:02,Sun,35600,angbutter,7
2019/10/27 11:18,Sun,14800,angbutter,1
2019/10/27 11:33,Sun,17800,angbutter,1
2019/10/27 11:51,Sun,19800,angbutter,2
2019/10/27 11:57,Sun,22300,angbutter,2
2019/10/27 12:40,Sun,17300,angbutter,1
2019/10/27 12:51,Sun,18800,angbutter,1
2019/10/27 13:01,Sun,14800,angbutter,1
2019/10/27 13:20,Sun,15800,angbutter,1
2019/10/28 11:14,Mon,19800,angbutter,1
2019/10/28 11:17,Mon,14800,angbutter,1
2019/10/28 11:40,Mon,15800,angbutter,1
2019/10/28 12:15,Mon,18300,angbutter,1
2019/10/28 12:55,Mon,14800,angbutter,1
2019/10/28 13:31,Mon,23300,angbutter,1
2019/10/28 13:39,Mon,17300,angbutter,1
2019/10/28 13:45,Mon,26600,angbutter,2
2019/10/28 14:20,Mon,34600,angbutter,2
2019/10/28 14:30,Mon,14800,angbutter,1
2019/10/31 11:05,Thur,55800,angbutter,3
2019/10/31 12:18,Thur,14800,angbutter,1
2019/11/1 11:10,Fri,14100,angbutter,1
2019/11/1 11:46,Fri,21800,angbutter,1
2019/11/1 12:11,Fri,19100,angbutter,2
2019/11/1 12:56,Fri,14800,angbutter,1
2019/11/2 11:08,Sat,30400,angbutter,3
2019/11/2 11:27,Sat,16800,angbutter,1
2019/11/2 11:45,Sat,16100,angbutter,2
2019/11/2 12:01,Sat,14100,angbutter,2
2019/11/2 12:44,Sat,17500,angbutter,1
2019/11/2 13:56,Sat,14800,angbutter,1
2019/11/2 14:38,Sat,16300,angbutter,1
2019/11/2 15:55,Sat,14800,angbutter,1
2019/11/2 16:03,Sat,14800,angbutter,1
2019/11/2 16:40,Sat,28800,angbutter,1
2019/11/2 16:54,Sat,14300,angbutter,1
2019/11/3 11:02,Sun,20800,angbutter,1
2019/11/3 11:04,Sun,23100,angbutter,2
2019/11/3 11:16,Sun,19800,angbutter,1
2019/11/3 12:01,Sun,33700,angbutter,2
2019/11/3 12:25,Sun,17800,angbutter,1
2019/11/3 12:58,Sun,16100,angbutter,2
2019/11/3 13:33,Sun,27900,angbutter,3
2019/11/3 14:30,Sun,15100,angbutter,2
2019/11/3 15:30,Sun,14800,angbutter,1
2019/11/4 13:13,Mon,26600,angbutter,2
2019/11/6 11:47,Wed,24600,angbutter,2
2019/11/6 12:04,Wed,18300,angbutter,1
2019/11/6 13:23,Wed,14800,angbutter,1
2019/11/6 14:33,Wed,15100,angbutter,2
2019/11/6 16:15,Wed,24800,angbutter,1
2019/11/7 11:20,Thur,15300,angbutter,1
2019/11/7 11:26,Thur,14800,angbutter,1
2019/11/7 12:31,Thur,14800,angbutter,1
2019/11/7 13:33,Thur,34800,angbutter,1
2019/11/7 13:43,Thur,27900,angbutter,2
2019/11/7 14:44,Thur,26800,angbutter,1
2019/11/7 15:21,Thur,16800,angbutter,1
2019/11/7 16:26,Thur,16600,angbutter,2
2019/11/8 11:36,Fri,22800,angbutter,1
2019/11/8 12:56,Fri,16400,angbutter,3
2019/11/8 13:03,Fri,19900,angbutter,3
2019/11/8 14:12,Fri,23300,angbutter,1
2019/11/8 14:46,Fri,15600,angbutter,2
2019/11/8 15:01,Fri,14800,angbutter,1
2019/11/8 15:02,Fri,27800,angbutter,1
2019/11/8 15:12,Fri,30000,angbutter,1
2019/11/8 11:36,Fri,16400,angbutter,3
2019/11/9 11:36,Sat,18300,angbutter,1
2019/11/9 11:36,Sat,20600,angbutter,2
2019/11/9 11:36,Sat,26100,angbutter,2
2019/11/9 11:36,Sat,27300,angbutter,1
2019/11/9 11:36,Sat,35700,angbutter,4
2019/11/9 11:36,Sat,18800,angbutter,2
2019/11/9 11:36,Sat,14800,angbutter,1
2019/11/9 14:06,Sat,15800,angbutter,1
2019/11/9 14:48,Sat,15800,angbutter,1
2019/11/9 15:40,Sat,14800,angbutter,1
2019/11/9 16:23,Sat,14800,angbutter,1
2019/11/9 16:49,Sat,15800,angbutter,2
2019/11/10 11:06,Sun,14800,angbutter,1
2019/11/10 11:10,Sun,21100,angbutter,2
2019/11/10 11:20,Sun,32800,angbutter,1
2019/11/10 11:29,Sun,19600,angbutter,2
2019/11/10 11:41,Sun,15800,angbutter,1
2019/11/10 11:44,Sun,16100,angbutter,2
2019/11/10 11:55,Sun,29100,angbutter,2
2019/11/10 12:11,Sun,19300,angbutter,1
2019/11/10 12:45,Sun,14800,angbutter,1
2019/11/10 13:09,Sun,23800,angbutter,1
2019/11/10 13:10,Sun,19800,angbutter,1
2019/11/10 13:35,Sun,24600,angbutter,3
2019/11/10 11:27,Sun,15400,angbutter,2
2019/11/10 14:21,Sun,18600,angbutter,2
2019/11/10 15:32,Sun,20900,angbutter,3
2019/11/10 15:52,Sun,15800,angbutter,1
2019/11/11 11:32,Mon,26600,angbutter,2
2019/11/11 12:00,Mon,18600,angbutter,2
2019/11/11 12:59,Mon,15300,angbutter,1
2019/11/11 14:00,Mon,19300,angbutter,1
2019/11/11 14:39,Mon,20300,angbutter,1
2019/11/11 17:25,Mon,28300,angbutter,1
2019/11/13 11:05,Wed,22300,angbutter,1
2019/11/13 11:37,Wed,30100,angbutter,3
2019/11/13 11:46,Wed,15800,angbutter,1
2019/11/13 12:04,Wed,15800,angbutter,1
2019/11/13 12:29,Wed,15300,angbutter,1
2019/11/13 14:45,Wed,14800,angbutter,1
2019/11/13 16:23,Wed,15800,angbutter,1
2019/11/13 17:22,Wed,15100,angbutter,1
2019/11/14 11:02,Thur,16400,angbutter,3
2019/11/14 12:52,Thur,16300,angbutter,1
2019/11/14 13:10,Thur,39300,angbutter,1
2019/11/15 13:06,Fri,14800,angbutter,1
2019/11/15 13:09,Fri,16100,angbutter,2
2019/11/15 14:39,Fri,17300,angbutter,1
2019/11/15 15:19,Fri,14800,angbutter,1
2019/11/15 16:30,Fri,70700,angbutter,4
2019/11/16 11:07,Sat,23800,angbutter,2
2019/11/16 11:18,Sat,15100,angbutter,2
2019/11/16 13:38,Sat,21100,angbutter,2
2019/11/16 14:15,Sat,16600,angbutter,2
2019/11/16 14:21,Sat,24800,angbutter,1
2019/11/16 16:13,Sat,19100,angbutter,2
2019/11/16 16:21,Sat,14300,angbutter,1
2019/11/17 11:06,Sun,26300,angbutter,1
2019/11/17 11:07,Sun,23800,angbutter,1
2019/11/17 11:07,Sun,22300,angbutter,2
2019/11/17 11:07,Sun,14800,angbutter,1
2019/11/17 11:09,Sun,15800,angbutter,1
2019/11/17 11:24,Sun,16500,angbutter,1
2019/11/17 11:57,Sun,16300,angbutter,1
2019/11/17 12:01,Sun,19600,angbutter,2
2019/11/17 13:18,Sun,23300,angbutter,2
2019/11/17 14:10,Sun,18100,angbutter,3
2019/11/17 15:25,Sun,17300,angbutter,1
2019/11/17 15:55,Sun,20600,angbutter,2
2019/11/17 15:58,Sun,14800,angbutter,2
2019/11/17 16:45,Sun,14500,angbutter,2
2019/11/18 11:16,Mon,15100,angbutter,2
2019/11/18 14:36,Mon,28800,angbutter,1
2019/11/18 15:17,Mon,22800,angbutter,1
2019/11/20 11:08,Wed,28100,angbutter,2
2019/11/20 12:46,Wed,17300,angbutter,1
2019/11/20 12:59,Wed,20300,angbutter,1
2019/11/20 13:24,Wed,23800,angbutter,1
2019/11/20 16:28,Wed,16300,angbutter,1
2019/11/21 11:08,Thur,26000,angbutter,5
2019/11/21 14:44,Thur,19600,angbutter,2
2019/11/22 12:25,Fri,21000,angbutter,1
2019/11/22 12:25,Fri,16300,angbutter,1
2019/11/22 16:02,Fri,12800,angbutter,1
2019/11/22 17:05,Fri,16600,angbutter,2
2019/11/23 11:55,Sat,19300,angbutter,1
2019/11/23 12:00,Sat,36100,angbutter,2
2019/11/23 13:30,Sat,17800,angbutter,1
2019/11/23 13:44,Sat,18800,angbutter,1
2019/11/23 14:39,Sat,14300,angbutter,1
2019/11/23 15:23,Sat,14800,angbutter,1
2019/11/23 15:30,Sat,22300,angbutter,1
2019/11/23 16:15,Sat,15300,angbutter,2
2019/11/24 11:29,Sun,19800,angbutter,1
2019/11/24 12:21,Sun,20800,angbutter,1
2019/11/24 12:26,Sun,18300,angbutter,1
2019/11/24 12:56,Sun,33700,angbutter,4
2019/11/24 13:00,Sun,17300,angbutter,1
2019/11/24 13:13,Sun,14800,angbutter,1
2019/11/24 13:39,Sun,18800,angbutter,1
2019/11/24 13:44,Sun,20300,angbutter,1
2019/11/24 13:53,Sun,19300,angbutter,1
2019/11/24 14:27,Sun,14100,angbutter,2
2019/11/24 14:59,Sun,18800,angbutter,1
2019/11/24 16:32,Sun,19500,angbutter,1
2019/11/25 11:05,Mon,19800,angbutter,1
2019/11/25 11:08,Mon,18800,angbutter,1
2019/11/25 11:31,Mon,54100,angbutter,1
2019/11/25 12:54,Mon,26300,angbutter,1
2019/11/25 13:42,Mon,15800,angbutter,1
2019/11/25 14:00,Mon,14800,angbutter,1
2019/11/27 12:02,Wed,33400,angbutter,3
2019/11/27 12:35,Wed,15300,angbutter,1
2019/11/27 12:59,Wed,15800,angbutter,1
2019/11/27 13:07,Wed,14800,angbutter,2
2019/11/27 13:34,Wed,17300,angbutter,1
2019/11/27 14:00,Wed,14100,angbutter,1
2019/11/28 11:48,Thur,38600,angbutter,2
2019/11/28 12:53,Thur,15300,angbutter,1
2019/11/28 13:15,Thur,25300,angbutter,1
2019/11/28 14:15,Thur,18300,angbutter,1
2019/11/28 14:28,Thur,15100,angbutter,2
2019/11/28 14:48,Thur,40000,angbutter,5
2019/11/28 15:09,Thur,19300,angbutter,1
2019/11/29 11:05,Fri,15800,angbutter,1
2019/11/29 12:03,Fri,16300,angbutter,1
2019/11/29 12:50,Fri,15800,angbutter,1
2019/11/29 13:23,Fri,19300,angbutter,1
2019/11/29 13:31,Fri,25000,angbutter,1
2019/11/29 13:39,Fri,17300,angbutter,1
2019/11/29 14:42,Fri,15300,angbutter,1
2019/11/29 15:05,Fri,14300,angbutter,1
2019/11/29 15:30,Fri,14800,angbutter,1
2019/11/29 16:12,Fri,28100,angbutter,2
2019/11/30 11:01,Sat,22100,angbutter,2
2019/11/30 11:09,Sat,20400,angbutter,3
2019/11/30 11:10,Sat,22800,angbutter,1
2019/11/30 11:43,Sat,15800,angbutter,1
2019/11/30 11:56,Sat,31400,angbutter,3
2019/11/30 13:01,Sat,38200,angbutter,4
2019/11/30 13:44,Sat,25100,angbutter,2
2019/11/30 13:49,Sat,20300,angbutter,1
2019/11/30 14:24,Sat,15800,angbutter,1
2019/11/30 17:04,Sat,27600,angbutter,2
2019/12/1 11:03,Sun,22100,angbutter,2
2019/12/1 11:29,Sun,14800,angbutter,1
2019/12/1 11:40,Sun,15300,angbutter,1
2019/12/1 11:48,Sun,15300,angbutter,1
2019/12/1 11:54,Sun,15300,angbutter,1
2019/12/1 12:11,Sun,23100,angbutter,2
2019/12/1 12:23,Sun,23100,angbutter,2
2019/12/1 13:15,Sun,15800,angbutter,1
2019/12/1 13:28,Sun,20300,angbutter,1
2019/12/1 14:24,Sun,31100,angbutter,2
2019/12/1 14:29,Sun,20800,angbutter,1
2019/12/1 16:18,Sun,18600,angbutter,2
2019/12/1 16:51,Sun,18300,angbutter,1
2019/12/2 13:03,Mon,16100,angbutter,2
2019/12/2 13:06,Mon,20600,angbutter,1
2019/12/2 13:38,Mon,14800,angbutter,1
2019/12/2 14:42,Mon,22800,angbutter,1
2019/12/2 16:22,Mon,14300,angbutter,1
2019/12/4 11:06,Wed,20300,angbutter,1
2019/12/4 11:10,Wed,23300,angbutter,1
2019/12/4 11:13,Wed,16600,angbutter,2
2019/12/4 11:18,Wed,35000,angbutter,6
2019/12/4 13:26,Wed,14800,angbutter,1
2019/12/4 13:30,Wed,19600,angbutter,2
2019/12/4 13:33,Wed,16100,angbutter,2
2019/12/4 13:51,Wed,15300,angbutter,1
2019/12/5 11:05,Thur,57700,angbutter,4
2019/12/5 11:08,Thur,15300,angbutter,1
2019/12/5 12:39,Thur,21800,angbutter,1
2019/12/5 13:00,Thur,25000,angbutter,4
2019/12/5 13:56,Thur,14800,angbutter,1
2019/12/5 14:48,Thur,36000,angbutter,5
2019/12/5 15:22,Thur,15800,angbutter,1
2019/12/6 11:08,Fri,22100,angbutter,2
2019/12/6 11:23,Fri,14800,angbutter,1
2019/12/6 11:38,Fri,13800,angbutter,1
2019/12/6 11:49,Fri,14800,angbutter,1
2019/12/6 12:17,Fri,20100,angbutter,2
2019/12/6 12:26,Fri,16300,angbutter,1
2019/12/6 12:43,Fri,27500,angbutter,5
2019/12/6 12:51,Fri,16300,angbutter,1
2019/12/7 12:02,Sat,14800,angbutter,1
2019/12/7 12:28,Sat,16100,angbutter,2
2019/12/7 13:36,Sat,14800,angbutter,1
2019/12/7 13:39,Sat,30800,angbutter,1
2019/12/7 13:55,Sat,28600,angbutter,3
2019/12/7 14:34,Sat,19900,angbutter,2
2019/12/7 14:35,Sat,15100,angbutter,2
2019/12/8 11:02,Sun,17300,angbutter,1
2019/12/8 11:11,Sun,27600,angbutter,2
2019/12/8 12:11,Sun,15300,angbutter,1
2019/12/8 12:22,Sun,15300,angbutter,1
2019/12/8 12:33,Sun,23000,angbutter,1
2019/12/8 12:41,Sun,22600,angbutter,2
2019/12/8 12:49,Sun,30600,angbutter,2
2019/12/8 12:52,Sun,20300,angbutter,1
2019/12/8 13:02,Sun,25400,angbutter,3
2019/12/8 13:12,Sun,15800,angbutter,1
2019/12/8 13:22,Sun,15800,angbutter,1
2019/12/8 13:44,Sun,28100,angbutter,2
2019/12/8 13:57,Sun,18300,angbutter,2
2019/12/8 14:06,Sun,16100,angbutter,2
2019/12/8 14:08,Sun,19800,angbutter,1
2019/12/8 14:57,Sun,25100,angbutter,2
2019/12/8 11:03,Sun,17100,angbutter,2
2019/12/9 11:31,Mon,14800,angbutter,1
2019/12/9 12:09,Mon,33100,angbutter,2
2019/12/9 13:22,Mon,15300,angbutter,1
2019/12/9 13:35,Mon,29800,angbutter,1
2019/12/9 13:54,Mon,15800,angbutter,1
2019/12/9 14:19,Mon,16600,angbutter,2
2019/12/9 17:01,Mon,17100,angbutter,2
2019/12/11 11:26,Wed,15300,angbutter,1
2019/12/11 11:36,Wed,15000,angbutter,1
2019/12/11 11:37,Wed,18800,angbutter,1
2019/12/11 12:02,Wed,14000,angbutter,1
2019/12/11 14:08,Wed,17300,angbutter,1
2019/12/11 15:07,Wed,14300,angbutter,1
2019/12/12 11:15,Thur,29200,angbutter,4
2019/12/12 11:27,Thur,14800,angbutter,1
2019/12/12 11:48,Thur,22300,angbutter,1
2019/12/12 12:50,Thur,20600,angbutter,2
2019/12/12 12:57,Thur,23300,angbutter,1
2019/12/12 13:41,Thur,17400,angbutter,3
2019/12/12 14:09,Thur,16300,angbutter,1
2019/12/12 14:34,Thur,16300,angbutter,1
2019/12/13 11:27,Fri,21100,angbutter,2
2019/12/13 11:45,Fri,16400,angbutter,3
2019/12/13 12:40,Fri,22800,angbutter,1
2019/12/13 14:21,Fri,14800,angbutter,1
2019/12/13 15:53,Fri,16800,angbutter,1
2019/12/14 11:51,Sat,40500,angbutter,5
2019/12/14 11:59,Sat,17300,angbutter,1
2019/12/14 12:19,Sat,23800,angbutter,1
2019/12/14 12:41,Sat,18300,angbutter,1
2019/12/14 12:51,Sat,19300,angbutter,1
2019/12/14 13:14,Sat,15800,angbutter,1
2019/12/14 14:15,Sat,16800,angbutter,1
2019/12/15 12:14,Sun,19300,angbutter,1
2019/12/15 12:14,Sun,26000,angbutter,5
2019/12/15 13:43,Sun,14000,angbutter,1
2019/12/15 14:06,Sun,45400,angbutter,3
2019/12/15 14:46,Sun,21800,angbutter,2
2019/12/15 15:16,Sun,15300,angbutter,1
2019/12/15 15:53,Sun,17100,angbutter,2
2019/12/16 11:12,Mon,15300,angbutter,1
2019/12/16 11:41,Mon,18900,angbutter,3
2019/12/16 12:07,Mon,14100,angbutter,1
2019/12/16 12:58,Mon,14800,angbutter,1
2019/12/16 13:21,Mon,16800,angbutter,1
2019/12/16 14:26,Mon,20300,angbutter,1
2019/12/16 14:31,Mon,23600,angbutter,3
2019/12/18 11:22,Wed,52800,angbutter,5
2019/12/18 12:39,Wed,14000,angbutter,1
2019/12/18 12:45,Wed,19600,angbutter,2
2019/12/18 13:28,Wed,14100,angbutter,2
2019/12/18 13:51,Wed,19600,angbutter,2
2019/12/18 15:05,Wed,19100,angbutter,2
2019/12/18 15:23,Wed,51200,angbutter,2
2019/12/19 11:29,Thur,24800,angbutter,1
2019/12/19 11:45,Thur,35300,angbutter,1
2019/12/19 12:16,Thur,14300,angbutter,1
2019/12/19 12:17,Thur,15800,angbutter,1
2019/12/19 13:02,Thur,15600,angbutter,2
2019/12/19 13:04,Thur,16400,angbutter,3
2019/12/19 13:53,Thur,16600,angbutter,2
2019/12/20 11:18,Fri,16800,angbutter,1
2019/12/20 11:53,Fri,16300,angbutter,1
2019/12/20 13:29,Fri,21600,angbutter,2
2019/12/20 14:29,Fri,19300,angbutter,1
2019/12/20 15:37,Fri,16800,angbutter,1
2019/12/20 16:43,Fri,31100,angbutter,2
2019/12/21 11:04,Sat,15100,angbutter,1
2019/12/21 11:52,Sat,14800,angbutter,1
2019/12/21 12:02,Sat,19800,angbutter,1
2019/12/21 12:17,Sat,15300,angbutter,1
2019/12/21 12:24,Sat,25300,angbutter,1
2019/12/21 14:18,Sat,15800,angbutter,1
2019/12/21 14:43,Sat,30900,angbutter,2
2019/12/22 11:05,Sun,14800,angbutter,1
2019/12/22 11:33,Sun,46000,angbutter,2
2019/12/22 11:38,Sun,19300,angbutter,1
2019/12/22 12:21,Sun,19300,angbutter,1
2019/12/22 13:54,Sun,15300,angbutter,1
2019/12/22 14:17,Sun,20300,angbutter,1
2019/12/22 14:35,Sun,19300,angbutter,1
2019/12/22 15:53,Sun,19600,angbutter,2
2019/12/23 11:31,Mon,26100,angbutter,2
2019/12/23 12:06,Mon,23800,angbutter,1
2019/12/23 13:05,Mon,25600,angbutter,2
2019/12/23 13:37,Mon,27300,angbutter,1
2019/12/23 13:57,Mon,30300,angbutter,1
2019/12/23 15:03,Mon,14000,angbutter,1
2019/12/24 11:13,Tues,15300,angbutter,1
2019/12/24 11:17,Tues,21400,angbutter,3
2019/12/25 11:29,Wed,24100,angbutter,2
2019/12/25 11:55,Wed,15300,angbutter,1
2019/12/25 12:16,Wed,14800,angbutter,1
2019/12/25 15:00,Wed,18300,angbutter,1
2019/12/26 12:18,Thur,26600,angbutter,2
2019/12/26 14:06,Thur,15600,angbutter,2
2019/12/27 11:39,Fri,16300,angbutter,1
2019/12/27 12:45,Fri,15800,angbutter,1
2019/12/28 11:10,Sat,16100,angbutter,2
2019/12/28 11:48,Sat,14800,angbutter,1
2019/12/28 12:09,Sat,22300,angbutter,1
2019/12/28 12:35,Sat,20900,angbutter,3
2019/12/28 13:09,Sat,35600,angbutter,7
2019/12/28 13:12,Sat,18800,angbutter,1
2019/12/28 13:47,Sat,18800,angbutter,1
2019/12/28 14:58,Sat,24300,angbutter,1
2019/12/28 15:52,Sat,19300,angbutter,1
2019/12/28 16:18,Sat,58900,angbutter,3
2019/12/28 16:38,Sat,21100,angbutter,2
2019/12/29 11:16,Sun,14000,angbutter,1
2019/12/29 11:34,Sun,15300,angbutter,1
2019/12/29 12:11,Sun,15300,angbutter,1
2019/12/29 12:24,Sun,23900,angbutter,4
2019/12/29 12:39,Sun,14800,angbutter,1
2019/12/29 12:52,Sun,23800,angbutter,2
2019/12/29 13:34,Sun,14800,angbutter,1
2019/12/29 13:43,Sun,15800,angbutter,1
2019/12/29 14:26,Sun,14800,angbutter,1
2019/12/29 14:42,Sun,22800,angbutter,1
2019/12/30 11:27,Mon,19800,angbutter,1
2019/12/30 11:44,Mon,15300,angbutter,1
2019/12/30 12:23,Mon,91300,angbutter,6
2019/12/30 14:35,Mon,53900,angbutter,3
2019/12/30 15:12,Mon,16100,angbutter,2
2019/12/30 15:22,Mon,26100,angbutter,2
2019/12/30 15:44,Mon,15800,angbutter,1
2020/1/2 11:23,Thur,20300,angbutter,1
2020/1/2 11:33,Thur,42900,angbutter,3
2020/1/2 12:27,Thur,14300,angbutter,2
2020/1/2 12:33,Thur,14800,angbutter,1
2020/1/2 12:50,Thur,29300,angbutter,1
2020/1/2 14:06,Thur,17600,angbutter,2
2020/1/2 15:40,Thur,46900,angbutter,8
2020/1/3 11:03,Fri,21600,angbutter,2
2020/1/3 11:17,Fri,20300,angbutter,1
2020/1/3 11:59,Fri,16300,angbutter,1
2020/1/3 13:44,Fri,17300,angbutter,1
2020/1/3 14:17,Fri,43100,angbutter,2
2020/1/3 15:41,Fri,16100,angbutter,2
2020/1/3 16:25,Fri,15100,angbutter,1
2020/1/3 17:23,Fri,20600,angbutter,2
2020/1/4 11:03,Sat,23800,angbutter,1
2020/1/4 11:10,Sat,14800,angbutter,1
2020/1/4 12:51,Sat,24800,angbutter,2
2020/1/4 14:36,Sat,15300,angbutter,1
2020/1/4 14:52,Sat,17400,angbutter,3
2020/1/4 16:02,Sat,15100,angbutter,1
2020/1/5 11:03,Sun,16800,angbutter,1
2020/1/5 11:10,Sun,18600,angbutter,2
2020/1/5 11:13,Sun,26700,angbutter,4
2020/1/5 11:19,Sun,14300,angbutter,1
2020/1/5 12:15,Sun,16400,angbutter,3
2020/1/5 12:37,Sun,14300,angbutter,1
2020/1/5 13:49,Sun,20300,angbutter,1
2020/1/5 14:06,Sun,23800,angbutter,1
2020/1/5 14:46,Sun,18300,angbutter,1
2020/1/5 14:54,Sun,14300,angbutter,1
2020/1/5 15:06,Sun,24400,angbutter,1
2020/1/5 16:54,Sun,15300,angbutter,1
2020/1/5 17:25,Sun,19600,angbutter,2
2020/1/6 12:25,Mon,14800,angbutter,1
2020/1/6 12:30,Mon,30800,angbutter,1
2020/1/6 12:43,Mon,18300,angbutter,1
2020/1/6 16:00,Mon,14300,angbutter,1
2020/1/8 11:15,Wed,18100,angbutter,3
2020/1/8 11:26,Wed,26000,angbutter,5
2020/1/8 12:42,Wed,22600,angbutter,2
2020/1/8 12:47,Wed,30300,angbutter,1
2020/1/8 13:08,Wed,21200,angbutter,4
2020/1/8 13:15,Wed,41400,angbutter,3
2020/1/8 13:31,Wed,18300,angbutter,1
2020/1/8 15:19,Wed,27200,angbutter,4
2020/1/8 15:42,Wed,19800,angbutter,2
2020/1/8 16:33,Wed,26900,angbutter,3
2020/1/9 11:12,Thur,35700,angbutter,4
2020/1/9 11:39,Thur,28300,angbutter,2
2020/1/9 12:09,Thur,17000,angbutter,2
2020/1/9 12:27,Thur,28800,angbutter,1
2020/1/9 12:34,Thur,18300,angbutter,1
2020/1/9 13:44,Thur,21900,angbutter,2
2020/1/9 13:59,Thur,19800,angbutter,1
2020/1/9 15:22,Thur,23300,angbutter,1
2020/1/9 15:42,Thur,19600,angbutter,2
2020/1/9 15:59,Thur,17600,angbutter,2
2020/1/9 16:00,Thur,14800,angbutter,1
2020/1/9 17:00,Thur,14800,angbutter,1
2020/1/10 11:07,Fri,16300,angbutter,1
2020/1/10 12:51,Fri,21800,angbutter,1
2020/1/10 12:57,Fri,19600,angbutter,2
2020/1/10 13:42,Fri,20100,angbutter,2
2020/1/10 13:51,Fri,15800,angbutter,1
2020/1/10 14:11,Fri,14300,angbutter,1
2020/1/10 14:48,Fri,19300,angbutter,1
2020/1/10 15:10,Fri,19300,angbutter,1
2020/1/11 13:03,Sat,20600,angbutter,2
2020/1/11 13:11,Sat,15100,angbutter,1
2020/1/11 13:16,Sat,19600,angbutter,2
2020/1/11 14:09,Sat,14800,angbutter,2
2020/1/11 14:19,Sat,18300,angbutter,1
2020/1/11 15:10,Sat,15800,angbutter,1
2020/1/11 15:42,Sat,15800,angbutter,1
2020/1/12 11:03,Sun,17300,angbutter,2
2020/1/12 11:03,Sun,21800,angbutter,1
2020/1/12 12:19,Sun,45400,angbutter,8
2020/1/12 13:23,Sun,18300,angbutter,1
2020/1/12 14:11,Sun,14800,angbutter,1
2020/1/12 14:19,Sun,24400,angbutter,3
2020/1/12 16:23,Sun,19600,angbutter,2
2020/1/12 17:05,Sun,21300,angbutter,1
2020/1/13 11:52,Mon,20300,angbutter,1
2020/1/13 11:59,Mon,15300,angbutter,1
2020/1/13 13:49,Mon,19300,angbutter,1
2020/1/13 15:44,Mon,15100,angbutter,2
2020/1/13 15:52,Mon,14800,angbutter,1
2020/1/15 11:04,Wed,20300,angbutter,1
2020/1/15 11:08,Wed,17300,angbutter,1
2020/1/15 11:28,Wed,116500,angbutter,10
2020/1/15 13:01,Wed,18300,angbutter,1
2020/1/15 13:22,Wed,26300,angbutter,1
2020/1/15 14:46,Wed,18800,angbutter,1
2020/1/16 11:28,Thur,18800,angbutter,1
2020/1/16 14:09,Thur,14800,angbutter,1
2020/1/17 11:46,Fri,14800,angbutter,1
2020/1/17 12:13,Fri,26600,angbutter,2
2020/1/17 12:26,Fri,16300,angbutter,1
2020/1/17 13:30,Fri,16300,angbutter,1
2020/1/17 14:15,Fri,17800,angbutter,1
2020/1/17 14:17,Fri,15300,angbutter,1
2020/1/18 11:16,Sat,18300,angbutter,1
2020/1/18 12:31,Sat,25800,angbutter,1
2020/1/18 14:11,Sat,34700,angbutter,4
2020/1/18 14:52,Sat,14300,angbutter,1
2020/1/18 15:27,Sat,23600,angbutter,2
2020/1/19 11:05,Sun,19300,angbutter,1
2020/1/19 11:09,Sun,14800,angbutter,1
2020/1/19 11:09,Sun,31100,angbutter,1
2020/1/19 11:18,Sun,20600,angbutter,2
2020/1/19 12:40,Sun,16300,angbutter,1
2020/1/19 12:52,Sun,32100,angbutter,2
2020/1/19 13:22,Sun,21100,angbutter,2
2020/1/19 14:18,Sun,23900,angbutter,2
2020/1/19 14:23,Sun,15100,angbutter,1
2020/1/19 15:53,Sun,19100,angbutter,3
2020/1/19 15:54,Sun,27400,angbutter,3
2020/1/19 16:21,Sun,19800,angbutter,1
2020/1/19 16:52,Sun,17800,angbutter,1
2020/1/20 11:25,Mon,23800,angbutter,1
2020/1/20 12:46,Mon,14800,angbutter,1
2020/1/20 13:59,Mon,19300,angbutter,1
2020/1/22 11:09,Wed,16100,angbutter,2
2020/1/22 11:50,Wed,18100,angbutter,1
2020/1/22 12:04,Wed,20300,angbutter,1
2020/1/22 13:44,Wed,18300,angbutter,1
2020/1/22 16:08,Wed,14800,angbutter,1
2020/1/22 16:14,Wed,15600,angbutter,1
2020/1/23 11:08,Thur,77100,angbutter,7
2020/1/23 11:17,Thur,58700,angbutter,9
2020/1/23 11:37,Thur,14100,angbutter,1
2020/1/23 11:45,Thur,18800,angbutter,1
2020/1/23 12:07,Thur,17800,angbutter,2
2020/1/23 14:04,Thur,18600,angbutter,2
2020/1/23 14:57,Thur,26000,angbutter,5
2020/1/23 15:26,Thur,27500,angbutter,1
2020/1/23 15:53,Thur,14800,angbutter,1
2020/1/24 11:37,Fri,23800,angbutter,1
2020/1/24 11:40,Fri,14800,angbutter,1
2020/1/24 11:50,Fri,15300,angbutter,1
2020/1/26 11:07,Sun,14800,angbutter,1
2020/1/26 12:30,Sun,14800,angbutter,1
2020/1/26 12:36,Sun,28100,angbutter,2
2020/1/26 12:50,Sun,34900,angbutter,3
2020/1/26 15:53,Sun,16800,angbutter,1
2020/1/27 11:02,Mon,21600,angbutter,1
2020/1/27 12:17,Mon,27600,angbutter,2
2020/1/27 12:32,Mon,21800,angbutter,1
2020/1/27 12:57,Mon,20300,angbutter,1
2020/1/27 13:29,Mon,20100,angbutter,2
2020/1/27 13:31,Mon,20600,angbutter,2
2020/1/29 11:09,Wed,15300,angbutter,1
2020/1/29 12:23,Wed,15100,angbutter,2
2020/1/29 14:07,Wed,15800,angbutter,1
2020/1/29 15:31,Wed,25900,angbutter,3
2020/1/30 11:43,Thur,23300,angbutter,2
2020/1/30 11:53,Thur,28800,angbutter,1
2020/1/30 11:54,Thur,42900,angbutter,3
2020/1/30 12:15,Thur,34300,angbutter,1
2020/1/30 12:26,Thur,26600,angbutter,2
2020/1/30 13:20,Thur,29600,angbutter,2
2020/1/30 14:26,Thur,23300,angbutter,2
2020/1/30 15:15,Thur,21100,angbutter,2
2020/1/31 11:11,Fri,16800,angbutter,1
2020/1/31 11:17,Fri,15300,angbutter,1
2020/1/31 11:21,Fri,19800,angbutter,1
2020/1/31 12:06,Fri,14800,angbutter,1
2020/1/31 12:36,Fri,29900,angbutter,3
2020/1/31 13:09,Fri,20300,angbutter,1
2020/1/31 14:15,Fri,16800,angbutter,1
2020/2/1 11:05,Sat,15100,angbutter,2
2020/2/1 12:56,Sat,17300,angbutter,1
2020/2/1 13:18,Sat,15300,angbutter,1
2020/2/1 13:42,Sat,19300,angbutter,1
2020/2/1 13:50,Sat,23600,angbutter,1
2020/2/1 14:06,Sat,15800,angbutter,1
2020/2/1 14:10,Sat,15300,angbutter,1
2020/2/1 15:40,Sat,32400,angbutter,3
2020/2/1 15:49,Sat,19600,angbutter,2
2020/2/2 11:05,Sun,19300,angbutter,1
2020/2/2 11:32,Sun,22300,angbutter,1
2020/2/2 11:34,Sun,15800,angbutter,1
2020/2/2 11:49,Sun,30800,angbutter,1
2020/2/2 12:06,Sun,21400,angbutter,3
2020/2/2 12:17,Sun,16800,angbutter,1
2020/2/2 12:21,Sun,18300,angbutter,1
2020/2/2 12:24,Sun,15300,angbutter,1
2020/2/2 12:42,Sun,17300,angbutter,1
2020/2/2 13:10,Sun,17800,angbutter,1
2020/2/2 13:33,Sun,19300,angbutter,1
2020/2/2 14:16,Sun,15100,angbutter,2
2020/2/2 14:58,Sun,16100,angbutter,2
2020/2/2 15:37,Sun,15800,angbutter,1
2020/2/2 16:13,Sun,16100,angbutter,2
2020/2/2 17:29,Sun,19600,angbutter,1
2020/2/3 12:52,Mon,45500,angbutter,8
2020/2/3 15:30,Mon,16100,angbutter,2
2020/2/3 14:26,Mon,16300,angbutter,1
2020/2/3 16:42,Mon,15800,angbutter,1
2020/2/5 11:08,Wed,20600,angbutter,2
2020/2/5 11:23,Wed,19800,angbutter,1
2020/2/5 11:48,Wed,34100,angbutter,2
2020/2/5 11:56,Wed,27600,angbutter,1
2020/2/5 12:07,Wed,21600,angbutter,2
2020/2/5 13:12,Wed,21300,angbutter,1
2020/2/5 13:48,Wed,14300,angbutter,1
2020/2/5 14:08,Wed,50000,angbutter,10
2020/2/5 15:58,Wed,17300,angbutter,1
2020/2/6 11:13,Thur,15800,angbutter,1
2020/2/6 11:15,Thur,15100,angbutter,2
2020/2/6 11:16,Thur,20900,angbutter,3
2020/2/6 11:34,Thur,18600,angbutter,2
2020/2/6 12:29,Thur,15600,angbutter,2
2020/2/6 12:36,Thur,14800,angbutter,1
2020/2/6 13:13,Thur,21300,angbutter,1
2020/2/6 13:31,Thur,18800,angbutter,1
2020/2/6 14:58,Thur,20300,angbutter,1
2020/2/6 15:55,Thur,15300,angbutter,1
2020/2/7 11:14,Fri,16300,angbutter,1
2020/2/7 11:51,Fri,17800,angbutter,1
2020/2/7 12:39,Fri,33300,angbutter,1
2020/2/7 12:48,Fri,15800,angbutter,1
2020/2/7 12:56,Fri,17900,angbutter,1
2020/2/7 13:41,Fri,18300,angbutter,1
2020/2/7 14:51,Fri,14800,angbutter,1
2020/2/7 15:14,Fri,19300,angbutter,1
2020/2/7 15:34,Fri,21800,angbutter,1
2020/2/7 15:40,Fri,26300,angbutter,1
2020/2/7 16:41,Fri,21800,angbutter,1
2020/2/7 17:28,Fri,16100,angbutter,2
2020/2/8 11:31,Sat,23600,angbutter,2
2020/2/8 11:57,Sat,14800,angbutter,1
2020/2/8 12:24,Sat,22800,angbutter,1
2020/2/8 12:38,Sat,21200,angbutter,4
2020/2/8 12:54,Sat,14800,angbutter,1
2020/2/8 13:01,Sat,24300,angbutter,1
2020/2/8 13:14,Sat,25600,angbutter,2
2020/2/8 13:27,Sat,25800,angbutter,1
2020/2/8 14:42,Sat,19800,angbutter,1
2020/2/8 15:22,Sat,22800,angbutter,1
2020/2/8 15:24,Sat,20800,angbutter,1
2020/2/9 11:03,Sun,19300,angbutter,1
2020/2/9 11:09,Sun,18300,angbutter,1
2020/2/9 11:52,Sun,34300,angbutter,1
2020/2/9 12:16,Sun,20800,angbutter,1
2020/2/9 12:17,Sun,21200,angbutter,4
2020/2/9 12:23,Sun,17300,angbutter,1
2020/2/9 12:33,Sun,19800,angbutter,1
2020/2/9 12:36,Sun,15800,angbutter,1
2020/2/9 12:54,Sun,22300,angbutter,1
2020/2/9 13:47,Sun,16300,angbutter,1
2020/2/9 13:54,Sun,18300,angbutter,1
2020/2/9 15:15,Sun,18500,angbutter,1
2020/2/9 15:48,Sun,24400,angbutter,3
2020/2/9 16:07,Sun,16300,angbutter,1
2020/2/9 16:32,Sun,14800,angbutter,1
2020/2/10 11:31,Mon,15300,angbutter,1
2020/2/10 11:41,Mon,19300,angbutter,1
2020/2/12 11:04,Wed,37600,angbutter,2
2020/2/12 11:12,Wed,16300,angbutter,1
2020/2/12 11:19,Wed,21200,angbutter,4
2020/2/12 11:41,Wed,19600,angbutter,4
2020/2/12 12:10,Wed,19300,angbutter,1
2020/2/12 12:48,Wed,53600,angbutter,2
2020/2/12 14:09,Wed,31600,angbutter,2
2020/2/12 14:35,Wed,55200,angbutter,4
2020/2/12 15:12,Wed,24500,angbutter,1
2020/2/13 11:35,Thur,14300,angbutter,1
2020/2/13 12:23,Thur,14800,angbutter,1
2020/2/13 12:28,Thur,18300,angbutter,1
2020/2/13 14:10,Thur,16100,angbutter,2
2020/2/13 15:22,Thur,31300,angbutter,1
2020/2/14 12:44,Fri,27300,angbutter,1
2020/2/14 13:06,Fri,16300,angbutter,1
2020/2/14 13:12,Fri,20300,angbutter,1
2020/2/14 13:46,Fri,57500,angbutter,5
2020/2/14 14:16,Fri,16100,angbutter,2
2020/2/14 14:18,Fri,67000,angbutter,5
2020/2/14 15:27,Fri,15100,angbutter,2
2020/2/15 11:07,Sat,25000,angbutter,1
2020/2/15 13:04,Sat,19300,angbutter,1
2020/2/15 13:38,Sat,17300,angbutter,1
2020/2/15 14:03,Sat,32100,angbutter,2
2020/2/15 14:13,Sat,16100,angbutter,2
2020/2/15 17:19,Sat,19600,angbutter,2
2020/2/16 11:17,Sun,27100,angbutter,2
2020/2/16 11:30,Sun,19800,angbutter,1
2020/2/16 11:57,Sun,26600,angbutter,2
2020/2/16 12:03,Sun,14300,angbutter,1
2020/2/16 12:06,Sun,22100,angbutter,2
2020/2/16 12:07,Sun,41800,angbutter,1
2020/2/16 12:41,Sun,14800,angbutter,1
2020/2/16 12:43,Sun,18300,angbutter,1
2020/2/16 13:51,Sun,25300,angbutter,1
2020/2/16 14:06,Sun,15600,angbutter,2
2020/2/16 14:46,Sun,16100,angbutter,2
2020/2/16 15:17,Sun,16400,angbutter,3
2020/2/17 12:24,Mon,15800,angbutter,1
2020/2/17 13:03,Mon,20100,angbutter,2
2020/2/17 13:05,Mon,20300,angbutter,1
2020/2/17 13:33,Mon,23300,angbutter,1
2020/2/17 13:48,Mon,16800,angbutter,2
2020/2/17 14:29,Mon,20300,angbutter,1
2020/2/17 15:25,Mon,36600,angbutter,1
2020/2/19 11:39,Wed,19600,angbutter,2
2020/2/19 11:49,Wed,18600,angbutter,2
2020/2/19 12:12,Wed,24600,angbutter,2
2020/2/19 13:03,Wed,17100,angbutter,2
2020/2/19 22:13,Wed,15800,angbutter,1
2020/2/19 14:40,Wed,30800,angbutter,6
2020/2/20 11:05,Thur,23100,angbutter,2
2020/2/20 11:11,Thur,23800,angbutter,1
2020/2/20 11:11,Thur,26800,angbutter,1
2020/2/20 11:01,Thur,14800,angbutter,1
2020/2/20 11:23,Thur,27600,angbutter,2
2020/2/20 12:12,Thur,14800,angbutter,1
2020/2/20 12:51,Thur,15600,angbutter,2
2020/2/20 13:18,Thur,15800,angbutter,1
2020/2/20 13:50,Thur,42200,angbutter,5
2020/2/20 15:41,Thur,25400,angbutter,3
2020/2/21 11:14,Fri,15300,angbutter,1
2020/2/21 11:54,Fri,19800,angbutter,1
2020/2/21 13:28,Fri,14800,angbutter,1
2020/2/21 14:21,Fri,33500,angbutter,2
2020/2/21 14:41,Fri,15800,angbutter,1
2020/2/22 11:03,Sat,14300,angbutter,1
2020/2/22 11:09,Sat,28300,angbutter,1
2020/2/22 11:14,Sat,16300,angbutter,1
2020/2/22 11:35,Sat,18600,angbutter,2
2020/2/22 11:39,Sat,21200,angbutter,4
2020/2/22 12:14,Sat,19300,angbutter,1
2020/2/22 12:22,Sat,17100,angbutter,2
2020/2/22 12:25,Sat,16300,angbutter,1
2020/2/22 12:48,Sat,16100,angbutter,2
2020/2/22 14:02,Sat,23100,angbutter,2
2020/2/22 14:14,Sat,15400,angbutter,2
2020/2/22 14:22,Sat,15100,angbutter,2
2020/2/22 15:00,Sat,24100,angbutter,1
2020/2/22 17:20,Sat,15300,angbutter,1
2020/2/23 11:04,Sun,35300,angbutter,2
2020/2/23 11:07,Sun,41300,angbutter,1
2020/2/23 11:10,Sun,26600,angbutter,1
2020/2/23 11:13,Sun,27200,angbutter,2
2020/2/23 11:32,Sun,24100,angbutter,2
2020/2/23 12:09,Sun,20300,angbutter,1
2020/2/23 12:25,Sun,15300,angbutter,1
2020/2/23 12:27,Sun,23100,angbutter,1
2020/2/23 12:38,Sun,18800,angbutter,1
2020/2/23 12:39,Sun,19800,angbutter,1
2020/2/23 12:42,Sun,24300,angbutter,1
2020/2/23 13:06,Sun,20300,angbutter,1
2020/2/23 13:09,Sun,21800,angbutter,1
2020/2/23 14:05,Sun,22300,angbutter,1
2020/2/23 14:21,Sun,24400,angbutter,2
2020/2/23 15:07,Sun,15800,angbutter,1
2020/2/23 15:57,Sun,15600,angbutter,3
2020/2/23 16:00,Sun,26600,angbutter,3
2020/2/23 16:29,Sun,30100,angbutter,2
2020/2/23 16:42,Sun,17600,angbutter,1
2020/2/24 11:07,Mon,29900,angbutter,3
2020/2/24 12:09,Mon,17900,angbutter,2
2020/2/24 12:26,Mon,29900,angbutter,3
2020/2/24 12:52,Mon,26900,angbutter,3
2020/2/24 14:36,Mon,22600,angbutter,2
2020/2/24 15:02,Mon,16100,angbutter,2
2020/2/24 15:55,Mon,19300,angbutter,1
2020/2/26 11:07,Wed,15800,angbutter,1
2020/2/26 11:12,Wed,31600,angbutter,2
2020/2/26 11:18,Wed,15600,angbutter,1
2020/2/26 11:20,Wed,18300,angbutter,1
2020/2/26 11:55,Wed,15300,angbutter,1
2020/2/26 12:01,Wed,23300,angbutter,2
2020/2/26 13:03,Wed,17800,angbutter,1
2020/2/26 13:08,Wed,15300,angbutter,1
2020/2/26 13:28,Wed,15800,angbutter,1
2020/2/26 13:38,Wed,20800,angbutter,1
2020/2/26 14:29,Wed,23300,angbutter,1
2020/2/26 14:40,Wed,17100,angbutter,2
2020/2/26 15:49,Wed,21200,angbutter,4
2020/2/26 16:13,Wed,27900,angbutter,3
2020/2/27 11:15,Thur,23300,angbutter,1
2020/2/27 11:23,Thur,23800,angbutter,1
2020/2/27 11:24,Thur,15300,angbutter,1
2020/2/27 11:25,Thur,23100,angbutter,2
2020/2/27 11:26,Thur,20900,angbutter,2
2020/2/27 12:20,Thur,19800,angbutter,1
2020/2/27 15:45,Thur,15100,angbutter,2
2020/2/27 15:47,Thur,19600,angbutter,2
2020/2/28 11:02,Fri,33800,angbutter,1
2020/2/28 11:09,Fri,25100,angbutter,2
2020/2/28 11:09,Fri,23100,angbutter,2
2020/2/28 11:13,Fri,20100,angbutter,2
2020/2/28 11:54,Fri,14800,angbutter,1
2020/2/28 12:04,Fri,20300,angbutter,1
2020/2/28 12:28,Fri,51100,angbutter,2
2020/2/28 12:57,Fri,19600,angbutter,2
2020/2/28 13:36,Fri,16100,angbutter,2
2020/2/28 15:50,Fri,17800,angbutter,1
2020/2/28 16:33,Fri,15600,angbutter,1
2020/2/28 16:58,Fri,20600,angbutter,2
2020/2/29 11:03,Sat,20600,angbutter,2
2020/2/29 11:09,Sat,17300,angbutter,1
2020/2/29 11:14,Sat,16100,angbutter,2
2020/2/29 11:35,Sat,16300,angbutter,1
2020/2/29 12:44,Sat,23600,angbutter,2
2020/2/29 12:52,Sat,21300,angbutter,2
2020/2/29 12:54,Sat,21800,angbutter,1
2020/2/29 14:23,Sat,22800,angbutter,2
2020/2/29 14:25,Sat,15300,angbutter,1
2020/2/29 15:34,Sat,19300,angbutter,1
2020/2/29 16:31,Sat,23600,angbutter,1
2020/3/1 11:06,Sun,34100,angbutter,2
2020/3/1 11:06,Sun,29800,angbutter,1
2020/3/1 11:14,Sun,23800,angbutter,1
2020/3/1 11:18,Sun,21100,angbutter,2
2020/3/1 11:47,Sun,41800,angbutter,1
2020/3/1 12:13,Sun,14800,angbutter,1
2020/3/1 12:19,Sun,20800,angbutter,1
2020/3/1 12:45,Sun,22300,angbutter,1
2020/3/1 13:10,Sun,33400,angbutter,3
2020/3/1 13:23,Sun,16300,angbutter,1
2020/3/1 13:32,Sun,24800,angbutter,1
2020/3/1 14:17,Sun,20800,angbutter,1
2020/3/1 14:27,Sun,27300,angbutter,1
2020/3/1 15:16,Sun,20300,angbutter,1
2020/3/2 12:26,Mon,31400,angbutter,3
2020/3/2 12:28,Mon,14800,angbutter,1
2020/3/2 12:51,Mon,27800,angbutter,2
2020/3/2 13:00,Mon,15800,angbutter,1
2020/3/2 13:00,Mon,18300,angbutter,1
2020/3/2 13:32,Mon,33600,angbutter,2
2020/3/2 13:41,Mon,20300,angbutter,1
2020/3/2 14:00,Mon,15300,angbutter,1
2020/3/2 14:02,Mon,21600,angbutter,2
2020/3/2 16:40,Mon,16300,angbutter,1
2020/3/5 11:03,Thur,14800,angbutter,1
2020/3/5 11:36,Thur,37100,angbutter,3
2020/3/5 12:00,Thur,24300,angbutter,1
2020/3/5 12:11,Thur,17800,angbutter,1
2020/3/5 12:17,Thur,14800,angbutter,1
2020/3/5 13:33,Thur,17600,angbutter,2
2020/3/5 13:36,Thur,25700,angbutter,4
2020/3/5 13:40,Thur,16400,angbutter,3
2020/3/5 13:46,Thur,16300,angbutter,1
2020/3/5 13:48,Thur,27800,angbutter,1
2020/3/5 14:20,Thur,15600,angbutter,2
2020/3/5 14:26,Thur,14300,angbutter,1
2020/3/5 14:49,Thur,20800,angbutter,1
2020/3/5 14:50,Thur,17400,angbutter,3
2020/3/5 15:03,Thur,17300,angbutter,1
2020/3/5 15:26,Thur,15100,angbutter,2
2020/3/5 15:29,Thur,15300,angbutter,1
2020/3/5 15:56,Thur,20600,angbutter,2
2020/3/6 11:07,Fri,19800,angbutter,1
2020/3/6 11:53,Fri,17500,angbutter,1
2020/3/6 12:02,Fri,16800,angbutter,1
2020/3/6 12:21,Fri,16300,angbutter,1
2020/3/6 12:22,Fri,22800,angbutter,1
2020/3/6 12:22,Fri,14800,angbutter,1
2020/3/6 12:24,Fri,25600,angbutter,2
2020/3/6 12:27,Fri,18300,angbutter,1
2020/3/6 13:21,Fri,20600,angbutter,2
2020/3/6 13:24,Fri,21100,angbutter,2
2020/3/6 13:44,Fri,15800,angbutter,1
2020/3/6 14:00,Fri,15800,angbutter,1
2020/3/6 14:05,Fri,16300,angbutter,1
2020/3/6 14:34,Fri,18800,angbutter,1
2020/3/7 11:16,Sat,14800,angbutter,1
2020/3/7 11:29,Sat,20800,angbutter,1
2020/3/7 12:00,Sat,19300,angbutter,1
2020/3/7 12:02,Sat,17300,angbutter,1
2020/3/7 12:59,Sat,18300,angbutter,1
2020/3/7 12:59,Sat,14800,angbutter,1
2020/3/7 13:20,Sat,19600,angbutter,2
2020/3/7 13:53,Sat,28100,angbutter,1
2020/3/7 14:20,Sat,19800,angbutter,1
2020/3/7 14:54,Sat,15600,angbutter,3
2020/3/7 14:56,Sat,16800,angbutter,1
2020/3/8 11:09,Sun,14800,angbutter,1
2020/3/8 11:38,Sun,16800,angbutter,1
2020/3/8 12:03,Sun,29100,angbutter,2
2020/3/8 12:03,Sun,19600,angbutter,2
2020/3/8 12:28,Sun,32800,angbutter,1
2020/3/8 12:50,Sun,14300,angbutter,1
2020/3/8 12:52,Sun,21300,angbutter,1
2020/3/8 13:26,Sun,20300,angbutter,1
2020/3/8 13:44,Sun,19600,angbutter,1
2020/3/8 14:07,Sun,22300,angbutter,1
2020/3/8 15:18,Sun,25400,angbutter,3
2020/3/8 15:23,Sun,16100,angbutter,2
2020/3/8 15:35,Sun,18300,angbutter,1
2020/3/8 16:19,Sun,14800,angbutter,3
2020/3/9 11:23,Mon,21300,angbutter,1
2020/3/9 11:42,Mon,14800,angbutter,1
2020/3/9 12:16,Mon,20500,angbutter,1
2020/3/9 12:47,Mon,15600,angbutter,2
2020/3/9 13:20,Mon,18800,angbutter,1
2020/3/11 11:10,Wed,28600,angbutter,2
2020/3/11 11:24,Wed,24300,angbutter,1
2020/3/11 11:51,Wed,16000,angbutter,1
2020/3/11 11:57,Wed,27100,angbutter,2
2020/3/11 12:05,Wed,26100,angbutter,3
2020/3/11 13:03,Wed,16100,angbutter,2
2020/3/11 13:14,Wed,22100,angbutter,2
2020/3/11 13:17,Wed,25300,angbutter,1
2020/3/12 11:03,Thur,22800,angbutter,1
2020/3/12 11:20,Thur,34100,angbutter,2
2020/3/12 11:42,Thur,27800,angbutter,1
2020/3/12 11:45,Thur,17300,angbutter,1
2020/3/12 12:23,Thur,20800,angbutter,1
2020/3/12 13:34,Thur,25100,angbutter,2
2020/3/12 13:56,Thur,47000,angbutter,7
2020/3/12 14:32,Thur,16100,angbutter,1
2020/3/12 15:17,Thur,22800,angbutter,1
2020/3/13 11:46,Fri,23800,angbutter,1
2020/3/13 12:14,Fri,21600,angbutter,2
2020/3/13 12:25,Fri,14800,angbutter,1
2020/3/13 12:30,Fri,14800,angbutter,1
2020/3/13 12:37,Fri,25100,angbutter,2
2020/3/13 13:43,Fri,15300,angbutter,2
2020/3/13 13:48,Fri,15300,angbutter,1
2020/3/13 14:37,Fri,22800,angbutter,1
2020/3/13 15:49,Fri,15100,angbutter,1
2020/3/13 15:58,Fri,19600,angbutter,2
2020/3/13 16:25,Fri,17100,angbutter,2
2020/3/14 11:03,Sat,15100,angbutter,1
2020/3/14 11:11,Sat,28300,angbutter,1
2020/3/14 11:29,Sat,15300,angbutter,1
2020/3/14 11:45,Sat,18000,angbutter,1
2020/3/14 13:49,Sat,15800,angbutter,1
2020/3/14 13:52,Sat,21800,angbutter,1
2020/3/14 14:11,Sat,15300,angbutter,1
2020/3/14 14:36,Sat,16100,angbutter,2
2020/3/14 14:47,Sat,15800,angbutter,1
2020/3/15 11:13,Sun,19300,angbutter,1
2020/3/15 11:19,Sun,14300,angbutter,1
2020/3/15 11:40,Sun,18600,angbutter,1
2020/3/15 12:35,Sun,15600,angbutter,2
2020/3/15 13:44,Sun,14800,angbutter,1
2020/3/15 14:09,Sun,21800,angbutter,1
2020/3/15 14:15,Sun,19400,angbutter,1
2020/3/15 14:27,Sun,16400,angbutter,3
2020/3/16 11:11,Mon,19300,angbutter,1
2020/3/16 11:56,Mon,22600,angbutter,3
2020/3/16 11:59,Mon,26800,angbutter,2
2020/3/16 12:32,Mon,15300,angbutter,2
2020/3/16 12:46,Mon,26800,angbutter,1
2020/3/16 12:58,Mon,23100,angbutter,2
2020/3/16 13:19,Mon,15300,angbutter,1
2020/3/16 13:23,Mon,20800,angbutter,1
2020/3/16 13:29,Mon,14800,angbutter,1
2020/3/16 14:05,Mon,34900,angbutter,3
2020/3/16 16:13,Mon,26800,angbutter,1
2020/3/18 11:32,Wed,20100,angbutter,2
2020/3/18 12:10,Wed,15800,angbutter,1
2020/3/18 12:29,Wed,39100,angbutter,2
2020/3/18 12:40,Wed,42400,angbutter,3
2020/3/18 12:53,Wed,20600,angbutter,2
2020/3/18 13:06,Wed,17500,angbutter,1
2020/3/18 13:42,Wed,25700,angbutter,4
2020/3/18 14:06,Wed,27900,angbutter,3
2020/3/18 14:30,Wed,15400,angbutter,2
2020/3/18 14:31,Wed,16100,angbutter,2
2020/3/19 11:06,Thur,16300,angbutter,1
2020/3/19 11:16,Thur,28200,angbutter,2
2020/3/19 12:25,Thur,23100,angbutter,1
2020/3/19 12:28,Thur,16400,angbutter,3
2020/3/19 12:30,Thur,22800,angbutter,1
2020/3/19 14:38,Thur,17600,angbutter,1
2020/3/19 14:47,Thur,15100,angbutter,1
2020/3/20 11:29,Fri,25800,angbutter,1
2020/3/20 12:17,Fri,28800,angbutter,1
2020/3/20 12:33,Fri,16100,angbutter,2
2020/3/20 13:48,Fri,19300,angbutter,1
2020/3/20 14:19,Fri,14800,angbutter,1
2020/3/20 15:40,Fri,14000,angbutter,1
2020/3/21 11:04,Sat,27800,angbutter,1
2020/3/21 11:04,Sat,16100,angbutter,2
2020/3/21 11:28,Sat,31600,angbutter,2
2020/3/21 11:44,Sat,27600,angbutter,2
2020/3/21 12:02,Sat,37700,angbutter,5
2020/3/21 12:07,Sat,14300,angbutter,1
2020/3/21 12:11,Sat,20900,angbutter,2
2020/3/21 12:34,Sat,14800,angbutter,1
2020/3/21 12:51,Sat,18300,angbutter,1
2020/3/21 13:32,Sat,19300,angbutter,1
2020/3/21 13:41,Sat,17800,angbutter,2
2020/3/21 14:17,Sat,33100,angbutter,2
2020/3/21 14:28,Sat,15800,angbutter,1
2020/3/21 15:02,Sat,16400,angbutter,3
2020/3/21 15:14,Sat,19600,angbutter,1
2020/3/22 11:22,Sun,14800,angbutter,1
2020/3/22 11:34,Sun,15100,angbutter,2
2020/3/22 11:43,Sun,32900,angbutter,3
2020/3/22 12:19,Sun,16600,angbutter,2
2020/3/22 12:38,Sun,31500,angbutter,5
2020/3/22 12:43,Sun,15100,angbutter,2
2020/3/22 13:19,Sun,21800,angbutter,1
2020/3/22 13:21,Sun,20900,angbutter,3
2020/3/22 13:52,Sun,15600,angbutter,2
2020/3/22 14:51,Sun,16100,angbutter,2
2020/3/22 15:21,Sun,19300,angbutter,1
2020/3/23 12:37,Mon,34100,angbutter,2
2020/3/23 13:12,Mon,18600,angbutter,2
2020/3/23 13:57,Mon,17800,angbutter,2
2020/3/23 13:58,Mon,24200,angbutter,3
2020/3/23 14:32,Mon,40700,angbutter,4
2020/3/23 14:49,Mon,18300,angbutter,1
2020/3/25 11:05,Wed,19300,angbutter,1
2020/3/25 11:13,Wed,15800,angbutter,1
2020/3/25 12:42,Wed,18800,angbutter,1
2020/3/25 14:12,Wed,22300,angbutter,1
2020/3/25 14:17,Wed,21300,angbutter,1
2020/3/25 15:54,Wed,16400,angbutter,3
2020/3/25 15:59,Wed,35600,angbutter,7
2020/3/25 16:17,Wed,20300,angbutter,1
2020/3/26 11:04,Thur,16600,angbutter,2
2020/3/26 11:32,Thur,43200,angbutter,4
2020/3/26 13:06,Thur,18300,angbutter,1
2020/3/26 14:35,Thur,24700,angbutter,4
2020/3/26 14:44,Thur,31100,angbutter,1
2020/3/26 15:07,Thur,15800,angbutter,1
2020/3/26 15:10,Thur,26900,angbutter,3
2020/3/26 15:22,Thur,14800,angbutter,1
2020/3/27 11:51,Fri,14800,angbutter,1
2020/3/27 13:36,Fri,24800,angbutter,2
2020/3/27 14:19,Fri,15300,angbutter,1
2020/3/27 15:11,Fri,15100,angbutter,2
2020/3/27 15:36,Fri,28800,angbutter,1
2020/3/27 15:38,Fri,16100,angbutter,2
2020/3/27 16:23,Fri,14800,angbutter,1
2020/3/28 11:09,Sat,26300,angbutter,1
2020/3/28 11:14,Sat,19300,angbutter,1
2020/3/28 11:38,Sat,14800,angbutter,1
2020/3/28 11:55,Sat,40300,angbutter,1
2020/3/28 13:05,Sat,22600,angbutter,3
2020/3/28 13:39,Sat,24100,angbutter,2
2020/3/28 15:14,Sat,16600,angbutter,1
2020/3/29 11:09,Sun,21800,angbutter,1
2020/3/29 11:25,Sun,27800,angbutter,1
2020/3/29 11:59,Sun,15800,angbutter,1
2020/3/29 12:09,Sun,14100,angbutter,2
2020/3/29 12:15,Sun,26900,angbutter,3
2020/3/29 12:31,Sun,19300,angbutter,1
2020/3/29 12:59,Sun,24300,angbutter,1
2020/3/29 13:04,Sun,29600,angbutter,3
2020/3/29 13:16,Sun,19600,angbutter,2
2020/3/29 13:16,Sun,18600,angbutter,2
2020/3/29 14:02,Sun,26300,angbutter,1
2020/3/29 15:37,Sun,15300,angbutter,1
2020/3/29 12:09,Sun,16100,angbutter,2
2020/3/30 11:22,Mon,17300,angbutter,1
2020/3/30 11:28,Mon,28600,angbutter,2
2020/3/30 12:07,Mon,19300,angbutter,1
2020/3/30 13:25,Mon,18800,angbutter,1
2020/3/30 14:08,Mon,32400,angbutter,3
2020/3/30 14:46,Mon,14800,angbutter,1
2020/3/30 15:07,Mon,17800,angbutter,1
2020/3/30 16:21,Mon,19800,angbutter,1
2020/3/30 16:22,Mon,35300,angbutter,6
2020/4/1 11:01,Wed,16400,angbutter,3
2020/4/1 11:15,Wed,29400,angbutter,3
2020/4/1 11:54,Wed,16100,angbutter,2
2020/4/1 12:32,Wed,23100,angbutter,2
2020/4/1 12:45,Wed,18300,angbutter,1
2020/4/1 13:29,Wed,32100,angbutter,1
2020/4/1 13:44,Wed,22800,angbutter,1
2020/4/1 13:49,Wed,28800,angbutter,1
2020/4/1 14:18,Wed,24300,angbutter,1
2020/4/1 14:28,Wed,18800,angbutter,1
2020/4/2 11:06,Thur,16000,angbutter,4
2020/4/2 11:06,Thur,15800,angbutter,1
2020/4/2 11:43,Thur,22800,angbutter,1
2020/4/2 11:54,Thur,15300,angbutter,1
2020/4/2 12:01,Thur,18600,angbutter,2
2020/4/2 12:11,Thur,28800,angbutter,1
2020/4/2 12:38,Thur,18000,angbutter,2
2020/4/2 13:12,Thur,15800,angbutter,1
2020/4/2 13:12,Thur,23100,angbutter,1
2020/4/2 13:58,Thur,20600,angbutter,2
2020/4/2 15:49,Thur,16100,angbutter,2
2020/4/2 16:02,Thur,14300,angbutter,1
2020/4/2 16:03,Thur,26900,angbutter,3
2020/4/2 16:21,Thur,29500,angbutter,4
2020/4/2 16:31,Thur,16100,angbutter,2
2020/4/3 11:24,Fri,24800,angbutter,1
2020/4/3 11:43,Fri,23600,angbutter,2
2020/4/3 11:44,Fri,14300,angbutter,1
2020/4/3 12:08,Fri,19300,angbutter,1
2020/4/3 13:29,Fri,44500,angbutter,4
2020/4/4 11:54,Sat,18300,angbutter,1
2020/4/4 12:36,Sat,14800,angbutter,1
2020/4/4 13:02,Sat,27800,angbutter,1
2020/4/4 14:06,Sat,21800,angbutter,1
2020/4/4 14:07,Sat,19600,angbutter,2
2020/4/4 14:56,Sat,18800,angbutter,1
2020/4/4 15:24,Sat,15100,angbutter,2
2020/4/4 16:11,Sat,16800,angbutter,1
2020/4/5 11:02,Sun,21800,angbutter,1
2020/4/5 12:33,Sun,16300,angbutter,1
2020/4/5 13:05,Sun,24600,angbutter,1
2020/4/5 13:17,Sun,17100,angbutter,2
2020/4/5 13:29,Sun,14800,angbutter,1
2020/4/5 13:34,Sun,22300,angbutter,1
2020/4/5 14:41,Sun,26300,angbutter,1
2020/4/5 14:56,Sun,14100,angbutter,1
2020/4/5 15:28,Sun,18100,angbutter,2
2020/4/5 16:23,Sun,16400,angbutter,3
2020/4/6 11:24,Mon,19800,angbutter,1
2020/4/6 11:54,Mon,18300,angbutter,1
2020/4/6 15:38,Mon,20600,angbutter,2
2020/4/6 15:55,Mon,27100,angbutter,1
2020/4/6 16:41,Mon,16400,angbutter,3
2020/4/6 17:21,Mon,15300,angbutter,1
2020/4/8 11:01,Wed,17300,angbutter,1
2020/4/8 11:22,Wed,16300,angbutter,1
2020/4/8 11:40,Wed,25800,angbutter,1
2020/4/8 11:53,Wed,28800,angbutter,1
2020/4/8 12:01,Wed,30300,angbutter,1
2020/4/8 12:10,Wed,19800,angbutter,1
2020/4/8 13:20,Wed,17100,angbutter,2
2020/4/8 14:56,Wed,21200,angbutter,4
2020/4/8 15:53,Wed,22300,angbutter,2
2020/4/8 17:09,Wed,16400,angbutter,2
2020/4/8 17:17,Wed,14300,angbutter,1
2020/4/9 11:10,Thur,26600,angbutter,1
2020/4/9 11:58,Thur,15600,angbutter,2
2020/4/9 11:59,Thur,20300,angbutter,1
2020/4/9 12:00,Thur,30800,angbutter,2
2020/4/9 13:25,Thur,14100,angbutter,2
2020/4/9 15:44,Thur,14300,angbutter,1
2020/4/9 16:44,Thur,24100,angbutter,1
2020/4/10 11:43,Fri,19300,angbutter,2
2020/4/10 12:29,Fri,15300,angbutter,1
2020/4/10 12:53,Fri,14300,angbutter,1
2020/4/10 16:13,Fri,31600,angbutter,1
2020/4/10 17:24,Fri,18600,angbutter,1
2020/4/11 11:20,Sat,17300,angbutter,1
2020/4/11 11:40,Sat,29800,angbutter,1
2020/4/11 12:40,Sat,18300,angbutter,1
2020/4/12 11:05,Sun,32200,angbutter,5
2020/4/12 11:52,Sun,36900,angbutter,3
2020/4/12 12:08,Sun,24300,angbutter,1
2020/4/12 12:19,Sun,15300,angbutter,1
2020/4/12 12:35,Sun,18300,angbutter,1
2020/4/12 13:33,Sun,18300,angbutter,1
2020/4/12 14:30,Sun,15800,angbutter,1
2020/4/12 14:32,Sun,14300,angbutter,1
2020/4/12 15:24,Sun,21600,angbutter,2
2020/4/13 15:19,Mon,26300,angbutter,1
2020/4/15 11:20,Wed,19800,angbutter,1
2020/4/15 11:43,Wed,27100,angbutter,2
2020/4/15 12:36,Wed,14300,angbutter,1
2020/4/15 13:19,Wed,34000,angbutter,5
2020/4/15 13:49,Wed,14300,angbutter,1
2020/4/15 13:52,Wed,17300,angbutter,1
2020/4/15 15:17,Wed,29200,angbutter,3
2020/4/15 15:59,Wed,15600,angbutter,2
2020/4/16 11:46,Thur,19300,angbutter,1
2020/4/16 11:51,Thur,18800,angbutter,1
2020/4/16 12:15,Thur,27600,angbutter,2
2020/4/16 13:04,Thur,18300,angbutter,1
2020/4/16 16:58,Thur,18800,angbutter,1
2020/4/17 11:45,Fri,20100,angbutter,2
2020/4/17 12:12,Fri,19300,angbutter,1
2020/4/17 13:38,Fri,20600,angbutter,2
2020/4/17 14:24,Fri,18600,angbutter,2
2020/4/17 15:01,Fri,19800,angbutter,2
2020/4/17 16:30,Fri,16100,angbutter,2
2020/4/18 11:19,Sat,19300,angbutter,1
2020/4/18 11:22,Sat,18600,angbutter,2
2020/4/18 11:22,Sat,16300,angbutter,1
2020/4/18 11:39,Sat,20800,angbutter,1
2020/4/18 11:46,Sat,33900,angbutter,3
2020/4/18 12:22,Sat,16300,angbutter,1
2020/4/18 12:35,Sat,15800,angbutter,1
2020/4/18 14:12,Sat,30100,angbutter,1
2020/4/18 14:35,Sat,17800,angbutter,2
2020/4/18 14:10,Sat,14800,angbutter,2
2020/4/19 11:09,Sun,24100,angbutter,2
2020/4/19 11:26,Sun,21200,angbutter,4
2020/4/19 12:35,Sun,14300,angbutter,1
2020/4/19 14:04,Sun,24600,angbutter,2
2020/4/19 15:02,Sun,16500,angbutter,1
2020/4/19 15:16,Sun,16100,angbutter,2
2020/4/19 16:46,Sun,23900,angbutter,3
2020/4/20 11:17,Mon,25100,angbutter,2
2020/4/20 12:13,Mon,20000,angbutter,1
2020/4/20 12:45,Mon,17400,angbutter,3
2020/4/20 14:46,Mon,64000,angbutter,3
2020/4/20 14:56,Mon,29900,angbutter,3
2020/4/22 11:02,Wed,20100,angbutter,2
2020/4/22 11:51,Wed,18600,angbutter,2
2020/4/22 12:06,Wed,28600,angbutter,3
2020/4/22 12:18,Wed,18300,angbutter,1
2020/4/22 12:53,Wed,18800,angbutter,1
2020/4/22 13:05,Wed,20300,angbutter,1
2020/4/22 13:07,Wed,25100,angbutter,2
2020/4/22 13:43,Wed,25700,angbutter,4
2020/4/22 15:05,Wed,16800,angbutter,1
2020/4/22 15:49,Wed,15100,angbutter,2
2020/4/23 11:07,Thur,20900,angbutter,3
2020/4/23 13:17,Thur,20100,angbutter,2
2020/4/23 13:57,Thur,17300,angbutter,1
2020/4/23 15:16,Thur,15000,angbutter,1
2020/4/24 11:12,Fri,18800,angbutter,1
2020/4/24 12:15,Fri,30900,angbutter,3
2020/4/24 12:53,Fri,24800,angbutter,1
2020/4/24 14:32,Fri,16600,angbutter,2
2020/4/24 16:27,Fri,15300,angbutter,1
2020/4/25 11:10,Sat,18300,angbutter,1
2020/4/25 11:16,Sat,30800,angbutter,1
2020/4/25 11:16,Sat,31200,angbutter,4
2020/4/25 11:37,Sat,20600,angbutter,2
2020/4/25 11:42,Sat,36600,angbutter,2
2020/4/25 11:52,Sat,14800,angbutter,1
2020/4/25 13:18,Sat,19300,angbutter,1
2020/4/25 13:30,Sat,28600,angbutter,2
2020/4/25 13:56,Sat,29300,angbutter,1
2020/4/25 14:25,Sat,22800,angbutter,1
2020/4/25 14:27,Sat,20800,angbutter,1
2020/4/25 16:13,Sat,15800,angbutter,1
2020/4/26 11:03,Sun,38900,angbutter,3
2020/4/26 11:05,Sun,33300,angbutter,1
2020/4/26 11:51,Sun,28300,angbutter,1
2020/4/26 12:00,Sun,23300,angbutter,1
2020/4/26 12:02,Sun,23600,angbutter,3
2020/4/26 13:01,Sun,16300,angbutter,1
2020/4/26 13:01,Sun,14800,angbutter,1
2020/4/26 13:44,Sun,22200,angbutter,4
2020/4/26 13:55,Sun,15100,angbutter,2
2020/4/26 14:05,Sun,17600,angbutter,2
2020/4/26 15:14,Sun,27300,angbutter,1
2020/4/27 11:28,Mon,18300,angbutter,1
2020/4/27 11:36,Mon,18800,angbutter,1
2020/4/27 11:41,Mon,19800,angbutter,1
2020/4/27 11:42,Mon,30800,angbutter,1
2020/4/27 11:56,Mon,22300,angbutter,1
2020/4/27 12:08,Mon,14800,angbutter,1
2020/4/27 12:31,Mon,18800,angbutter,1
2020/4/27 14:42,Mon,14300,angbutter,1
2020/4/27 15:07,Mon,18800,angbutter,1
2020/4/27 15:10,Mon,25800,angbutter,1
2020/4/27 16:00,Mon,18600,angbutter,1
2020/4/29 12:00,Wed,21800,angbutter,1
2020/4/29 13:15,Wed,14800,angbutter,1
2020/4/29 13:58,Wed,15100,angbutter,2
2020/4/29 15:05,Wed,26800,angbutter,1
2020/4/29 16:35,Wed,16100,angbutter,2
2020/4/30 11:18,Thur,31300,angbutter,1
2020/4/30 12:17,Thur,18800,angbutter,1
2020/4/30 13:10,Thur,14800,angbutter,1
2020/4/30 13:43,Thur,16800,angbutter,2
2020/4/30 15:01,Thur,18800,angbutter,1
2020/4/30 16:02,Thur,15300,angbutter,1
2020/5/1 11:09,Fri,31600,angbutter,2
2020/5/1 11:10,Fri,21200,angbutter,4
2020/5/1 11:47,Fri,19800,angbutter,1
2020/5/1 12:00,Fri,30800,angbutter,1
2020/5/1 12:10,Fri,18300,angbutter,1
2020/5/1 13:05,Fri,28400,angbutter,4
2020/5/1 13:55,Fri,21300,angbutter,1
2020/5/1 15:03,Fri,14800,angbutter,1
2020/5/2 11:39,Sat,19800,angbutter,1
2020/5/2 12:15,Sat,14300,angbutter,1
2020/5/2 14:45,Sat,24100,angbutter,2
2019/7/13 13:19,Sat,14800,plain bread,1
2019/7/13 15:23,Sat,19100,plain bread,1
2019/7/13 16:32,Sat,22300,plain bread,1
2019/7/17 11:47,Wed,17800,plain bread,1
2019/7/17 16:32,Wed,18100,plain bread,1
2019/7/21 11:42,Sun,17300,plain bread,1
2019/7/21 12:47,Sun,21000,plain bread,1
2019/7/21 14:05,Sun,18300,plain bread,1
2019/7/21 14:53,Sun,15300,plain bread,1
2019/7/24 11:56,Wed,27100,plain bread,2
2019/7/24 13:24,Wed,18800,plain bread,1
2019/7/24 14:28,Wed,26300,plain bread,2
2019/7/25 11:57,Thur,26800,plain bread,1
2019/7/26 11:26,Fri,25300,plain bread,1
2019/7/26 11:23,Fri,73200,plain bread,3
2019/7/26 11:36,Fri,1293000,plain bread,5
2019/7/26 11:37,Fri,15000,plain bread,1
2019/7/27 11:29,Sat,18800,plain bread,1
2019/7/27 11:57,Sat,21800,plain bread,1
2019/7/27 12:07,Sat,33200,plain bread,2
2019/7/27 12:43,Sat,16400,plain bread,1
2019/7/27 13:50,Sat,14800,plain bread,1
2019/7/27 14:05,Sat,32600,plain bread,1
2019/7/28 12:10,Sun,14800,plain bread,1
2019/7/28 13:13,Sun,25600,plain bread,1
2019/7/28 13:14,Sun,19500,plain bread,1
2019/7/29 12:22,Mon,27900,plain bread,1
2019/7/31 11:25,Wed,30100,plain bread,1
2019/7/31 11:38,Wed,23300,plain bread,1
2019/7/31 12:48,Wed,15100,plain bread,1
2019/7/31 13:18,Wed,27300,plain bread,1
2019/8/1 12:02,Thur,21100,plain bread,1
2019/8/1 12:24,Thur,32600,plain bread,2
2019/8/1 12:38,Thur,14500,plain bread,1
2019/8/1 13:39,Thur,15000,plain bread,1
2019/8/2 11:04,Fri,14100,plain bread,1
2019/8/2 11:31,Fri,17300,plain bread,1
2019/8/2 12:51,Fri,15800,plain bread,1
2019/8/3 11:03,Sat,26100,plain bread,1
2019/8/3 11:06,Sat,16800,plain bread,1
2019/8/3 11:08,Sat,22800,plain bread,1
2019/8/3 11:53,Sat,18800,plain bread,1
2019/8/3 12:44,Sat,19300,plain bread,1
2019/8/4 11:02,Sun,34800,plain bread,1
2019/8/4 11:04,Sun,31600,plain bread,1
2019/8/4 11:07,Sun,19300,plain bread,1
2019/8/4 11:41,Sun,24300,plain bread,1
2019/8/4 12:27,Sun,14800,plain bread,1
2019/8/4 12:30,Sun,19500,plain bread,1
2019/8/4 12:39,Sun,17800,plain bread,1
2019/8/5 11:59,Mon,22300,plain bread,1
2019/8/5 12:14,Mon,26600,plain bread,1
2019/8/5 12:14,Mon,14800,plain bread,1
2019/8/5 12:49,Mon,49300,plain bread,1
2019/8/5 13:54,Mon,19800,plain bread,1
2019/8/5 14:25,Mon,20800,plain bread,1
2019/8/7 13:33,Wed,19500,plain bread,3
2019/8/7 14:05,Wed,15000,plain bread,1
2019/8/7 14:50,Wed,23800,plain bread,1
2019/8/8 11:07,Thur,16100,plain bread,1
2019/8/8 12:03,Thur,16500,plain bread,1
2019/8/8 12:39,Thur,15300,plain bread,1
2019/8/8 12:56,Thur,16000,plain bread,1
2019/8/8 14:52,Thur,17000,plain bread,1
2019/8/8 14:58,Thur,20500,plain bread,1
2019/8/10 11:05,Sat,28600,plain bread,1
2019/8/10 11:27,Sat,36800,plain bread,1
2019/8/10 11:38,Sat,25300,plain bread,1
2019/8/11 11:01,Sun,21800,plain bread,1
2019/8/11 11:46,Sun,19600,plain bread,1
2019/8/11 11:50,Sun,15300,plain bread,1
2019/8/11 11:58,Sun,27900,plain bread,1
2019/8/12 11:48,Mon,16300,plain bread,1
2019/8/12 12:39,Mon,24300,plain bread,2
2019/8/12 13:27,Mon,18300,plain bread,1
2019/8/14 11:03,Wed,41200,plain bread,1
2019/8/14 11:03,Wed,17800,plain bread,1
2019/8/14 11:16,Wed,65600,plain bread,1
2019/8/14 11:25,Wed,27300,plain bread,1
2019/8/14 11:31,Wed,22300,plain bread,1
2019/8/15 11:03,Thur,24100,plain bread,1
2019/8/15 11:06,Thur,17300,plain bread,1
2019/8/15 11:23,Thur,22100,plain bread,1
2019/8/16 12:49,Fri,18300,plain bread,1
2019/8/17 11:01,Sat,20100,plain bread,1
2019/8/17 12:29,Sat,14800,plain bread,1
2019/8/17 12:57,Sat,29600,plain bread,1
2019/8/17 13:02,Sat,19800,plain bread,1
2019/8/17 13:19,Sat,20300,plain bread,1
2019/8/17 13:38,Sat,32600,plain bread,1
2019/8/18 12:22,Sun,15000,plain bread,1
2019/8/18 14:39,Sun,23000,plain bread,1
2019/8/19 11:59,Mon,16800,plain bread,1
2019/8/19 12:10,Mon,19300,plain bread,1
2019/8/19 12:21,Mon,15800,plain bread,1
2019/8/19 12:34,Mon,23600,plain bread,1
2019/8/19 13:06,Mon,19300,plain bread,1
2019/8/19 15:14,Mon,15300,plain bread,1
2019/8/21 11:28,Wed,54000,plain bread,3
2019/8/21 12:51,Wed,17500,plain bread,1
2019/8/21 14:11,Wed,25000,plain bread,1
2019/8/21 14:38,Wed,23000,plain bread,1
2019/8/23 11:28,Fri,42200,plain bread,3
2019/8/24 11:13,Sat,25600,plain bread,1
2019/8/24 11:14,Sat,23100,plain bread,1
2019/8/24 11:14,Sat,17300,plain bread,1
2019/8/24 11:55,Sat,20800,plain bread,1
2019/8/24 12:56,Sat,23300,plain bread,2
2019/8/24 13:07,Sat,14800,plain bread,1
2019/8/25 11:18,Sun,15300,plain bread,1
2019/8/25 11:53,Sun,15300,plain bread,1
2019/8/26 11:17,Mon,19900,plain bread,1
2019/8/28 11:19,Wed,16300,plain bread,1
2019/8/28 14:05,Wed,19300,plain bread,1
2019/8/29 11:04,Thur,22300,plain bread,2
2019/8/29 13:28,Thur,53800,plain bread,2
2019/8/29 16:15,Thur,19000,plain bread,1
2019/8/30 11:16,Fri,14800,plain bread,1
2019/8/30 15:05,Fri,28800,plain bread,1
2019/8/30 16:18,Fri,18800,plain bread,1
2019/8/31 11:37,Sat,14800,plain bread,1
2019/8/31 13:16,Sat,16000,plain bread,4
2019/9/1 11:40,Sun,22100,plain bread,1
2019/9/1 12:07,Sun,16600,plain bread,1
2019/9/1 12:25,Sun,22900,plain bread,1
2019/9/1 12:39,Sun,28300,plain bread,1
2019/9/4 12:58,Wed,17000,plain bread,1
2019/9/4 13:53,Wed,22800,plain bread,1
2019/9/4 14:54,Wed,14800,plain bread,1
2019/9/4 15:26,Wed,41100,plain bread,2
2019/9/5 11:27,Thur,21800,plain bread,2
2019/9/5 11:47,Thur,15100,plain bread,1
2019/9/5 14:30,Thur,29200,plain bread,1
2019/9/5 14:46,Thur,18800,plain bread,1
2019/9/6 12:09,Fri,15300,plain bread,1
2019/9/7 11:15,Sat,19800,plain bread,2
2019/9/7 11:47,Sat,22500,plain bread,1
2019/9/7 12:05,Sat,18600,plain bread,1
2019/9/7 12:39,Sat,15100,plain bread,1
2019/9/7 15:22,Sat,26300,plain bread,2
2019/9/7 16:12,Sat,27500,plain bread,1
2019/9/7 16:23,Sat,27400,plain bread,1
2019/9/8 11:37,Sun,26000,plain bread,1
2019/9/9 12:04,Mon,22600,plain bread,1
2019/9/9 13:12,Mon,14800,plain bread,1
2019/9/9 13:23,Mon,21000,plain bread,1
2019/9/9 14:17,Mon,18800,plain bread,1
2019/9/9 15:42,Mon,21800,plain bread,1
2019/9/11 13:08,Wed,24400,plain bread,1
2019/9/11 14:57,Wed,24600,plain bread,1
2019/9/12 12:01,Thur,19800,plain bread,1
2019/9/12 13:51,Thur,27600,plain bread,1
2019/9/14 11:18,Sat,22300,plain bread,1
2019/9/15 11:07,Sun,32200,plain bread,2
2019/9/15 11:33,Sun,24600,plain bread,1
2019/9/15 11:36,Sun,17000,plain bread,1
2019/9/15 11:57,Sun,16000,plain bread,1
2019/9/15 13:38,Sun,25300,plain bread,1
2019/9/18 11:32,Wed,16500,plain bread,1
2019/9/19 15:34,Thur,15000,plain bread,1
2019/9/19 15:53,Thur,23100,plain bread,1
2019/9/19 16:17,Thur,30500,plain bread,1
2019/9/19 16:27,Thur,34600,plain bread,1
2019/9/20 11:48,Fri,19300,plain bread,1
2019/9/20 12:53,Fri,21000,plain bread,2
2019/9/20 14:58,Fri,18300,plain bread,1
2019/9/21 11:12,Sat,14000,plain bread,1
2019/9/21 12:16,Sat,17600,plain bread,1
2019/9/21 12:28,Sat,37900,plain bread,1
2019/9/22 11:18,Sun,30900,plain bread,3
2019/9/22 12:06,Sun,22300,plain bread,1
2019/9/22 12:07,Sun,34100,plain bread,1
2019/9/22 12:33,Sun,15300,plain bread,1
2019/9/22 12:51,Sun,14800,plain bread,1
2019/9/23 15:25,Mon,24900,plain bread,1
2019/9/23 16:13,Mon,22300,plain bread,1
2019/9/25 11:05,Wed,14800,plain bread,1
2019/9/25 15:18,Wed,26300,plain bread,1
2019/9/25 15:39,Wed,17800,plain bread,1
2019/9/26 14:45,Thur,14800,plain bread,1
2019/9/27 14:35,Fri,19600,plain bread,1
2019/9/27 15:42,Fri,14800,plain bread,1
2019/9/28 11:11,Sat,28700,plain bread,1
2019/9/28 12:23,Sat,18000,plain bread,1
2019/9/28 12:27,Sat,21800,plain bread,1
2019/9/28 12:41,Sat,22100,plain bread,1
2019/9/28 14:07,Sat,25800,plain bread,2
2019/9/29 13:59,Sun,15300,plain bread,1
2019/9/30 12:47,Mon,17300,plain bread,1
2019/9/30 16:04,Mon,16000,plain bread,3
2019/10/2 14:16,Wed,17000,plain bread,1
2019/10/2 14:18,Wed,16000,plain bread,1
2019/10/2 15:57,Wed,24500,plain bread,2
2019/10/2 16:12,Wed,15000,plain bread,1
2019/10/3 11:53,Thur,18300,plain bread,1
2019/10/3 12:12,Thur,22300,plain bread,1
2019/10/3 12:17,Thur,28300,plain bread,2
2019/10/3 13:17,Thur,24000,plain bread,1
2019/10/3 13:42,Thur,18800,plain bread,1
2019/10/3 14:50,Thur,21800,plain bread,1
2019/10/6 11:25,Sun,21300,plain bread,2
2019/10/6 11:58,Sun,18300,plain bread,1
2019/10/6 12:31,Sun,16300,plain bread,1
2019/10/6 13:51,Sun,19300,plain bread,1
2019/10/7 12:24,Mon,17300,plain bread,1
2019/10/7 16:12,Mon,17300,plain bread,1
2019/10/10 12:08,Thur,18300,plain bread,1
2019/10/11 11:24,Fri,17300,plain bread,1
2019/10/11 11:34,Fri,14800,plain bread,1
2019/10/11 14:09,Fri,20800,plain bread,1
2019/10/12 11:40,Sat,15100,plain bread,1
2019/10/13 11:10,Sun,14500,plain bread,1
2019/10/13 11:30,Sun,15000,plain bread,1
2019/10/13 12:55,Sun,18500,plain bread,1
2019/10/13 13:07,Sun,17300,plain bread,1
2019/10/13 13:15,Sun,41100,plain bread,2
2019/10/13 14:42,Sun,22800,plain bread,1
2019/10/13 14:48,Sun,21300,plain bread,2
2019/10/14 13:22,Mon,14500,plain bread,1
2019/10/16 11:09,Wed,22800,plain bread,1
2019/10/16 11:12,Wed,28900,plain bread,1
2019/10/17 12:49,Thur,15300,plain bread,1
2019/10/17 13:05,Thur,18300,plain bread,1
2019/10/17 13:16,Thur,24800,plain bread,1
2019/10/17 13:50,Thur,32300,plain bread,1
2019/10/17 14:45,Thur,16300,plain bread,1
2019/10/18 13:57,Fri,15300,plain bread,1
2019/10/19 11:09,Sat,15000,plain bread,1
2019/10/19 11:17,Sat,29100,plain bread,1
2019/10/19 11:24,Sat,16300,plain bread,1
2019/10/19 12:49,Sat,14800,plain bread,1
2019/10/20 11:05,Sun,14800,plain bread,1
2019/10/20 11:34,Sun,28100,plain bread,1
2019/10/20 11:58,Sun,16300,plain bread,1
2019/10/20 12:03,Sun,17300,plain bread,1
2019/10/21 11:19,Mon,18300,plain bread,1
2019/10/21 11:34,Mon,22800,plain bread,1
2019/10/21 11:36,Mon,20800,plain bread,1
2019/10/21 12:36,Mon,33700,plain bread,1
2019/10/21 12:48,Mon,15800,plain bread,1
2019/10/23 13:56,Wed,14500,plain bread,1
2019/10/24 11:03,Thur,25300,plain bread,2
2019/10/25 11:16,Fri,27300,plain bread,1
2019/10/26 11:03,Sat,14800,plain bread,1
2019/10/26 12:07,Sat,14800,plain bread,1
2019/10/26 12:47,Sat,17300,plain bread,1
2019/10/26 13:04,Sat,15100,plain bread,1
2019/10/27 11:33,Sun,17800,plain bread,1
2019/10/27 12:40,Sun,17300,plain bread,1
2019/10/28 12:15,Mon,18300,plain bread,1
2019/10/28 13:39,Mon,17300,plain bread,2
2019/10/28 13:43,Mon,15000,plain bread,1
2019/10/28 13:45,Mon,26600,plain bread,1
2019/10/31 13:29,Thur,25000,plain bread,1
2019/11/1 11:46,Fri,21800,plain bread,1
2019/11/1 11:55,Fri,23000,plain bread,1
2019/11/1 13:52,Fri,22000,plain bread,1
2019/11/2 12:44,Sat,17500,plain bread,1
2019/11/2 14:19,Sat,22300,plain bread,1
2019/11/2 14:38,Sat,16300,plain bread,1
2019/11/3 11:16,Sun,19800,plain bread,1
2019/11/3 12:01,Sun,33700,plain bread,3
2019/11/3 13:33,Sun,27900,plain bread,2
2019/11/3 15:30,Sun,14800,plain bread,1
2019/11/4 11:41,Mon,16000,plain bread,4
2019/11/4 11:53,Mon,15000,plain bread,1
2019/11/4 13:17,Mon,17500,plain bread,1
2019/11/4 16:37,Mon,17000,plain bread,1
2019/11/6 16:15,Wed,24800,plain bread,1
2019/11/6 16:53,Wed,16000,plain bread,1
2019/11/7 11:20,Thur,15300,plain bread,1
2019/11/7 12:31,Thur,14800,plain bread,1
2019/11/7 13:33,Thur,34800,plain bread,1
2019/11/7 13:43,Thur,27900,plain bread,1
2019/11/7 16:26,Thur,16600,plain bread,1
2019/11/8 14:12,Fri,23300,plain bread,2
2019/11/8 15:01,Fri,14800,plain bread,1
2019/11/8 15:02,Fri,27800,plain bread,1
2019/11/8 15:12,Fri,30000,plain bread,1
2019/11/9 11:36,Sat,27300,plain bread,1
2019/11/9 11:36,Sat,14800,plain bread,1
2019/11/9 14:48,Sat,15800,plain bread,1
2019/11/9 15:40,Sat,14800,plain bread,1
2019/11/9 16:23,Sat,14800,plain bread,1
2019/11/9 16:49,Sat,15800,plain bread,1
2019/11/10 11:06,Sun,14800,plain bread,1
2019/11/10 11:29,Sun,19600,plain bread,1
2019/11/10 12:45,Sun,14800,plain bread,1
2019/11/10 14:21,Sun,18600,plain bread,1
2019/11/10 15:32,Sun,20900,plain bread,1
2019/11/11 11:32,Mon,26600,plain bread,3
2019/11/11 12:00,Mon,18600,plain bread,1
2019/11/11 14:00,Mon,19300,plain bread,1
2019/11/11 14:39,Mon,20300,plain bread,1
2019/11/11 17:25,Mon,28300,plain bread,1
2019/11/13 11:05,Wed,22300,plain bread,1
2019/11/13 11:37,Wed,30100,plain bread,2
2019/11/13 14:45,Wed,14800,plain bread,1
2019/11/14 12:52,Thur,16300,plain bread,1
2019/11/15 13:44,Fri,18500,plain bread,1
2019/11/15 16:30,Fri,70700,plain bread,5
2019/11/16 11:07,Sat,23800,plain bread,1
2019/11/16 11:18,Sat,15100,plain bread,1
2019/11/16 14:15,Sat,16600,plain bread,1
2019/11/16 14:21,Sat,24800,plain bread,1
2019/11/16 16:21,Sat,14300,plain bread,1
2019/11/17 11:06,Sun,26300,plain bread,1
2019/11/17 11:07,Sun,23800,plain bread,1
2019/11/17 11:07,Sun,22300,plain bread,1
2019/11/17 11:24,Sun,16500,plain bread,1
2019/11/17 11:40,Sun,17500,plain bread,1
2019/11/17 11:57,Sun,16300,plain bread,1
2019/11/17 13:18,Sun,23300,plain bread,1
2019/11/17 14:23,Sun,23500,plain bread,1
2019/11/17 15:25,Sun,17300,plain bread,1
2019/11/18 13:55,Mon,14000,plain bread,1
2019/11/18 15:17,Mon,22800,plain bread,2
2019/11/20 11:08,Wed,28100,plain bread,3
2019/11/20 12:46,Wed,17300,plain bread,1
2019/11/20 12:59,Wed,20300,plain bread,1
2019/11/20 15:52,Wed,15000,plain bread,1
2019/11/20 16:28,Wed,16300,plain bread,1
2019/11/22 12:25,Fri,16300,plain bread,1
2019/11/22 17:05,Fri,16600,plain bread,1
2019/11/23 11:55,Sat,19300,plain bread,1
2019/11/23 13:30,Sat,17800,plain bread,1
2019/11/23 15:54,Sat,19500,plain bread,1
2019/11/24 12:26,Sun,18300,plain bread,1
2019/11/24 12:56,Sun,33700,plain bread,1
2019/11/24 13:00,Sun,17300,plain bread,1
2019/11/24 13:13,Sun,14800,plain bread,1
2019/11/24 13:39,Sun,18800,plain bread,1
2019/11/24 13:53,Sun,19300,plain bread,1
2019/11/24 16:32,Sun,19500,plain bread,1
2019/11/25 12:54,Mon,26300,plain bread,1
2019/11/27 12:02,Wed,33400,plain bread,1
2019/11/27 12:35,Wed,15300,plain bread,1
2019/11/27 14:00,Wed,14100,plain bread,1
2019/11/27 14:16,Wed,16500,plain bread,1
2019/11/28 13:16,Thur,17500,plain bread,1
2019/11/28 14:15,Thur,18300,plain bread,1
2019/11/28 14:28,Thur,15100,plain bread,1
2019/11/28 14:48,Thur,40000,plain bread,1
2019/11/28 15:09,Thur,19300,plain bread,1
2019/11/29 13:39,Fri,17300,plain bread,1
2019/11/29 15:30,Fri,14800,plain bread,1
2019/11/29 16:12,Fri,28100,plain bread,1
2019/11/30 11:01,Sat,22100,plain bread,1
2019/11/30 11:10,Sat,22800,plain bread,1
2019/11/30 11:56,Sat,31400,plain bread,3
2019/11/30 14:24,Sat,15800,plain bread,1
2019/12/1 11:03,Sun,22100,plain bread,1
2019/12/1 11:40,Sun,15300,plain bread,1
2019/12/1 12:11,Sun,23100,plain bread,1
2019/12/1 12:23,Sun,23100,plain bread,1
2019/12/1 12:55,Sun,19000,plain bread,1
2019/12/1 14:24,Sun,31100,plain bread,1
2019/12/2 11:03,Mon,17500,plain bread,1
2019/12/4 11:47,Wed,17500,plain bread,1
2019/12/4 13:30,Wed,19600,plain bread,1
2019/12/4 14:58,Wed,20500,plain bread,3
2019/12/5 12:32,Thur,16000,plain bread,1
2019/12/5 12:39,Thur,21800,plain bread,1
2019/12/5 14:48,Thur,36000,plain bread,1
2019/12/6 11:08,Fri,22100,plain bread,1
2019/12/6 11:49,Fri,14800,plain bread,1
2019/12/6 12:26,Fri,16300,plain bread,1
2019/12/6 12:43,Fri,27500,plain bread,1
2019/12/7 12:02,Sat,14800,plain bread,1
2019/12/7 13:39,Sat,30800,plain bread,1
2019/12/7 13:55,Sat,28600,plain bread,1
2019/12/7 14:35,Sat,15100,plain bread,1
2019/12/8 11:11,Sun,27600,plain bread,2
2019/12/8 11:50,Sun,18000,plain bread,1
2019/12/8 12:11,Sun,15300,plain bread,1
2019/12/8 12:33,Sun,23000,plain bread,1
2019/12/8 12:41,Sun,22600,plain bread,2
2019/12/8 12:49,Sun,30600,plain bread,1
2019/12/8 12:52,Sun,20300,plain bread,1
2019/12/8 13:57,Sun,17000,plain bread,1
2019/12/8 13:57,Sun,18300,plain bread,1
2019/12/11 11:26,Wed,15300,plain bread,1
2019/12/11 11:36,Wed,15000,plain bread,1
2019/12/11 11:37,Wed,18800,plain bread,1
2019/12/11 12:09,Wed,21500,plain bread,2
2019/12/11 13:32,Wed,21500,plain bread,1
2019/12/11 14:08,Wed,17300,plain bread,2
2019/12/11 14:26,Wed,32000,plain bread,2
2019/12/11 15:05,Wed,14500,plain bread,1
2019/12/12 11:15,Thur,29200,plain bread,1
2019/12/12 11:27,Thur,14800,plain bread,1
2019/12/12 12:50,Thur,20600,plain bread,1
2019/12/12 14:34,Thur,16300,plain bread,1
2019/12/12 14:52,Thur,19500,plain bread,1
2019/12/13 15:53,Fri,16800,plain bread,1
2019/12/13 16:48,Fri,14000,plain bread,1
2019/12/14 11:59,Sat,17300,plain bread,2
2019/12/14 12:41,Sat,18300,plain bread,2
2019/12/16 13:37,Mon,14500,plain bread,1
2019/12/18 12:39,Wed,14000,plain bread,1
2019/12/18 12:45,Wed,19600,plain bread,1
2019/12/18 13:51,Wed,19600,plain bread,1
2019/12/19 11:45,Thur,35300,plain bread,1
2019/12/19 12:16,Thur,14300,plain bread,1
2019/12/19 13:06,Thur,32500,plain bread,1
2019/12/19 13:21,Thur,14300,plain bread,2
2019/12/20 14:29,Fri,19300,plain bread,1
2019/12/20 15:37,Fri,16800,plain bread,1
2019/12/20 16:43,Fri,31100,plain bread,2
2019/12/21 13:58,Sat,20000,plain bread,1
2019/12/22 11:33,Sun,46000,plain bread,3
2019/12/22 14:03,Sun,16000,plain bread,4
2019/12/22 14:17,Sun,20300,plain bread,1
2019/12/23 15:03,Mon,14000,plain bread,1
2019/12/25 11:29,Wed,24100,plain bread,1
2019/12/25 11:55,Wed,15300,plain bread,1
2019/12/25 17:14,Wed,17000,plain bread,3
2019/12/26 12:16,Thur,20500,plain bread,1
2019/12/27 11:39,Fri,16300,plain bread,1
2019/12/28 12:04,Sat,17000,plain bread,1
2019/12/28 13:47,Sat,18800,plain bread,1
2019/12/28 14:55,Sat,21500,plain bread,2
2019/12/28 14:58,Sat,24300,plain bread,1
2019/12/28 16:18,Sat,58900,plain bread,2
2019/12/29 12:24,Sun,23900,plain bread,1
2019/12/29 12:39,Sun,14800,plain bread,1
2019/12/29 12:52,Sun,23800,plain bread,1
2019/12/29 13:03,Sun,19800,plain bread,1
2019/12/29 14:39,Sun,14000,plain bread,1
2019/12/29 16:02,Sun,25500,plain bread,1
2019/12/30 11:44,Mon,15300,plain bread,1
2019/12/30 14:35,Mon,53900,plain bread,1
2020/1/2 11:22,Thur,15000,plain bread,1
2020/1/2 12:17,Thur,16500,plain bread,1
2020/1/2 12:27,Thur,14300,plain bread,1
2020/1/2 12:33,Thur,14800,plain bread,1
2020/1/2 14:06,Thur,17600,plain bread,1
2020/1/3 13:44,Fri,17300,plain bread,1
2020/1/3 14:05,Fri,17000,plain bread,1
2020/1/3 14:18,Fri,18000,plain bread,1
2020/1/3 16:06,Fri,17300,plain bread,1
2020/1/4 12:51,Sat,24800,plain bread,1
2020/1/5 12:37,Sun,14300,plain bread,1
2020/1/5 14:06,Sun,23800,plain bread,1
2020/1/5 14:46,Sun,18300,plain bread,1
2020/1/5 14:54,Sun,14300,plain bread,1
2020/1/5 15:06,Sun,24400,plain bread,1
2020/1/6 12:25,Mon,14800,plain bread,1
2020/1/6 12:30,Mon,30800,plain bread,1
2020/1/8 12:42,Wed,22600,plain bread,1
2020/1/8 13:31,Wed,18300,plain bread,2
2020/1/9 11:39,Thur,28300,plain bread,1
2020/1/9 12:09,Thur,17000,plain bread,2
2020/1/9 12:34,Thur,18300,plain bread,2
2020/1/9 15:22,Thur,23300,plain bread,1
2020/1/9 15:42,Thur,19600,plain bread,1
2020/1/9 15:59,Thur,17600,plain bread,1
2020/1/9 16:00,Thur,14800,plain bread,1
2020/1/10 15:10,Fri,19300,plain bread,1
2020/1/12 12:16,Sun,44100,plain bread,2
2020/1/12 12:19,Sun,45400,plain bread,1
2020/1/12 12:30,Sun,16000,plain bread,1
2020/1/12 12:42,Sun,18000,plain bread,1
2020/1/12 13:23,Sun,18300,plain bread,1
2020/1/12 14:11,Sun,14800,plain bread,1
2020/1/12 14:31,Sun,14500,plain bread,1
2020/1/12 17:05,Sun,21300,plain bread,1
2020/1/13 12:23,Mon,19000,plain bread,2
2020/1/15 11:04,Wed,20300,plain bread,1
2020/1/15 12:19,Wed,16000,plain bread,1
2020/1/15 13:01,Wed,18300,plain bread,1
2020/1/15 13:22,Wed,26300,plain bread,1
2020/1/15 14:46,Wed,18800,plain bread,1
2020/1/16 11:28,Thur,18800,plain bread,1
2020/1/16 14:09,Thur,14800,plain bread,1
2020/1/17 11:46,Fri,14800,plain bread,1
2020/1/17 12:13,Fri,26600,plain bread,2
2020/1/18 11:16,Sat,18300,plain bread,1
2020/1/18 12:31,Sat,25800,plain bread,1
2020/1/18 13:17,Sat,15000,plain bread,1
2020/1/18 14:52,Sat,14300,plain bread,1
2020/1/18 15:27,Sat,23600,plain bread,2
2020/1/19 11:05,Sun,19300,plain bread,1
2020/1/19 11:49,Sun,14500,plain bread,1
2020/1/19 12:52,Sun,32100,plain bread,2
2020/1/19 15:53,Sun,19100,plain bread,1
2020/1/19 15:54,Sun,27400,plain bread,2
2020/1/19 16:21,Sun,19800,plain bread,1
2020/1/22 12:04,Wed,20300,plain bread,1
2020/1/22 13:44,Wed,18300,plain bread,1
2020/1/22 15:22,Wed,14500,plain bread,1
2020/1/22 16:08,Wed,14800,plain bread,1
2020/1/23 12:07,Thur,17800,plain bread,2
2020/1/23 14:04,Thur,18600,plain bread,2
2020/1/23 14:08,Thur,15000,plain bread,1
2020/1/23 15:26,Thur,27500,plain bread,1
2020/1/23 15:53,Thur,14800,plain bread,1
2020/1/24 11:37,Fri,23800,plain bread,1
2020/1/26 12:16,Sun,15000,plain bread,1
2020/1/26 12:30,Sun,14800,plain bread,1
2020/1/26 12:50,Sun,34900,plain bread,1
2020/1/26 13:09,Sun,18000,plain bread,1
2020/1/29 11:46,Wed,17500,plain bread,2
2020/1/29 12:23,Wed,15100,plain bread,1
2020/1/30 12:15,Thur,34300,plain bread,2
2020/1/30 12:26,Thur,26600,plain bread,1
2020/1/30 14:26,Thur,23300,plain bread,1
2020/1/30 14:27,Thur,16000,plain bread,1
2020/1/31 11:17,Fri,15300,plain bread,2
2020/1/31 11:21,Fri,19800,plain bread,1
2020/1/31 11:32,Fri,22500,plain bread,1
2020/1/31 12:06,Fri,14800,plain bread,1
2020/1/31 13:47,Fri,15000,plain bread,2
2020/1/31 16:45,Fri,15000,plain bread,1
2020/2/1 12:56,Sat,17300,plain bread,1
2020/2/1 13:42,Sat,19300,plain bread,1
2020/2/1 14:10,Sat,15300,plain bread,1
2020/2/2 11:05,Sun,15000,plain bread,2
2020/2/2 11:32,Sun,22300,plain bread,2
2020/2/2 11:49,Sun,30800,plain bread,1
2020/2/2 12:18,Sun,16000,plain bread,1
2020/2/2 12:21,Sun,18300,plain bread,2
2020/2/2 12:42,Sun,17300,plain bread,2
2020/2/2 13:10,Sun,17800,plain bread,1
2020/2/2 13:31,Sun,14500,plain bread,1
2020/2/2 14:16,Sun,15100,plain bread,1
2020/2/5 11:23,Wed,19800,plain bread,1
2020/2/5 11:54,Wed,21500,plain bread,3
2020/2/5 11:56,Wed,27600,plain bread,1
2020/2/5 12:36,Wed,17500,plain bread,1
2020/2/6 12:31,Thur,15000,plain bread,1
2020/2/6 12:36,Thur,14800,plain bread,1
2020/2/6 13:31,Thur,18800,plain bread,1
2020/2/6 15:55,Thur,15300,plain bread,1
2020/2/7 12:44,Fri,29300,plain bread,1
2020/2/7 12:56,Fri,17900,plain bread,1
2020/2/7 14:51,Fri,14800,plain bread,1
2020/2/7 15:34,Fri,21800,plain bread,3
2020/2/7 15:40,Fri,26300,plain bread,1
2020/2/7 16:41,Fri,21800,plain bread,1
2020/2/8 12:24,Sat,22800,plain bread,1
2020/2/8 13:24,Sat,16500,plain bread,3
2020/2/8 13:27,Sat,25800,plain bread,2
2020/2/8 14:42,Sat,19800,plain bread,2
2020/2/9 11:09,Sun,18300,plain bread,1
2020/2/9 12:16,Sun,20800,plain bread,1
2020/2/9 12:23,Sun,17300,plain bread,2
2020/2/9 12:36,Sun,15800,plain bread,1
2020/2/9 12:54,Sun,22300,plain bread,1
2020/2/9 13:47,Sun,16300,plain bread,1
2020/2/9 13:54,Sun,18300,plain bread,1
2020/2/9 14:34,Sun,14000,plain bread,1
2020/2/9 15:15,Sun,18500,plain bread,1
2020/2/9 15:48,Sun,24400,plain bread,1
2020/2/10 13:24,Mon,15000,plain bread,1
2020/2/12 12:10,Wed,19300,plain bread,1
2020/2/12 16:21,Wed,22500,plain bread,1
2020/2/15 11:07,Sat,25000,plain bread,1
2020/2/15 11:59,Sat,17000,plain bread,2
2020/2/15 12:50,Sat,17500,plain bread,1
2020/2/15 12:55,Sat,20500,plain bread,1
2020/2/15 13:38,Sat,17300,plain bread,1
2020/2/16 11:17,Sun,27100,plain bread,2
2020/2/16 11:57,Sun,26600,plain bread,1
2020/2/16 12:03,Sun,14300,plain bread,1
2020/2/16 12:06,Sun,22100,plain bread,1
2020/2/16 12:07,Sun,41800,plain bread,3
2020/2/16 12:43,Sun,18300,plain bread,1
2020/2/16 13:09,Sun,15000,plain bread,1
2020/2/16 13:51,Sun,25300,plain bread,2
2020/2/19 11:39,Wed,19600,plain bread,1
2020/2/19 11:49,Wed,18600,plain bread,2
2020/2/19 13:01,Wed,17500,plain bread,1
2020/2/19 14:42,Wed,23000,plain bread,1
2020/2/20 11:06,Thur,20000,plain bread,1
2020/2/20 11:11,Thur,23800,plain bread,1
2020/2/20 11:23,Thur,27600,plain bread,1
2020/2/20 12:12,Thur,14800,plain bread,1
2020/2/20 13:50,Thur,42200,plain bread,1
2020/2/21 11:40,Fri,18000,plain bread,2
2020/2/21 11:54,Fri,19800,plain bread,1
2020/2/21 13:20,Fri,20000,plain bread,1
2020/2/21 13:28,Fri,14800,plain bread,1
2020/2/21 14:41,Fri,15800,plain bread,1
2020/2/22 11:35,Sat,18600,plain bread,1
2020/2/22 12:13,Sat,17000,plain bread,1
2020/2/22 12:14,Sat,19300,plain bread,1
2020/2/22 12:25,Sat,16300,plain bread,1
2020/2/22 13:10,Sat,22000,plain bread,1
2020/2/22 13:24,Sat,17500,plain bread,1
2020/2/22 14:22,Sat,15100,plain bread,1
2020/2/23 11:06,Sun,18000,plain bread,1
2020/2/23 11:07,Sun,41300,plain bread,3
2020/2/23 11:10,Sun,26600,plain bread,1
2020/2/23 12:38,Sun,18800,plain bread,1
2020/2/23 12:49,Sun,32000,plain bread,2
2020/2/23 13:09,Sun,21800,plain bread,2
2020/2/23 13:35,Sun,18500,plain bread,1
2020/2/23 13:58,Sun,18000,plain bread,1
2020/2/23 14:05,Sun,22300,plain bread,1
2020/2/23 14:07,Sun,24000,plain bread,2
2020/2/26 11:12,Wed,31600,plain bread,1
2020/2/26 12:34,Wed,22000,plain bread,2
2020/2/26 12:48,Wed,15000,plain bread,1
2020/2/26 13:03,Wed,17800,plain bread,1
2020/2/26 13:08,Wed,15300,plain bread,1
2020/2/26 14:29,Wed,23300,plain bread,1
2020/2/27 11:15,Thur,23300,plain bread,1
2020/2/27 12:20,Thur,19800,plain bread,1
2020/2/27 14:22,Thur,22000,plain bread,1
2020/2/27 15:45,Thur,15100,plain bread,1
2020/2/28 11:02,Fri,33800,plain bread,1
2020/2/28 11:09,Fri,23100,plain bread,1
2020/2/28 11:52,Fri,16500,plain bread,2
2020/2/28 11:54,Fri,14800,plain bread,1
2020/2/28 12:04,Fri,20300,plain bread,1
2020/2/28 12:10,Fri,24500,plain bread,1
2020/2/28 12:57,Fri,19600,plain bread,1
2020/2/29 12:48,Sat,19000,plain bread,1
2020/2/29 12:49,Sat,18500,plain bread,1
2020/2/29 12:52,Sat,21300,plain bread,1
2020/2/29 12:54,Sat,21800,plain bread,2
2020/2/29 14:55,Sat,18000,plain bread,1
2020/3/1 11:06,Sun,29800,plain bread,1
2020/3/1 11:26,Sun,14000,plain bread,1
2020/3/1 12:13,Sun,14800,plain bread,1
2020/3/1 12:19,Sun,20800,plain bread,1
2020/3/1 12:45,Sun,22300,plain bread,1
2020/3/1 13:23,Sun,16300,plain bread,1
2020/3/1 13:32,Sun,24800,plain bread,1
2020/3/1 14:19,Sun,23500,plain bread,1
2020/3/2 12:26,Mon,31400,plain bread,3
2020/3/2 12:28,Mon,14800,plain bread,1
2020/3/2 12:51,Mon,27800,plain bread,2
2020/3/2 13:00,Mon,15800,plain bread,1
2020/3/2 13:00,Mon,18300,plain bread,1
2020/3/2 13:00,Mon,20000,plain bread,1
2020/3/2 13:32,Mon,33600,plain bread,2
2020/3/2 13:41,Mon,20300,plain bread,1
2020/3/5 11:03,Thur,14800,plain bread,1
2020/3/5 11:36,Thur,37100,plain bread,1
2020/3/5 12:00,Thur,20500,plain bread,2
2020/3/5 12:00,Thur,24300,plain bread,2
2020/3/5 12:11,Thur,17800,plain bread,1
2020/3/5 12:17,Thur,14800,plain bread,1
2020/3/5 12:28,Thur,18000,plain bread,1
2020/3/5 13:39,Thur,18500,plain bread,1
2020/3/5 13:46,Thur,16300,plain bread,1
2020/3/6 11:07,Fri,19800,plain bread,1
2020/3/6 12:15,Fri,18500,plain bread,1
2020/3/6 12:22,Fri,22800,plain bread,1
2020/3/6 12:24,Fri,25600,plain bread,2
2020/3/6 12:27,Fri,18300,plain bread,1
2020/3/6 13:12,Fri,27000,plain bread,1
2020/3/6 14:00,Fri,15800,plain bread,1
2020/3/7 11:29,Sat,20800,plain bread,1
2020/3/7 12:00,Sat,19300,plain bread,2
2020/3/7 12:02,Sat,17300,plain bread,1
2020/3/7 12:39,Sat,17500,plain bread,1
2020/3/7 12:58,Sat,23000,plain bread,1
2020/3/7 12:59,Sat,18300,plain bread,2
2020/3/7 12:59,Sat,14800,plain bread,1
2020/3/8 11:09,Sun,14800,plain bread,1
2020/3/8 11:19,Sun,19000,plain bread,1
2020/3/8 11:38,Sun,16800,plain bread,1
2020/3/8 12:03,Sun,29100,plain bread,1
2020/3/8 12:03,Sun,19600,plain bread,1
2020/3/8 12:13,Sun,15000,plain bread,1
2020/3/8 12:50,Sun,14300,plain bread,1
2020/3/8 12:52,Sun,21300,plain bread,1
2020/3/8 13:44,Sun,19600,plain bread,1
2020/3/8 14:07,Sun,22300,plain bread,1
2020/3/8 15:35,Sun,18300,plain bread,2
2020/3/9 11:23,Mon,21300,plain bread,1
2020/3/9 12:24,Mon,16000,plain bread,1
2020/3/9 12:50,Mon,19000,plain bread,1
2020/3/9 13:20,Mon,18800,plain bread,1
2020/3/9 14:05,Mon,18000,plain bread,1
2020/3/11 11:10,Wed,28600,plain bread,1
2020/3/11 11:24,Wed,24300,plain bread,1
2020/3/11 11:57,Wed,27100,plain bread,1
2020/3/11 12:05,Wed,26100,plain bread,1
2020/3/11 13:14,Wed,22100,plain bread,2
2020/3/11 13:17,Wed,25300,plain bread,1
2020/3/12 11:20,Thur,34100,plain bread,1
2020/3/12 11:31,Thur,18000,plain bread,1
2020/3/12 11:42,Thur,27800,plain bread,1
2020/3/12 11:45,Thur,17300,plain bread,1
2020/3/12 13:34,Thur,25100,plain bread,1
2020/3/12 13:56,Thur,47000,plain bread,2
2020/3/13 12:30,Fri,14800,plain bread,1
2020/3/13 12:35,Fri,18800,plain bread,1
2020/3/14 12:22,Sat,19000,plain bread,2
2020/3/14 12:57,Sat,17500,plain bread,1
2020/3/14 13:05,Sat,14500,plain bread,1
2020/3/14 13:49,Sat,15800,plain bread,1
2020/3/14 13:52,Sat,21800,plain bread,1
2020/3/15 11:13,Sun,19300,plain bread,1
2020/3/15 12:03,Sun,20500,plain bread,2
2020/3/15 13:44,Sun,14800,plain bread,1
2020/3/15 14:07,Sun,25000,plain bread,1
2020/3/15 14:09,Sun,21800,plain bread,1
2020/3/15 14:18,Sun,16000,plain bread,1
2020/3/16 11:56,Mon,22600,plain bread,1
2020/3/16 11:59,Mon,26800,plain bread,2
2020/3/16 12:32,Mon,15300,plain bread,1
2020/3/16 12:46,Mon,26800,plain bread,1
2020/3/16 12:58,Mon,23100,plain bread,2
2020/3/16 13:23,Mon,20800,plain bread,1
2020/3/16 13:45,Mon,17000,plain bread,1
2020/3/16 14:05,Mon,34900,plain bread,2
2020/3/18 11:10,Wed,24000,plain bread,3
2020/3/18 12:08,Wed,14000,plain bread,1
2020/3/18 12:18,Wed,14500,plain bread,1
2020/3/18 12:29,Wed,39100,plain bread,2
2020/3/18 12:40,Wed,42400,plain bread,1
2020/3/18 13:06,Wed,17500,plain bread,1
2020/3/19 11:07,Thur,14000,plain bread,3
2020/3/19 12:25,Thur,23100,plain bread,1
2020/3/19 12:30,Thur,22800,plain bread,2
2020/3/20 12:17,Fri,28800,plain bread,1
2020/3/20 12:34,Fri,17000,plain bread,1
2020/3/20 14:19,Fri,14800,plain bread,1
2020/3/20 15:40,Fri,14000,plain bread,1
2020/3/21 11:04,Sat,16100,plain bread,1
2020/3/21 11:28,Sat,31600,plain bread,1
2020/3/21 11:33,Sat,20000,plain bread,1
2020/3/21 12:02,Sat,37700,plain bread,1
2020/3/21 12:07,Sat,14300,plain bread,1
2020/3/21 12:51,Sat,18300,plain bread,1
2020/3/21 13:38,Sat,17500,plain bread,2
2020/3/21 13:41,Sat,17800,plain bread,1
2020/3/21 14:17,Sat,33100,plain bread,2
2020/3/22 11:34,Sun,15100,plain bread,1
2020/3/22 11:43,Sun,32900,plain bread,1
2020/3/22 13:19,Sun,21800,plain bread,1
2020/3/22 13:21,Sun,20900,plain bread,1
2020/3/23 11:06,Mon,14500,plain bread,1
2020/3/23 11:53,Mon,14500,plain bread,1
2020/3/23 13:12,Mon,18600,plain bread,1
2020/3/23 13:57,Mon,17800,plain bread,1
2020/3/23 14:49,Mon,18300,plain bread,2
2020/3/25 12:42,Wed,18800,plain bread,1
2020/3/25 14:38,Wed,14000,plain bread,1
2020/3/25 14:57,Wed,14500,plain bread,1
2020/3/26 11:04,Thur,16600,plain bread,1
2020/3/26 11:32,Thur,43200,plain bread,2
2020/3/26 13:06,Thur,18300,plain bread,1
2020/3/27 11:42,Fri,17000,plain bread,2
2020/3/27 13:00,Fri,19500,plain bread,1
2020/3/27 13:36,Fri,24800,plain bread,1
2020/3/27 14:19,Fri,15300,plain bread,1
2020/3/28 11:09,Sat,26300,plain bread,2
2020/3/28 11:55,Sat,40300,plain bread,2
2020/3/29 11:25,Sun,27800,plain bread,1
2020/3/29 12:15,Sun,26900,plain bread,1
2020/3/29 12:59,Sun,24300,plain bread,1
2020/3/29 13:04,Sun,29600,plain bread,1
2020/3/29 13:16,Sun,18600,plain bread,2
2020/3/29 13:28,Sun,15000,plain bread,1
2020/3/30 13:38,Mon,14500,plain bread,1
2020/3/30 14:08,Mon,32400,plain bread,1
2020/3/30 16:21,Mon,19800,plain bread,1
2020/3/30 16:22,Mon,35300,plain bread,1
2020/4/1 12:45,Wed,18300,plain bread,1
2020/4/1 13:29,Wed,32100,plain bread,1
2020/4/1 13:44,Wed,22800,plain bread,1
2020/4/2 11:43,Thur,22800,plain bread,1
2020/4/2 12:01,Thur,18600,plain bread,2
2020/4/2 12:11,Thur,28800,plain bread,1
2020/4/2 13:12,Thur,15800,plain bread,1
2020/4/2 13:12,Thur,23100,plain bread,1
2020/4/3 11:43,Fri,23600,plain bread,1
2020/4/3 11:44,Fri,14300,plain bread,1
2020/4/3 12:08,Fri,19300,plain bread,1
2020/4/3 13:29,Fri,44500,plain bread,2
2020/4/3 14:12,Fri,14000,plain bread,1
2020/4/4 11:54,Sat,18300,plain bread,1
2020/4/4 15:24,Sat,15100,plain bread,1
2020/4/5 11:02,Sun,21800,plain bread,2
2020/4/5 11:18,Sun,19000,plain bread,1
2020/4/5 13:05,Sun,24600,plain bread,2
2020/4/5 13:29,Sun,14800,plain bread,1
2020/4/5 16:03,Sun,15000,plain bread,1
2020/4/6 11:54,Mon,18300,plain bread,2
2020/4/6 14:41,Mon,14500,plain bread,1
2020/4/6 15:38,Mon,20600,plain bread,1
2020/4/6 15:55,Mon,27100,plain bread,1
2020/4/8 12:01,Wed,30300,plain bread,1
2020/4/8 14:49,Wed,18000,plain bread,1
2020/4/8 15:53,Wed,22300,plain bread,1
2020/4/8 17:17,Wed,14300,plain bread,1
2020/4/9 11:59,Thur,20300,plain bread,1
2020/4/9 12:00,Thur,30800,plain bread,1
2020/4/9 12:45,Thur,14500,plain bread,1
2020/4/9 14:31,Thur,19500,plain bread,1
2020/4/10 11:45,Fri,20500,plain bread,1
2020/4/10 12:53,Fri,14300,plain bread,1
2020/4/10 16:13,Fri,31600,plain bread,1
2020/4/10 17:24,Fri,18600,plain bread,1
2020/4/11 12:40,Sat,18300,plain bread,1
2020/4/12 11:52,Sun,36900,plain bread,2
2020/4/12 12:08,Sun,24300,plain bread,1
2020/4/12 12:35,Sun,18300,plain bread,1
2020/4/15 12:36,Wed,14300,plain bread,1
2020/4/15 13:52,Wed,17300,plain bread,2
2020/4/16 11:51,Thur,18800,plain bread,1
2020/4/16 12:15,Thur,27600,plain bread,2
2020/4/17 12:12,Fri,19300,plain bread,1
2020/4/17 13:38,Fri,20600,plain bread,1
2020/4/17 14:24,Fri,18600,plain bread,1
2020/4/17 15:01,Fri,19800,plain bread,1
2020/4/18 11:19,Sat,19300,plain bread,1
2020/4/18 11:46,Sat,33900,plain bread,2
2020/4/18 13:42,Sat,15000,plain bread,1
2020/4/18 14:12,Sat,30100,plain bread,1
2020/4/19 15:02,Sun,16500,plain bread,1
2020/4/19 16:46,Sun,23900,plain bread,1
2020/4/20 12:53,Mon,16000,plain bread,1
2020/4/20 14:46,Mon,64000,plain bread,2
2020/4/22 11:51,Wed,18600,plain bread,1
2020/4/22 12:06,Wed,28600,plain bread,1
2020/4/22 12:18,Wed,18300,plain bread,1
2020/4/23 11:40,Thur,28500,plain bread,2
2020/4/23 13:57,Thur,17300,plain bread,1
2020/4/23 15:16,Thur,15000,plain bread,1
2020/4/24 12:53,Fri,24800,plain bread,1
2020/4/24 14:03,Fri,14000,plain bread,1
2020/4/24 15:10,Fri,26000,plain bread,1
2020/4/25 11:16,Sat,30800,plain bread,2
2020/4/25 13:30,Sat,28600,plain bread,1
2020/4/25 13:56,Sat,29300,plain bread,1
2020/4/25 13:56,Sat,19000,plain bread,1
2020/4/25 14:25,Sat,22800,plain bread,1
2020/4/26 11:05,Sun,33300,plain bread,3
2020/4/26 13:55,Sun,15100,plain bread,1
2020/4/26 14:13,Sun,17000,plain bread,2
2020/4/27 11:28,Mon,18300,plain bread,1
2020/4/27 11:36,Mon,18800,plain bread,1
2020/4/27 11:42,Mon,30800,plain bread,1
2020/4/27 12:31,Mon,18800,plain bread,1
2020/4/27 13:22,Mon,14500,plain bread,1
2020/4/27 15:07,Mon,18800,plain bread,1
2020/4/27 16:00,Mon,18600,plain bread,1
2020/4/29 12:00,Wed,21800,plain bread,2
2020/4/29 12:24,Wed,23500,plain bread,2
2020/4/29 13:15,Wed,14800,plain bread,1
2020/4/29 13:58,Wed,15100,plain bread,1
2020/4/29 15:05,Wed,26800,plain bread,1
2020/4/30 12:17,Thur,18800,plain bread,1
2020/4/30 13:43,Thur,16800,plain bread,1
2020/4/30 15:01,Thur,18800,plain bread,1
2020/5/1 12:00,Fri,30800,plain bread,1
2020/5/1 12:10,Fri,18300,plain bread,1
2020/5/1 13:05,Fri,28400,plain bread,1
2020/5/1 15:19,Fri,14500,plain bread,1
2020/5/2 12:15,Sat,14300,plain bread,1
2019/7/14 14:51,Sun,25600,jam,1
2019/7/17 14:16,Wed,23400,jam,2
2019/7/20 11:40,Sat,22800,jam,1
2019/7/21 14:53,Sun,15300,jam,1
2019/7/26 11:37,Fri,15000,jam,1
2019/7/27 14:05,Sat,32600,jam,1
2019/7/28 13:14,Sun,19500,jam,1
2019/7/31 11:38,Wed,23300,jam,1
2019/8/1 13:39,Thur,15000,jam,1
2019/8/3 11:06,Sat,16800,jam,1
2019/8/3 13:20,Sat,16300,jam,1
2019/8/3 15:07,Sat,17900,jam,1
2019/8/4 11:41,Sun,24300,jam,1
2019/8/4 12:39,Sun,17800,jam,1
2019/8/5 11:59,Mon,22300,jam,1
2019/8/5 12:49,Mon,49300,jam,1
2019/8/5 13:54,Mon,19800,jam,1
2019/8/7 14:05,Wed,15000,jam,1
2019/8/8 12:03,Thur,16500,jam,1
2019/8/8 14:52,Thur,17000,jam,2
2019/8/8 14:58,Thur,20500,jam,2
2019/8/11 11:50,Sun,15300,jam,1
2019/8/14 11:03,Wed,41200,jam,1
2019/8/14 11:03,Wed,17800,jam,1
2019/8/14 11:25,Wed,27300,jam,1
2019/8/17 11:01,Sat,20100,jam,1
2019/8/17 12:57,Sat,29600,jam,2
2019/8/17 13:02,Sat,19800,jam,1
2019/8/17 13:19,Sat,20300,jam,1
2019/8/17 13:38,Sat,32600,jam,1
2019/8/18 12:22,Sun,15000,jam,1
2019/8/19 12:21,Mon,15800,jam,1
2019/8/19 12:34,Mon,23600,jam,1
2019/8/19 15:14,Mon,15300,jam,1
2019/8/25 11:53,Sun,15300,jam,1
2019/8/29 16:15,Thur,19000,jam,1
2019/8/30 15:05,Fri,28800,jam,1
2019/9/1 12:07,Sun,16600,jam,1
2019/9/4 13:53,Wed,22800,jam,1
2019/9/4 15:26,Wed,41100,jam,2
2019/9/6 12:09,Fri,15300,jam,1
2019/9/7 11:15,Sat,19800,jam,1
2019/9/7 15:22,Sat,26300,jam,3
2019/9/9 13:23,Mon,21000,jam,1
2019/9/11 14:57,Wed,24600,jam,1
2019/9/12 12:01,Thur,19800,jam,1
2019/9/19 16:33,Thur,16000,jam,1
2019/9/20 12:53,Fri,21000,jam,2
2019/9/21 11:12,Sat,14000,jam,1
2019/9/21 12:28,Sat,37900,jam,1
2019/9/23 15:25,Mon,24900,jam,1
2019/9/28 14:07,Sat,25800,jam,2
2019/9/29 13:59,Sun,15300,jam,1
2019/10/2 15:57,Wed,24500,jam,1
2019/10/3 11:53,Thur,18300,jam,1
2019/10/3 12:17,Thur,28300,jam,2
2019/10/6 11:25,Sun,21300,jam,2
2019/10/7 16:12,Mon,17300,jam,1
2019/10/11 14:09,Fri,20800,jam,1
2019/10/13 11:30,Sun,15000,jam,1
2019/10/13 14:42,Sun,22800,jam,1
2019/10/13 14:48,Sun,21300,jam,2
2019/10/17 13:50,Thur,32300,jam,1
2019/10/17 14:45,Thur,16300,jam,1
2019/10/18 13:57,Fri,15300,jam,1
2019/10/19 11:09,Sat,15000,jam,1
2019/10/19 11:24,Sat,16300,jam,1
2019/10/19 12:00,Sat,18300,jam,1
2019/10/20 11:34,Sun,28100,jam,1
2019/10/20 11:58,Sun,16300,jam,1
2019/10/21 11:36,Mon,20800,jam,1
2019/10/21 12:48,Mon,15800,jam,1
2019/10/23 13:56,Wed,14500,jam,1
2019/10/25 11:16,Fri,27300,jam,1
2019/10/28 13:43,Mon,15000,jam,1
2019/10/31 11:05,Thur,55800,jam,1
2019/11/1 13:52,Fri,22000,jam,1
2019/11/2 14:19,Sat,22300,jam,1
2019/11/2 14:38,Sat,16300,jam,1
2019/11/3 11:16,Sun,19800,jam,1
2019/11/4 11:53,Mon,15000,jam,1
2019/11/4 16:37,Mon,17000,jam,1
2019/11/6 16:53,Wed,16000,jam,1
2019/11/7 11:20,Thur,15300,jam,1
2019/11/7 13:33,Thur,34800,jam,2
2019/11/7 16:26,Thur,16600,jam,1
2019/11/8 14:12,Fri,23300,jam,2
2019/11/8 15:02,Fri,27800,jam,1
2019/11/8 15:12,Fri,30000,jam,1
2019/11/9 14:48,Sat,15800,jam,1
2019/11/9 16:49,Sat,15800,jam,1
2019/11/11 14:39,Mon,20300,jam,1
2019/11/11 17:25,Mon,28300,jam,1
2019/11/13 11:37,Wed,30100,jam,2
2019/11/14 12:52,Thur,16300,jam,1
2019/11/16 14:15,Sat,16600,jam,1
2019/11/16 14:21,Sat,24800,jam,1
2019/11/20 11:08,Wed,28100,jam,1
2019/11/20 15:52,Wed,15000,jam,1
2019/11/20 16:28,Wed,16300,jam,1
2019/11/22 12:25,Fri,16300,jam,1
2019/11/22 17:05,Fri,16600,jam,1
2019/11/23 15:54,Sat,19500,jam,1
2019/11/24 13:00,Sun,17300,jam,1
2019/11/24 16:32,Sun,19500,jam,1
2019/11/25 11:31,Mon,54100,jam,1
2019/11/27 12:35,Wed,15300,jam,1
2019/11/28 13:16,Thur,17500,jam,1
2019/11/30 14:24,Sat,15800,jam,1
2019/12/1 11:40,Sun,15300,jam,1
2019/12/1 12:55,Sun,19000,jam,1
2019/12/5 14:48,Thur,36000,jam,1
2019/12/6 12:26,Fri,16300,jam,1
2019/12/6 15:25,Fri,13800,jam,1
2019/12/7 13:55,Sat,28600,jam,1
2019/12/8 12:52,Sun,20300,jam,1
2019/12/8 14:57,Sun,25100,jam,1
2019/12/9 12:09,Mon,33100,jam,1
2019/12/11 15:05,Wed,14500,jam,1
2019/12/12 12:50,Thur,20600,jam,2
2019/12/12 14:34,Thur,16300,jam,1
2019/12/12 14:52,Thur,19500,jam,1
2019/12/13 15:53,Fri,16800,jam,1
2019/12/13 16:48,Fri,14000,jam,1
2019/12/19 12:16,Thur,14300,jam,1
2019/12/19 13:06,Thur,32500,jam,1
2019/12/19 13:21,Thur,14300,jam,1
2019/12/20 15:37,Fri,16800,jam,1
2019/12/25 11:55,Wed,15300,jam,1
2019/12/26 12:16,Thur,20500,jam,1
2019/12/27 11:39,Fri,16300,jam,1
2019/12/28 12:04,Sat,17000,jam,2
2019/12/29 13:03,Sun,19800,jam,1
2019/12/30 11:44,Mon,15300,jam,1
2020/1/2 11:22,Thur,15000,jam,1
2020/1/2 14:06,Thur,17600,jam,1
2020/1/5 11:13,Sun,26700,jam,1
2020/1/6 16:30,Mon,14000,jam,1
2020/1/9 11:39,Thur,28300,jam,1
2020/1/10 15:10,Fri,19300,jam,1
2020/1/12 12:19,Sun,45400,jam,1
2020/1/12 12:30,Sun,16000,jam,1
2020/1/12 14:31,Sun,14500,jam,1
2020/1/12 17:05,Sun,21300,jam,1
2020/1/13 16:55,Mon,14500,jam,1
2020/1/15 12:19,Wed,16000,jam,1
2020/1/18 13:17,Sat,15000,jam,1
2020/1/18 14:36,Sat,16500,jam,1
2020/1/19 11:49,Sun,14500,jam,1
2020/1/19 12:40,Sun,16300,jam,1
2020/1/22 15:22,Wed,14500,jam,1
2020/1/23 14:08,Thur,15000,jam,1
2020/1/23 15:26,Thur,27500,jam,1
2020/1/24 11:50,Fri,15300,jam,1
2020/1/30 15:15,Thur,21100,jam,1
2020/1/31 11:17,Fri,15300,jam,1
2020/1/31 13:47,Fri,15000,jam,1
2020/2/1 14:10,Sat,15300,jam,1
2020/2/2 11:32,Sun,22300,jam,1
2020/2/5 11:54,Wed,21500,jam,3
2020/2/5 11:56,Wed,27600,jam,1
2020/2/6 12:31,Thur,15000,jam,1
2020/2/6 15:55,Thur,15300,jam,1
2020/2/7 12:44,Fri,29300,jam,1
2020/2/8 13:27,Sat,25800,jam,1
2020/2/9 12:16,Sun,20800,jam,1
2020/2/9 12:36,Sun,15800,jam,1
2020/2/9 12:54,Sun,22300,jam,2
2020/2/9 13:47,Sun,16300,jam,1
2020/2/10 13:24,Mon,15000,jam,1
2020/2/10 14:03,Mon,16000,jam,1
2020/2/12 11:04,Wed,15000,jam,1
2020/2/12 16:21,Wed,22500,jam,1
2020/2/15 11:07,Sat,25000,jam,1
2020/2/15 12:55,Sat,20500,jam,1
2020/2/15 13:38,Sat,17300,jam,1
2020/2/19 13:01,Wed,17500,jam,1
2020/2/19 14:42,Wed,23000,jam,1
2020/2/23 14:05,Sun,22300,jam,1
2020/2/28 11:52,Fri,16500,jam,2
2020/2/28 12:04,Fri,20300,jam,1
2020/2/29 14:23,Sat,22800,jam,1
2020/3/1 12:19,Sun,20800,jam,1
2020/3/2 13:41,Mon,20300,jam,2
2020/3/5 12:00,Thur,20500,jam,2
2020/3/5 13:46,Thur,16300,jam,1
2020/3/6 13:12,Fri,27000,jam,5
2020/3/7 12:02,Sat,17300,jam,1
2020/3/8 11:19,Sun,19000,jam,1
2020/3/8 11:38,Sun,16800,jam,1
2020/3/9 12:24,Mon,16000,jam,1
2020/3/11 12:05,Wed,26100,jam,1
2020/3/12 13:56,Thur,47000,jam,1
2020/3/14 13:49,Sat,15800,jam,1
2020/3/18 12:08,Wed,14000,jam,1
2020/3/19 11:07,Thur,14000,jam,1
2020/3/21 11:28,Sat,31600,jam,1
2020/3/21 12:07,Sat,14300,jam,1
2020/3/26 11:04,Thur,16600,jam,1
2020/3/27 13:36,Fri,24800,jam,1
2020/3/27 14:19,Fri,15300,jam,1
2020/3/28 11:55,Sat,40300,jam,2
2020/3/28 12:17,Sat,15500,jam,1
2020/3/29 12:15,Sun,26900,jam,1
2020/3/29 12:59,Sun,24300,jam,1
2020/3/29 13:28,Sun,15000,jam,1
2020/4/2 11:54,Thur,15300,jam,1
2020/4/2 12:11,Thur,28800,jam,1
2020/4/4 11:54,Sat,18300,jam,1
2020/4/5 16:03,Sun,15000,jam,1
2020/4/6 15:55,Mon,27100,jam,1
2020/4/8 13:20,Wed,17100,jam,1
2020/4/9 11:10,Thur,26600,jam,1
2020/4/18 11:46,Sat,33900,jam,1
2020/4/18 13:42,Sat,15000,jam,1
2020/4/20 14:46,Mon,64000,jam,2
2020/4/25 13:56,Sat,29300,jam,1
2020/4/26 13:01,Sun,16300,jam,1
2020/4/26 14:05,Sun,17600,jam,1
2020/4/27 11:36,Mon,18800,jam,1
2019/7/11 15:35,Thur,23800,americano,1
2019/7/14 11:15,Sun,27600,americano,3
2019/7/20 11:35,Sat,18800,americano,1
2019/7/20 13:56,Sat,17800,americano,1
2019/7/21 12:12,Sun,17800,americano,1
2019/7/21 13:45,Sun,22300,americano,2
2019/7/22 11:38,Mon,15600,americano,1
2019/7/24 13:24,Wed,18800,americano,1
2019/7/24 14:28,Wed,26300,americano,1
2019/7/25 11:57,Thur,26800,americano,1
2019/7/25 13:42,Thur,15300,americano,1
2019/7/25 15:09,Thur,14300,americano,1
2019/7/26 13:24,Fri,28100,americano,1
2019/7/27 11:29,Sat,18800,americano,1
2019/7/28 12:47,Sun,14300,americano,1
2019/7/29 13:25,Mon,18100,americano,1
2019/7/29 13:53,Mon,28000,americano,2
2019/7/31 11:09,Wed,15600,americano,1
2019/7/31 11:44,Wed,30200,americano,1
2019/7/31 13:18,Wed,27300,americano,2
2019/7/31 13:19,Wed,15300,americano,1
2019/8/3 13:18,Sat,18300,americano,2
2019/8/4 11:02,Sun,34800,americano,2
2019/8/7 13:59,Wed,14800,americano,2
2019/8/8 13:55,Thur,22300,americano,1
2019/8/8 14:52,Thur,17000,americano,1
2019/8/10 11:02,Sat,15300,americano,1
2019/8/11 11:02,Sun,16800,americano,1
2019/8/11 11:08,Sun,17800,americano,1
2019/8/12 13:56,Mon,19100,americano,1
2019/8/12 14:08,Mon,32100,americano,2
2019/8/14 11:22,Wed,29000,americano,1
2019/8/14 11:25,Wed,27300,americano,1
2019/8/14 11:41,Wed,14300,americano,1
2019/8/15 11:53,Thur,15000,americano,1
2019/8/17 11:30,Sat,24300,americano,1
2019/8/17 12:40,Sat,18800,americano,1
2019/8/17 13:19,Sat,20300,americano,1
2019/8/18 11:23,Sun,17800,americano,1
2019/8/18 13:30,Sun,36100,americano,1
2019/8/19 11:29,Mon,22800,americano,2
2019/8/19 13:24,Mon,14800,americano,1
2019/8/19 13:53,Mon,24300,americano,1
2019/8/19 14:20,Mon,15300,americano,1
2019/8/21 11:04,Wed,18800,americano,1
2019/8/21 13:01,Wed,15800,americano,1
2019/8/21 13:43,Wed,21100,americano,1
2019/8/23 12:47,Fri,19800,americano,1
2019/8/24 11:42,Sat,14300,americano,1
2019/8/25 11:04,Sun,15300,americano,1
2019/8/26 11:16,Mon,17800,americano,1
2019/8/26 16:06,Mon,14000,americano,1
2019/8/28 13:57,Wed,33400,americano,2
2019/8/29 13:12,Thur,24000,americano,1
2019/8/29 13:28,Thur,53800,americano,2
2019/8/30 11:18,Fri,39300,americano,1
2019/8/30 13:10,Fri,14300,americano,1
2019/8/30 15:25,Fri,28300,americano,2
2019/8/30 16:18,Fri,18800,americano,1
2019/9/1 14:05,Sun,33100,americano,2
2019/9/4 11:49,Wed,23000,americano,1
2019/9/4 12:04,Wed,14800,americano,1
2019/9/4 13:31,Wed,15300,americano,1
2019/9/4 15:26,Wed,41100,americano,2
2019/9/5 13:30,Thur,15600,americano,1
2019/9/7 11:10,Sat,23600,americano,1
2019/9/7 11:57,Sat,22800,americano,2
2019/9/9 13:23,Mon,21000,americano,1
2019/9/9 14:17,Mon,18800,americano,1
2019/9/11 13:06,Wed,14300,americano,1
2019/9/11 14:22,Wed,15300,americano,1
2019/9/12 11:16,Thur,15800,americano,1
2019/9/12 12:01,Thur,19800,americano,1
2019/9/12 12:40,Thur,23300,americano,2
2019/9/14 12:06,Sat,19300,americano,1
2019/9/18 11:32,Wed,16500,americano,1
2019/9/18 16:42,Wed,15500,americano,1
2019/9/19 13:24,Thur,15300,americano,1
2019/9/19 14:07,Thur,23300,americano,3
2019/9/19 16:04,Thur,15600,americano,1
2019/9/19 16:17,Thur,30500,americano,1
2019/9/21 13:38,Sat,18800,americano,1
2019/9/21 13:56,Sat,25100,americano,1
2019/9/21 14:15,Sat,19300,americano,1
2019/9/22 12:54,Sun,21300,americano,1
2019/9/23 12:43,Mon,15000,americano,1
2019/9/25 16:10,Wed,17300,americano,2
2019/9/26 11:48,Thur,14500,americano,1
2019/9/27 12:30,Fri,21300,americano,1
2019/9/28 11:11,Sat,28700,americano,1
2019/9/28 11:27,Sat,14300,americano,1
2019/9/28 12:37,Sat,21800,americano,1
2019/9/28 13:52,Sat,27100,americano,1
2019/9/28 16:01,Sat,15300,americano,1
2019/9/29 13:50,Sun,15300,americano,1
2019/9/30 15:17,Mon,15500,americano,1
2019/10/2 11:58,Wed,19300,americano,1
2019/10/3 11:07,Thur,17800,americano,1
2019/10/3 11:20,Thur,14300,americano,1
2019/10/3 13:42,Thur,18800,americano,1
2019/10/3 15:53,Thur,16000,americano,1
2019/10/6 11:08,Sun,15800,americano,1
2019/10/6 12:51,Sun,25300,americano,2
2019/10/7 11:12,Mon,19800,americano,1
2019/10/9 11:09,Wed,14300,americano,1
2019/10/11 14:29,Fri,15500,americano,1
2019/10/12 13:02,Sat,19300,americano,2
2019/10/12 13:23,Sat,15300,americano,1
2019/10/13 11:08,Sun,14500,americano,2
2019/10/13 11:18,Sun,22800,americano,2
2019/10/13 11:20,Sun,25800,americano,1
2019/10/13 12:55,Sun,18500,americano,1
2019/10/13 14:42,Sun,22800,americano,1
2019/10/13 14:54,Sun,27600,americano,2
2019/10/16 13:03,Wed,23300,americano,1
2019/10/16 15:01,Wed,15600,americano,1
2019/10/19 11:13,Sat,29000,americano,2
2019/10/19 11:45,Sat,18000,americano,1
2019/10/19 12:00,Sat,18300,americano,1
2019/10/19 14:45,Sat,14800,americano,1
2019/10/20 12:49,Sun,14300,americano,1
2019/10/21 12:48,Mon,15800,americano,1
2019/10/23 13:12,Wed,23600,americano,1
2019/10/24 12:35,Thur,28300,americano,2
2019/10/25 12:31,Fri,14300,americano,1
2019/10/25 12:33,Fri,15000,americano,1
2019/10/27 11:33,Sun,17800,americano,1
2019/10/27 13:01,Sun,14800,americano,1
2019/10/27 13:42,Sun,18500,americano,2
2019/10/31 13:29,Thur,25000,americano,2
2019/11/2 12:44,Sat,17500,americano,1
2019/11/2 16:03,Sat,14800,americano,2
2019/11/2 16:40,Sat,28800,americano,2
2019/11/2 16:54,Sat,14300,americano,1
2019/11/3 12:01,Sun,33700,americano,1
2019/11/3 12:25,Sun,17800,americano,1
2019/11/4 13:17,Mon,17500,americano,1
2019/11/7 14:44,Thur,26800,americano,3
2019/11/8 13:12,Fri,36000,americano,2
2019/11/8 15:02,Fri,27800,americano,1
2019/11/9 14:48,Sat,15800,americano,1
2019/11/10 11:20,Sun,32800,americano,1
2019/11/10 11:55,Sun,29100,americano,1
2019/11/11 12:59,Mon,15300,americano,1
2019/11/13 11:05,Wed,22300,americano,1
2019/11/14 13:10,Thur,39300,americano,1
2019/11/15 11:50,Fri,18500,americano,1
2019/11/16 16:21,Sat,14300,americano,1
2019/11/17 11:09,Sun,15800,americano,1
2019/11/17 11:40,Sun,17500,americano,1
2019/11/17 14:12,Sun,14000,americano,1
2019/11/17 15:58,Sun,14800,americano,1
2019/11/21 14:44,Thur,19600,americano,2
2019/11/23 13:30,Sat,17800,americano,1
2019/11/23 15:30,Sat,22300,americano,1
2019/11/24 13:34,Sun,39000,americano,1
2019/11/24 13:39,Sun,18800,americano,1
2019/11/24 14:59,Sun,18800,americano,3
2019/11/24 16:32,Sun,19500,americano,1
2019/11/27 13:07,Wed,14800,americano,1
2019/11/29 14:42,Fri,15300,americano,1
2019/11/30 11:09,Sat,20400,americano,1
2019/12/1 11:48,Sun,15300,americano,1
2019/12/1 12:23,Sun,23100,americano,2
2019/12/1 12:55,Sun,19000,americano,1
2019/12/2 16:22,Mon,14300,americano,1
2019/12/4 11:10,Wed,23300,americano,1
2019/12/4 11:47,Wed,17500,americano,1
2019/12/4 13:51,Wed,15300,americano,1
2019/12/6 12:23,Fri,15000,americano,1
2019/12/6 15:25,Fri,13800,americano,1
2019/12/8 11:02,Sun,17300,americano,2
2019/12/8 12:22,Sun,15300,americano,1
2019/12/8 12:33,Sun,23000,americano,1
2019/12/8 12:41,Sun,22600,americano,1
2019/12/8 13:44,Sun,28100,americano,1
2019/12/8 13:57,Sun,17000,americano,1
2019/12/8 13:57,Sun,18300,americano,1
2019/12/8 14:06,Sun,16100,americano,1
2019/12/9 13:35,Mon,29800,americano,1
2019/12/9 14:19,Mon,16600,americano,1
2019/12/11 11:26,Wed,15300,americano,1
2019/12/11 11:36,Wed,22000,americano,1
2019/12/11 11:37,Wed,18800,americano,1
2019/12/11 15:05,Wed,14500,americano,1
2019/12/11 15:07,Wed,14300,americano,1
2019/12/12 12:57,Thur,23300,americano,3
2019/12/13 11:27,Fri,21100,americano,1
2019/12/13 12:40,Fri,22800,americano,4
2019/12/13 15:53,Fri,16800,americano,1
2019/12/15 14:06,Sun,45400,americano,3
2019/12/16 11:12,Mon,15300,americano,1
2019/12/20 11:53,Fri,16300,americano,1
2019/12/20 15:37,Fri,16800,americano,1
2019/12/21 12:02,Sat,19800,americano,1
2019/12/21 12:17,Sat,15300,americano,1
2019/12/21 12:24,Sat,25300,americano,2
2019/12/22 12:21,Sun,19300,americano,2
2019/12/22 13:54,Sun,15300,americano,1
2019/12/22 14:35,Sun,19300,americano,2
2019/12/22 15:10,Sun,15000,americano,1
2019/12/23 13:05,Mon,25600,americano,1
2019/12/23 13:37,Mon,27300,americano,2
2019/12/24 11:13,Tues,15300,americano,1
2019/12/25 14:47,Wed,20000,americano,1
2019/12/26 14:06,Thur,15600,americano,1
2019/12/28 13:12,Sat,18800,americano,1
2019/12/28 13:47,Sat,18800,americano,1
2019/12/29 11:34,Sun,15300,americano,1
2019/12/29 14:32,Sun,15000,americano,1
2019/12/29 14:39,Sun,14000,americano,1
2019/12/29 14:42,Sun,22800,americano,1
2019/12/29 16:02,Sun,25500,americano,1
2019/12/30 11:27,Mon,19800,americano,1
2020/1/2 12:17,Thur,16500,americano,1
2020/1/4 11:10,Sat,14800,americano,1
2020/1/4 14:36,Sat,15300,americano,1
2020/1/5 11:13,Sun,26700,americano,1
2020/1/5 11:23,Sun,18000,americano,1
2020/1/5 14:54,Sun,14300,americano,1
2020/1/5 16:54,Sun,15300,americano,1
2020/1/6 16:00,Mon,14300,americano,1
2020/1/8 16:33,Wed,26900,americano,1
2020/1/9 13:44,Thur,21900,americano,1
2020/1/9 13:59,Thur,19800,americano,1
2020/1/10 12:51,Fri,21800,americano,1
2020/1/10 14:11,Fri,14300,americano,1
2020/1/10 15:10,Fri,19300,americano,1
2020/1/11 14:09,Sat,14800,americano,1
2020/1/12 14:31,Sun,14500,americano,1
2020/1/12 16:05,Sun,14500,americano,2
2020/1/12 16:23,Sun,19600,americano,2
2020/1/13 11:59,Mon,15300,americano,1
2020/1/15 14:46,Wed,18800,americano,1
2020/1/17 12:26,Fri,16300,americano,1
2020/1/18 13:17,Sat,15000,americano,1
2020/1/18 14:52,Sat,14300,americano,1
2020/1/19 11:09,Sun,14800,americano,1
2020/1/19 11:09,Sun,31100,americano,1
2020/1/19 13:22,Sun,21100,americano,1
2020/1/19 14:18,Sun,23900,americano,1
2020/1/19 15:54,Sun,27400,americano,1
2020/1/19 16:21,Sun,19800,americano,1
2020/1/19 16:52,Sun,17800,americano,1
2020/1/20 11:32,Mon,15000,americano,1
2020/1/22 11:50,Wed,18100,americano,1
2020/1/22 14:17,Wed,18500,americano,1
2020/1/22 15:22,Wed,14500,americano,1
2020/1/23 11:45,Thur,18800,americano,1
2020/1/23 14:08,Thur,15000,americano,1
2020/1/23 15:26,Thur,27500,americano,1
2020/1/27 12:57,Mon,20300,americano,1
2020/1/29 11:09,Wed,15300,americano,1
2020/1/30 11:53,Thur,28800,americano,1
2020/1/30 12:26,Thur,26600,americano,1
2020/1/31 13:39,Fri,15000,americano,1
2020/2/1 15:49,Sat,19600,americano,2
2020/2/2 11:49,Sun,30800,americano,2
2020/2/2 13:10,Sun,17800,americano,1
2020/2/5 12:36,Wed,17500,americano,1
2020/2/5 13:48,Wed,14300,americano,1
2020/2/7 12:39,Fri,33300,americano,1
2020/2/8 11:31,Sat,23600,americano,2
2020/2/8 13:24,Sat,16500,americano,1
2020/2/9 11:03,Sun,30000,americano,1
2020/2/9 11:52,Sun,34300,americano,2
2020/2/9 12:16,Sun,20800,americano,2
2020/2/9 12:33,Sun,19800,americano,1
2020/2/9 12:36,Sun,15800,americano,1
2020/2/9 16:32,Sun,14800,americano,2
2020/2/12 11:03,Wed,16800,americano,1
2020/2/12 11:12,Wed,16300,americano,1
2020/2/13 11:35,Thur,14300,americano,1
2020/2/13 12:28,Thur,18300,americano,2
2020/2/13 15:22,Thur,31300,americano,5
2020/2/14 12:44,Fri,27300,americano,2
2020/2/15 12:15,Sat,19000,americano,2
2020/2/15 12:31,Sat,16500,americano,1
2020/2/15 12:50,Sat,17500,americano,1
2020/2/15 12:55,Sat,20500,americano,1
2020/2/15 14:03,Sat,32100,americano,1
2020/2/16 11:30,Sun,19800,americano,1
2020/2/16 11:57,Sun,26600,americano,2
2020/2/16 12:03,Sun,14300,americano,1
2020/2/16 12:43,Sun,18300,americano,2
2020/2/16 13:09,Sun,15000,americano,1
2020/2/16 13:51,Sun,25300,americano,2
2020/2/16 14:06,Sun,15600,americano,1
2020/2/17 12:24,Mon,15800,americano,1
2020/2/20 12:51,Thur,15600,americano,1
2020/2/21 11:14,Fri,15300,americano,1
2020/2/22 13:24,Sat,17500,americano,1
2020/2/22 17:20,Sat,15300,americano,1
2020/2/23 11:04,Sun,35300,americano,1
2020/2/23 11:13,Sun,27200,americano,2
2020/2/23 11:41,Sun,17000,americano,2
2020/2/23 12:25,Sun,15300,americano,1
2020/2/23 12:38,Sun,18800,americano,1
2020/2/23 12:49,Sun,32000,americano,1
2020/2/23 13:35,Sun,18500,americano,1
2020/2/23 14:07,Sun,24000,americano,2
2020/2/23 16:29,Sun,30100,americano,1
2020/2/24 12:26,Mon,29900,americano,2
2020/2/26 11:12,Wed,31600,americano,1
2020/2/26 13:38,Wed,20800,americano,1
2020/2/26 13:46,Wed,14500,americano,1
2020/2/27 11:23,Thur,23800,americano,2
2020/2/27 14:22,Thur,22000,americano,1
2020/2/28 11:02,Fri,33800,americano,1
2020/2/28 12:10,Fri,24500,americano,3
2020/2/28 12:28,Fri,51100,americano,1
2020/2/29 11:35,Sat,16300,americano,1
2020/2/29 12:44,Sat,23600,americano,3
2020/2/29 15:34,Sat,19300,americano,2
2020/2/29 16:31,Sat,23600,americano,2
2020/3/1 11:14,Sun,23800,americano,2
2020/3/1 11:18,Sun,21100,americano,1
2020/3/1 12:45,Sun,22300,americano,1
2020/3/1 14:27,Sun,27300,americano,2
2020/3/1 14:57,Sun,14500,americano,2
2020/3/2 14:00,Mon,15300,americano,1
2020/3/5 12:00,Thur,20500,americano,1
2020/3/5 12:11,Thur,17800,americano,1
2020/3/5 13:33,Thur,17600,americano,1
2020/3/5 13:39,Thur,18500,americano,1
2020/3/5 13:48,Thur,27800,americano,1
2020/3/5 14:20,Thur,15600,americano,1
2020/3/6 13:24,Fri,21100,americano,1
2020/3/6 14:34,Fri,18800,americano,1
2020/3/7 13:20,Sat,19600,americano,2
2020/3/7 13:53,Sat,28100,americano,1
2020/3/7 14:40,Sat,14000,americano,1
2020/3/8 12:28,Sun,32800,americano,1
2020/3/8 14:07,Sun,22300,americano,1
2020/3/9 11:23,Mon,21300,americano,1
2020/3/9 12:47,Mon,15600,americano,1
2020/3/12 11:42,Thur,27800,americano,1
2020/3/13 13:48,Fri,15300,americano,1
2020/3/14 13:49,Sat,15800,americano,1
2020/3/14 14:11,Sat,15300,americano,1
2020/3/15 14:09,Sun,21800,americano,2
2020/3/16 12:46,Mon,26800,americano,1
2020/3/16 13:19,Mon,15300,americano,1
2020/3/18 11:32,Wed,20100,americano,1
2020/3/19 11:06,Thur,16300,americano,1
2020/3/20 11:29,Fri,25800,americano,2
2020/3/20 13:48,Fri,19300,americano,2
2020/3/21 11:04,Sat,27800,americano,1
2020/3/21 11:28,Sat,31600,americano,2
2020/3/21 13:38,Sat,17500,americano,1
2020/3/21 14:17,Sat,33100,americano,1
2020/3/22 11:22,Sun,14800,americano,2
2020/3/22 11:43,Sun,32900,americano,1
2020/3/22 12:19,Sun,16600,americano,1
2020/3/22 13:19,Sun,21800,americano,2
2020/3/22 13:52,Sun,15600,americano,1
2020/3/22 14:31,Sun,19500,americano,1
2020/3/22 15:21,Sun,19300,americano,2
2020/3/23 12:37,Mon,34100,americano,1
2020/3/25 14:38,Wed,14000,americano,1
2020/3/25 16:17,Wed,20300,americano,1
2020/3/27 11:51,Fri,14800,americano,1
2020/3/27 15:36,Fri,28800,americano,1
2020/3/27 15:48,Fri,14000,americano,1
2020/3/28 11:55,Sat,40300,americano,1
2020/3/28 13:39,Sat,24100,americano,1
2020/3/29 11:25,Sun,27800,americano,1
2020/3/29 12:31,Sun,19300,americano,1
2020/3/29 14:02,Sun,26300,americano,2
2020/3/29 15:37,Sun,15300,americano,1
2020/4/1 11:15,Wed,29400,americano,1
2020/4/1 13:49,Wed,28800,americano,1
2020/4/1 14:28,Wed,18800,americano,1
2020/4/2 16:02,Thur,14300,americano,1
2020/4/3 11:44,Fri,14300,americano,1
2020/4/4 11:54,Sat,18300,americano,1
2020/4/5 14:41,Sun,26300,americano,1
2020/4/6 17:21,Mon,15300,americano,1
2020/4/8 11:40,Wed,25800,americano,2
2020/4/8 12:10,Wed,19800,americano,1
2020/4/9 12:00,Thur,30800,americano,1
2020/4/9 15:44,Thur,14300,americano,1
2020/4/10 14:55,Fri,14300,americano,1
2020/4/12 12:08,Sun,24300,americano,1
2020/4/12 14:32,Sun,14300,americano,1
2020/4/13 14:06,Mon,27000,americano,3
2020/4/13 15:19,Mon,26300,americano,1
2020/4/15 11:43,Wed,27100,americano,3
2020/4/15 12:36,Wed,14300,americano,1
2020/4/15 15:59,Wed,15600,americano,1
2020/4/17 11:45,Fri,20100,americano,1
2020/4/18 12:22,Sat,16300,americano,1
2020/4/18 14:10,Sat,36000,americano,2
2020/4/18 14:17,Sat,14500,americano,1
2020/4/19 11:09,Sun,24100,americano,2
2020/4/23 12:57,Thur,17500,americano,1
2020/4/24 14:03,Fri,14000,americano,1
2020/4/24 14:32,Fri,16600,americano,1
2020/4/25 11:42,Sat,36600,americano,2
2020/4/26 11:51,Sun,28300,americano,1
2020/4/26 12:00,Sun,23300,americano,1
2020/4/26 15:14,Sun,27300,americano,2
2020/4/27 11:56,Mon,22300,americano,1
2020/4/27 12:31,Mon,18800,americano,1
2020/4/27 14:42,Mon,14300,americano,1
2020/4/29 15:05,Wed,26800,americano,1
2020/4/30 12:17,Thur,18800,americano,1
2020/4/30 15:01,Thur,18800,americano,1
2020/5/1 11:47,Fri,19800,americano,1
2020/5/1 12:00,Fri,30800,americano,2
2020/5/1 13:55,Fri,21300,americano,1
2020/5/2 11:39,Sat,19800,americano,1
2019/7/17 13:23,Wed,14800,croissant,1
2019/7/19 11:43,Fri,14800,croissant,1
2019/7/19 12:36,Fri,21800,croissant,1
2019/7/19 13:35,Fri,14800,croissant,1
2019/7/19 14:12,Fri,58000,croissant,16
2019/7/19 15:33,Fri,35900,croissant,3
2019/7/20 11:35,Sat,18800,croissant,1
2019/7/20 13:19,Sat,20500,croissant,2
2019/7/20 13:44,Sat,18600,croissant,1
2019/7/20 13:56,Sat,17800,croissant,1
2019/7/21 11:07,Sun,18600,croissant,1
2019/7/21 11:42,Sun,17300,croissant,1
2019/7/21 12:47,Sun,21000,croissant,1
2019/7/21 13:37,Sun,19300,croissant,1
2019/7/21 13:45,Sun,22300,croissant,1
2019/7/21 14:05,Sun,18300,croissant,1
2019/7/21 14:53,Sun,15300,croissant,1
2019/7/22 12:16,Mon,19300,croissant,1
2019/7/22 12:24,Mon,18300,croissant,1
2019/7/22 12:41,Mon,18300,croissant,2
2019/7/22 16:54,Mon,18600,croissant,1
2019/7/24 13:24,Wed,18800,croissant,1
2019/7/25 11:57,Thur,26800,croissant,1
2019/7/25 12:35,Thur,38000,croissant,1
2019/7/25 13:40,Thur,19600,croissant,1
2019/7/25 15:09,Thur,14300,croissant,1
2019/7/26 11:26,Fri,25300,croissant,3
2019/7/26 11:23,Fri,73200,croissant,6
2019/7/26 11:36,Fri,1293000,croissant,5
2019/7/26 11:37,Fri,15000,croissant,1
2019/7/27 11:57,Sat,21800,croissant,1
2019/7/27 12:00,Sat,18600,croissant,1
2019/7/27 12:20,Sat,22800,croissant,1
2019/7/27 12:26,Sat,17000,croissant,3
2019/7/28 11:17,Sun,17300,croissant,1
2019/7/28 12:48,Sun,14800,croissant,1
2019/7/28 13:13,Sun,25600,croissant,2
2019/7/29 11:08,Mon,24800,croissant,3
2019/7/29 11:12,Mon,24100,croissant,1
2019/7/29 12:15,Mon,18300,croissant,1
2019/7/29 13:25,Mon,18100,croissant,1
2019/7/29 13:36,Mon,28000,croissant,1
2019/7/31 11:25,Wed,30100,croissant,2
2019/7/31 11:38,Wed,23300,croissant,1
2019/8/1 11:50,Thur,14800,croissant,1
2019/8/1 12:02,Thur,21100,croissant,1
2019/8/1 12:24,Thur,32600,croissant,2
2019/8/1 13:37,Thur,15100,croissant,1
2019/8/1 14:56,Thur,23000,croissant,4
2019/8/3 11:03,Sat,16000,croissant,2
2019/8/3 11:05,Sat,29100,croissant,1
2019/8/3 11:08,Sat,22800,croissant,1
2019/8/3 11:20,Sat,16600,croissant,1
2019/8/3 11:53,Sat,18800,croissant,1
2019/8/3 13:18,Sat,18300,croissant,1
2019/8/3 13:20,Sat,16300,croissant,1
2019/8/4 11:02,Sun,34800,croissant,2
2019/8/4 11:04,Sun,31600,croissant,1
2019/8/4 11:52,Sun,22100,croissant,1
2019/8/4 12:30,Sun,19500,croissant,2
2019/8/5 12:14,Mon,26600,croissant,1
2019/8/5 12:49,Mon,49300,croissant,1
2019/8/5 13:54,Mon,19800,croissant,1
2019/8/5 14:53,Mon,16300,croissant,2
2019/8/7 11:03,Wed,16300,croissant,2
2019/8/7 12:17,Wed,15300,croissant,1
2019/8/7 12:20,Wed,27300,croissant,1
2019/8/7 13:28,Wed,17600,croissant,2
2019/8/7 14:05,Wed,15000,croissant,1
2019/8/8 12:56,Thur,16000,croissant,1
2019/8/8 13:26,Thur,17300,croissant,1
2019/8/8 13:55,Thur,22300,croissant,1
2019/8/8 13:57,Thur,32400,croissant,2
2019/8/9 11:34,Fri,17000,croissant,2
2019/8/9 12:31,Fri,18600,croissant,1
2019/8/9 15:22,Fri,35800,croissant,2
2019/8/10 11:09,Sat,17300,croissant,1
2019/8/10 11:27,Sat,36800,croissant,1
2019/8/10 11:38,Sat,25300,croissant,1
2019/8/10 13:15,Sat,16600,croissant,1
2019/8/10 13:31,Sat,24400,croissant,1
2019/8/11 11:01,Sun,21800,croissant,1
2019/8/11 11:03,Sun,16000,croissant,1
2019/8/11 11:40,Sun,38900,croissant,2
2019/8/12 11:05,Mon,28400,croissant,1
2019/8/12 11:08,Mon,20800,croissant,1
2019/8/12 11:48,Mon,16300,croissant,1
2019/8/12 12:39,Mon,24300,croissant,3
2019/8/12 13:56,Mon,19100,croissant,1
2019/8/14 11:03,Wed,41200,croissant,2
2019/8/14 11:03,Wed,17800,croissant,1
2019/8/14 11:07,Wed,17300,croissant,1
2019/8/14 11:22,Wed,29000,croissant,3
2019/8/14 11:25,Wed,27300,croissant,1
2019/8/14 11:31,Wed,22300,croissant,1
2019/8/14 11:41,Wed,14300,croissant,1
2019/8/15 11:15,Thur,16100,croissant,1
2019/8/15 11:23,Thur,22100,croissant,1
2019/8/15 11:50,Thur,58000,croissant,16
2019/8/16 11:05,Fri,14800,croissant,1
2019/8/17 11:03,Sat,18300,croissant,1
2019/8/17 12:57,Sat,29600,croissant,1
2019/8/17 13:02,Sat,19800,croissant,1
2019/8/18 11:01,Sun,17300,croissant,2
2019/8/18 11:06,Sun,36900,croissant,2
2019/8/18 11:09,Sun,22800,croissant,1
2019/8/18 12:24,Sun,16000,croissant,1
2019/8/18 13:06,Sun,14300,croissant,1
2019/8/18 13:29,Sun,14800,croissant,1
2019/8/18 13:30,Sun,36100,croissant,2
2019/8/19 11:29,Mon,22800,croissant,1
2019/8/19 15:30,Mon,18800,croissant,1
2019/8/21 11:02,Wed,19900,croissant,1
2019/8/21 11:04,Wed,18800,croissant,1
2019/8/21 11:28,Wed,54000,croissant,1
2019/8/21 12:51,Wed,17500,croissant,1
2019/8/21 13:15,Wed,17000,croissant,2
2019/8/21 14:11,Wed,25000,croissant,2
2019/8/22 11:48,Thur,14800,croissant,1
2019/8/22 12:08,Thur,23300,croissant,1
2019/8/22 13:07,Thur,26600,croissant,1
2019/8/22 15:24,Thur,26000,croissant,1
2019/8/23 11:28,Fri,42200,croissant,3
2019/8/23 12:42,Fri,14100,croissant,1
2019/8/23 15:32,Fri,22000,croissant,1
2019/8/24 11:06,Sat,16000,croissant,2
2019/8/24 11:14,Sat,23100,croissant,1
2019/8/24 11:14,Sat,17300,croissant,1
2019/8/24 11:18,Sat,24900,croissant,1
2019/8/24 11:19,Sat,17300,croissant,3
2019/8/24 11:42,Sat,14300,croissant,1
2019/8/24 11:55,Sat,20800,croissant,2
2019/8/25 11:53,Sun,15300,croissant,1
2019/8/25 12:23,Sun,25300,croissant,1
2019/8/26 11:30,Mon,18000,croissant,1
2019/8/26 12:05,Mon,14800,croissant,1
2019/8/28 11:19,Wed,16300,croissant,1
2019/8/28 12:20,Wed,30400,croissant,2
2019/8/28 12:46,Wed,18600,croissant,2
2019/8/29 12:25,Thur,18300,croissant,2
2019/8/29 13:28,Thur,53800,croissant,1
2019/8/29 14:31,Thur,15500,croissant,1
2019/8/29 15:08,Thur,15000,croissant,1
2019/8/30 13:10,Fri,14300,croissant,1
2019/8/30 14:13,Fri,16000,croissant,1
2019/8/31 11:20,Sat,16300,croissant,1
2019/8/31 12:31,Sat,16300,croissant,1
2019/9/1 11:40,Sun,22100,croissant,1
2019/9/1 14:05,Sun,33100,croissant,1
2019/9/1 14:35,Sun,14800,croissant,1
2019/9/2 12:12,Mon,31400,croissant,1
2019/9/2 15:13,Mon,23500,croissant,1
2019/9/4 12:06,Wed,18600,croissant,1
2019/9/4 12:31,Wed,18600,croissant,1
2019/9/4 12:58,Wed,17000,croissant,1
2019/9/4 13:19,Wed,19300,croissant,1
2019/9/4 13:53,Wed,22800,croissant,1
2019/9/4 14:52,Wed,25600,croissant,2
2019/9/4 16:28,Wed,18600,croissant,2
2019/9/5 11:27,Thur,21800,croissant,1
2019/9/6 11:14,Fri,16300,croissant,2
2019/9/6 16:29,Fri,39700,croissant,2
2019/9/7 11:10,Sat,23600,croissant,1
2019/9/7 11:40,Sat,14800,croissant,1
2019/9/7 11:42,Sat,18800,croissant,1
2019/9/7 11:47,Sat,22500,croissant,1
2019/9/7 16:23,Sat,27400,croissant,1
2019/9/8 11:37,Sun,26000,croissant,2
2019/9/9 11:12,Mon,23100,croissant,1
2019/9/9 13:01,Mon,14800,croissant,1
2019/9/9 15:42,Mon,21800,croissant,2
2019/9/9 16:01,Mon,18600,croissant,2
2019/9/11 13:21,Wed,33400,croissant,1
2019/9/11 14:48,Wed,16300,croissant,1
2019/9/12 12:00,Thur,14300,croissant,1
2019/9/12 12:45,Thur,22100,croissant,1
2019/9/12 13:25,Thur,15100,croissant,1
2019/9/12 13:51,Thur,27600,croissant,1
2019/9/14 11:07,Sat,22800,croissant,1
2019/9/14 11:15,Sat,19500,croissant,3
2019/9/14 11:41,Sat,15100,croissant,1
2019/9/15 11:57,Sun,16000,croissant,1
2019/9/15 12:13,Sun,32600,croissant,2
2019/9/15 13:34,Sun,24400,croissant,1
2019/9/15 13:38,Sun,16300,croissant,2
2019/9/15 15:28,Sun,57900,croissant,2
2019/9/18 15:24,Wed,17000,croissant,1
2019/9/19 16:27,Thur,34600,croissant,2
2019/9/20 11:06,Fri,39700,croissant,2
2019/9/20 13:28,Fri,14800,croissant,1
2019/9/20 14:58,Fri,18300,croissant,1
2019/9/21 11:08,Sat,39300,croissant,3
2019/9/21 11:12,Sat,14000,croissant,1
2019/9/21 11:39,Sat,21100,croissant,2
2019/9/21 12:01,Sat,17000,croissant,1
2019/9/21 13:38,Sat,18800,croissant,1
2019/9/22 11:09,Sun,14100,croissant,1
2019/9/22 11:33,Sun,14500,croissant,1
2019/9/22 11:46,Sun,18600,croissant,2
2019/9/22 12:05,Sun,17000,croissant,2
2019/9/22 12:06,Sun,22300,croissant,2
2019/9/22 12:07,Sun,34100,croissant,2
2019/9/22 12:08,Sun,17800,croissant,1
2019/9/22 12:19,Sun,24300,croissant,1
2019/9/22 12:54,Sun,21300,croissant,3
2019/9/22 12:56,Sun,15100,croissant,1
2019/9/23 11:25,Mon,16300,croissant,1
2019/9/23 15:54,Mon,20500,croissant,4
2019/9/25 12:21,Wed,21500,croissant,2
2019/9/26 11:48,Thur,14500,croissant,1
2019/9/27 16:12,Fri,36100,croissant,3
2019/9/28 11:27,Sat,14300,croissant,1
2019/9/28 12:27,Sat,21800,croissant,1
2019/9/28 12:37,Sat,21800,croissant,1
2019/9/28 12:41,Sat,22100,croissant,1
2019/9/28 12:52,Sat,41400,croissant,2
2019/9/28 13:52,Sat,27100,croissant,1
2019/9/29 11:06,Sun,18800,croissant,1
2019/9/29 11:30,Sun,17000,croissant,1
2019/9/29 11:49,Sun,17300,croissant,1
2019/9/29 12:00,Sun,14800,croissant,1
2019/9/29 13:59,Sun,15300,croissant,1
2019/9/29 15:22,Sun,27800,croissant,3
2019/9/30 13:03,Mon,18600,croissant,2
2019/9/30 13:43,Mon,27600,croissant,2
2019/9/30 16:04,Mon,16000,croissant,1
2019/10/2 14:16,Wed,17000,croissant,2
2019/10/2 14:18,Wed,16000,croissant,1
2019/10/2 16:12,Wed,15000,croissant,1
2019/10/3 14:25,Thur,22800,croissant,2
2019/10/3 14:50,Thur,21800,croissant,1
2019/10/5 12:39,Sat,31800,croissant,1
2019/10/6 11:08,Sun,15800,croissant,1
2019/10/6 11:58,Sun,18300,croissant,1
2019/10/6 12:51,Sun,25300,croissant,1
2019/10/9 11:09,Wed,14300,croissant,1
2019/10/10 12:02,Thur,15100,croissant,1
2019/10/10 12:49,Thur,18600,croissant,2
2019/10/11 11:18,Fri,14800,croissant,1
2019/10/11 11:24,Fri,17300,croissant,1
2019/10/12 11:07,Sat,20500,croissant,1
2019/10/12 12:00,Sat,17300,croissant,1
2019/10/12 13:11,Sat,23800,croissant,1
2019/10/13 11:20,Sun,25800,croissant,2
2019/10/13 11:30,Sun,15000,croissant,1
2019/10/13 13:01,Sun,14800,croissant,1
2019/10/13 13:07,Sun,17300,croissant,1
2019/10/14 11:08,Mon,26000,croissant,2
2019/10/14 11:40,Mon,14800,croissant,1
2019/10/14 12:09,Mon,14800,croissant,1
2019/10/14 13:47,Mon,18300,croissant,1
2019/10/16 11:09,Wed,22800,croissant,1
2019/10/17 11:47,Thur,14800,croissant,1
2019/10/17 13:16,Thur,24800,croissant,1
2019/10/17 13:50,Thur,32300,croissant,1
2019/10/17 15:41,Thur,18600,croissant,2
2019/10/18 12:08,Fri,17000,croissant,2
2019/10/18 13:57,Fri,15300,croissant,1
2019/10/19 11:13,Sat,29000,croissant,1
2019/10/19 11:17,Sat,29100,croissant,2
2019/10/19 11:45,Sat,18000,croissant,1
2019/10/19 15:56,Sat,15800,croissant,1
2019/10/20 11:18,Sun,18600,croissant,2
2019/10/20 11:25,Sun,19800,croissant,2
2019/10/20 11:34,Sun,28100,croissant,1
2019/10/20 12:03,Sun,17300,croissant,2
2019/10/20 12:55,Sun,35200,croissant,2
2019/10/21 11:27,Mon,16300,croissant,1
2019/10/21 11:27,Mon,17300,croissant,1
2019/10/21 11:47,Mon,28600,croissant,2
2019/10/21 13:28,Mon,14800,croissant,1
2019/10/23 11:17,Wed,17300,croissant,1
2019/10/24 11:03,Thur,25300,croissant,1
2019/10/24 11:18,Thur,18800,croissant,1
2019/10/24 12:59,Thur,26900,croissant,3
2019/10/25 11:16,Fri,27300,croissant,1
2019/10/25 11:51,Fri,22800,croissant,1
2019/10/25 12:31,Fri,14300,croissant,1
2019/10/25 13:45,Fri,17500,croissant,2
2019/10/26 12:47,Sat,17300,croissant,2
2019/10/26 12:52,Sat,20100,croissant,1
2019/10/27 11:02,Sun,16000,croissant,2
2019/10/27 11:57,Sun,22300,croissant,1
2019/10/27 12:40,Sun,17300,croissant,2
2019/10/27 12:51,Sun,18800,croissant,1
2019/10/27 13:42,Sun,18500,croissant,1
2019/10/28 11:17,Mon,14800,croissant,1
2019/10/28 12:15,Mon,18300,croissant,1
2019/10/28 12:55,Mon,14800,croissant,1
2019/10/28 13:31,Mon,23300,croissant,1
2019/10/28 13:43,Mon,15000,croissant,1
2019/10/28 13:45,Mon,26600,croissant,2
2019/10/28 14:20,Mon,34600,croissant,2
2019/10/31 11:05,Thur,55800,croissant,3
2019/10/31 12:18,Thur,14800,croissant,1
2019/11/1 11:46,Fri,21800,croissant,2
2019/11/1 12:56,Fri,14800,croissant,1
2019/11/1 13:52,Fri,22000,croissant,1
2019/11/2 11:08,Sat,30400,croissant,2
2019/11/2 13:56,Sat,14800,croissant,1
2019/11/2 14:19,Sat,22300,croissant,1
2019/11/2 14:35,Sat,15000,croissant,1
2019/11/2 15:55,Sat,14800,croissant,1
2019/11/2 16:54,Sat,14300,croissant,1
2019/11/4 11:53,Mon,15000,croissant,1
2019/11/4 13:13,Mon,26600,croissant,2
2019/11/6 11:47,Wed,24600,croissant,1
2019/11/6 13:23,Wed,14800,croissant,1
2019/11/6 14:33,Wed,15100,croissant,1
2019/11/7 11:20,Thur,15300,croissant,1
2019/11/7 11:26,Thur,14800,croissant,1
2019/11/7 13:33,Thur,34800,croissant,3
2019/11/7 14:44,Thur,26800,croissant,1
2019/11/7 15:21,Thur,16800,croissant,1
2019/11/8 11:36,Fri,22800,croissant,1
2019/11/8 13:12,Fri,36000,croissant,1
2019/11/8 15:02,Fri,27800,croissant,1
2019/11/9 11:36,Sat,26100,croissant,1
2019/11/9 11:36,Sat,35700,croissant,1
2019/11/9 11:36,Sat,18800,croissant,1
2019/11/10 11:27,Sun,17000,croissant,1
2019/11/13 11:05,Wed,22300,croissant,1
2019/11/14 13:10,Thur,39300,croissant,2
2019/11/15 13:06,Fri,14800,croissant,1
2019/11/15 14:39,Fri,17300,croissant,3
2019/11/15 16:30,Fri,70700,croissant,4
2019/11/16 11:07,Sat,23800,croissant,1
2019/11/16 12:21,Sat,18500,croissant,1
2019/11/16 16:13,Sat,19100,croissant,1
2019/11/17 11:06,Sun,26300,croissant,2
2019/11/17 11:07,Sun,22300,croissant,1
2019/11/17 11:07,Sun,14800,croissant,1
2019/11/17 11:24,Sun,16500,croissant,1
2019/11/17 11:57,Sun,16300,croissant,1
2019/11/17 12:01,Sun,19600,croissant,1
2019/11/17 14:12,Sun,14000,croissant,1
2019/11/18 11:11,Mon,18000,croissant,1
2019/11/18 11:16,Mon,15100,croissant,1
2019/11/20 13:24,Wed,23800,croissant,1
2019/11/20 16:59,Wed,15500,croissant,2
2019/11/21 16:37,Thur,16000,croissant,4
2019/11/22 12:25,Fri,21000,croissant,3
2019/11/22 16:02,Fri,12800,croissant,1
2019/11/23 12:00,Sat,36100,croissant,2
2019/11/23 14:39,Sat,14300,croissant,1
2019/11/23 15:23,Sat,14800,croissant,1
2019/11/23 15:30,Sat,22300,croissant,2
2019/11/23 15:54,Sat,19500,croissant,1
2019/11/24 12:57,Sun,14500,croissant,1
2019/11/25 11:05,Mon,19800,croissant,1
2019/11/25 11:08,Mon,18800,croissant,1
2019/11/25 11:31,Mon,54100,croissant,3
2019/11/25 12:25,Mon,18000,croissant,1
2019/11/25 14:00,Mon,14800,croissant,1
2019/11/27 13:34,Wed,17300,croissant,2
2019/11/28 13:16,Thur,17500,croissant,1
2019/11/28 15:09,Thur,19300,croissant,1
2019/11/29 12:03,Fri,16300,croissant,1
2019/11/29 13:31,Fri,25000,croissant,1
2019/11/29 15:05,Fri,14300,croissant,1
2019/11/29 15:27,Fri,15000,croissant,1
2019/11/30 11:01,Sat,22100,croissant,2
2019/11/30 17:04,Sat,27600,croissant,1
2019/12/1 11:29,Sun,14800,croissant,1
2019/12/1 12:35,Sun,23000,croissant,1
2019/12/1 12:55,Sun,19000,croissant,1
2019/12/1 14:24,Sun,31100,croissant,1
2019/12/1 16:18,Sun,18600,croissant,1
2019/12/2 11:03,Mon,17500,croissant,1
2019/12/2 14:42,Mon,22800,croissant,1
2019/12/2 16:22,Mon,14300,croissant,1
2019/12/4 11:47,Wed,17500,croissant,1
2019/12/4 13:34,Wed,16000,croissant,2
2019/12/5 12:32,Thur,16000,croissant,1
2019/12/5 12:39,Thur,21800,croissant,2
2019/12/5 13:56,Thur,14800,croissant,1
2019/12/5 14:48,Thur,36000,croissant,1
2019/12/6 11:08,Fri,22100,croissant,2
2019/12/6 11:23,Fri,14800,croissant,1
2019/12/6 11:31,Fri,20500,croissant,2
2019/12/7 11:41,Sat,17500,croissant,1
2019/12/7 13:39,Sat,30800,croissant,1
2019/12/7 13:50,Sat,14500,croissant,1
2019/12/8 11:50,Sun,18000,croissant,1
2019/12/8 13:44,Sun,28100,croissant,1
2019/12/8 14:57,Sun,25100,croissant,1
2019/12/9 12:09,Mon,33100,croissant,2
2019/12/11 11:36,Wed,22000,croissant,1
2019/12/11 12:02,Wed,14000,croissant,1
2019/12/11 12:09,Wed,21500,croissant,1
2019/12/11 14:26,Wed,32000,croissant,2
2019/12/11 15:05,Wed,14500,croissant,1
2019/12/11 15:07,Wed,14300,croissant,1
2019/12/12 14:09,Thur,16300,croissant,1
2019/12/13 14:21,Fri,14800,croissant,1
2019/12/13 16:48,Fri,14000,croissant,1
2019/12/14 11:59,Sat,17300,croissant,1
2019/12/14 12:51,Sat,19300,croissant,1
2019/12/15 12:14,Sun,19300,croissant,1
2019/12/16 14:31,Mon,23600,croissant,1
2019/12/18 15:23,Wed,51200,croissant,2
2019/12/19 11:29,Thur,24800,croissant,2
2019/12/19 11:45,Thur,35300,croissant,1
2019/12/19 13:06,Thur,32500,croissant,2
2019/12/20 16:43,Fri,31100,croissant,2
2019/12/21 13:29,Sat,18500,croissant,4
2019/12/21 13:58,Sat,20000,croissant,1
2019/12/21 14:43,Sat,30900,croissant,1
2019/12/22 11:05,Sun,14800,croissant,1
2019/12/22 11:33,Sun,46000,croissant,4
2019/12/22 14:45,Sun,19000,croissant,1
2019/12/22 15:53,Sun,19600,croissant,1
2019/12/23 13:37,Mon,27300,croissant,1
2019/12/23 14:42,Mon,19500,croissant,1
2019/12/25 11:55,Wed,15300,croissant,1
2019/12/25 12:16,Wed,14800,croissant,1
2019/12/25 15:00,Wed,18300,croissant,2
2019/12/26 13:47,Thur,14500,croissant,1
2019/12/27 12:49,Fri,15000,croissant,1
2019/12/28 13:31,Sat,21500,croissant,3
2019/12/28 14:51,Sat,17000,croissant,4
2019/12/28 15:52,Sat,19300,croissant,1
2019/12/28 16:18,Sat,58900,croissant,4
2019/12/30 14:35,Mon,53900,croissant,4
2020/1/2 11:22,Thur,15000,croissant,1
2020/1/2 11:33,Thur,42900,croissant,1
2020/1/2 14:16,Thur,16500,croissant,1
2020/1/3 11:17,Fri,20300,croissant,1
2020/1/3 14:05,Fri,17000,croissant,1
2020/1/3 14:18,Fri,18000,croissant,2
2020/1/5 13:49,Sun,20300,croissant,1
2020/1/5 13:59,Sun,14500,croissant,1
2020/1/5 14:46,Sun,18300,croissant,1
2020/1/6 12:30,Mon,30800,croissant,2
2020/1/6 12:43,Mon,18300,croissant,1
2020/1/6 12:50,Mon,17300,croissant,2
2020/1/6 16:30,Mon,14000,croissant,2
2020/1/8 12:42,Wed,22600,croissant,1
2020/1/8 12:47,Wed,30300,croissant,1
2020/1/8 13:15,Wed,41400,croissant,2
2020/1/9 11:39,Thur,28300,croissant,1
2020/1/9 17:00,Thur,14800,croissant,1
2020/1/10 15:10,Fri,19300,croissant,1
2020/1/11 13:16,Sat,19600,croissant,1
2020/1/11 14:19,Sat,18300,croissant,2
2020/1/12 12:16,Sun,44100,croissant,2
2020/1/12 12:42,Sun,18000,croissant,1
2020/1/12 13:23,Sun,18300,croissant,2
2020/1/13 13:49,Mon,19300,croissant,1
2020/1/13 15:44,Mon,15100,croissant,1
2020/1/13 16:55,Mon,14500,croissant,1
2020/1/15 11:04,Wed,20300,croissant,1
2020/1/15 11:08,Wed,17300,croissant,1
2020/1/15 13:22,Wed,26300,croissant,2
2020/1/16 11:28,Thur,18800,croissant,1
2020/1/17 12:13,Fri,26600,croissant,2
2020/1/17 13:30,Fri,16300,croissant,1
2020/1/18 11:16,Sat,18300,croissant,1
2020/1/18 12:31,Sat,25800,croissant,2
2020/1/18 14:36,Sat,16500,croissant,1
2020/1/18 16:12,Sat,14500,croissant,1
2020/1/19 11:49,Sun,14500,croissant,1
2020/1/20 12:46,Mon,14800,croissant,1
2020/1/20 13:28,Mon,19500,croissant,5
2020/1/20 13:59,Mon,19300,croissant,1
2020/1/22 11:09,Wed,16100,croissant,1
2020/1/22 11:50,Wed,18100,croissant,1
2020/1/22 12:04,Wed,20300,croissant,1
2020/1/22 13:44,Wed,18300,croissant,1
2020/1/23 11:45,Thur,18800,croissant,1
2020/1/26 12:16,Sun,15000,croissant,1
2020/1/26 12:36,Sun,28100,croissant,2
2020/1/26 12:50,Sun,34900,croissant,2
2020/1/26 13:09,Sun,18000,croissant,1
2020/1/27 12:17,Mon,27600,croissant,1
2020/1/27 12:32,Mon,21800,croissant,2
2020/1/27 13:29,Mon,26000,croissant,1
2020/1/30 11:43,Thur,23300,croissant,1
2020/1/30 11:54,Thur,42900,croissant,3
2020/1/30 12:15,Thur,34300,croissant,1
2020/1/30 12:26,Thur,26600,croissant,1
2020/1/30 14:27,Thur,16000,croissant,1
2020/1/30 15:15,Thur,21100,croissant,1
2020/2/1 11:05,Sat,15100,croissant,1
2020/2/1 12:56,Sat,17300,croissant,1
2020/2/2 11:32,Sun,22300,croissant,2
2020/2/2 11:49,Sun,30800,croissant,2
2020/2/2 12:18,Sun,16000,croissant,3
2020/2/2 13:10,Sun,17800,croissant,1
2020/2/2 13:33,Sun,19300,croissant,1
2020/2/3 12:52,Mon,45500,croissant,2
2020/2/5 11:56,Wed,27600,croissant,1
2020/2/5 12:36,Wed,17500,croissant,1
2020/2/6 11:05,Thur,14500,croissant,1
2020/2/6 11:15,Thur,15100,croissant,1
2020/2/6 11:34,Thur,18600,croissant,1
2020/2/6 12:31,Thur,15000,croissant,1
2020/2/6 13:31,Thur,18800,croissant,1
2020/2/6 14:58,Thur,20300,croissant,1
2020/2/7 11:51,Fri,17800,croissant,1
2020/2/7 12:44,Fri,29300,croissant,1
2020/2/7 15:40,Fri,26300,croissant,2
2020/2/8 12:24,Sat,22800,croissant,1
2020/2/8 13:27,Sat,25800,croissant,3
2020/2/8 15:22,Sat,22800,croissant,1
2020/2/9 11:03,Sun,30000,croissant,1
2020/2/9 12:23,Sun,17300,croissant,1
2020/2/9 13:54,Sun,18300,croissant,1
2020/2/10 14:03,Mon,16000,croissant,1
2020/2/12 12:10,Wed,19300,croissant,1
2020/2/12 12:48,Wed,53600,croissant,3
2020/2/12 14:35,Wed,55200,croissant,1
2020/2/12 16:21,Wed,22500,croissant,1
2020/2/12 17:21,Wed,21300,croissant,1
2020/2/13 12:28,Thur,18300,croissant,1
2020/2/14 12:44,Fri,27300,croissant,1
2020/2/14 12:58,Fri,23300,croissant,1
2020/2/14 13:06,Fri,16300,croissant,1
2020/2/15 11:07,Sat,25000,croissant,2
2020/2/15 11:59,Sat,17000,croissant,2
2020/2/15 12:35,Sat,15500,croissant,1
2020/2/15 12:50,Sat,17500,croissant,1
2020/2/15 12:55,Sat,20500,croissant,1
2020/2/15 17:19,Sat,19600,croissant,1
2020/2/16 11:17,Sun,17000,croissant,2
2020/2/16 11:30,Sun,19800,croissant,2
2020/2/16 12:06,Sun,22100,croissant,2
2020/2/16 12:07,Sun,41800,croissant,3
2020/2/16 12:41,Sun,14800,croissant,1
2020/2/17 13:33,Mon,23300,croissant,2
2020/2/17 13:48,Mon,16800,croissant,1
2020/2/17 17:01,Mon,14500,croissant,1
2020/2/19 11:00,Wed,14500,croissant,1
2020/2/19 11:34,Wed,14500,croissant,1
2020/2/19 12:07,Wed,16000,croissant,1
2020/2/19 12:12,Wed,24600,croissant,1
2020/2/19 13:01,Wed,17500,croissant,2
2020/2/19 14:42,Wed,23000,croissant,1
2020/2/20 11:05,Thur,23100,croissant,2
2020/2/20 11:06,Thur,20000,croissant,1
2020/2/20 11:01,Thur,14800,croissant,1
2020/2/20 11:23,Thur,27600,croissant,1
2020/2/21 13:20,Fri,20000,croissant,1
2020/2/21 13:32,Fri,18500,croissant,3
2020/2/21 14:21,Fri,33500,croissant,3
2020/2/22 11:14,Sat,16300,croissant,1
2020/2/22 11:35,Sat,18600,croissant,1
2020/2/22 12:13,Sat,17000,croissant,1
2020/2/22 13:24,Sat,17500,croissant,1
2020/2/22 13:51,Sat,21500,croissant,2
2020/2/22 14:02,Sat,23100,croissant,1
2020/2/23 11:04,Sun,35300,croissant,1
2020/2/23 11:07,Sun,41300,croissant,3
2020/2/23 11:10,Sun,26600,croissant,1
2020/2/23 11:32,Sun,24100,croissant,2
2020/2/23 11:41,Sun,17000,croissant,1
2020/2/23 13:06,Sun,20300,croissant,2
2020/2/23 13:09,Sun,21800,croissant,1
2020/2/23 13:58,Sun,18000,croissant,1
2020/2/23 14:05,Sun,22300,croissant,1
2020/2/23 14:07,Sun,24000,croissant,2
2020/2/24 12:52,Mon,26900,croissant,3
2020/2/24 14:36,Mon,22600,croissant,2
2020/2/24 15:55,Mon,19300,croissant,1
2020/2/26 11:12,Wed,31600,croissant,1
2020/2/26 12:49,Wed,14500,croissant,1
2020/2/26 13:38,Wed,20800,croissant,1
2020/2/26 16:13,Wed,27900,croissant,2
2020/2/27 11:15,Thur,23300,croissant,2
2020/2/27 11:25,Thur,23100,croissant,1
2020/2/28 11:09,Fri,23100,croissant,1
2020/2/28 13:26,Fri,18000,croissant,2
2020/2/29 12:52,Sat,21300,croissant,1
2020/2/29 12:54,Sat,21800,croissant,1
2020/2/29 14:23,Sat,22800,croissant,1
2020/3/1 11:06,Sun,29800,croissant,1
2020/3/1 12:45,Sun,22300,croissant,1
2020/3/1 14:27,Sun,27300,croissant,1
2020/3/1 15:16,Sun,20300,croissant,1
2020/3/2 13:32,Mon,33600,croissant,4
2020/3/2 13:41,Mon,20300,croissant,2
2020/3/2 14:35,Mon,19000,croissant,1
2020/3/5 12:00,Thur,24300,croissant,2
2020/3/5 14:26,Thur,14300,croissant,1
2020/3/5 15:03,Thur,17300,croissant,1
2020/3/5 15:26,Thur,15100,croissant,1
2020/3/6 11:53,Fri,17500,croissant,1
2020/3/6 12:22,Fri,22800,croissant,1
2020/3/6 12:22,Fri,14800,croissant,1
2020/3/6 12:24,Fri,25600,croissant,1
2020/3/6 12:27,Fri,18300,croissant,1
2020/3/6 13:12,Fri,27000,croissant,4
2020/3/6 14:34,Fri,18800,croissant,1
2020/3/7 11:29,Sat,20800,croissant,1
2020/3/7 12:58,Sat,23000,croissant,1
2020/3/7 14:40,Sat,14000,croissant,1
2020/3/7 14:56,Sat,16800,croissant,1
2020/3/8 11:19,Sun,19000,croissant,1
2020/3/8 12:03,Sun,29100,croissant,1
2020/3/8 12:28,Sun,32800,croissant,1
2020/3/8 13:26,Sun,20300,croissant,1
2020/3/9 11:42,Mon,14800,croissant,1
2020/3/11 11:24,Wed,24300,croissant,1
2020/3/11 11:57,Wed,27100,croissant,1
2020/3/11 13:14,Wed,22100,croissant,1
2020/3/11 13:17,Wed,25300,croissant,3
2020/3/12 11:03,Thur,22800,croissant,1
2020/3/12 11:45,Thur,17300,croissant,1
2020/3/12 12:23,Thur,20800,croissant,1
2020/3/13 11:46,Fri,23800,croissant,1
2020/3/13 12:37,Fri,25100,croissant,1
2020/3/13 14:37,Fri,22800,croissant,3
2020/3/13 15:58,Fri,19600,croissant,1
2020/3/14 13:52,Sat,21800,croissant,1
2020/3/15 12:03,Sun,20500,croissant,2
2020/3/15 13:45,Sun,28000,croissant,1
2020/3/15 14:07,Sun,25000,croissant,1
2020/3/15 14:18,Sun,16000,croissant,1
2020/3/16 11:11,Mon,19300,croissant,1
2020/3/16 11:56,Mon,22600,croissant,1
2020/3/16 12:46,Mon,26800,croissant,2
2020/3/16 13:23,Mon,20800,croissant,3
2020/3/16 13:45,Mon,17000,croissant,1
2020/3/18 11:10,Wed,24000,croissant,2
2020/3/18 12:29,Wed,39100,croissant,2
2020/3/18 12:40,Wed,42400,croissant,2
2020/3/18 13:06,Wed,17500,croissant,1
2020/3/19 14:38,Thur,17600,croissant,2
2020/3/20 12:17,Fri,28800,croissant,3
2020/3/20 12:34,Fri,17000,croissant,1
2020/3/20 13:48,Fri,19300,croissant,1
2020/3/21 11:28,Sat,31600,croissant,1
2020/3/21 11:44,Sat,27600,croissant,2
2020/3/21 12:34,Sat,14800,croissant,1
2020/3/21 13:32,Sat,19300,croissant,1
2020/3/21 13:38,Sat,17500,croissant,1
2020/3/21 14:17,Sat,33100,croissant,3
2020/3/22 14:31,Sun,19500,croissant,2
2020/3/23 13:12,Mon,18600,croissant,1
2020/3/23 13:57,Mon,17800,croissant,1
2020/3/25 14:08,Wed,18000,croissant,2
2020/3/25 14:12,Wed,22300,croissant,1
2020/3/26 11:32,Thur,43200,croissant,1
2020/3/26 14:44,Thur,31100,croissant,1
2020/3/26 15:22,Thur,14800,croissant,1
2020/3/27 13:00,Fri,19500,croissant,1
2020/3/27 14:19,Fri,15300,croissant,1
2020/3/27 15:36,Fri,28800,croissant,1
2020/3/27 15:48,Fri,14000,croissant,1
2020/3/28 11:09,Sat,26300,croissant,2
2020/3/28 11:14,Sat,19300,croissant,1
2020/3/28 11:38,Sat,14800,croissant,1
2020/3/28 12:17,Sat,15500,croissant,1
2020/3/29 11:09,Sun,21800,croissant,2
2020/3/29 11:59,Sun,15800,croissant,1
2020/3/29 12:02,Sun,29800,croissant,2
2020/3/29 13:16,Sun,19600,croissant,1
2020/3/29 13:28,Sun,15000,croissant,1
2020/3/29 14:02,Sun,26300,croissant,2
2020/3/30 12:07,Mon,19300,croissant,1
2020/3/30 14:08,Mon,32400,croissant,2
2020/3/30 15:07,Mon,17800,croissant,1
2020/3/30 16:21,Mon,19800,croissant,1
2020/4/1 12:32,Wed,23100,croissant,1
2020/4/1 13:44,Wed,22800,croissant,1
2020/4/2 11:54,Thur,15300,croissant,1
2020/4/2 12:11,Thur,28800,croissant,1
2020/4/2 12:38,Thur,18000,croissant,1
2020/4/2 16:02,Thur,14300,croissant,1
2020/4/2 16:03,Thur,26900,croissant,1
2020/4/3 11:43,Fri,23600,croissant,1
2020/4/3 13:29,Fri,44500,croissant,3
2020/4/4 12:36,Sat,14800,croissant,1
2020/4/4 13:02,Sat,27800,croissant,2
2020/4/4 14:06,Sat,21800,croissant,2
2020/4/4 14:07,Sat,19600,croissant,1
2020/4/4 14:56,Sat,18800,croissant,2
2020/4/5 12:33,Sun,16300,croissant,1
2020/4/5 14:41,Sun,26300,croissant,1
2020/4/5 14:56,Sun,14100,croissant,1
2020/4/6 11:24,Mon,19800,croissant,1
2020/4/6 15:55,Mon,27100,croissant,1
2020/4/8 11:01,Wed,17300,croissant,1
2020/4/8 11:53,Wed,28800,croissant,1
2020/4/8 12:10,Wed,19800,croissant,1
2020/4/8 14:49,Wed,18000,croissant,1
2020/4/8 16:38,Wed,25000,croissant,4
2020/4/9 11:05,Thur,18800,croissant,1
2020/4/9 11:10,Thur,26600,croissant,1
2020/4/9 12:00,Thur,30800,croissant,1
2020/4/9 14:31,Thur,19500,croissant,1
2020/4/9 15:44,Thur,14300,croissant,1
2020/4/10 11:45,Fri,20500,croissant,2
2020/4/10 17:24,Fri,18600,croissant,1
2020/4/11 12:40,Sat,18300,croissant,1
2020/4/11 14:45,Sat,14000,croissant,1
2020/4/12 11:05,Sun,32200,croissant,1
2020/4/12 13:33,Sun,18300,croissant,1
2020/4/13 14:06,Mon,27000,croissant,1
2020/4/15 13:19,Wed,34000,croissant,1
2020/4/15 15:01,Wed,16000,croissant,1
2020/4/17 14:24,Fri,18600,croissant,1
2020/4/17 15:01,Fri,19800,croissant,1
2020/4/17 16:05,Fri,17000,croissant,1
2020/4/18 11:22,Sat,18600,croissant,2
2020/4/18 12:35,Sat,15800,croissant,1
2020/4/18 14:10,Sat,36000,croissant,1
2020/4/18 14:12,Sat,30100,croissant,1
2020/4/18 14:35,Sat,17800,croissant,1
2020/4/20 11:17,Mon,25100,croissant,1
2020/4/20 12:13,Mon,20000,croissant,2
2020/4/20 12:53,Mon,16000,croissant,2
2020/4/20 14:46,Mon,64000,croissant,3
2020/4/22 11:51,Wed,18600,croissant,1
2020/4/22 12:06,Wed,28600,croissant,1
2020/4/22 12:53,Wed,18800,croissant,1
2020/4/22 15:05,Wed,16800,croissant,1
2020/4/22 15:49,Wed,15100,croissant,1
2020/4/23 11:40,Thur,28500,croissant,2
2020/4/23 15:14,Thur,19000,croissant,1
2020/4/24 11:12,Fri,18800,croissant,1
2020/4/25 11:16,Sat,30800,croissant,1
2020/4/25 11:42,Sat,36600,croissant,2
2020/4/25 13:18,Sat,19300,croissant,1
2020/4/25 13:56,Sat,29300,croissant,1
2020/4/25 13:56,Sat,19000,croissant,1
2020/4/26 11:05,Sun,33300,croissant,1
2020/4/26 12:00,Sun,23300,croissant,2
2020/4/26 12:02,Sun,23600,croissant,1
2020/4/26 13:01,Sun,16300,croissant,2
2020/4/26 14:13,Sun,17000,croissant,2
2020/4/26 15:14,Sun,27300,croissant,1
2020/4/27 11:28,Mon,18300,croissant,1
2020/4/27 11:36,Mon,18800,croissant,2
2020/4/27 11:42,Mon,30800,croissant,2
2020/4/27 12:02,Mon,15000,croissant,1
2020/4/27 12:31,Mon,18800,croissant,1
2020/4/27 16:00,Mon,18600,croissant,1
2020/4/29 12:00,Wed,21800,croissant,1
2020/4/29 15:05,Wed,26800,croissant,1
2020/4/30 13:10,Thur,14800,croissant,1
2020/5/1 11:09,Fri,31600,croissant,1
2020/5/1 12:00,Fri,30800,croissant,1
2020/5/1 12:10,Fri,18300,croissant,1
2020/5/1 13:55,Fri,21300,croissant,1
2020/5/1 15:03,Fri,14800,croissant,1
2020/5/2 13:45,Sat,15000,croissant,1
2019/7/14 14:51,Sun,25600,caffe latte,1
2019/7/20 11:35,Sat,18800,caffe latte,1
2019/7/20 12:13,Sat,26300,caffe latte,1
2019/7/20 12:31,Sat,14800,caffe latte,1
2019/7/21 12:25,Sun,14800,caffe latte,1
2019/7/22 15:37,Mon,19600,caffe latte,1
2019/7/25 11:57,Thur,26800,caffe latte,1
2019/8/2 12:21,Fri,15800,caffe latte,1
2019/8/5 12:49,Mon,49300,caffe latte,1
2019/8/5 13:54,Mon,19800,caffe latte,1
2019/8/5 14:25,Mon,20800,caffe latte,1
2019/8/7 12:20,Wed,27300,caffe latte,1
2019/8/7 14:50,Wed,23800,caffe latte,1
2019/8/8 13:55,Thur,22300,caffe latte,1
2019/8/11 12:58,Sun,15800,caffe latte,1
2019/8/11 13:27,Sun,17300,caffe latte,1
2019/8/12 12:48,Mon,14800,caffe latte,1
2019/8/15 11:03,Thur,24100,caffe latte,1
2019/8/17 11:03,Sat,18300,caffe latte,1
2019/8/18 14:39,Sun,23000,caffe latte,1
2019/8/18 12:40,Sun,16300,caffe latte,1
2019/8/19 12:34,Mon,23600,caffe latte,1
2019/8/21 12:51,Wed,17500,caffe latte,1
2019/8/22 11:48,Thur,14800,caffe latte,1
2019/8/22 14:35,Thur,15800,caffe latte,1
2019/8/24 11:55,Sat,20800,caffe latte,1
2019/8/24 13:07,Sat,14800,caffe latte,1
2019/8/25 12:23,Sun,25300,caffe latte,1
2019/8/28 13:57,Wed,33400,caffe latte,1
2019/8/28 14:05,Wed,19300,caffe latte,1
2019/8/29 14:31,Thur,15500,caffe latte,1
2019/8/30 15:25,Fri,28300,caffe latte,2
2019/8/31 15:27,Sat,14100,caffe latte,1
2019/9/1 12:04,Sun,19600,caffe latte,1
2019/9/4 11:49,Wed,23000,caffe latte,1
2019/9/9 13:12,Mon,14800,caffe latte,1
2019/9/11 13:08,Wed,24400,caffe latte,1
2019/9/15 13:34,Sun,24400,caffe latte,1
2019/9/18 11:32,Wed,16500,caffe latte,1
2019/9/19 16:17,Thur,30500,caffe latte,1
2019/9/20 14:58,Fri,18300,caffe latte,1
2019/9/23 12:08,Mon,15800,caffe latte,1
2019/9/23 12:43,Mon,15000,caffe latte,1
2019/9/23 13:22,Mon,18300,caffe latte,1
2019/9/26 14:45,Thur,14800,caffe latte,1
2019/9/27 12:30,Fri,21300,caffe latte,1
2019/9/27 15:42,Fri,14800,caffe latte,1
2019/9/28 13:36,Sat,14800,caffe latte,1
2019/9/29 11:39,Sun,23100,caffe latte,1
2019/10/2 12:35,Wed,15500,caffe latte,1
2019/10/3 15:53,Thur,16000,caffe latte,1
2019/10/5 15:00,Sat,15500,caffe latte,1
2019/10/6 12:05,Sun,15300,caffe latte,1
2019/10/10 12:08,Thur,18300,caffe latte,1
2019/10/12 11:07,Sat,20500,caffe latte,1
2019/10/12 13:02,Sat,19300,caffe latte,1
2019/10/13 11:10,Sun,14500,caffe latte,1
2019/10/14 11:08,Mon,26000,caffe latte,1
2019/10/17 12:48,Thur,15800,caffe latte,1
2019/10/20 11:05,Sun,14800,caffe latte,1
2019/10/21 11:36,Mon,20800,caffe latte,1
2019/10/24 12:35,Thur,28300,caffe latte,2
2019/10/25 14:16,Fri,18600,caffe latte,1
2019/10/28 13:43,Mon,15000,caffe latte,1
2019/10/28 13:45,Mon,26600,caffe latte,1
2019/11/2 13:56,Sat,14800,caffe latte,1
2019/11/2 14:35,Sat,15000,caffe latte,1
2019/11/2 14:38,Sat,16300,caffe latte,1
2019/11/3 11:02,Sun,20800,caffe latte,1
2019/11/6 13:23,Wed,14800,caffe latte,1
2019/11/9 11:36,Sat,14800,caffe latte,1
2019/11/9 14:06,Sat,15800,caffe latte,1
2019/11/10 11:10,Sun,21100,caffe latte,1
2019/11/10 11:55,Sun,29100,caffe latte,1
2019/11/11 14:00,Mon,19300,caffe latte,1
2019/11/17 15:25,Sun,17300,caffe latte,1
2019/11/17 16:45,Sun,14500,caffe latte,1
2019/11/18 14:36,Mon,28800,caffe latte,1
2019/11/20 12:46,Wed,17300,caffe latte,1
2019/11/20 16:28,Wed,16300,caffe latte,1
2019/11/23 11:55,Sat,19300,caffe latte,1
2019/11/24 11:29,Sun,19800,caffe latte,1
2019/11/24 12:57,Sun,14500,caffe latte,1
2019/11/24 13:34,Sun,39000,caffe latte,2
2019/11/25 12:25,Mon,18000,caffe latte,2
2019/11/25 13:42,Mon,15800,caffe latte,2
2019/11/28 13:15,Thur,25300,caffe latte,1
2019/11/29 13:31,Fri,25000,caffe latte,1
2019/11/30 11:10,Sat,22800,caffe latte,2
2019/11/30 11:43,Sat,15800,caffe latte,1
2019/12/5 13:56,Thur,14800,caffe latte,1
2019/12/6 11:23,Fri,14800,caffe latte,1
2019/12/6 11:31,Fri,20500,caffe latte,1
2019/12/8 12:33,Sun,23000,caffe latte,1
2019/12/8 12:49,Sun,30600,caffe latte,1
2019/12/8 14:08,Sun,19800,caffe latte,1
2019/12/11 12:02,Wed,14000,caffe latte,1
2019/12/12 14:52,Thur,19500,caffe latte,1
2019/12/13 11:27,Fri,21100,caffe latte,1
2019/12/13 14:21,Fri,14800,caffe latte,1
2019/12/14 12:19,Sat,23800,caffe latte,3
2019/12/15 14:06,Sun,45400,caffe latte,2
2019/12/16 13:37,Mon,14500,caffe latte,1
2019/12/16 14:32,Mon,19500,caffe latte,1
2019/12/18 12:39,Wed,14000,caffe latte,1
2019/12/21 14:18,Sat,15800,caffe latte,1
2019/12/22 15:10,Sun,15000,caffe latte,1
2019/12/23 13:57,Mon,30300,caffe latte,3
2019/12/25 15:00,Wed,18300,caffe latte,1
2019/12/28 13:31,Sat,21500,caffe latte,1
2019/12/29 14:39,Sun,14000,caffe latte,1
2020/1/2 12:17,Thur,16500,caffe latte,1
2020/1/3 16:06,Fri,17300,caffe latte,1
2020/1/4 11:03,Sat,23800,caffe latte,1
2020/1/4 14:36,Sat,15300,caffe latte,1
2020/1/6 12:25,Mon,14800,caffe latte,1
2020/1/8 12:47,Wed,30300,caffe latte,3
2020/1/12 16:30,Sun,17000,caffe latte,2
2020/1/16 14:09,Thur,14800,caffe latte,1
2020/1/19 12:52,Sun,32100,caffe latte,1
2020/1/19 13:22,Sun,21100,caffe latte,1
2020/1/30 11:53,Thur,28800,caffe latte,1
2020/1/30 14:27,Thur,16000,caffe latte,1
2020/2/2 17:29,Sun,19600,caffe latte,1
2020/2/3 16:42,Mon,15800,caffe latte,1
2020/2/5 13:12,Wed,21300,caffe latte,1
2020/2/6 12:31,Thur,15000,caffe latte,1
2020/2/7 12:39,Fri,33300,caffe latte,1
2020/2/12 11:03,Wed,16800,caffe latte,1
2020/2/12 11:12,Wed,16300,caffe latte,1
2020/2/17 13:05,Mon,20300,caffe latte,1
2020/2/19 14:42,Wed,23000,caffe latte,1
2020/2/20 15:41,Thur,25400,caffe latte,1
2020/2/21 11:54,Fri,19800,caffe latte,1
2020/2/23 11:10,Sun,26600,caffe latte,1
2020/2/23 13:58,Sun,18000,caffe latte,1
2020/2/23 14:05,Sun,22300,caffe latte,1
2020/2/24 11:07,Mon,29900,caffe latte,1
2020/2/26 14:29,Wed,23300,caffe latte,1
2020/2/27 14:22,Thur,22000,caffe latte,1
2020/2/28 11:02,Fri,33800,caffe latte,1
2020/2/29 12:48,Sat,19000,caffe latte,1
2020/3/1 11:06,Sun,29800,caffe latte,3
2020/3/1 11:18,Sun,21100,caffe latte,1
2020/3/1 14:19,Sun,23500,caffe latte,1
2020/3/2 14:35,Mon,19000,caffe latte,1
2020/3/5 11:36,Thur,37100,caffe latte,1
2020/3/5 13:48,Thur,27800,caffe latte,1
2020/3/5 14:49,Thur,20800,caffe latte,1
2020/3/5 15:03,Thur,17300,caffe latte,1
2020/3/6 11:07,Fri,19800,caffe latte,1
2020/3/6 12:22,Fri,22800,caffe latte,1
2020/3/6 14:05,Fri,16300,caffe latte,1
2020/3/7 12:39,Sat,17500,caffe latte,1
2020/3/7 12:59,Sat,14800,caffe latte,1
2020/3/7 13:07,Sat,19500,caffe latte,2
2020/3/7 13:17,Sat,15500,caffe latte,1
2020/3/8 13:26,Sun,20300,caffe latte,1
2020/3/11 11:10,Wed,28600,caffe latte,1
2020/3/12 11:03,Thur,22800,caffe latte,1
2020/3/12 12:23,Thur,20800,caffe latte,1
2020/3/12 15:17,Thur,22800,caffe latte,1
2020/3/14 13:05,Sat,14500,caffe latte,1
2020/3/15 13:45,Sun,28000,caffe latte,1
2020/3/16 12:46,Mon,26800,caffe latte,1
2020/3/19 15:11,Thur,20000,caffe latte,2
2020/3/21 12:51,Sat,18300,caffe latte,1
2020/3/23 14:49,Mon,18300,caffe latte,1
2020/3/25 14:17,Wed,21300,caffe latte,2
2020/3/26 13:06,Thur,18300,caffe latte,1
2020/3/27 13:10,Fri,18500,caffe latte,1
2020/3/28 11:55,Sat,40300,caffe latte,1
2020/3/29 11:25,Sun,27800,caffe latte,1
2020/3/29 11:59,Sun,15800,caffe latte,1
2020/3/30 12:07,Mon,19300,caffe latte,1
2020/4/2 11:06,Thur,15800,caffe latte,1
2020/4/5 13:34,Sun,22300,caffe latte,1
2020/4/8 14:49,Wed,18000,caffe latte,1
2020/4/8 16:38,Wed,25000,caffe latte,1
2020/4/9 12:00,Thur,30800,caffe latte,1
2020/4/13 15:19,Mon,26300,caffe latte,1
2020/4/15 14:22,Wed,14800,caffe latte,1
2020/4/16 13:04,Thur,18300,caffe latte,1
2020/4/18 14:10,Sat,36000,caffe latte,2
2020/4/19 11:09,Sun,24100,caffe latte,1
2020/4/19 14:04,Sun,24600,caffe latte,1
2020/4/23 12:57,Thur,17500,caffe latte,1
2020/4/24 12:00,Fri,19500,caffe latte,1
2020/4/25 11:42,Sat,36600,caffe latte,1
2020/4/25 13:56,Sat,29300,caffe latte,2
2020/4/27 11:41,Mon,19800,caffe latte,1
2020/5/1 11:32,Fri,15000,caffe latte,1
2020/5/2 11:37,Sat,19500,caffe latte,1
2019/7/11 15:35,Thur,23800,tiramisu croissant,3
2019/7/11 16:10,Thur,15800,tiramisu croissant,1
2019/7/12 11:49,Fri,58000,tiramisu croissant,14
2019/7/13 13:22,Sat,15600,tiramisu croissant,1
2019/7/13 15:09,Sat,14000,tiramisu croissant,2
2019/7/13 15:23,Sat,19100,tiramisu croissant,1
2019/7/13 16:32,Sat,22300,tiramisu croissant,1
2019/7/14 11:08,Sun,15300,tiramisu croissant,1
2019/7/14 11:15,Sun,27600,tiramisu croissant,1
2019/7/14 11:44,Sun,26300,tiramisu croissant,2
2019/7/14 11:59,Sun,19800,tiramisu croissant,1
2019/7/14 13:05,Sun,15600,tiramisu croissant,1
2019/7/14 14:06,Sun,23600,tiramisu croissant,1
2019/7/14 14:41,Sun,20100,tiramisu croissant,1
2019/7/14 15:02,Sun,19800,tiramisu croissant,1
2019/7/15 16:21,Mon,15800,tiramisu croissant,1
2019/7/17 11:47,Wed,17800,tiramisu croissant,1
2019/7/19 11:43,Fri,14800,tiramisu croissant,1
2019/7/19 12:36,Fri,21800,tiramisu croissant,2
2019/7/19 12:44,Fri,20600,tiramisu croissant,1
2019/7/19 13:35,Fri,14800,tiramisu croissant,1
2019/7/19 15:33,Fri,35900,tiramisu croissant,2
2019/7/20 11:40,Sat,22800,tiramisu croissant,1
2019/7/20 12:55,Sat,15800,tiramisu croissant,1
2019/7/20 13:19,Sat,20500,tiramisu croissant,1
2019/7/21 12:47,Sun,21000,tiramisu croissant,1
2019/7/21 13:45,Sun,22300,tiramisu croissant,1
2019/7/22 12:41,Mon,18300,tiramisu croissant,1
2019/7/22 15:37,Mon,19600,tiramisu croissant,1
2019/7/24 11:56,Wed,27100,tiramisu croissant,1
2019/7/24 14:28,Wed,26300,tiramisu croissant,1
2019/7/24 15:40,Wed,16100,tiramisu croissant,1
2019/7/25 11:49,Thur,18600,tiramisu croissant,1
2019/7/25 13:01,Thur,23100,tiramisu croissant,1
2019/7/26 11:23,Fri,73200,tiramisu croissant,1
2019/7/26 11:31,Fri,22800,tiramisu croissant,1
2019/7/26 11:55,Fri,20800,tiramisu croissant,1
2019/7/26 13:19,Fri,25900,tiramisu croissant,1
2019/7/27 11:29,Sat,18800,tiramisu croissant,1
2019/7/28 12:21,Sun,14800,tiramisu croissant,1
2019/7/28 12:48,Sun,14800,tiramisu croissant,1
2019/7/29 11:12,Mon,24100,tiramisu croissant,1
2019/7/28 11:14,Mon,15800,tiramisu croissant,1
2019/7/29 13:53,Mon,28000,tiramisu croissant,1
2019/7/31 13:19,Wed,15300,tiramisu croissant,1
2019/7/31 13:58,Wed,15800,tiramisu croissant,1
2019/8/1 11:03,Thur,14500,tiramisu croissant,1
2019/8/1 12:15,Thur,20600,tiramisu croissant,1
2019/8/1 12:24,Thur,32600,tiramisu croissant,1
2019/8/1 14:17,Thur,14800,tiramisu croissant,1
2019/8/2 11:06,Fri,18000,tiramisu croissant,1
2019/8/2 12:21,Fri,15800,tiramisu croissant,1
2019/8/2 12:51,Fri,15800,tiramisu croissant,1
2019/8/4 11:07,Sun,19300,tiramisu croissant,1
2019/8/4 11:41,Sun,24300,tiramisu croissant,1
2019/8/5 11:11,Mon,16300,tiramisu croissant,1
2019/8/5 11:18,Mon,31400,tiramisu croissant,1
2019/8/5 12:14,Mon,26600,tiramisu croissant,1
2019/8/5 12:42,Mon,19600,tiramisu croissant,1
2019/8/7 12:20,Wed,27300,tiramisu croissant,1
2019/8/7 14:50,Wed,23800,tiramisu croissant,1
2019/8/8 12:03,Thur,16500,tiramisu croissant,1
2019/8/8 13:22,Thur,15800,tiramisu croissant,1
2019/8/8 13:36,Thur,33200,tiramisu croissant,2
2019/8/10 11:01,Sat,19600,tiramisu croissant,1
2019/8/10 11:05,Sat,28600,tiramisu croissant,1
2019/8/10 11:38,Sat,25300,tiramisu croissant,1
2019/8/10 13:09,Sat,30200,tiramisu croissant,2
2019/8/10 13:31,Sat,24400,tiramisu croissant,1
2019/8/11 11:08,Sun,22800,tiramisu croissant,1
2019/8/11 11:08,Sun,17800,tiramisu croissant,1
2019/8/11 11:40,Sun,38900,tiramisu croissant,1
2019/8/12 11:08,Mon,20800,tiramisu croissant,1
2019/8/14 11:16,Wed,65600,tiramisu croissant,1
2019/8/15 11:03,Thur,24100,tiramisu croissant,1
2019/8/15 11:06,Thur,17300,tiramisu croissant,1
2019/8/16 11:54,Fri,17800,tiramisu croissant,1
2019/8/17 11:30,Sat,24300,tiramisu croissant,1
2019/8/17 12:29,Sat,14800,tiramisu croissant,1
2019/8/17 13:19,Sat,20300,tiramisu croissant,1
2019/8/17 13:38,Sat,32600,tiramisu croissant,2
2019/8/17 14:07,Sat,19000,tiramisu croissant,1
2019/8/18 11:09,Sun,26600,tiramisu croissant,1
2019/8/18 12:04,Sun,20000,tiramisu croissant,1
2019/8/18 12:50,Sun,23800,tiramisu croissant,1
2019/8/18 14:39,Sun,23000,tiramisu croissant,1
2019/8/19 13:06,Mon,19300,tiramisu croissant,2
2019/8/19 13:53,Mon,24300,tiramisu croissant,1
2019/8/19 14:16,Mon,23800,tiramisu croissant,1
2019/8/19 14:20,Mon,15300,tiramisu croissant,1
2019/8/19 15:27,Mon,21600,tiramisu croissant,2
2019/8/21 12:13,Wed,18300,tiramisu croissant,1
2019/8/21 13:15,Wed,17000,tiramisu croissant,1
2019/8/22 12:08,Thur,23300,tiramisu croissant,1
2019/8/22 12:12,Thur,15800,tiramisu croissant,1
2019/8/22 14:35,Thur,15800,tiramisu croissant,1
2019/8/22 15:24,Thur,26000,tiramisu croissant,1
2019/8/24 11:13,Sat,25600,tiramisu croissant,1
2019/8/24 11:14,Sat,23100,tiramisu croissant,1
2019/8/25 11:04,Sun,15300,tiramisu croissant,1
2019/8/25 12:02,Sun,15800,tiramisu croissant,1
2019/8/25 12:48,Sun,15100,tiramisu croissant,1
2019/8/26 11:49,Mon,15500,tiramisu croissant,2
2019/8/26 12:05,Mon,14800,tiramisu croissant,1
2019/8/26 15:48,Mon,21600,tiramisu croissant,2
2019/8/26 16:11,Mon,22800,tiramisu croissant,1
2019/8/28 11:30,Wed,34100,tiramisu croissant,2
2019/8/28 12:24,Wed,18000,tiramisu croissant,1
2019/8/29 16:45,Thur,24300,tiramisu croissant,1
2019/8/30 15:39,Fri,15500,tiramisu croissant,2
2019/8/30 16:18,Fri,18800,tiramisu croissant,1
2019/8/31 11:15,Sat,18600,tiramisu croissant,1
2019/8/31 11:37,Sat,14800,tiramisu croissant,1
2019/8/31 12:34,Sat,14800,tiramisu croissant,1
2019/9/1 13:56,Sun,14800,tiramisu croissant,1
2019/9/2 14:17,Mon,20300,tiramisu croissant,1
2019/9/2 15:13,Mon,23500,tiramisu croissant,2
2019/9/4 11:49,Wed,23000,tiramisu croissant,1
2019/9/4 12:06,Wed,18600,tiramisu croissant,1
2019/9/4 13:31,Wed,15300,tiramisu croissant,1
2019/9/4 14:52,Wed,25600,tiramisu croissant,1
2019/9/4 14:54,Wed,14800,tiramisu croissant,1
2019/9/5 13:49,Thur,20900,tiramisu croissant,1
2019/9/5 14:46,Thur,18800,tiramisu croissant,1
2019/9/5 15:46,Thur,14800,tiramisu croissant,1
2019/9/6 11:30,Fri,14800,tiramisu croissant,1
2019/9/6 13:46,Fri,19800,tiramisu croissant,1
2019/9/7 11:15,Sat,19800,tiramisu croissant,1
2019/9/7 11:40,Sat,14800,tiramisu croissant,1
2019/9/7 11:47,Sat,22500,tiramisu croissant,2
2019/9/8 11:27,Sun,14800,tiramisu croissant,1
2019/9/8 11:37,Sun,26000,tiramisu croissant,1
2019/9/9 11:12,Mon,23100,tiramisu croissant,1
2019/9/9 13:23,Mon,21000,tiramisu croissant,1
2019/9/11 11:13,Wed,42300,tiramisu croissant,1
2019/9/11 15:30,Wed,15100,tiramisu croissant,1
2019/9/12 12:40,Thur,23300,tiramisu croissant,1
2019/9/12 13:51,Thur,27600,tiramisu croissant,1
2019/9/14 11:18,Sat,22300,tiramisu croissant,1
2019/9/14 11:35,Sat,25400,tiramisu croissant,2
2019/9/14 12:17,Sat,26300,tiramisu croissant,1
2019/9/15 11:33,Sun,24600,tiramisu croissant,1
2019/9/15 12:13,Sun,32600,tiramisu croissant,1
2019/9/15 14:54,Sun,15100,tiramisu croissant,1
2019/9/15 15:28,Sun,57900,tiramisu croissant,2
2019/9/18 11:26,Wed,19800,tiramisu croissant,1
2019/9/18 16:42,Wed,15500,tiramisu croissant,1
2019/9/19 12:23,Thur,20000,tiramisu croissant,2
2019/9/19 12:47,Thur,15300,tiramisu croissant,1
2019/9/19 14:15,Thur,71800,tiramisu croissant,2
2019/9/19 15:53,Thur,23100,tiramisu croissant,1
2019/9/20 11:48,Fri,19300,tiramisu croissant,2
2019/9/20 12:53,Fri,21000,tiramisu croissant,1
2019/9/20 12:59,Fri,15100,tiramisu croissant,1
2019/9/20 13:28,Fri,14800,tiramisu croissant,1
2019/9/20 16:08,Fri,18000,tiramisu croissant,1
2019/9/21 11:19,Sat,23600,tiramisu croissant,1
2019/9/21 11:22,Sat,18300,tiramisu croissant,1
2019/9/21 12:01,Sat,17000,tiramisu croissant,1
2019/9/21 12:27,Sat,16100,tiramisu croissant,1
2019/9/21 12:28,Sat,37900,tiramisu croissant,1
2019/9/22 11:18,Sun,30900,tiramisu croissant,1
2019/9/22 12:51,Sun,14800,tiramisu croissant,1
2019/9/22 13:01,Sun,20000,tiramisu croissant,2
2019/9/23 12:08,Mon,15800,tiramisu croissant,1
2019/9/23 12:43,Mon,15000,tiramisu croissant,1
2019/9/23 13:41,Mon,24600,tiramisu croissant,1
2019/9/23 15:54,Mon,20500,tiramisu croissant,1
2019/9/25 11:05,Wed,14800,tiramisu croissant,1
2019/9/25 15:18,Wed,26300,tiramisu croissant,1
2019/9/27 14:35,Fri,19600,tiramisu croissant,1
2019/9/28 12:23,Sat,18000,tiramisu croissant,1
2019/9/28 12:52,Sat,41400,tiramisu croissant,2
2019/9/28 13:52,Sat,27100,tiramisu croissant,1
2019/9/28 16:12,Sat,15800,tiramisu croissant,1
2019/9/29 11:17,Sun,14800,tiramisu croissant,1
2019/9/29 11:39,Sun,23100,tiramisu croissant,1
2019/9/29 11:49,Sun,17300,tiramisu croissant,1
2019/9/29 15:05,Sun,19600,tiramisu croissant,1
2019/9/30 12:35,Mon,18600,tiramisu croissant,1
2019/9/30 13:43,Mon,27600,tiramisu croissant,1
2019/10/2 12:35,Wed,15500,tiramisu croissant,1
2019/10/3 12:05,Thur,16100,tiramisu croissant,1
2019/10/3 12:54,Thur,14300,tiramisu croissant,1
2019/10/3 13:17,Thur,24000,tiramisu croissant,2
2019/10/3 14:20,Thur,19600,tiramisu croissant,1
2019/10/3 14:44,Thur,19300,tiramisu croissant,1
2019/10/3 14:50,Thur,21800,tiramisu croissant,1
2019/10/5 12:39,Sat,31800,tiramisu croissant,2
2019/10/5 13:34,Sat,15300,tiramisu croissant,1
2019/10/6 13:51,Sun,19300,tiramisu croissant,1
2019/10/7 12:00,Mon,16100,tiramisu croissant,1
2019/10/7 13:31,Mon,15100,tiramisu croissant,1
2019/10/7 16:49,Mon,16100,tiramisu croissant,1
2019/10/9 11:18,Wed,16100,tiramisu croissant,1
2019/10/10 13:05,Thur,68100,tiramisu croissant,7
2019/10/11 11:18,Fri,14800,tiramisu croissant,1
2019/10/11 12:38,Fri,15100,tiramisu croissant,1
2019/10/12 13:11,Sat,23800,tiramisu croissant,1
2019/10/12 13:23,Sat,15300,tiramisu croissant,1
2019/10/13 11:08,Sun,14500,tiramisu croissant,1
2019/10/13 13:15,Sun,41100,tiramisu croissant,2
2019/10/14 12:21,Mon,17300,tiramisu croissant,1
2019/10/14 13:22,Mon,14500,tiramisu croissant,1
2019/10/14 15:21,Mon,28500,tiramisu croissant,2
2019/10/16 11:12,Wed,28900,tiramisu croissant,1
2019/10/16 13:03,Wed,23300,tiramisu croissant,1
2019/10/17 13:16,Thur,24800,tiramisu croissant,1
2019/10/17 13:50,Thur,32300,tiramisu croissant,1
2019/10/17 14:45,Thur,16300,tiramisu croissant,1
2019/10/19 11:09,Sat,15000,tiramisu croissant,1
2019/10/19 11:45,Sat,18000,tiramisu croissant,1
2019/10/19 11:55,Sat,15800,tiramisu croissant,2
2019/10/20 11:34,Sun,28100,tiramisu croissant,1
2019/10/21 11:34,Mon,22800,tiramisu croissant,1
2019/10/21 11:36,Mon,20800,tiramisu croissant,1
2019/10/21 11:58,Mon,47600,tiramisu croissant,5
2019/10/21 12:36,Mon,33700,tiramisu croissant,2
2019/10/23 11:06,Wed,15800,tiramisu croissant,1
2019/10/24 11:03,Thur,25300,tiramisu croissant,1
2019/10/24 13:35,Thur,17300,tiramisu croissant,1
2019/10/24 11:06,Thur,15100,tiramisu croissant,1
2019/10/24 14:06,Thur,15800,tiramisu croissant,1
2019/10/24 14:25,Thur,21000,tiramisu croissant,1
2019/10/25 11:51,Fri,22800,tiramisu croissant,1
2019/10/26 11:03,Sat,14800,tiramisu croissant,1
2019/10/26 11:54,Sat,25800,tiramisu croissant,1
2019/10/26 12:07,Sat,14800,tiramisu croissant,1
2019/10/26 12:47,Sat,20600,tiramisu croissant,1
2019/10/27 11:51,Sun,19800,tiramisu croissant,1
2019/10/27 12:51,Sun,18800,tiramisu croissant,1
2019/10/28 11:14,Mon,19800,tiramisu croissant,1
2019/10/28 13:31,Mon,23300,tiramisu croissant,1
2019/11/1 11:55,Fri,23000,tiramisu croissant,1
2019/11/1 13:52,Fri,22000,tiramisu croissant,1
2019/11/2 11:45,Sat,16100,tiramisu croissant,1
2019/11/2 15:55,Sat,14800,tiramisu croissant,1
2019/11/2 16:40,Sat,28800,tiramisu croissant,1
2019/11/3 11:02,Sun,20800,tiramisu croissant,1
2019/11/3 13:33,Sun,27900,tiramisu croissant,1
2019/11/3 15:06,Sun,14500,tiramisu croissant,1
2019/11/4 16:37,Mon,17000,tiramisu croissant,1
2019/11/6 16:53,Wed,16000,tiramisu croissant,1
2019/11/7 11:26,Thur,14800,tiramisu croissant,1
2019/11/8 11:36,Fri,22800,tiramisu croissant,1
2019/11/8 13:12,Fri,36000,tiramisu croissant,1
2019/11/8 15:01,Fri,14800,tiramisu croissant,1
2019/11/9 11:36,Sat,18300,tiramisu croissant,1
2019/11/9 11:36,Sat,20600,tiramisu croissant,2
2019/11/9 11:36,Sat,19300,tiramisu croissant,1
2019/11/9 11:36,Sat,27300,tiramisu croissant,1
2019/11/9 11:36,Sat,35700,tiramisu croissant,1
2019/11/9 15:40,Sat,14800,tiramisu croissant,1
2019/11/10 11:06,Sun,14800,tiramisu croissant,1
2019/11/10 11:20,Sun,32800,tiramisu croissant,1
2019/11/10 11:44,Sun,16100,tiramisu croissant,1
2019/11/10 11:55,Sun,29100,tiramisu croissant,1
2019/11/10 13:10,Sun,19800,tiramisu croissant,1
2019/11/10 13:35,Sun,24600,tiramisu croissant,1
2019/11/10 15:52,Sun,15800,tiramisu croissant,1
2019/11/11 14:00,Mon,19300,tiramisu croissant,1
2019/11/11 14:39,Mon,20300,tiramisu croissant,1
2019/11/11 17:25,Mon,28300,tiramisu croissant,1
2019/11/13 11:05,Wed,22300,tiramisu croissant,1
2019/11/13 11:37,Wed,30100,tiramisu croissant,1
2019/11/13 12:04,Wed,15800,tiramisu croissant,2
2019/11/13 16:23,Wed,15800,tiramisu croissant,1
2019/11/14 13:10,Thur,39300,tiramisu croissant,1
2019/11/15 11:50,Fri,18500,tiramisu croissant,1
2019/11/15 15:19,Fri,14800,tiramisu croissant,1
2019/11/16 14:21,Sat,24800,tiramisu croissant,1
2019/11/17 11:07,Sun,23800,tiramisu croissant,1
2019/11/17 11:07,Sun,14800,tiramisu croissant,1
2019/11/17 14:12,Sun,14000,tiramisu croissant,1
2019/11/17 14:23,Sun,23500,tiramisu croissant,1
2019/11/18 11:11,Mon,18000,tiramisu croissant,1
2019/11/18 13:55,Mon,14000,tiramisu croissant,1
2019/11/18 14:36,Mon,28800,tiramisu croissant,1
2019/11/18 15:17,Mon,22800,tiramisu croissant,1
2019/11/20 12:59,Wed,20300,tiramisu croissant,1
2019/11/20 13:24,Wed,23800,tiramisu croissant,1
2019/11/23 11:55,Sat,19300,tiramisu croissant,1
2019/11/23 12:00,Sat,36100,tiramisu croissant,2
2019/11/23 13:44,Sat,18800,tiramisu croissant,1
2019/11/23 15:30,Sat,22300,tiramisu croissant,1
2019/11/23 15:54,Sat,19500,tiramisu croissant,1
2019/11/24 13:39,Sun,18800,tiramisu croissant,1
2019/11/24 13:44,Sun,20300,tiramisu croissant,2
2019/11/25 11:08,Mon,18800,tiramisu croissant,1
2019/11/25 12:54,Mon,26300,tiramisu croissant,1
2019/11/27 12:02,Wed,33400,tiramisu croissant,1
2019/11/27 12:59,Wed,15800,tiramisu croissant,1
2019/11/28 11:48,Thur,38600,tiramisu croissant,2
2019/11/28 13:15,Thur,25300,tiramisu croissant,1
2019/11/28 14:15,Thur,18300,tiramisu croissant,1
2019/11/29 11:05,Fri,15800,tiramisu croissant,1
2019/11/29 12:50,Fri,15800,tiramisu croissant,1
2019/11/29 13:23,Fri,19300,tiramisu croissant,1
2019/11/29 14:42,Fri,15300,tiramisu croissant,1
2019/11/30 13:01,Sat,38200,tiramisu croissant,2
2019/11/30 13:44,Sat,25100,tiramisu croissant,2
2019/11/30 13:49,Sat,20300,tiramisu croissant,2
2019/11/30 17:04,Sat,27600,tiramisu croissant,1
2019/12/1 11:48,Sun,15300,tiramisu croissant,1
2019/12/1 12:35,Sun,23000,tiramisu croissant,1
2019/12/1 13:28,Sun,20300,tiramisu croissant,2
2019/12/1 14:24,Sun,31100,tiramisu croissant,1
2019/12/1 14:29,Sun,20800,tiramisu croissant,1
2019/12/1 16:51,Sun,18300,tiramisu croissant,1
2019/12/2 13:03,Mon,16100,tiramisu croissant,1
2019/12/2 13:38,Mon,14800,tiramisu croissant,1
2019/12/4 11:10,Wed,23300,tiramisu croissant,1
2019/12/5 11:05,Thur,57700,tiramisu croissant,3
2019/12/5 11:08,Thur,15300,tiramisu croissant,1
2019/12/5 12:32,Thur,16000,tiramisu croissant,1
2019/12/5 12:39,Thur,21800,tiramisu croissant,1
2019/12/5 15:22,Thur,15800,tiramisu croissant,1
2019/12/6 11:38,Fri,13800,tiramisu croissant,1
2019/12/6 11:49,Fri,14800,tiramisu croissant,1
2019/12/7 12:28,Sat,16100,tiramisu croissant,1
2019/12/7 13:36,Sat,14800,tiramisu croissant,1
2019/12/7 13:39,Sat,30800,tiramisu croissant,1
2019/12/7 13:50,Sat,14500,tiramisu croissant,1
2019/12/8 11:02,Sun,17300,tiramisu croissant,1
2019/12/8 11:22,Sun,20500,tiramisu croissant,3
2019/12/8 12:22,Sun,15300,tiramisu croissant,1
2019/12/8 12:49,Sun,30600,tiramisu croissant,2
2019/12/8 13:12,Sun,15800,tiramisu croissant,1
2019/12/8 13:22,Sun,15800,tiramisu croissant,1
2019/12/8 13:44,Sun,28100,tiramisu croissant,1
2019/12/8 14:57,Sun,25100,tiramisu croissant,1
2019/12/9 11:31,Mon,14800,tiramisu croissant,1
2019/12/9 12:09,Mon,33100,tiramisu croissant,2
2019/12/9 13:22,Mon,15300,tiramisu croissant,1
2019/12/9 13:35,Mon,29800,tiramisu croissant,1
2019/12/9 13:54,Mon,15800,tiramisu croissant,1
2019/12/9 17:01,Mon,17100,tiramisu croissant,1
2019/12/11 11:36,Wed,15000,tiramisu croissant,1
2019/12/11 11:37,Wed,18800,tiramisu croissant,1
2019/12/11 13:32,Wed,21500,tiramisu croissant,1
2019/12/12 11:15,Thur,29200,tiramisu croissant,1
2019/12/12 11:27,Thur,14800,tiramisu croissant,1
2019/12/12 11:48,Thur,22300,tiramisu croissant,3
2019/12/12 17:22,Thur,21800,tiramisu croissant,1
2019/12/14 11:51,Sat,40500,tiramisu croissant,3
2019/12/14 12:41,Sat,18300,tiramisu croissant,1
2019/12/14 12:51,Sat,19300,tiramisu croissant,1
2019/12/14 13:14,Sat,15800,tiramisu croissant,1
2019/12/14 14:15,Sat,16800,tiramisu croissant,1
2019/12/15 14:46,Sun,21800,tiramisu croissant,1
2019/12/15 15:16,Sun,15300,tiramisu croissant,1
2019/12/16 11:12,Mon,15300,tiramisu croissant,1
2019/12/16 13:21,Mon,16800,tiramisu croissant,1
2019/12/16 13:37,Mon,14500,tiramisu croissant,1
2019/12/16 14:26,Mon,20300,tiramisu croissant,1
2019/12/16 14:32,Mon,19500,tiramisu croissant,1
2019/12/18 11:22,Wed,52800,tiramisu croissant,1
2019/12/18 12:45,Wed,19600,tiramisu croissant,1
2019/12/19 11:45,Thur,35300,tiramisu croissant,1
2019/12/19 12:17,Thur,15800,tiramisu croissant,2
2019/12/19 13:06,Thur,32500,tiramisu croissant,1
2019/12/20 11:18,Fri,16800,tiramisu croissant,1
2019/12/20 11:53,Fri,16300,tiramisu croissant,1
2019/12/20 14:29,Fri,19300,tiramisu croissant,1
2019/12/21 11:04,Sat,15100,tiramisu croissant,1
2019/12/21 12:17,Sat,15300,tiramisu croissant,1
2019/12/21 14:18,Sat,15800,tiramisu croissant,1
2019/12/22 11:38,Sun,19300,tiramisu croissant,1
2019/12/22 13:54,Sun,15300,tiramisu croissant,1
2019/12/22 14:35,Sun,19300,tiramisu croissant,1
2019/12/22 14:45,Sun,19000,tiramisu croissant,1
2019/12/22 15:10,Sun,15000,tiramisu croissant,1
2019/12/22 15:53,Sun,19600,tiramisu croissant,1
2019/12/23 12:06,Mon,23800,tiramisu croissant,1
2019/12/23 14:42,Mon,19500,tiramisu croissant,1
2019/12/24 11:13,Tues,15300,tiramisu croissant,1
2019/12/24 13:14,Tues,19300,tiramisu croissant,1
2019/12/25 11:29,Wed,24100,tiramisu croissant,1
2019/12/25 12:16,Wed,14800,tiramisu croissant,1
2019/12/25 14:47,Wed,20000,tiramisu croissant,1
2019/12/26 12:16,Thur,20500,tiramisu croissant,1
2019/12/26 12:18,Thur,26600,tiramisu croissant,1
2019/12/26 13:47,Thur,14500,tiramisu croissant,2
2019/12/27 11:39,Fri,16300,tiramisu croissant,1
2019/12/27 12:45,Fri,15800,tiramisu croissant,1
2019/12/28 11:10,Sat,16100,tiramisu croissant,1
2019/12/28 11:48,Sat,14800,tiramisu croissant,1
2019/12/28 12:35,Sat,20900,tiramisu croissant,1
2019/12/28 13:31,Sat,21500,tiramisu croissant,1
2019/12/28 13:47,Sat,18800,tiramisu croissant,1
2019/12/28 14:55,Sat,21500,tiramisu croissant,1
2019/12/28 16:18,Sat,58900,tiramisu croissant,3
2019/12/29 11:16,Sun,14000,tiramisu croissant,1
2019/12/29 11:34,Sun,15300,tiramisu croissant,1
2019/12/29 12:39,Sun,14800,tiramisu croissant,1
2019/12/29 12:52,Sun,23800,tiramisu croissant,1
2019/12/29 14:32,Sun,15000,tiramisu croissant,1
2019/12/30 11:27,Mon,19800,tiramisu croissant,1
2019/12/30 12:23,Mon,91300,tiramisu croissant,6
2019/12/30 15:12,Mon,16100,tiramisu croissant,1
2020/1/2 11:23,Thur,20300,tiramisu croissant,1
2020/1/2 12:33,Thur,14800,tiramisu croissant,1
2020/1/2 12:50,Thur,29300,tiramisu croissant,1
2020/1/2 15:40,Thur,46900,tiramisu croissant,1
2020/1/3 11:17,Fri,20300,tiramisu croissant,1
2020/1/3 13:44,Fri,17300,tiramisu croissant,1
2020/1/3 14:17,Fri,43100,tiramisu croissant,4
2020/1/4 11:03,Sat,23800,tiramisu croissant,1
2020/1/5 11:23,Sun,18000,tiramisu croissant,1
2020/1/5 13:49,Sun,20300,tiramisu croissant,1
2020/1/5 14:06,Sun,23800,tiramisu croissant,1
2020/1/6 12:30,Mon,30800,tiramisu croissant,2
2020/1/6 12:50,Mon,17300,tiramisu croissant,1
2020/1/8 12:47,Wed,30300,tiramisu croissant,1
2020/1/8 13:15,Wed,41400,tiramisu croissant,2
2020/1/8 15:42,Wed,19800,tiramisu croissant,1
2020/1/9 11:12,Thur,35700,tiramisu croissant,2
2020/1/9 12:27,Thur,28800,tiramisu croissant,2
2020/1/9 12:34,Thur,18300,tiramisu croissant,1
2020/1/9 13:59,Thur,19800,tiramisu croissant,1
2020/1/10 11:07,Fri,16300,tiramisu croissant,1
2020/1/10 12:57,Fri,19600,tiramisu croissant,1
2020/1/10 13:51,Fri,15800,tiramisu croissant,1
2020/1/11 11:03,Sat,29000,tiramisu croissant,6
2020/1/11 13:03,Sat,20600,tiramisu croissant,2
2020/1/11 13:11,Sat,15100,tiramisu croissant,1
2020/1/12 14:11,Sun,14800,tiramisu croissant,1
2020/1/13 11:52,Mon,20300,tiramisu croissant,1
2020/1/13 11:59,Mon,15300,tiramisu croissant,1
2020/1/15 11:04,Wed,20300,tiramisu croissant,1
2020/1/15 11:28,Wed,116500,tiramisu croissant,10
2020/1/15 13:01,Wed,18300,tiramisu croissant,1
2020/1/18 11:16,Sat,18300,tiramisu croissant,1
2020/1/18 14:11,Sat,34700,tiramisu croissant,3
2020/1/18 14:36,Sat,16500,tiramisu croissant,1
2020/1/19 11:05,Sun,19300,tiramisu croissant,1
2020/1/19 11:09,Sun,31100,tiramisu croissant,1
2020/1/19 11:18,Sun,20600,tiramisu croissant,1
2020/1/19 11:21,Sun,37000,tiramisu croissant,4
2020/1/19 12:40,Sun,16300,tiramisu croissant,1
2020/1/20 11:25,Mon,23800,tiramisu croissant,1
2020/1/20 11:32,Mon,15000,tiramisu croissant,1
2020/1/20 13:59,Mon,19300,tiramisu croissant,1
2020/1/22 13:44,Wed,18300,tiramisu croissant,1
2020/1/22 14:17,Wed,18500,tiramisu croissant,1
2020/1/23 11:08,Thur,77100,tiramisu croissant,5
2020/1/23 11:45,Thur,18800,tiramisu croissant,1
2020/1/24 11:40,Fri,14800,tiramisu croissant,1
2020/1/24 11:50,Fri,15300,tiramisu croissant,1
2020/1/26 11:07,Sun,14800,tiramisu croissant,1
2020/1/26 12:36,Sun,28100,tiramisu croissant,1
2020/1/26 15:53,Sun,16800,tiramisu croissant,1
2020/1/27 11:02,Mon,21600,tiramisu croissant,1
2020/1/27 12:57,Mon,20300,tiramisu croissant,1
2020/1/27 13:29,Mon,26000,tiramisu croissant,1
2020/1/27 13:31,Mon,20600,tiramisu croissant,1
2020/1/29 11:09,Wed,15300,tiramisu croissant,1
2020/1/29 11:46,Wed,17500,tiramisu croissant,1
2020/1/29 15:31,Wed,25900,tiramisu croissant,1
2020/1/30 11:53,Thur,28800,tiramisu croissant,2
2020/1/30 13:20,Thur,29600,tiramisu croissant,2
2020/1/31 11:21,Fri,19800,tiramisu croissant,1
2020/1/31 12:06,Fri,14800,tiramisu croissant,1
2020/1/31 13:09,Fri,20300,tiramisu croissant,1
2020/1/31 13:39,Fri,15000,tiramisu croissant,1
2020/1/31 14:15,Fri,16800,tiramisu croissant,1
2020/2/1 13:18,Sat,15300,tiramisu croissant,1
2020/2/1 13:42,Sat,19300,tiramisu croissant,1
2020/2/1 13:50,Sat,23600,tiramisu croissant,1
2020/2/1 14:06,Sat,15800,tiramisu croissant,1
2020/2/2 11:05,Sun,19300,tiramisu croissant,1
2020/2/2 11:34,Sun,15800,tiramisu croissant,1
2020/2/2 12:17,Sun,16800,tiramisu croissant,1
2020/2/2 12:24,Sun,15300,tiramisu croissant,1
2020/2/2 13:31,Sun,14500,tiramisu croissant,1
2020/2/2 13:33,Sun,19300,tiramisu croissant,1
2020/2/3 15:30,Mon,16100,tiramisu croissant,1
2020/2/3 16:42,Mon,15800,tiramisu croissant,1
2020/2/5 11:08,Wed,20600,tiramisu croissant,2
2020/2/5 11:48,Wed,34100,tiramisu croissant,2
2020/2/5 12:32,Wed,16300,tiramisu croissant,1
2020/2/5 12:36,Wed,17500,tiramisu croissant,1
2020/2/5 13:12,Wed,21300,tiramisu croissant,1
2020/2/6 11:05,Thur,14500,tiramisu croissant,1
2020/2/6 11:13,Thur,15800,tiramisu croissant,1
2020/2/6 12:36,Thur,14800,tiramisu croissant,1
2020/2/6 14:58,Thur,20300,tiramisu croissant,1
2020/2/7 15:14,Fri,19300,tiramisu croissant,1
2020/2/8 12:24,Sat,22800,tiramisu croissant,1
2020/2/8 15:22,Sat,22800,tiramisu croissant,1
2020/2/8 15:24,Sat,20800,tiramisu croissant,1
2020/2/9 11:03,Sun,30000,tiramisu croissant,1
2020/2/9 12:33,Sun,19800,tiramisu croissant,1
2020/2/9 13:54,Sun,18300,tiramisu croissant,1
2020/2/10 13:24,Mon,15000,tiramisu croissant,1
2020/2/10 14:03,Mon,16000,tiramisu croissant,1
2020/2/12 11:04,Wed,15000,tiramisu croissant,1
2020/2/12 11:04,Wed,37600,tiramisu croissant,3
2020/2/12 14:35,Wed,55200,tiramisu croissant,4
2020/2/12 15:12,Wed,24500,tiramisu croissant,1
2020/2/13 11:20,Thur,15500,tiramisu croissant,1
2020/2/13 12:23,Thur,14800,tiramisu croissant,1
2020/2/14 12:58,Fri,23300,tiramisu croissant,1
2020/2/14 13:46,Fri,57500,tiramisu croissant,3
2020/2/15 12:15,Sat,19000,tiramisu croissant,2
2020/2/15 13:04,Sat,19300,tiramisu croissant,1
2020/2/16 11:17,Sun,27100,tiramisu croissant,1
2020/2/16 11:17,Sun,17000,tiramisu croissant,1
2020/2/16 13:09,Sun,15000,tiramisu croissant,1
2020/2/17 13:03,Mon,20100,tiramisu croissant,1
2020/2/17 13:05,Mon,20300,tiramisu croissant,1
2020/2/17 14:29,Mon,20300,tiramisu croissant,1
2020/2/17 17:01,Mon,14500,tiramisu croissant,2
2020/2/19 11:00,Wed,14500,tiramisu croissant,1
2020/2/19 11:34,Wed,14500,tiramisu croissant,1
2020/2/19 22:13,Wed,15800,tiramisu croissant,1
2020/2/20 11:05,Thur,23100,tiramisu croissant,1
2020/2/20 11:06,Thur,20000,tiramisu croissant,2
2020/2/20 11:01,Thur,14800,tiramisu croissant,1
2020/2/20 11:23,Thur,27600,tiramisu croissant,2
2020/2/20 13:50,Thur,42200,tiramisu croissant,3
2020/2/21 13:28,Fri,14800,tiramisu croissant,1
2020/2/22 11:09,Sat,28300,tiramisu croissant,2
2020/2/22 12:13,Sat,17000,tiramisu croissant,1
2020/2/22 12:14,Sat,19300,tiramisu croissant,1
2020/2/22 12:33,Sat,14500,tiramisu croissant,1
2020/2/22 13:10,Sat,22000,tiramisu croissant,1
2020/2/22 13:51,Sat,21500,tiramisu croissant,1
2020/2/23 11:04,Sun,35300,tiramisu croissant,1
2020/2/23 11:06,Sun,18000,tiramisu croissant,2
2020/2/23 11:47,Sun,23500,tiramisu croissant,1
2020/2/23 11:52,Sun,25500,tiramisu croissant,1
2020/2/23 12:09,Sun,20300,tiramisu croissant,2
2020/2/23 12:39,Sun,19800,tiramisu croissant,1
2020/2/23 12:42,Sun,24300,tiramisu croissant,1
2020/2/23 12:49,Sun,32000,tiramisu croissant,2
2020/2/23 13:06,Sun,20300,tiramisu croissant,1
2020/2/23 13:35,Sun,18500,tiramisu croissant,1
2020/2/23 13:58,Sun,18000,tiramisu croissant,1
2020/2/24 11:07,Mon,29900,tiramisu croissant,2
2020/2/24 15:55,Mon,19300,tiramisu croissant,1
2020/2/26 11:20,Wed,18300,tiramisu croissant,1
2020/2/26 12:01,Wed,23300,tiramisu croissant,1
2020/2/26 12:48,Wed,15000,tiramisu croissant,1
2020/2/26 13:28,Wed,15800,tiramisu croissant,1
2020/2/26 14:29,Wed,23300,tiramisu croissant,1
2020/2/27 11:23,Thur,23800,tiramisu croissant,1
2020/2/27 11:24,Thur,15300,tiramisu croissant,1
2020/2/27 11:26,Thur,20900,tiramisu croissant,1
2020/2/27 12:04,Thur,14800,tiramisu croissant,2
2020/2/27 12:20,Thur,19800,tiramisu croissant,1
2020/2/28 11:09,Fri,25100,tiramisu croissant,1
2020/2/28 12:04,Fri,20300,tiramisu croissant,1
2020/2/28 12:57,Fri,19600,tiramisu croissant,1
2020/2/29 11:03,Sat,20600,tiramisu croissant,1
2020/2/29 12:54,Sat,21800,tiramisu croissant,1
2020/3/1 11:06,Sun,34100,tiramisu croissant,1
2020/3/1 11:14,Sun,23800,tiramisu croissant,1
2020/3/1 11:47,Sun,41800,tiramisu croissant,2
2020/3/1 12:45,Sun,22300,tiramisu croissant,1
2020/3/1 13:32,Sun,24800,tiramisu croissant,1
2020/3/1 14:19,Sun,23500,tiramisu croissant,1
2020/3/1 14:57,Sun,14500,tiramisu croissant,1
2020/3/2 12:28,Mon,14800,tiramisu croissant,1
2020/3/2 13:00,Mon,18300,tiramisu croissant,1
2020/3/2 13:00,Mon,20000,tiramisu croissant,2
2020/3/2 14:00,Mon,15300,tiramisu croissant,1
2020/3/2 14:02,Mon,21600,tiramisu croissant,2
2020/3/5 11:03,Thur,14800,tiramisu croissant,1
2020/3/5 11:36,Thur,37100,tiramisu croissant,2
2020/3/5 11:39,Thur,15500,tiramisu croissant,1
2020/3/5 12:17,Thur,14800,tiramisu croissant,1
2020/3/5 12:28,Thur,18000,tiramisu croissant,1
2020/3/5 13:39,Thur,18500,tiramisu croissant,1
2020/3/5 13:46,Thur,16300,tiramisu croissant,1
2020/3/5 13:48,Thur,27800,tiramisu croissant,1
2020/3/6 11:53,Fri,17500,tiramisu croissant,1
2020/3/6 12:02,Fri,16800,tiramisu croissant,1
2020/3/6 12:22,Fri,14800,tiramisu croissant,1
2020/3/6 13:44,Fri,15800,tiramisu croissant,1
2020/3/7 11:29,Sat,20800,tiramisu croissant,1
2020/3/7 12:02,Sat,17300,tiramisu croissant,1
2020/3/7 12:58,Sat,23000,tiramisu croissant,1
2020/3/7 14:20,Sat,19800,tiramisu croissant,1
2020/3/7 14:40,Sat,14000,tiramisu croissant,1
2020/3/7 14:56,Sat,16800,tiramisu croissant,1
2020/3/8 11:09,Sun,14800,tiramisu croissant,1
2020/3/8 12:03,Sun,29100,tiramisu croissant,1
2020/3/8 12:03,Sun,19600,tiramisu croissant,1
2020/3/8 12:28,Sun,32800,tiramisu croissant,1
2020/3/8 13:44,Sun,19600,tiramisu croissant,1
2020/3/8 13:48,Sun,18500,tiramisu croissant,1
2020/3/9 11:42,Mon,14800,tiramisu croissant,1
2020/3/9 12:24,Mon,16000,tiramisu croissant,1
2020/3/9 12:50,Mon,19000,tiramisu croissant,1
2020/3/9 14:05,Mon,18000,tiramisu croissant,2
2020/3/11 11:51,Wed,16000,tiramisu croissant,1
2020/3/11 11:57,Wed,27100,tiramisu croissant,1
2020/3/12 11:20,Thur,34100,tiramisu croissant,2
2020/3/12 11:31,Thur,18000,tiramisu croissant,1
2020/3/12 13:34,Thur,25100,tiramisu croissant,2
2020/3/12 14:32,Thur,16100,tiramisu croissant,1
2020/3/12 15:17,Thur,22800,tiramisu croissant,1
2020/3/13 11:46,Fri,23800,tiramisu croissant,1
2020/3/13 12:14,Fri,21600,tiramisu croissant,2
2020/3/13 12:30,Fri,14800,tiramisu croissant,1
2020/3/13 12:35,Fri,18800,tiramisu croissant,1
2020/3/13 12:37,Fri,25100,tiramisu croissant,1
2020/3/13 13:48,Fri,15300,tiramisu croissant,1
2020/3/14 11:03,Sat,15100,tiramisu croissant,1
2020/3/14 11:11,Sat,28300,tiramisu croissant,2
2020/3/14 12:22,Sat,19000,tiramisu croissant,1
2020/3/14 12:57,Sat,17500,tiramisu croissant,1
2020/3/14 13:52,Sat,21800,tiramisu croissant,1
2020/3/15 11:13,Sun,19300,tiramisu croissant,1
2020/3/15 12:03,Sun,20500,tiramisu croissant,1
2020/3/15 13:02,Sun,15000,tiramisu croissant,1
2020/3/15 13:44,Sun,14800,tiramisu croissant,1
2020/3/15 14:05,Sun,15000,tiramisu croissant,1
2020/3/15 14:18,Sun,16000,tiramisu croissant,1
2020/3/16 11:11,Mon,19300,tiramisu croissant,1
2020/3/16 11:59,Mon,26800,tiramisu croissant,1
2020/3/16 12:58,Mon,23100,tiramisu croissant,1
2020/3/16 13:19,Mon,15300,tiramisu croissant,1
2020/3/16 13:45,Mon,17000,tiramisu croissant,1
2020/3/16 14:05,Mon,34900,tiramisu croissant,1
2020/3/18 11:10,Wed,24000,tiramisu croissant,1
2020/3/18 12:10,Wed,15800,tiramisu croissant,1
2020/3/18 12:18,Wed,14500,tiramisu croissant,2
2020/3/19 11:06,Thur,16300,tiramisu croissant,1
2020/3/19 15:11,Thur,20000,tiramisu croissant,2
2020/3/21 11:04,Sat,27800,tiramisu croissant,1
2020/3/21 11:44,Sat,27600,tiramisu croissant,1
2020/3/21 12:11,Sat,20900,tiramisu croissant,1
2020/3/21 13:32,Sat,19300,tiramisu croissant,1
2020/3/21 14:28,Sat,15800,tiramisu croissant,1
2020/3/21 15:14,Sat,19600,tiramisu croissant,1
2020/3/22 11:43,Sun,32900,tiramisu croissant,1
2020/3/22 12:38,Sun,31500,tiramisu croissant,1
2020/3/22 14:31,Sun,19500,tiramisu croissant,1
2020/3/23 11:06,Mon,14500,tiramisu croissant,1
2020/3/23 11:53,Mon,14500,tiramisu croissant,2
2020/3/23 12:04,Mon,15500,tiramisu croissant,1
2020/3/23 12:44,Mon,15000,tiramisu croissant,1
2020/3/23 14:32,Mon,40700,tiramisu croissant,2
2020/3/25 11:05,Wed,19300,tiramisu croissant,1
2020/3/25 12:42,Wed,18800,tiramisu croissant,1
2020/3/25 14:12,Wed,22300,tiramisu croissant,1
2020/3/25 14:17,Wed,21300,tiramisu croissant,1
2020/3/25 14:57,Wed,14500,tiramisu croissant,1
2020/3/26 11:04,Thur,15300,tiramisu croissant,1
2020/3/26 14:44,Thur,31100,tiramisu croissant,1
2020/3/26 15:07,Thur,15800,tiramisu croissant,1
2020/3/26 15:22,Thur,14800,tiramisu croissant,1
2020/3/27 11:42,Fri,17000,tiramisu croissant,1
2020/3/27 13:00,Fri,19500,tiramisu croissant,1
2020/3/27 13:10,Fri,18500,tiramisu croissant,1
2020/3/27 15:36,Fri,28800,tiramisu croissant,1
2020/3/27 15:48,Fri,14000,tiramisu croissant,1
2020/3/28 11:09,Sat,26300,tiramisu croissant,1
2020/3/28 11:38,Sat,14800,tiramisu croissant,1
2020/3/28 11:55,Sat,40300,tiramisu croissant,1
2020/3/28 12:17,Sat,15500,tiramisu croissant,1
2020/3/28 13:05,Sat,22600,tiramisu croissant,1
2020/3/28 13:39,Sat,24100,tiramisu croissant,1
2020/3/29 11:25,Sun,27800,tiramisu croissant,1
2020/3/29 12:02,Sun,29800,tiramisu croissant,1
2020/3/29 12:15,Sun,26900,tiramisu croissant,1
2020/3/29 13:16,Sun,19600,tiramisu croissant,1
2020/3/29 13:28,Sun,15000,tiramisu croissant,1
2020/3/29 15:37,Sun,15300,tiramisu croissant,1
2020/3/30 11:28,Mon,28600,tiramisu croissant,2
2020/3/30 13:25,Mon,18800,tiramisu croissant,1
2020/3/30 13:38,Mon,14500,tiramisu croissant,1
2020/4/1 12:45,Wed,18300,tiramisu croissant,1
2020/4/1 13:29,Wed,32100,tiramisu croissant,2
2020/4/1 13:49,Wed,28800,tiramisu croissant,1
2020/4/1 14:18,Wed,24300,tiramisu croissant,1
2020/4/2 11:06,Thur,15800,tiramisu croissant,1
2020/4/2 11:43,Thur,22800,tiramisu croissant,1
2020/4/2 12:11,Thur,28800,tiramisu croissant,1
2020/4/2 13:58,Thur,20600,tiramisu croissant,2
2020/4/2 16:21,Thur,29500,tiramisu croissant,1
2020/4/2 16:31,Thur,16100,tiramisu croissant,1
2020/4/3 11:24,Fri,24800,tiramisu croissant,1
2020/4/3 12:08,Fri,19300,tiramisu croissant,1
2020/4/3 14:12,Fri,14000,tiramisu croissant,1
2020/4/4 14:06,Sat,21800,tiramisu croissant,1
2020/4/4 16:11,Sat,16800,tiramisu croissant,2
2020/4/5 11:18,Sun,19000,tiramisu croissant,2
2020/4/5 13:34,Sun,22300,tiramisu croissant,1
2020/4/5 15:28,Sun,18100,tiramisu croissant,1
2020/4/6 14:41,Mon,14500,tiramisu croissant,1
2020/4/6 15:55,Mon,27100,tiramisu croissant,1
2020/4/6 17:21,Mon,15300,tiramisu croissant,1
2020/4/8 11:01,Wed,17300,tiramisu croissant,1
2020/4/8 11:40,Wed,25800,tiramisu croissant,2
2020/4/8 12:01,Wed,30300,tiramisu croissant,1
2020/4/8 12:10,Wed,19800,tiramisu croissant,1
2020/4/8 14:49,Wed,18000,tiramisu croissant,1
2020/4/8 15:53,Wed,22300,tiramisu croissant,1
2020/4/9 11:10,Thur,26600,tiramisu croissant,1
2020/4/9 12:45,Thur,14500,tiramisu croissant,2
2020/4/9 16:44,Thur,24100,tiramisu croissant,1
2020/4/10 11:43,Fri,19300,tiramisu croissant,1
2020/4/10 11:45,Fri,20500,tiramisu croissant,1
2020/4/10 12:29,Fri,15300,tiramisu croissant,1
2020/4/10 16:13,Fri,31600,tiramisu croissant,1
2020/4/10 17:14,Fri,15500,tiramisu croissant,1
2020/4/11 11:20,Sat,17300,tiramisu croissant,1
2020/4/11 11:40,Sat,29800,tiramisu croissant,2
2020/4/11 12:34,Sat,21000,tiramisu croissant,1
2020/4/11 12:40,Sat,18300,tiramisu croissant,1
2020/4/11 14:45,Sat,14000,tiramisu croissant,1
2020/4/11 15:01,Sat,19300,tiramisu croissant,1
2020/4/12 12:08,Sun,24300,tiramisu croissant,1
2020/4/12 12:19,Sun,15300,tiramisu croissant,1
2020/4/12 13:33,Sun,18300,tiramisu croissant,1
2020/4/12 14:06,Sun,15000,tiramisu croissant,1
2020/4/13 15:19,Mon,26300,tiramisu croissant,1
2020/4/15 11:20,Wed,19800,tiramisu croissant,1
2020/4/15 14:22,Wed,14800,tiramisu croissant,1
2020/4/16 13:04,Thur,18300,tiramisu croissant,1
2020/4/17 12:12,Fri,19300,tiramisu croissant,1
2020/4/17 13:18,Fri,15500,tiramisu croissant,2
2020/4/17 16:05,Fri,17000,tiramisu croissant,1
2020/4/18 11:19,Sat,19300,tiramisu croissant,1
2020/4/18 11:39,Sat,20800,tiramisu croissant,1
2020/4/18 11:46,Sat,33900,tiramisu croissant,2
2020/4/18 12:22,Sat,16300,tiramisu croissant,1
2020/4/18 14:10,Sat,36000,tiramisu croissant,1
2020/4/18 14:12,Sat,30100,tiramisu croissant,1
2020/4/19 15:02,Sun,16500,tiramisu croissant,1
2020/4/19 15:16,Sun,16100,tiramisu croissant,1
2020/4/20 11:17,Mon,25100,tiramisu croissant,1
2020/4/20 14:56,Mon,29900,tiramisu croissant,3
2020/4/22 11:02,Wed,20100,tiramisu croissant,1
2020/4/22 12:18,Wed,18300,tiramisu croissant,1
2020/4/22 13:05,Wed,20300,tiramisu croissant,1
2020/4/22 13:43,Wed,25700,tiramisu croissant,1
2020/4/22 15:05,Wed,16800,tiramisu croissant,1
2020/4/23 12:57,Thur,17500,tiramisu croissant,1
2020/4/23 13:17,Thur,20100,tiramisu croissant,1
2020/4/23 15:16,Thur,15000,tiramisu croissant,1
2020/4/24 12:00,Fri,19500,tiramisu croissant,1
2020/4/24 12:15,Fri,30900,tiramisu croissant,3
2020/4/24 12:53,Fri,24800,tiramisu croissant,1
2020/4/24 16:27,Fri,15300,tiramisu croissant,1
2020/4/25 11:10,Sat,18300,tiramisu croissant,1
2020/4/25 11:37,Sat,20600,tiramisu croissant,1
2020/4/25 13:30,Sat,28600,tiramisu croissant,1
2020/4/25 13:56,Sat,29300,tiramisu croissant,1
2020/4/25 13:56,Sat,19000,tiramisu croissant,1
2020/4/25 14:25,Sat,22800,tiramisu croissant,1
2020/4/26 11:51,Sun,28300,tiramisu croissant,2
2020/4/26 13:01,Sun,14800,tiramisu croissant,1
2020/4/26 14:05,Sun,17600,tiramisu croissant,1
2020/4/27 11:41,Mon,19800,tiramisu croissant,1
2020/4/27 11:42,Mon,30800,tiramisu croissant,2
2020/4/27 11:56,Mon,22300,tiramisu croissant,1
2020/4/27 12:02,Mon,15000,tiramisu croissant,1
2020/4/27 13:22,Mon,14500,tiramisu croissant,1
2020/4/27 13:35,Mon,14000,tiramisu croissant,1
2020/4/27 15:07,Mon,18800,tiramisu croissant,1
2020/4/29 12:24,Wed,23500,tiramisu croissant,1
2020/4/29 13:15,Wed,14800,tiramisu croissant,1
2020/4/29 15:05,Wed,26800,tiramisu croissant,1
2020/4/29 16:35,Wed,16100,tiramisu croissant,1
2020/4/30 11:18,Thur,31300,tiramisu croissant,1
2020/4/30 11:43,Thur,18300,tiramisu croissant,2
2020/4/30 13:10,Thur,14800,tiramisu croissant,1
2020/5/1 11:09,Fri,31600,tiramisu croissant,1
2020/5/1 11:32,Fri,15000,tiramisu croissant,1
2020/5/1 11:47,Fri,19800,tiramisu croissant,1
2020/5/1 13:55,Fri,21300,tiramisu croissant,1
2020/5/1 15:19,Fri,14500,tiramisu croissant,2
2020/5/2 11:39,Sat,19800,tiramisu croissant,1
2020/5/2 13:45,Sat,15000,tiramisu croissant,1
2020/5/2 14:45,Sat,24100,tiramisu croissant,1
2019/7/13 15:09,Sat,14000,cacao deep,1
2019/7/13 16:32,Sat,22300,cacao deep,1
2019/7/14 11:44,Sun,26300,cacao deep,2
2019/7/14 12:59,Sun,18300,cacao deep,1
2019/7/14 14:06,Sun,23600,cacao deep,1
2019/7/15 11:45,Mon,15100,cacao deep,1
2019/8/14 11:31,Wed,22300,cacao deep,1
2019/8/16 11:54,Fri,17800,cacao deep,1
2019/8/17 11:17,Sat,24100,cacao deep,1
2019/8/18 13:06,Sun,14300,cacao deep,1
2019/8/18 14:39,Sun,23000,cacao deep,1
2019/8/18 12:40,Sun,16300,cacao deep,1
2019/8/19 12:21,Mon,15800,cacao deep,1
2019/8/19 13:24,Mon,14800,cacao deep,1
2019/8/22 12:08,Thur,23300,cacao deep,1
2019/8/23 15:32,Fri,22000,cacao deep,1
2019/8/24 11:51,Sat,15600,cacao deep,1
2019/8/24 12:56,Sat,23300,cacao deep,1
2019/8/25 13:13,Sun,15600,cacao deep,1
2019/8/26 11:30,Mon,18000,cacao deep,1
2019/8/26 14:25,Mon,15300,cacao deep,1
2019/8/26 16:06,Mon,14000,cacao deep,2
2019/8/29 16:45,Thur,24300,cacao deep,1
2019/9/1 11:05,Sun,23300,cacao deep,1
2019/9/1 12:25,Sun,22900,cacao deep,1
2019/9/1 12:39,Sun,28300,cacao deep,1
2019/9/1 14:05,Sun,33100,cacao deep,1
2019/9/2 14:30,Mon,24300,cacao deep,1
2019/9/2 15:24,Mon,15000,cacao deep,1
2019/9/4 12:04,Wed,14800,cacao deep,1
2019/9/4 13:42,Wed,27700,cacao deep,1
2019/9/4 13:53,Wed,22800,cacao deep,1
2019/9/5 11:15,Thur,27700,cacao deep,1
2019/9/5 14:46,Thur,18800,cacao deep,1
2019/9/6 13:46,Fri,19800,cacao deep,1
2019/9/7 11:42,Sat,18800,cacao deep,1
2019/9/7 12:00,Sat,15300,cacao deep,1
2019/9/9 12:04,Mon,22600,cacao deep,1
2019/9/9 14:49,Mon,24100,cacao deep,1
2019/9/9 15:42,Mon,20400,cacao deep,1
2019/9/11 11:25,Wed,15600,cacao deep,1
2019/9/11 13:21,Wed,33400,cacao deep,2
2019/9/12 11:13,Thur,15000,cacao deep,1
2019/9/12 12:01,Thur,19800,cacao deep,1
2019/9/12 12:40,Thur,23300,cacao deep,1
2019/9/12 12:00,Thur,14300,cacao deep,1
2019/9/12 13:43,Thur,15800,cacao deep,1
2019/9/14 11:18,Sat,22300,cacao deep,1
2019/9/14 12:06,Sat,19300,cacao deep,1
2019/9/15 11:07,Sun,32200,cacao deep,1
2019/9/18 12:42,Wed,17500,cacao deep,1
2019/9/18 14:37,Wed,14300,cacao deep,1
2019/9/18 16:42,Wed,15500,cacao deep,1
2019/9/18 11:26,Wed,19600,cacao deep,2
2019/9/19 12:47,Thur,15300,cacao deep,1
2019/9/19 14:15,Thur,71800,cacao deep,2
2019/9/19 16:27,Thur,34600,cacao deep,1
2019/9/21 11:06,Sat,17800,cacao deep,1
2019/9/21 11:19,Sat,23600,cacao deep,1
2019/9/21 12:28,Sat,37900,cacao deep,1
2019/9/21 13:56,Sat,25100,cacao deep,1
2019/9/21 14:15,Sat,19300,cacao deep,1
2019/9/22 12:08,Sun,17800,cacao deep,1
2019/9/23 13:41,Mon,24600,cacao deep,1
2019/9/23 16:13,Mon,22300,cacao deep,1
2019/9/25 15:39,Wed,17800,cacao deep,1
2019/9/28 12:52,Sat,41400,cacao deep,2
2019/9/29 11:30,Sun,17000,cacao deep,2
2019/9/29 15:31,Sun,14800,cacao deep,1
2019/9/30 15:17,Mon,15500,cacao deep,1
2019/10/2 11:58,Wed,19300,cacao deep,1
2019/10/3 11:53,Thur,18300,cacao deep,1
2019/10/3 12:12,Thur,22300,cacao deep,1
2019/10/5 14:19,Sat,15800,cacao deep,1
2019/10/6 12:05,Sun,15300,cacao deep,1
2019/10/7 15:41,Mon,15600,cacao deep,1
2019/10/9 11:21,Wed,14800,cacao deep,2
2019/10/12 12:38,Sat,15800,cacao deep,2
2019/10/13 11:18,Sun,22800,cacao deep,2
2019/10/13 12:55,Sun,18500,cacao deep,1
2019/10/14 15:21,Mon,28500,cacao deep,1
2019/10/17 13:16,Thur,24800,cacao deep,1
2019/10/19 11:45,Sat,18000,cacao deep,1
2019/10/19 14:45,Sat,14800,cacao deep,1
2019/10/23 13:12,Wed,23600,cacao deep,2
2019/10/23 13:56,Wed,14500,cacao deep,1
2019/10/24 14:25,Thur,21000,cacao deep,1
2019/10/24 16:35,Thur,15300,cacao deep,1
2019/10/24 17:18,Thur,14300,cacao deep,1
2019/10/25 13:45,Fri,17500,cacao deep,1
2019/10/27 11:18,Sun,14800,cacao deep,2
2019/10/27 12:51,Sun,18800,cacao deep,1
2019/10/27 13:01,Sun,14800,cacao deep,1
2019/10/28 11:14,Mon,19800,cacao deep,1
2019/10/28 13:31,Mon,23300,cacao deep,1
2019/11/1 12:11,Fri,19100,cacao deep,1
2019/11/2 12:44,Sat,17500,cacao deep,1
2019/11/3 11:02,Sun,20800,cacao deep,1
2019/11/4 13:13,Mon,26600,cacao deep,2
2019/11/7 15:21,Thur,16800,cacao deep,1
2019/11/8 14:12,Fri,23300,cacao deep,1
2019/11/8 14:46,Fri,15600,cacao deep,1
2019/11/8 15:02,Fri,27800,cacao deep,1
2019/11/9 11:36,Sat,21300,cacao deep,1
2019/11/9 11:36,Sat,35700,cacao deep,1
2019/11/10 11:10,Sun,21100,cacao deep,1
2019/11/10 11:20,Sun,32800,cacao deep,1
2019/11/11 17:25,Mon,28300,cacao deep,1
2019/11/16 12:21,Sat,18500,cacao deep,1
2019/11/16 14:21,Sat,24800,cacao deep,1
2019/11/16 16:13,Sat,19100,cacao deep,1
2019/11/17 14:23,Sun,23500,cacao deep,1
2019/11/18 13:55,Mon,14000,cacao deep,1
2019/11/20 16:59,Wed,15500,cacao deep,1
2019/11/23 13:44,Sat,18800,cacao deep,1
2019/11/23 14:39,Sat,14300,cacao deep,1
2019/11/24 11:29,Sun,19800,cacao deep,1
2019/11/24 12:26,Sun,18300,cacao deep,2
2019/11/24 12:56,Sun,33700,cacao deep,1
2019/11/25 11:08,Mon,18800,cacao deep,1
2019/11/28 12:53,Thur,15300,cacao deep,1
2019/11/29 13:31,Fri,25000,cacao deep,1
2019/11/29 15:05,Fri,14300,cacao deep,1
2019/11/29 16:12,Fri,28100,cacao deep,1
2019/11/30 14:24,Sat,15800,cacao deep,1
2019/12/1 11:54,Sun,15300,cacao deep,1
2019/12/4 11:13,Wed,16600,cacao deep,1
2019/12/4 14:58,Wed,20500,cacao deep,2
2019/12/5 11:08,Thur,15300,cacao deep,1
2019/12/6 12:17,Fri,20100,cacao deep,1
2019/12/6 12:23,Fri,15000,cacao deep,1
2019/12/7 11:41,Sat,17500,cacao deep,1
2019/12/7 14:34,Sat,19900,cacao deep,1
2019/12/8 12:49,Sun,30600,cacao deep,1
2019/12/8 12:52,Sun,20300,cacao deep,1
2019/12/8 14:08,Sun,19800,cacao deep,1
2019/12/8 14:57,Sun,25100,cacao deep,1
2019/12/9 12:09,Mon,33100,cacao deep,1
2019/12/9 13:22,Mon,15300,cacao deep,1
2019/12/12 17:22,Thur,21800,cacao deep,1
2019/12/15 13:43,Sun,14000,cacao deep,2
2019/12/15 14:06,Sun,45400,cacao deep,2
2019/12/15 15:16,Sun,15300,cacao deep,1
2019/12/16 14:32,Mon,19500,cacao deep,1
2019/12/18 15:05,Wed,19100,cacao deep,1
2019/12/19 11:29,Thur,24800,cacao deep,1
2019/12/21 13:58,Sat,20000,cacao deep,1
2019/12/21 14:28,Sat,18500,cacao deep,1
2019/12/21 14:43,Sat,30900,cacao deep,1
2019/12/23 11:31,Mon,26100,cacao deep,1
2019/12/23 12:06,Mon,23800,cacao deep,2
2019/12/26 15:18,Thur,15300,cacao deep,1
2019/12/28 12:04,Sat,17000,cacao deep,1
2019/12/28 12:09,Sat,22300,cacao deep,1
2019/12/28 15:52,Sat,19300,cacao deep,1
2019/12/28 16:18,Sat,58900,cacao deep,2
2019/12/29 12:11,Sun,15300,cacao deep,1
2019/12/29 13:43,Sun,15800,cacao deep,1
2019/12/29 14:42,Sun,22800,cacao deep,1
2020/1/2 14:16,Thur,16500,cacao deep,1
2020/1/4 11:10,Sat,14800,cacao deep,1
2020/1/5 11:19,Sun,14300,cacao deep,1
2020/1/5 12:37,Sun,14300,cacao deep,1
2020/1/5 13:59,Sun,14500,cacao deep,1
2020/1/8 12:42,Wed,22600,cacao deep,1
2020/1/10 11:07,Fri,16300,cacao deep,1
2020/1/10 12:51,Fri,21800,cacao deep,1
2020/1/10 13:42,Fri,20100,cacao deep,1
2020/1/12 11:03,Sun,17300,cacao deep,1
2020/1/12 12:16,Sun,44100,cacao deep,4
2020/1/13 16:55,Mon,14500,cacao deep,1
2020/1/15 11:24,Wed,15500,cacao deep,1
2020/1/15 12:19,Wed,16000,cacao deep,1
2020/1/15 13:16,Wed,15000,cacao deep,1
2020/1/17 14:17,Fri,15300,cacao deep,1
2020/1/18 12:31,Sat,25800,cacao deep,1
2020/1/18 13:17,Sat,15000,cacao deep,1
2020/1/19 11:09,Sun,14800,cacao deep,1
2020/1/19 11:09,Sun,31100,cacao deep,1
2020/1/19 11:21,Sun,37000,cacao deep,4
2020/1/19 11:49,Sun,14500,cacao deep,1
2020/1/23 14:08,Thur,15000,cacao deep,1
2020/1/26 12:50,Sun,34900,cacao deep,2
2020/1/27 12:17,Mon,27600,cacao deep,2
2020/1/27 13:29,Mon,26000,cacao deep,1
2020/1/27 13:29,Mon,20100,cacao deep,1
2020/1/29 11:46,Wed,17500,cacao deep,1
2020/1/30 11:43,Thur,23300,cacao deep,1
2020/1/30 12:15,Thur,34300,cacao deep,1
2020/1/30 12:26,Thur,26600,cacao deep,1
2020/2/1 13:18,Sat,15300,cacao deep,1
2020/2/1 13:50,Sat,23600,cacao deep,1
2020/2/2 12:06,Sun,21400,cacao deep,1
2020/2/5 12:07,Wed,21600,cacao deep,1
2020/2/6 12:29,Thur,15600,cacao deep,1
2020/2/7 11:51,Fri,17800,cacao deep,1
2020/2/8 11:31,Sat,23600,cacao deep,1
2020/2/8 13:14,Sat,25600,cacao deep,1
2020/2/9 11:03,Sun,30000,cacao deep,1
2020/2/9 14:34,Sun,14000,cacao deep,1
2020/2/10 11:31,Mon,15300,cacao deep,1
2020/2/12 15:12,Wed,24500,cacao deep,3
2020/2/12 16:21,Wed,22500,cacao deep,1
2020/2/12 17:21,Wed,21300,cacao deep,1
2020/2/15 12:55,Sat,20500,cacao deep,1
2020/2/15 14:03,Sat,32100,cacao deep,1
2020/2/16 11:17,Sun,27100,cacao deep,1
2020/2/17 12:24,Mon,15800,cacao deep,1
2020/2/17 13:03,Mon,20100,cacao deep,1
2020/2/17 15:25,Mon,36600,cacao deep,1
2020/2/19 12:12,Wed,24600,cacao deep,1
2020/2/21 14:21,Fri,33500,cacao deep,2
2020/2/22 13:10,Sat,22000,cacao deep,1
2020/2/22 14:02,Sat,23100,cacao deep,2
2020/2/23 11:10,Sun,26600,cacao deep,1
2020/2/23 12:39,Sun,19800,cacao deep,1
2020/2/23 12:42,Sun,24300,cacao deep,1
2020/2/24 14:36,Mon,22600,cacao deep,1
2020/2/26 11:55,Wed,15300,cacao deep,1
2020/2/26 12:34,Wed,22000,cacao deep,1
2020/2/26 12:48,Wed,15000,cacao deep,1
2020/2/26 13:03,Wed,17800,cacao deep,1
2020/2/26 13:46,Wed,14500,cacao deep,1
2020/2/26 14:29,Wed,23300,cacao deep,1
2020/2/27 11:24,Thur,15300,cacao deep,1
2020/2/28 11:02,Fri,33800,cacao deep,2
2020/2/28 11:09,Fri,25100,cacao deep,1
2020/2/28 11:13,Fri,20100,cacao deep,1
2020/2/28 12:04,Fri,20300,cacao deep,1
2020/2/29 12:49,Sat,18500,cacao deep,1
2020/2/29 14:25,Sat,15300,cacao deep,1
2020/3/1 11:26,Sun,14000,cacao deep,1
2020/3/1 11:47,Sun,41800,cacao deep,2
2020/3/1 13:23,Sun,16300,cacao deep,1
2020/3/5 11:39,Thur,15500,cacao deep,2
2020/3/5 14:26,Thur,14300,cacao deep,1
2020/3/5 14:49,Thur,20800,cacao deep,1
2020/3/5 15:29,Thur,15300,cacao deep,1
2020/3/6 11:07,Fri,19800,cacao deep,1
2020/3/6 12:15,Fri,18500,cacao deep,1
2020/3/7 12:39,Sat,17500,cacao deep,1
2020/3/7 12:58,Sat,23000,cacao deep,1
2020/3/7 13:07,Sat,19500,cacao deep,1
2020/3/7 14:20,Sat,19800,cacao deep,1
2020/3/8 11:19,Sun,19000,cacao deep,1
2020/3/8 12:03,Sun,29100,cacao deep,1
2020/3/8 12:50,Sun,14300,cacao deep,1
2020/3/8 12:52,Sun,21300,cacao deep,1
2020/3/9 13:20,Mon,18800,cacao deep,1
2020/3/11 11:57,Wed,27100,cacao deep,1
2020/3/14 11:45,Sat,18000,cacao deep,1
2020/3/14 12:57,Sat,17500,cacao deep,1
2020/3/15 11:19,Sun,14300,cacao deep,1
2020/3/15 12:35,Sun,15600,cacao deep,1
2020/3/15 13:02,Sun,15000,cacao deep,1
2020/3/15 14:05,Sun,15000,cacao deep,1
2020/3/15 14:15,Sun,19400,cacao deep,1
2020/3/18 12:29,Wed,39100,cacao deep,2
2020/3/20 11:29,Fri,25800,cacao deep,1
2020/3/21 11:33,Sat,20000,cacao deep,1
2020/3/21 12:02,Sat,37700,cacao deep,2
2020/3/23 12:44,Mon,15000,cacao deep,1
2020/3/23 13:58,Mon,24200,cacao deep,1
2020/3/25 12:42,Wed,18800,cacao deep,1
2020/3/25 14:12,Wed,22300,cacao deep,1
2020/3/26 11:04,Thur,15300,cacao deep,1
2020/3/26 11:32,Thur,43200,cacao deep,2
2020/3/27 11:51,Fri,14800,cacao deep,1
2020/3/27 13:10,Fri,18500,cacao deep,1
2020/3/27 13:36,Fri,24800,cacao deep,1
2020/3/27 16:23,Fri,14800,cacao deep,2
2020/3/28 12:17,Sat,15500,cacao deep,1
2020/3/28 13:39,Sat,24100,cacao deep,1
2020/3/29 12:59,Sun,24300,cacao deep,1
2020/3/30 13:25,Mon,18800,cacao deep,1
2020/3/30 16:21,Mon,19800,cacao deep,1
2020/4/1 14:18,Wed,24300,cacao deep,1
2020/4/3 11:24,Fri,24800,cacao deep,1
2020/4/3 11:43,Fri,23600,cacao deep,1
2020/4/3 14:12,Fri,14000,cacao deep,1
2020/4/5 11:02,Sun,21800,cacao deep,2
2020/4/5 13:34,Sun,22300,cacao deep,1
2020/4/5 14:41,Sun,26300,cacao deep,1
2020/4/8 12:01,Wed,30300,cacao deep,1
2020/4/8 17:17,Wed,14300,cacao deep,1
2020/4/9 11:10,Thur,26600,cacao deep,1
2020/4/9 11:58,Thur,15600,cacao deep,1
2020/4/10 11:43,Fri,19300,cacao deep,1
2020/4/10 12:29,Fri,15300,cacao deep,1
2020/4/10 12:53,Fri,14300,cacao deep,1
2020/4/10 16:13,Fri,31600,cacao deep,1
2020/4/11 11:40,Sat,29800,cacao deep,1
2020/4/11 14:45,Sat,14000,cacao deep,1
2020/4/11 15:01,Sat,19300,cacao deep,1
2020/4/12 11:52,Sun,36900,cacao deep,2
2020/4/12 12:19,Sun,15300,cacao deep,1
2020/4/12 14:06,Sun,15000,cacao deep,1
2020/4/15 11:20,Wed,19800,cacao deep,1
2020/4/15 13:49,Wed,14300,cacao deep,1
2020/4/16 16:58,Thur,18800,cacao deep,1
2020/4/18 14:17,Sat,14500,cacao deep,1
2020/4/18 14:10,Sat,14800,cacao deep,1
2020/4/19 12:35,Sun,14300,cacao deep,1
2020/4/19 14:04,Sun,24600,cacao deep,1
2020/4/19 16:46,Sun,23900,cacao deep,1
2020/4/22 11:02,Wed,20100,cacao deep,1
2020/4/22 12:53,Wed,18800,cacao deep,1
2020/4/23 13:17,Thur,20100,cacao deep,1
2020/4/24 11:12,Fri,18800,cacao deep,1
2020/4/24 12:00,Fri,19500,cacao deep,1
2020/4/24 16:27,Fri,15300,cacao deep,1
2020/4/25 11:52,Sat,14800,cacao deep,1
2020/4/25 14:27,Sat,20800,cacao deep,1
2020/4/26 15:14,Sun,27300,cacao deep,1
2020/4/27 11:41,Mon,19800,cacao deep,1
2020/4/27 12:02,Mon,15000,cacao deep,1
2020/4/27 13:35,Mon,14000,cacao deep,1
2020/4/27 15:07,Mon,18800,cacao deep,1
2020/4/27 15:10,Mon,25800,cacao deep,2
2020/4/30 11:18,Thur,31300,cacao deep,1
2020/4/30 16:02,Thur,15300,cacao deep,1
2020/5/1 11:09,Fri,31600,cacao deep,1
2020/5/2 12:15,Sat,14300,cacao deep,1
2019/7/17 13:23,Wed,14800,pain au chocolat,1
2019/7/19 11:43,Fri,14800,pain au chocolat,1
2019/7/19 12:36,Fri,21800,pain au chocolat,1
2019/7/19 13:50,Fri,15100,pain au chocolat,1
2019/7/20 11:40,Sat,22800,pain au chocolat,1
2019/7/20 12:13,Sat,26300,pain au chocolat,1
2019/7/20 12:31,Sat,14800,pain au chocolat,1
2019/7/20 13:19,Sat,20500,pain au chocolat,2
2019/7/20 13:44,Sat,18600,pain au chocolat,1
2019/7/20 13:56,Sat,17800,pain au chocolat,1
2019/7/21 11:42,Sun,17300,pain au chocolat,1
2019/7/21 12:25,Sun,14800,pain au chocolat,1
2019/7/21 12:47,Sun,21000,pain au chocolat,1
2019/7/22 12:24,Mon,18300,pain au chocolat,1
2019/7/22 13:28,Mon,16600,pain au chocolat,2
2019/7/22 13:44,Mon,14800,pain au chocolat,1
2019/7/24 17:20,Wed,15000,pain au chocolat,1
2019/7/25 11:49,Thur,18600,pain au chocolat,1
2019/7/25 12:35,Thur,38000,pain au chocolat,1
2019/7/25 13:01,Thur,23100,pain au chocolat,1
2019/7/25 13:05,Thur,17300,pain au chocolat,2
2019/7/26 11:23,Fri,73200,pain au chocolat,2
2019/7/26 11:36,Fri,1293000,pain au chocolat,5
2019/7/26 13:24,Fri,28100,pain au chocolat,1
2019/7/27 11:57,Sat,21800,pain au chocolat,1
2019/7/27 12:07,Sat,33200,pain au chocolat,2
2019/7/27 12:20,Sat,22800,pain au chocolat,1
2019/7/28 12:21,Sun,14800,pain au chocolat,1
2019/7/28 12:47,Sun,14300,pain au chocolat,1
2019/7/28 13:14,Sun,19500,pain au chocolat,1
2019/7/29 11:39,Mon,14800,pain au chocolat,1
2019/7/29 12:02,Mon,14800,pain au chocolat,1
2019/7/29 12:15,Mon,18300,pain au chocolat,1
2019/7/29 12:22,Mon,27900,pain au chocolat,1
2019/7/31 11:25,Wed,30100,pain au chocolat,1
2019/7/31 11:38,Wed,23300,pain au chocolat,1
2019/7/31 11:44,Wed,30200,pain au chocolat,2
2019/8/1 11:03,Thur,14500,pain au chocolat,1
2019/8/1 11:17,Thur,13100,pain au chocolat,1
2019/8/1 12:24,Thur,32600,pain au chocolat,1
2019/8/1 13:39,Thur,15000,pain au chocolat,1
2019/8/1 14:17,Thur,14800,pain au chocolat,1
2019/8/1 14:56,Thur,23000,pain au chocolat,2
2019/8/2 11:03,Fri,19900,pain au chocolat,1
2019/8/3 11:03,Sat,26100,pain au chocolat,1
2019/8/3 11:03,Sat,16000,pain au chocolat,2
2019/8/3 11:05,Sat,29100,pain au chocolat,1
2019/8/4 11:02,Sun,34800,pain au chocolat,2
2019/8/4 11:04,Sun,31600,pain au chocolat,1
2019/8/4 11:41,Sun,24300,pain au chocolat,1
2019/8/4 12:30,Sun,19500,pain au chocolat,1
2019/8/5 11:18,Mon,31400,pain au chocolat,1
2019/8/5 11:32,Mon,17000,pain au chocolat,1
2019/8/5 11:59,Mon,22300,pain au chocolat,1
2019/8/5 12:14,Mon,26600,pain au chocolat,1
2019/8/5 12:42,Mon,19600,pain au chocolat,1
2019/8/5 12:49,Mon,49300,pain au chocolat,1
2019/8/7 12:17,Wed,15300,pain au chocolat,1
2019/8/7 12:20,Wed,27300,pain au chocolat,1
2019/8/7 13:33,Wed,19500,pain au chocolat,2
2019/8/8 12:13,Thur,15100,pain au chocolat,1
2019/8/8 13:26,Thur,17300,pain au chocolat,2
2019/8/9 11:34,Fri,17000,pain au chocolat,1
2019/8/10 11:01,Sat,19600,pain au chocolat,1
2019/8/10 11:03,Sat,19100,pain au chocolat,1
2019/8/10 11:09,Sat,17300,pain au chocolat,2
2019/8/10 11:27,Sat,36800,pain au chocolat,1
2019/8/10 12:17,Sat,46200,pain au chocolat,2
2019/8/11 11:01,Sun,21800,pain au chocolat,1
2019/8/11 11:02,Sun,16800,pain au chocolat,1
2019/8/11 11:03,Sun,16000,pain au chocolat,1
2019/8/11 11:40,Sun,38900,pain au chocolat,2
2019/8/11 11:50,Sun,15300,pain au chocolat,1
2019/8/11 11:58,Sun,27900,pain au chocolat,1
2019/8/11 13:14,Sun,19300,pain au chocolat,1
2019/8/11 13:27,Sun,17300,pain au chocolat,1
2019/8/12 11:05,Mon,28400,pain au chocolat,2
2019/8/12 12:48,Mon,14800,pain au chocolat,1
2019/8/12 13:27,Mon,18300,pain au chocolat,1
2019/8/14 11:03,Wed,41200,pain au chocolat,1
2019/8/14 11:16,Wed,65600,pain au chocolat,1
2019/8/14 11:22,Wed,29000,pain au chocolat,1
2019/8/14 11:25,Wed,27300,pain au chocolat,1
2019/8/15 12:00,Thur,18900,pain au chocolat,1
2019/8/16 11:54,Fri,15100,pain au chocolat,1
2019/8/17 11:03,Sat,18300,pain au chocolat,1
2019/8/17 12:40,Sat,18800,pain au chocolat,1
2019/8/17 12:57,Sat,29600,pain au chocolat,1
2019/8/17 13:38,Sat,32600,pain au chocolat,1
2019/8/18 11:01,Sun,17300,pain au chocolat,1
2019/8/18 11:09,Sun,26600,pain au chocolat,1
2019/8/18 11:09,Sun,22800,pain au chocolat,1
2019/8/18 12:22,Sun,15000,pain au chocolat,1
2019/8/18 12:24,Sun,16000,pain au chocolat,1
2019/8/18 12:50,Sun,23800,pain au chocolat,1
2019/8/19 12:34,Mon,23600,pain au chocolat,1
2019/8/19 14:16,Mon,23800,pain au chocolat,1
2019/8/21 11:07,Wed,15300,pain au chocolat,1
2019/8/21 12:29,Wed,19300,pain au chocolat,1
2019/8/21 13:15,Wed,17000,pain au chocolat,1
2019/8/21 14:11,Wed,25000,pain au chocolat,1
2019/8/22 13:07,Thur,26600,pain au chocolat,2
2019/8/22 13:49,Thur,23400,pain au chocolat,2
2019/8/23 11:53,Fri,57700,pain au chocolat,1
2019/8/23 15:32,Fri,22000,pain au chocolat,1
2019/8/24 11:06,Sat,16000,pain au chocolat,2
2019/8/24 11:14,Sat,17300,pain au chocolat,1
2019/8/25 11:06,Sun,17300,pain au chocolat,1
2019/8/25 12:05,Sun,22100,pain au chocolat,3
2019/8/25 12:23,Sun,25300,pain au chocolat,1
2019/8/26 11:30,Mon,18000,pain au chocolat,1
2019/8/28 12:20,Wed,30400,pain au chocolat,2
2019/8/28 13:42,Wed,14800,pain au chocolat,1
2019/8/29 11:04,Thur,22300,pain au chocolat,1
2019/8/29 16:15,Thur,19000,pain au chocolat,1
2019/8/30 14:13,Fri,16000,pain au chocolat,1
2019/8/30 15:00,Fri,23100,pain au chocolat,2
2019/8/30 15:05,Fri,28800,pain au chocolat,1
2019/8/31 11:15,Sat,18600,pain au chocolat,1
2019/8/31 11:20,Sat,16300,pain au chocolat,1
2019/8/31 12:31,Sat,16300,pain au chocolat,1
2019/8/31 12:34,Sat,14800,pain au chocolat,1
2019/9/1 11:05,Sun,23300,pain au chocolat,1
2019/9/1 11:22,Sun,14800,pain au chocolat,1
2019/9/1 11:40,Sun,22100,pain au chocolat,1
2019/9/1 12:04,Sun,19600,pain au chocolat,1
2019/9/1 12:39,Sun,28300,pain au chocolat,1
2019/9/1 14:05,Sun,33100,pain au chocolat,2
2019/9/4 11:49,Wed,23000,pain au chocolat,1
2019/9/4 12:58,Wed,17000,pain au chocolat,1
2019/9/4 13:42,Wed,27700,pain au chocolat,1
2019/9/4 13:53,Wed,22800,pain au chocolat,1
2019/9/4 15:26,Wed,41100,pain au chocolat,2
2019/9/5 12:24,Thur,17600,pain au chocolat,1
2019/9/5 14:30,Thur,29200,pain au chocolat,1
2019/9/5 15:46,Thur,14800,pain au chocolat,1
2019/9/6 11:30,Fri,14800,pain au chocolat,1
2019/9/6 12:09,Fri,15300,pain au chocolat,1
2019/9/8 11:27,Sun,14800,pain au chocolat,1
2019/9/9 12:04,Mon,22600,pain au chocolat,1
2019/9/9 14:17,Mon,18800,pain au chocolat,1
2019/9/9 14:44,Mon,15100,pain au chocolat,1
2019/9/11 13:06,Wed,14300,pain au chocolat,1
2019/9/11 14:48,Wed,16300,pain au chocolat,1
2019/9/12 12:45,Thur,22100,pain au chocolat,2
2019/9/14 11:07,Sat,22800,pain au chocolat,1
2019/9/14 12:17,Sat,26300,pain au chocolat,1
2019/9/15 11:36,Sun,17000,pain au chocolat,2
2019/9/15 11:57,Sun,16000,pain au chocolat,2
2019/9/18 11:26,Wed,19800,pain au chocolat,1
2019/9/18 12:42,Wed,17500,pain au chocolat,2
2019/9/18 14:37,Wed,14300,pain au chocolat,1
2019/9/18 15:24,Wed,17000,pain au chocolat,2
2019/9/19 15:53,Thur,23100,pain au chocolat,1
2019/9/19 16:27,Thur,34600,pain au chocolat,1
2019/9/19 16:33,Thur,16000,pain au chocolat,1
2019/9/20 11:06,Fri,39700,pain au chocolat,2
2019/9/21 11:08,Sat,39300,pain au chocolat,3
2019/9/21 11:12,Sat,14000,pain au chocolat,1
2019/9/21 11:39,Sat,21100,pain au chocolat,1
2019/9/22 12:05,Sun,17000,pain au chocolat,1
2019/9/22 12:07,Sun,34100,pain au chocolat,2
2019/9/22 12:08,Sun,17800,pain au chocolat,1
2019/9/22 12:19,Sun,24300,pain au chocolat,4
2019/9/23 11:25,Mon,16300,pain au chocolat,1
2019/9/23 13:22,Mon,18300,pain au chocolat,2
2019/9/23 15:25,Mon,24900,pain au chocolat,1
2019/9/23 16:13,Mon,22300,pain au chocolat,1
2019/9/25 12:21,Wed,21500,pain au chocolat,1
2019/9/25 15:18,Wed,26300,pain au chocolat,1
2019/9/25 15:39,Wed,17800,pain au chocolat,1
2019/9/27 16:12,Fri,36100,pain au chocolat,2
2019/9/28 12:23,Sat,18000,pain au chocolat,1
2019/9/28 12:27,Sat,21800,pain au chocolat,1
2019/9/28 12:37,Sat,21800,pain au chocolat,1
2019/9/28 12:41,Sat,22100,pain au chocolat,1
2019/9/28 13:36,Sat,14800,pain au chocolat,1
2019/9/29 11:06,Sun,18800,pain au chocolat,1
2019/9/29 11:17,Sun,14800,pain au chocolat,1
2019/9/29 11:30,Sun,17000,pain au chocolat,1
2019/9/29 12:13,Sun,23800,pain au chocolat,1
2019/9/29 13:50,Sun,15300,pain au chocolat,1
2019/9/29 15:22,Sun,27800,pain au chocolat,3
2019/10/2 14:18,Wed,16000,pain au chocolat,2
2019/10/2 16:12,Wed,15000,pain au chocolat,1
2019/10/3 11:20,Thur,14300,pain au chocolat,1
2019/10/3 12:12,Thur,22300,pain au chocolat,1
2019/10/3 14:20,Thur,19600,pain au chocolat,1
2019/10/3 14:34,Thur,14800,pain au chocolat,1
2019/10/3 14:50,Thur,21800,pain au chocolat,1
2019/10/4 12:29,Fri,15100,pain au chocolat,1
2019/10/5 12:39,Sat,31800,pain au chocolat,1
2019/10/6 12:31,Sun,16300,pain au chocolat,1
2019/10/6 12:51,Sun,25300,pain au chocolat,2
2019/10/10 12:08,Thur,18300,pain au chocolat,1
2019/10/11 11:24,Fri,17300,pain au chocolat,1
2019/10/12 11:07,Sat,20500,pain au chocolat,1
2019/10/12 12:00,Sat,17300,pain au chocolat,2
2019/10/13 13:48,Sun,21500,pain au chocolat,1
2019/10/14 11:08,Mon,26000,pain au chocolat,1
2019/10/14 11:26,Mon,26900,pain au chocolat,3
2019/10/14 12:21,Mon,17300,pain au chocolat,1
2019/10/14 13:47,Mon,18300,pain au chocolat,1
2019/10/16 12:15,Wed,22000,pain au chocolat,5
2019/10/16 13:03,Wed,23300,pain au chocolat,1
2019/10/17 12:35,Thur,14800,pain au chocolat,1
2019/10/17 13:05,Thur,18300,pain au chocolat,2
2019/10/17 13:50,Thur,32300,pain au chocolat,1
2019/10/18 12:08,Fri,17000,pain au chocolat,1
2019/10/19 11:09,Sat,15000,pain au chocolat,1
2019/10/19 11:13,Sat,29000,pain au chocolat,2
2019/10/19 11:17,Sat,29100,pain au chocolat,2
2019/10/19 12:00,Sat,18300,pain au chocolat,1
2019/10/20 11:25,Sun,19800,pain au chocolat,1
2019/10/20 11:34,Sun,28100,pain au chocolat,1
2019/10/20 11:58,Sun,16300,pain au chocolat,1
2019/10/20 12:49,Sun,14300,pain au chocolat,1
2019/10/20 12:55,Sun,35200,pain au chocolat,2
2019/10/21 11:19,Mon,18300,pain au chocolat,1
2019/10/21 11:27,Mon,16300,pain au chocolat,1
2019/10/21 11:34,Mon,22800,pain au chocolat,1
2019/10/21 13:47,Mon,54700,pain au chocolat,2
2019/10/23 11:17,Wed,17300,pain au chocolat,2
2019/10/23 13:56,Wed,14500,pain au chocolat,1
2019/10/24 11:03,Thur,25300,pain au chocolat,1
2019/10/24 11:53,Thur,21800,pain au chocolat,3
2019/10/24 13:35,Thur,17300,pain au chocolat,1
2019/10/24 14:25,Thur,21000,pain au chocolat,1
2019/10/24 17:18,Thur,14300,pain au chocolat,1
2019/10/25 11:16,Fri,27300,pain au chocolat,1
2019/10/25 11:51,Fri,22800,pain au chocolat,1
2019/10/26 11:54,Sat,25800,pain au chocolat,1
2019/10/27 11:02,Sun,16000,pain au chocolat,2
2019/10/27 11:33,Sun,17800,pain au chocolat,1
2019/10/27 11:57,Sun,22300,pain au chocolat,1
2019/10/28 12:55,Mon,14800,pain au chocolat,1
2019/10/28 13:39,Mon,17300,pain au chocolat,1
2019/10/28 14:20,Mon,34600,pain au chocolat,2
2019/10/28 14:30,Mon,14800,pain au chocolat,1
2019/10/31 11:05,Thur,55800,pain au chocolat,3
2019/10/31 13:29,Thur,25000,pain au chocolat,2
2019/11/1 11:10,Fri,14100,pain au chocolat,1
2019/11/1 11:55,Fri,23000,pain au chocolat,1
2019/11/1 12:11,Fri,19100,pain au chocolat,1
2019/11/2 11:08,Sat,30400,pain au chocolat,2
2019/11/2 14:19,Sat,22300,pain au chocolat,2
2019/11/3 11:04,Sun,23100,pain au chocolat,2
2019/11/3 11:16,Sun,19800,pain au chocolat,1
2019/11/3 14:30,Sun,15100,pain au chocolat,1
2019/11/3 15:06,Sun,14500,pain au chocolat,1
2019/11/4 13:17,Mon,17500,pain au chocolat,1
2019/11/6 12:04,Wed,18300,pain au chocolat,2
2019/11/7 13:33,Thur,34800,pain au chocolat,1
2019/11/8 11:36,Fri,22800,pain au chocolat,1
2019/11/8 13:03,Fri,19900,pain au chocolat,1
2019/11/8 15:12,Fri,30000,pain au chocolat,2
2019/11/9 11:36,Sat,26100,pain au chocolat,1
2019/11/9 11:36,Sat,21300,pain au chocolat,2
2019/11/9 11:36,Sat,27300,pain au chocolat,1
2019/11/10 11:04,Sun,18000,pain au chocolat,2
2019/11/10 12:11,Sun,19300,pain au chocolat,1
2019/11/10 14:21,Sun,18600,pain au chocolat,1
2019/11/13 12:29,Wed,15300,pain au chocolat,1
2019/11/15 11:50,Fri,18500,pain au chocolat,1
2019/11/15 13:44,Fri,18500,pain au chocolat,1
2019/11/15 15:19,Fri,14800,pain au chocolat,1
2019/11/16 11:07,Sat,23800,pain au chocolat,1
2019/11/17 11:24,Sun,16500,pain au chocolat,1
2019/11/17 11:40,Sun,17500,pain au chocolat,1
2019/11/18 11:11,Mon,18000,pain au chocolat,1
2019/11/18 14:36,Mon,28800,pain au chocolat,1
2019/11/20 15:52,Wed,15000,pain au chocolat,1
2019/11/23 13:30,Sat,17800,pain au chocolat,1
2019/11/23 13:44,Sat,18800,pain au chocolat,1
2019/11/24 13:34,Sun,39000,pain au chocolat,1
2019/11/25 11:05,Mon,19800,pain au chocolat,2
2019/11/25 11:31,Mon,54100,pain au chocolat,5
2019/11/25 12:25,Mon,18000,pain au chocolat,1
2019/11/27 12:35,Wed,15300,pain au chocolat,1
2019/11/27 13:34,Wed,17300,pain au chocolat,1
2019/11/27 14:16,Wed,16500,pain au chocolat,2
2019/11/28 14:15,Thur,18300,pain au chocolat,1
2019/11/28 14:48,Thur,40000,pain au chocolat,1
2019/11/29 12:03,Fri,16300,pain au chocolat,1
2019/11/29 13:23,Fri,19300,pain au chocolat,1
2019/11/29 13:31,Fri,25000,pain au chocolat,2
2019/11/30 11:10,Sat,22800,pain au chocolat,1
2019/11/30 13:01,Sat,38200,pain au chocolat,1
2019/11/30 17:04,Sat,27600,pain au chocolat,1
2019/12/1 11:03,Sun,22100,pain au chocolat,1
2019/12/1 11:40,Sun,15300,pain au chocolat,1
2019/12/1 12:11,Sun,23100,pain au chocolat,1
2019/12/1 12:35,Sun,23000,pain au chocolat,1
2019/12/1 16:18,Sun,18600,pain au chocolat,1
2019/12/2 11:03,Mon,17500,pain au chocolat,1
2019/12/2 13:38,Mon,14800,pain au chocolat,1
2019/12/2 14:42,Mon,22800,pain au chocolat,1
2019/12/4 11:10,Wed,23300,pain au chocolat,1
2019/12/5 11:05,Thur,57700,pain au chocolat,4
2019/12/6 11:31,Fri,20500,pain au chocolat,2
2019/12/7 11:41,Sat,17500,pain au chocolat,1
2019/12/7 13:36,Sat,14800,pain au chocolat,1
2019/12/7 13:39,Sat,30800,pain au chocolat,1
2019/12/7 13:55,Sat,28600,pain au chocolat,1
2019/12/9 11:31,Mon,14800,pain au chocolat,1
2019/12/11 11:36,Wed,22000,pain au chocolat,1
2019/12/11 13:32,Wed,21500,pain au chocolat,2
2019/12/11 14:08,Wed,17300,pain au chocolat,1
2019/12/11 14:26,Wed,32000,pain au chocolat,2
2019/12/12 14:09,Thur,16300,pain au chocolat,1
2019/12/12 14:52,Thur,19500,pain au chocolat,1
2019/12/13 16:48,Fri,14000,pain au chocolat,1
2019/12/14 12:19,Sat,23800,pain au chocolat,1
2019/12/15 13:41,Sun,15000,pain au chocolat,1
2019/12/16 12:07,Mon,14100,pain au chocolat,1
2019/12/16 12:58,Mon,14800,pain au chocolat,1
2019/12/18 11:22,Wed,52800,pain au chocolat,1
2019/12/18 15:05,Wed,19100,pain au chocolat,1
2019/12/18 15:23,Wed,51200,pain au chocolat,2
2019/12/19 11:29,Thur,24800,pain au chocolat,1
2019/12/19 11:45,Thur,35300,pain au chocolat,2
2019/12/19 13:06,Thur,32500,pain au chocolat,2
2019/12/21 11:52,Sat,14800,pain au chocolat,1
2019/12/21 12:24,Sat,25300,pain au chocolat,1
2019/12/21 13:58,Sat,20000,pain au chocolat,1
2019/12/21 14:28,Sat,18500,pain au chocolat,1
2019/12/21 14:43,Sat,30900,pain au chocolat,1
2019/12/22 11:38,Sun,19300,pain au chocolat,1
2019/12/22 12:21,Sun,19300,pain au chocolat,1
2019/12/23 13:57,Mon,30300,pain au chocolat,1
2019/12/23 14:42,Mon,19500,pain au chocolat,1
2019/12/27 12:49,Fri,15000,pain au chocolat,2
2019/12/28 11:48,Sat,14800,pain au chocolat,1
2019/12/28 13:12,Sat,18800,pain au chocolat,1
2019/12/28 14:55,Sat,21500,pain au chocolat,2
2019/12/29 11:16,Sun,14000,pain au chocolat,1
2019/12/29 13:34,Sun,14800,pain au chocolat,1
2019/12/29 14:26,Sun,14800,pain au chocolat,1
2019/12/29 14:42,Sun,22800,pain au chocolat,1
2019/12/30 12:23,Mon,91300,pain au chocolat,6
2020/1/2 11:22,Thur,15000,pain au chocolat,1
2020/1/2 14:16,Thur,16500,pain au chocolat,2
2020/1/3 16:06,Fri,17300,pain au chocolat,1
2020/1/4 11:03,Sat,23800,pain au chocolat,1
2020/1/5 11:19,Sun,14300,pain au chocolat,1
2020/1/5 17:25,Sun,19600,pain au chocolat,1
2020/1/6 12:43,Mon,18300,pain au chocolat,1
2020/1/6 16:00,Mon,14300,pain au chocolat,1
2020/1/6 16:30,Mon,14000,pain au chocolat,1
2020/1/8 13:31,Wed,18300,pain au chocolat,1
2020/1/9 12:27,Thur,28800,pain au chocolat,1
2020/1/9 15:22,Thur,23300,pain au chocolat,1
2020/1/10 12:57,Fri,19600,pain au chocolat,1
2020/1/10 14:11,Fri,14300,pain au chocolat,1
2020/1/11 13:16,Sat,19600,pain au chocolat,1
2020/1/12 11:03,Sun,21800,pain au chocolat,1
2020/1/12 14:19,Sun,24400,pain au chocolat,1
2020/1/12 14:31,Sun,14500,pain au chocolat,1
2020/1/12 16:30,Sun,17000,pain au chocolat,1
2020/1/13 15:52,Mon,14800,pain au chocolat,1
2020/1/13 16:55,Mon,14500,pain au chocolat,1
2020/1/15 11:28,Wed,116500,pain au chocolat,2
2020/1/15 13:01,Wed,18300,pain au chocolat,1
2020/1/15 13:16,Wed,15000,pain au chocolat,1
2020/1/17 13:30,Fri,16300,pain au chocolat,1
2020/1/18 12:31,Sat,25800,pain au chocolat,1
2020/1/19 11:09,Sun,31100,pain au chocolat,1
2020/1/19 12:40,Sun,16300,pain au chocolat,1
2020/1/20 11:25,Mon,23800,pain au chocolat,1
2020/1/22 14:17,Wed,18500,pain au chocolat,1
2020/1/22 15:22,Wed,14500,pain au chocolat,1
2020/1/23 11:17,Thur,58700,pain au chocolat,1
2020/1/23 11:37,Thur,14100,pain au chocolat,1
2020/1/23 15:26,Thur,27500,pain au chocolat,1
2020/1/24 11:37,Fri,23800,pain au chocolat,1
2020/1/24 11:40,Fri,14800,pain au chocolat,1
2020/1/26 11:07,Sun,14800,pain au chocolat,1
2020/1/27 12:32,Mon,21800,pain au chocolat,2
2020/1/30 11:54,Thur,42900,pain au chocolat,2
2020/1/30 12:15,Thur,34300,pain au chocolat,1
2020/1/31 11:32,Fri,22500,pain au chocolat,1
2020/1/31 13:09,Fri,20300,pain au chocolat,1
2020/2/1 12:56,Sat,17300,pain au chocolat,1
2020/2/1 14:10,Sat,15300,pain au chocolat,1
2020/2/1 15:40,Sat,32400,pain au chocolat,2
2020/2/2 11:05,Sun,15000,pain au chocolat,1
2020/2/2 11:05,Sun,19300,pain au chocolat,1
2020/2/2 12:42,Sun,17300,pain au chocolat,1
2020/2/5 12:32,Wed,16300,pain au chocolat,1
2020/2/5 13:48,Wed,14300,pain au chocolat,1
2020/2/6 15:55,Thur,15300,pain au chocolat,1
2020/2/7 11:51,Fri,17800,pain au chocolat,1
2020/2/7 13:41,Fri,18300,pain au chocolat,2
2020/2/7 16:41,Fri,21800,pain au chocolat,1
2020/2/8 11:57,Sat,14800,pain au chocolat,1
2020/2/8 12:54,Sat,14800,pain au chocolat,1
2020/2/8 13:01,Sat,24300,pain au chocolat,1
2020/2/8 13:14,Sat,25600,pain au chocolat,1
2020/2/8 14:42,Sat,19800,pain au chocolat,1
2020/2/8 15:22,Sat,22800,pain au chocolat,1
2020/2/9 11:03,Sun,19300,pain au chocolat,1
2020/2/9 11:52,Sun,34300,pain au chocolat,1
2020/2/10 11:41,Mon,19300,pain au chocolat,1
2020/2/10 13:24,Mon,15000,pain au chocolat,1
2020/2/10 14:03,Mon,16000,pain au chocolat,1
2020/2/12 11:04,Wed,37600,pain au chocolat,2
2020/2/12 14:35,Wed,55200,pain au chocolat,2
2020/2/12 16:21,Wed,22500,pain au chocolat,1
2020/2/12 17:21,Wed,21300,pain au chocolat,1
2020/2/13 11:35,Thur,14300,pain au chocolat,1
2020/2/13 12:23,Thur,14800,pain au chocolat,1
2020/2/14 13:06,Fri,16300,pain au chocolat,1
2020/2/14 14:18,Fri,67000,pain au chocolat,5
2020/2/14 15:27,Fri,15100,pain au chocolat,1
2020/2/15 12:31,Sat,16500,pain au chocolat,1
2020/2/15 13:04,Sat,19300,pain au chocolat,1
2020/2/15 14:13,Sat,16100,pain au chocolat,1
2020/2/16 11:17,Sun,17000,pain au chocolat,1
2020/2/16 11:57,Sun,26600,pain au chocolat,1
2020/2/16 13:51,Sun,25300,pain au chocolat,1
2020/2/17 11:20,Mon,15500,pain au chocolat,1
2020/2/17 13:33,Mon,23300,pain au chocolat,1
2020/2/19 12:07,Wed,16000,pain au chocolat,1
2020/2/19 12:12,Wed,24600,pain au chocolat,1
2020/2/19 13:01,Wed,17500,pain au chocolat,1
2020/2/19 14:42,Wed,23000,pain au chocolat,1
2020/2/20 11:11,Thur,23800,pain au chocolat,1
2020/2/22 11:14,Sat,16300,pain au chocolat,1
2020/2/22 12:13,Sat,17000,pain au chocolat,1
2020/2/22 12:25,Sat,16300,pain au chocolat,1
2020/2/22 12:33,Sat,14500,pain au chocolat,1
2020/2/22 13:10,Sat,22000,pain au chocolat,1
2020/2/22 13:51,Sat,21500,pain au chocolat,1
2020/2/23 11:04,Sun,35300,pain au chocolat,1
2020/2/23 11:06,Sun,18000,pain au chocolat,1
2020/2/23 11:41,Sun,17000,pain au chocolat,1
2020/2/23 12:27,Sun,23100,pain au chocolat,1
2020/2/23 13:09,Sun,21800,pain au chocolat,1
2020/2/23 13:35,Sun,18500,pain au chocolat,1
2020/2/24 14:32,Mon,26800,pain au chocolat,2
2020/2/26 12:01,Wed,23300,pain au chocolat,1
2020/2/26 13:03,Wed,17800,pain au chocolat,1
2020/2/26 14:40,Wed,17100,pain au chocolat,1
2020/2/27 11:25,Thur,23100,pain au chocolat,1
2020/2/27 14:22,Thur,22000,pain au chocolat,1
2020/2/27 15:47,Thur,19600,pain au chocolat,1
2020/2/28 11:09,Fri,23100,pain au chocolat,1
2020/2/28 12:10,Fri,24500,pain au chocolat,1
2020/2/29 11:09,Sat,17300,pain au chocolat,1
2020/2/29 12:52,Sat,21300,pain au chocolat,1
2020/2/29 14:23,Sat,22800,pain au chocolat,1
2020/2/29 14:55,Sat,18000,pain au chocolat,1
2020/3/1 13:10,Sun,33400,pain au chocolat,2
2020/3/2 13:00,Mon,18300,pain au chocolat,1
2020/3/2 13:00,Mon,20000,pain au chocolat,1
2020/3/2 14:35,Mon,19000,pain au chocolat,1
2020/3/5 12:00,Thur,24300,pain au chocolat,1
2020/3/5 12:11,Thur,17800,pain au chocolat,1
2020/3/5 12:28,Thur,18000,pain au chocolat,1
2020/3/5 13:48,Thur,27800,pain au chocolat,1
2020/3/6 11:53,Fri,17500,pain au chocolat,1
2020/3/6 12:15,Fri,18500,pain au chocolat,1
2020/3/6 12:24,Fri,25600,pain au chocolat,1
2020/3/7 11:16,Sat,14800,pain au chocolat,1
2020/3/7 12:39,Sat,17500,pain au chocolat,1
2020/3/8 13:48,Sun,18500,pain au chocolat,2
2020/3/8 14:07,Sun,22300,pain au chocolat,1
2020/3/9 11:23,Mon,21300,pain au chocolat,2
2020/3/9 14:05,Mon,18000,pain au chocolat,1
2020/3/11 11:24,Wed,24300,pain au chocolat,1
2020/3/11 13:17,Wed,25300,pain au chocolat,1
2020/3/11 13:21,Wed,19000,pain au chocolat,1
2020/3/12 11:03,Thur,22800,pain au chocolat,2
2020/3/12 11:31,Thur,18000,pain au chocolat,1
2020/3/12 11:45,Thur,17300,pain au chocolat,1
2020/3/12 12:23,Thur,20800,pain au chocolat,1
2020/3/13 11:46,Fri,23800,pain au chocolat,1
2020/3/13 12:25,Fri,14800,pain au chocolat,1
2020/3/14 11:29,Sat,15300,pain au chocolat,1
2020/3/14 12:57,Sat,17500,pain au chocolat,1
2020/3/14 13:52,Sat,21800,pain au chocolat,1
2020/3/15 11:19,Sun,14300,pain au chocolat,1
2020/3/15 11:40,Sun,18600,pain au chocolat,1
2020/3/15 14:07,Sun,25000,pain au chocolat,2
2020/3/15 14:09,Sun,21800,pain au chocolat,1
2020/3/16 11:11,Mon,19300,pain au chocolat,1
2020/3/16 13:29,Mon,14800,pain au chocolat,1
2020/3/16 13:45,Mon,17000,pain au chocolat,1
2020/3/16 14:05,Mon,34900,pain au chocolat,2
2020/3/18 11:43,Wed,30500,pain au chocolat,1
2020/3/18 12:10,Wed,15800,pain au chocolat,1
2020/3/18 13:06,Wed,17500,pain au chocolat,1
2020/3/18 14:06,Wed,27900,pain au chocolat,2
2020/3/19 12:25,Thur,23100,pain au chocolat,1
2020/3/20 11:29,Fri,25800,pain au chocolat,2
2020/3/20 12:17,Fri,28800,pain au chocolat,1
2020/3/20 12:34,Fri,17000,pain au chocolat,1
2020/3/21 11:04,Sat,27800,pain au chocolat,1
2020/3/21 11:28,Sat,31600,pain au chocolat,1
2020/3/21 11:33,Sat,20000,pain au chocolat,1
2020/3/21 12:51,Sat,18300,pain au chocolat,1
2020/3/21 13:41,Sat,17800,pain au chocolat,1
2020/3/22 11:02,Sun,18500,pain au chocolat,2
2020/3/22 12:43,Sun,15100,pain au chocolat,1
2020/3/23 12:44,Mon,15000,pain au chocolat,1
2020/3/23 14:32,Mon,40700,pain au chocolat,3
2020/3/25 11:05,Wed,19300,pain au chocolat,2
2020/3/25 14:08,Wed,18000,pain au chocolat,1
2020/3/25 14:12,Wed,22300,pain au chocolat,1
2020/3/26 13:06,Thur,18300,pain au chocolat,1
2020/3/26 14:35,Thur,24700,pain au chocolat,1
2020/3/26 14:44,Thur,31100,pain au chocolat,1
2020/3/26 15:10,Thur,26900,pain au chocolat,3
2020/3/27 11:42,Fri,17000,pain au chocolat,1
2020/3/27 13:10,Fri,18500,pain au chocolat,1
2020/3/27 15:11,Fri,15100,pain au chocolat,1
2020/3/27 15:36,Fri,28800,pain au chocolat,1
2020/3/28 11:55,Sat,40300,pain au chocolat,1
2020/3/28 13:36,Sat,18000,pain au chocolat,2
2020/3/29 11:09,Sun,21800,pain au chocolat,2
2020/3/29 11:25,Sun,27800,pain au chocolat,1
2020/3/29 12:02,Sun,29800,pain au chocolat,1
2020/3/30 11:28,Mon,28600,pain au chocolat,2
2020/3/30 13:25,Mon,18800,pain au chocolat,1
2020/3/30 14:46,Mon,14800,pain au chocolat,1
2020/3/30 15:07,Mon,17800,pain au chocolat,1
2020/4/1 12:32,Wed,23100,pain au chocolat,1
2020/4/1 12:45,Wed,18300,pain au chocolat,1
2020/4/1 13:29,Wed,32100,pain au chocolat,1
2020/4/1 13:49,Wed,28800,pain au chocolat,1
2020/4/1 14:28,Wed,18800,pain au chocolat,1
2020/4/2 11:43,Thur,22800,pain au chocolat,1
2020/4/2 11:54,Thur,15300,pain au chocolat,1
2020/4/2 13:12,Thur,23100,pain au chocolat,1
2020/4/2 16:03,Thur,26900,pain au chocolat,2
2020/4/4 14:06,Sat,21800,pain au chocolat,1
2020/4/5 12:33,Sun,16300,pain au chocolat,1
2020/4/5 14:41,Sun,26300,pain au chocolat,1
2020/4/5 16:03,Sun,15000,pain au chocolat,1
2020/4/6 11:24,Mon,19800,pain au chocolat,1
2020/4/6 15:55,Mon,27100,pain au chocolat,1
2020/4/8 12:01,Wed,30300,pain au chocolat,1
2020/4/10 11:45,Fri,20500,pain au chocolat,1
2020/4/10 16:13,Fri,31600,pain au chocolat,1
2020/4/11 11:20,Sat,17300,pain au chocolat,1
2020/4/12 11:05,Sun,32200,pain au chocolat,1
2020/4/12 12:35,Sun,18300,pain au chocolat,1
2020/4/12 13:33,Sun,18300,pain au chocolat,1
2020/4/12 14:32,Sun,14300,pain au chocolat,1
2020/4/15 11:43,Wed,27100,pain au chocolat,1
2020/4/15 13:49,Wed,14300,pain au chocolat,1
2020/4/15 15:01,Wed,16000,pain au chocolat,1
2020/4/18 14:10,Sat,36000,pain au chocolat,1
2020/4/18 14:12,Sat,30100,pain au chocolat,1
2020/4/18 14:35,Sat,17800,pain au chocolat,1
2020/4/19 12:35,Sun,14300,pain au chocolat,1
2020/4/20 12:13,Mon,20000,pain au chocolat,2
2020/4/20 12:53,Mon,16000,pain au chocolat,1
2020/4/20 14:46,Mon,64000,pain au chocolat,3
2020/4/22 11:53,Wed,18000,pain au chocolat,3
2020/4/22 12:06,Wed,28600,pain au chocolat,1
2020/4/22 12:18,Wed,18300,pain au chocolat,1
2020/4/22 12:53,Wed,18800,pain au chocolat,1
2020/4/22 13:05,Wed,20300,pain au chocolat,2
2020/4/23 11:40,Thur,28500,pain au chocolat,2
2020/4/23 13:57,Thur,17300,pain au chocolat,2
2020/4/23 15:10,Thur,26000,pain au chocolat,4
2020/4/25 11:10,Sat,18300,pain au chocolat,1
2020/4/25 11:37,Sat,20600,pain au chocolat,1
2020/4/25 13:18,Sat,19300,pain au chocolat,1
2020/4/25 14:25,Sat,22800,pain au chocolat,1
2020/4/26 11:03,Sun,38900,pain au chocolat,1
2020/4/26 12:02,Sun,23600,pain au chocolat,1
2020/4/26 13:01,Sun,14800,pain au chocolat,1
2020/4/27 11:42,Mon,30800,pain au chocolat,1
2020/4/27 12:08,Mon,14800,pain au chocolat,1
2020/4/27 13:35,Mon,14000,pain au chocolat,1
2020/4/27 14:42,Mon,14300,pain au chocolat,1
2020/4/27 15:10,Mon,25800,pain au chocolat,2
2020/4/29 12:00,Wed,21800,pain au chocolat,1
2020/4/30 11:18,Thur,31300,pain au chocolat,1
2020/4/30 12:17,Thur,18800,pain au chocolat,1
2020/5/1 11:09,Fri,31600,pain au chocolat,1
2020/5/1 12:00,Fri,30800,pain au chocolat,1
2020/5/1 12:10,Fri,18300,pain au chocolat,1
2020/5/2 11:37,Sat,19500,pain au chocolat,1
2020/5/2 14:45,Sat,24100,pain au chocolat,1
2019/7/21 15:21,Sun,15100,almond croissant,1
2019/7/24 15:36,Wed,16100,almond croissant,1
2019/7/24 17:20,Wed,15000,almond croissant,1
2019/7/25 12:01,Thur,35000,almond croissant,4
2019/7/25 15:57,Thur,15100,almond croissant,1
2019/7/25 16:03,Thur,20000,almond croissant,1
2019/7/26 11:36,Fri,1293000,almond croissant,5
2019/7/26 11:55,Fri,20800,almond croissant,1
2019/7/26 14:52,Fri,22100,almond croissant,1
2019/7/29 12:54,Mon,15800,almond croissant,1
2019/7/29 13:36,Mon,28000,almond croissant,1
2019/7/29 13:53,Mon,28000,almond croissant,1
2019/7/31 11:38,Wed,23300,almond croissant,1
2019/8/3 11:05,Sat,29100,almond croissant,1
2019/8/3 13:42,Sat,15800,almond croissant,2
2019/8/4 12:39,Sun,17800,almond croissant,1
2019/8/5 11:32,Mon,17000,almond croissant,2
2019/8/10 11:27,Sat,36800,almond croissant,1
2019/8/10 12:17,Sat,46200,almond croissant,1
2019/8/11 11:40,Sun,38900,almond croissant,1
2019/8/11 11:46,Sun,19600,almond croissant,1
2019/8/12 12:53,Mon,16300,almond croissant,1
2019/8/12 13:27,Mon,18300,almond croissant,1
2019/8/14 11:04,Wed,18300,almond croissant,1
2019/8/14 11:07,Wed,17300,almond croissant,1
2019/8/14 11:22,Wed,29000,almond croissant,1
2019/8/14 11:31,Wed,22300,almond croissant,1
2019/8/16 13:27,Fri,15800,almond croissant,1
2019/8/17 12:57,Sat,29600,almond croissant,1
2019/8/18 11:06,Sun,36900,almond croissant,1
2019/8/18 11:09,Sun,22800,almond croissant,1
2019/8/18 12:04,Sun,20000,almond croissant,1
2019/8/18 12:24,Sun,16000,almond croissant,1
2019/8/19 11:29,Mon,22800,almond croissant,1
2019/8/19 12:08,Mon,21300,almond croissant,1
2019/8/19 15:14,Mon,15300,almond croissant,1
2019/8/21 14:11,Wed,25000,almond croissant,1
2019/8/21 14:38,Wed,23000,almond croissant,1
2019/8/22 12:08,Thur,23300,almond croissant,1
2019/8/23 12:47,Fri,19800,almond croissant,1
2019/8/24 12:56,Sat,23300,almond croissant,1
2019/8/24 14:13,Sat,15300,almond croissant,1
2019/8/25 11:06,Sun,17300,almond croissant,1
2019/8/26 16:11,Mon,22800,almond croissant,1
2019/8/28 13:57,Wed,33400,almond croissant,1
2019/8/29 12:35,Thur,16100,almond croissant,1
2019/8/29 13:28,Thur,53800,almond croissant,1
2019/8/29 16:45,Thur,24300,almond croissant,1
2019/8/30 15:39,Fri,15500,almond croissant,1
2019/9/1 11:05,Sun,23300,almond croissant,1
2019/9/1 14:43,Sun,15800,almond croissant,1
2019/9/2 14:30,Mon,24300,almond croissant,2
2019/9/2 15:13,Mon,23500,almond croissant,1
2019/9/2 15:24,Mon,15000,almond croissant,1
2019/9/6 16:29,Fri,39700,almond croissant,2
2019/9/7 11:47,Sat,22500,almond croissant,1
2019/9/7 11:57,Sat,22800,almond croissant,2
2019/9/8 11:08,Sun,25100,almond croissant,1
2019/9/12 11:13,Thur,15000,almond croissant,1
2019/9/14 11:07,Sat,22800,almond croissant,1
2019/9/15 13:38,Sun,25300,almond croissant,1
2019/9/19 12:23,Thur,20000,almond croissant,1
2019/9/19 16:33,Thur,16000,almond croissant,1
2019/9/21 11:06,Sat,17800,almond croissant,1
2019/9/21 11:22,Sat,18300,almond croissant,1
2019/9/22 11:33,Sun,14500,almond croissant,2
2019/9/22 12:05,Sun,17000,almond croissant,1
2019/9/25 15:18,Wed,26300,almond croissant,2
2019/9/29 11:03,Sun,24400,almond croissant,1
2019/10/3 11:07,Thur,17800,almond croissant,1
2019/10/3 14:44,Thur,19300,almond croissant,1
2019/10/5 12:39,Sat,31800,almond croissant,1
2019/10/5 15:00,Sat,15500,almond croissant,1
2019/10/11 11:34,Fri,14800,almond croissant,1
2019/10/11 14:09,Fri,20800,almond croissant,1
2019/10/13 11:10,Sun,14500,almond croissant,1
2019/10/13 11:20,Sun,25800,almond croissant,2
2019/10/14 15:21,Mon,28500,almond croissant,2
2019/10/16 11:48,Wed,15500,almond croissant,1
2019/10/16 14:31,Wed,20300,almond croissant,1
2019/10/17 11:47,Thur,14800,almond croissant,1
2019/10/17 12:48,Thur,15800,almond croissant,1
2019/10/18 11:43,Fri,51900,almond croissant,1
2019/10/19 11:13,Sat,29000,almond croissant,1
2019/10/19 16:20,Sat,15100,almond croissant,1
2019/10/21 11:19,Mon,18300,almond croissant,1
2019/10/21 13:47,Mon,54700,almond croissant,1
2019/10/23 11:06,Wed,15800,almond croissant,1
2019/10/25 12:33,Fri,15000,almond croissant,1
2019/10/28 11:40,Mon,15800,almond croissant,1
2019/10/28 13:31,Mon,23300,almond croissant,1
2019/10/31 11:05,Thur,55800,almond croissant,2
2019/11/6 11:07,Wed,16000,almond croissant,1
2019/11/6 11:47,Wed,24600,almond croissant,1
2019/11/6 16:15,Wed,24800,almond croissant,2
2019/11/8 15:12,Fri,30000,almond croissant,1
2019/11/9 11:36,Sat,19300,almond croissant,1
2019/11/10 11:41,Sun,15800,almond croissant,1
2019/11/13 11:46,Wed,15800,almond croissant,1
2019/11/24 12:57,Sun,14500,almond croissant,1
2019/11/24 13:34,Sun,39000,almond croissant,1
2019/11/25 11:31,Mon,54100,almond croissant,2
2019/11/29 12:50,Fri,15800,almond croissant,1
2019/11/29 15:27,Fri,15000,almond croissant,1
2019/11/30 11:43,Sat,15800,almond croissant,1
2019/12/4 11:06,Wed,20300,almond croissant,1
2019/12/4 11:47,Wed,17500,almond croissant,1
2019/12/4 13:33,Wed,16100,almond croissant,1
2019/12/6 12:17,Fri,20100,almond croissant,1
2019/12/7 11:41,Sat,17500,almond croissant,1
2019/12/8 11:50,Sun,18000,almond croissant,1
2019/12/8 12:52,Sun,20300,almond croissant,1
2019/12/8 13:02,Sun,25400,almond croissant,2
2019/12/8 13:44,Sun,28100,almond croissant,1
2019/12/11 11:36,Wed,22000,almond croissant,1
2019/12/11 12:09,Wed,21500,almond croissant,1
2019/12/15 12:14,Sun,19300,almond croissant,1
2019/12/20 13:29,Fri,21600,almond croissant,2
2019/12/21 12:24,Sat,25300,almond croissant,1
2019/12/23 11:31,Mon,26100,almond croissant,1
2019/12/28 14:58,Sat,24300,almond croissant,1
2019/12/28 16:38,Sat,21100,almond croissant,1
2019/12/29 16:02,Sun,25500,almond croissant,1
2019/12/30 14:35,Mon,53900,almond croissant,2
2020/1/2 11:33,Thur,42900,almond croissant,1
2020/1/3 11:59,Fri,16300,almond croissant,1
2020/1/5 11:10,Sun,18600,almond croissant,1
2020/1/12 12:30,Sun,16000,almond croissant,1
2020/1/13 15:50,Mon,20500,almond croissant,1
2020/1/15 11:24,Wed,15500,almond croissant,1
2020/1/15 13:16,Wed,15000,almond croissant,1
2020/1/18 16:12,Sat,14500,almond croissant,1
2020/1/19 13:17,Sun,24300,almond croissant,1
2020/1/19 16:21,Sun,19800,almond croissant,1
2020/1/26 13:09,Sun,18000,almond croissant,1
2020/1/29 12:23,Wed,14800,almond croissant,1
2020/1/30 12:15,Thur,34300,almond croissant,1
2020/1/31 11:32,Fri,22500,almond croissant,2
2020/1/31 13:09,Fri,20300,almond croissant,1
2020/2/2 12:21,Sun,18300,almond croissant,1
2020/2/5 11:23,Wed,19800,almond croissant,1
2020/2/5 13:12,Wed,21300,almond croissant,1
2020/2/6 11:13,Thur,15800,almond croissant,1
2020/2/6 13:13,Thur,21300,almond croissant,1
2020/2/7 15:34,Fri,21800,almond croissant,1
2020/2/7 16:23,Fri,20000,almond croissant,2
2020/2/9 12:54,Sun,22300,almond croissant,1
2020/2/10 11:41,Mon,19300,almond croissant,1
2020/2/12 11:04,Wed,15000,almond croissant,1
2020/2/12 14:35,Wed,55200,almond croissant,1
2020/2/13 11:20,Thur,15500,almond croissant,2
2020/2/14 13:12,Fri,20300,almond croissant,1
2020/2/15 14:03,Sat,32100,almond croissant,1
2020/2/17 11:20,Mon,15500,almond croissant,1
2020/2/17 13:05,Mon,20300,almond croissant,1
2020/2/17 15:25,Mon,36600,almond croissant,2
2020/2/19 11:00,Wed,14500,almond croissant,1
2020/2/19 11:39,Wed,19600,almond croissant,1
2020/2/20 13:18,Thur,15800,almond croissant,1
2020/2/21 11:40,Fri,18000,almond croissant,2
2020/2/26 12:34,Wed,22000,almond croissant,1
2020/2/26 13:38,Wed,20800,almond croissant,1
2020/2/26 16:13,Wed,27900,almond croissant,1
2020/2/28 13:26,Fri,18000,almond croissant,2
2020/2/29 12:48,Sat,19000,almond croissant,1
2020/2/29 12:49,Sat,18500,almond croissant,1
2020/2/29 15:34,Sat,19300,almond croissant,1
2020/3/1 11:14,Sun,23800,almond croissant,1
2020/3/1 12:19,Sun,20800,almond croissant,1
2020/3/5 12:28,Thur,18000,almond croissant,1
2020/3/5 13:39,Thur,18500,almond croissant,1
2020/3/8 13:34,Sun,18000,almond croissant,2
2020/3/8 15:18,Sun,25400,almond croissant,1
2020/3/11 11:51,Wed,16000,almond croissant,1
2020/3/14 12:22,Sat,19000,almond croissant,1
2020/3/15 14:07,Sun,25000,almond croissant,2
2020/3/18 11:43,Wed,30500,almond croissant,2
2020/3/18 12:40,Wed,42400,almond croissant,1
2020/3/19 12:30,Thur,22800,almond croissant,2
2020/3/22 11:02,Sun,18500,almond croissant,1
2020/3/22 15:21,Sun,19300,almond croissant,1
2020/3/28 11:14,Sat,19300,almond croissant,1
2020/3/29 12:09,Sun,16100,almond croissant,1
2020/3/30 14:46,Mon,14800,almond croissant,1
2020/4/1 12:32,Wed,23100,almond croissant,1
2020/4/2 12:11,Thur,28800,almond croissant,1
2020/4/5 13:29,Sun,14800,almond croissant,1
2020/4/11 12:34,Sat,21000,almond croissant,1
2020/4/12 14:30,Sun,15800,almond croissant,1
2020/4/15 15:17,Wed,29200,almond croissant,1
2020/4/16 11:46,Thur,19300,almond croissant,1
2020/4/17 16:05,Fri,17000,almond croissant,1
2020/4/22 13:07,Wed,25100,almond croissant,1
2020/4/23 15:14,Thur,19000,almond croissant,1
2020/4/24 11:12,Fri,18800,almond croissant,1
2020/4/24 15:10,Fri,26000,almond croissant,2
2020/4/25 11:16,Sat,30800,almond croissant,1
2020/4/25 14:27,Sat,20800,almond croissant,1
2020/4/26 11:03,Sun,38900,almond croissant,1
2020/4/30 16:02,Thur,15300,almond croissant,1
2020/5/1 11:09,Fri,31600,almond croissant,1
2020/5/1 15:03,Fri,14800,almond croissant,1
2019/7/13 14:54,Sat,15800,milk tea,1
2019/7/20 11:19,Sat,15800,milk tea,1
2019/7/21 13:37,Sun,19300,milk tea,2
2019/7/22 12:16,Mon,19300,milk tea,1
2019/7/24 14:25,Wed,25400,milk tea,2
2019/7/26 14:05,Fri,15800,milk tea,1
2019/7/29 13:36,Mon,28000,milk tea,1
2019/7/31 13:54,Wed,15100,milk tea,1
2019/8/1 12:38,Thur,14500,milk tea,1
2019/8/1 13:39,Thur,15000,milk tea,1
2019/8/3 12:44,Sat,19300,milk tea,1
2019/8/4 11:07,Sun,19300,milk tea,1
2019/8/5 11:16,Mon,23100,milk tea,1
2019/8/7 14:50,Wed,23800,milk tea,1
2019/8/9 12:31,Fri,18600,milk tea,1
2019/8/19 13:53,Mon,24300,milk tea,1
2019/8/21 13:43,Wed,21100,milk tea,1
2019/8/23 15:32,Fri,22000,milk tea,1
2019/8/28 11:30,Wed,34100,milk tea,3
2019/8/28 12:24,Wed,18000,milk tea,1
2019/8/29 12:25,Thur,18300,milk tea,1
2019/8/31 14:50,Sat,16100,milk tea,1
2019/9/4 12:31,Wed,18600,milk tea,1
2019/9/4 15:26,Wed,41100,milk tea,1
2019/9/5 15:39,Thur,16100,milk tea,1
2019/9/7 15:22,Sat,26300,milk tea,1
2019/9/8 11:37,Sun,26000,milk tea,1
2019/9/9 13:23,Mon,21000,milk tea,1
2019/9/11 14:57,Wed,24600,milk tea,1
2019/9/15 13:38,Sun,25300,milk tea,1
2019/9/15 15:28,Sun,57900,milk tea,2
2019/9/18 15:24,Wed,17000,milk tea,1
2019/9/19 13:50,Thur,20900,milk tea,1
2019/9/19 16:17,Thur,30500,milk tea,1
2019/9/27 16:12,Fri,36100,milk tea,1
2019/9/28 13:52,Sat,27100,milk tea,1
2019/9/29 11:03,Sun,24400,milk tea,1
2019/9/29 12:13,Sun,23800,milk tea,1
2019/10/3 13:42,Thur,18800,milk tea,1
2019/10/7 11:12,Mon,19800,milk tea,1
2019/10/13 13:48,Sun,21500,milk tea,2
2019/10/14 12:09,Mon,14800,milk tea,1
2019/10/14 13:47,Mon,18300,milk tea,1
2019/11/1 13:52,Fri,22000,milk tea,1
2019/11/3 12:25,Sun,17800,milk tea,1
2019/11/10 11:55,Sun,29100,milk tea,1
2019/11/10 12:11,Sun,19300,milk tea,2
2019/11/13 16:23,Wed,15800,milk tea,1
2019/11/13 17:22,Wed,15100,milk tea,1
2019/11/14 12:52,Thur,16300,milk tea,1
2019/11/14 13:10,Thur,39300,milk tea,1
2019/11/15 13:09,Fri,16100,milk tea,1
2019/11/17 11:40,Sun,17500,milk tea,1
2019/11/17 13:18,Sun,23300,milk tea,1
2019/11/20 13:24,Wed,23800,milk tea,1
2019/11/22 12:25,Fri,16300,milk tea,1
2019/11/23 12:00,Sat,36100,milk tea,1
2019/11/24 13:00,Sun,17300,milk tea,1
2019/11/24 13:34,Sun,39000,milk tea,1
2019/11/28 15:09,Thur,19300,milk tea,1
2019/11/29 11:05,Fri,15800,milk tea,1
2019/12/1 14:29,Sun,20800,milk tea,1
2019/12/2 14:42,Mon,22800,milk tea,2
2019/12/6 11:38,Fri,13800,milk tea,1
2019/12/7 13:39,Sat,30800,milk tea,1
2019/12/12 14:34,Thur,16300,milk tea,1
2019/12/14 13:14,Sat,15800,milk tea,1
2019/12/14 14:15,Sat,16800,milk tea,1
2019/12/15 15:53,Sun,17100,milk tea,1
2019/12/16 14:26,Mon,20300,milk tea,2
2019/12/18 14:40,Wed,15500,milk tea,3
2019/12/19 13:06,Thur,32500,milk tea,1
2019/12/21 14:28,Sat,18500,milk tea,1
2019/12/23 12:06,Mon,23800,milk tea,1
2019/12/23 13:37,Mon,27300,milk tea,1
2019/12/23 13:57,Mon,30300,milk tea,1
2019/12/26 12:18,Thur,26600,milk tea,1
2019/12/30 15:22,Mon,26100,milk tea,2
2020/1/2 12:50,Thur,29300,milk tea,1
2020/1/3 11:14,Fri,15500,milk tea,1
2020/1/5 11:03,Sun,16800,milk tea,1
2020/1/5 15:06,Sun,24400,milk tea,1
2020/1/8 15:42,Wed,19800,milk tea,1
2020/1/10 13:42,Fri,20100,milk tea,1
2020/1/12 11:03,Sun,21800,milk tea,2
2020/1/12 17:05,Sun,21300,milk tea,1
2020/1/13 11:52,Mon,20300,milk tea,1
2020/1/13 15:52,Mon,14800,milk tea,1
2020/1/15 13:22,Wed,26300,milk tea,1
2020/1/27 11:02,Mon,21600,milk tea,1
2020/1/30 13:20,Thur,29600,milk tea,2
2020/1/30 14:26,Thur,23300,milk tea,1
2020/1/30 15:15,Thur,21100,milk tea,1
2020/1/31 12:36,Fri,29900,milk tea,1
2020/2/1 14:06,Sat,15800,milk tea,1
2020/2/8 15:22,Sat,22800,milk tea,1
2020/2/9 11:52,Sun,34300,milk tea,2
2020/2/12 12:48,Wed,53600,milk tea,6
2020/2/14 14:16,Fri,16100,milk tea,1
2020/2/15 13:04,Sat,19300,milk tea,1
2020/2/15 17:19,Sat,19600,milk tea,1
2020/2/17 11:20,Mon,15500,milk tea,1
2020/2/17 14:29,Mon,20300,milk tea,1
2020/2/19 12:07,Wed,16000,milk tea,1
2020/2/20 12:12,Thur,14800,milk tea,1
2020/2/21 13:20,Fri,20000,milk tea,1
2020/2/23 12:38,Sun,18800,milk tea,1
2020/2/23 14:21,Sun,24400,milk tea,1
2020/2/23 15:07,Sun,15800,milk tea,1
2020/2/23 16:29,Sun,30100,milk tea,2
2020/2/24 15:02,Mon,16100,milk tea,1
2020/2/28 15:50,Fri,17800,milk tea,1
2020/2/29 11:09,Sat,17300,milk tea,1
2020/2/29 14:55,Sat,18000,milk tea,1
2020/3/1 11:06,Sun,34100,milk tea,1
2020/3/2 12:51,Mon,27800,milk tea,1
2020/3/6 12:21,Fri,16300,milk tea,1
2020/3/6 13:21,Fri,20600,milk tea,1
2020/3/7 13:53,Sat,28100,milk tea,1
2020/3/8 11:19,Sun,19000,milk tea,1
2020/3/8 12:52,Sun,21300,milk tea,1
2020/3/11 11:24,Wed,24300,milk tea,1
2020/3/13 12:25,Fri,14800,milk tea,1
2020/3/15 13:02,Sun,15000,milk tea,1
2020/3/15 13:45,Sun,28000,milk tea,3
2020/3/15 14:05,Sun,15000,milk tea,1
2020/3/18 11:43,Wed,30500,milk tea,1
2020/3/18 14:31,Wed,16100,milk tea,1
2020/3/27 15:38,Fri,16100,milk tea,1
2020/3/28 11:55,Sat,40300,milk tea,1
2020/4/1 13:49,Wed,28800,milk tea,1
2020/4/9 16:44,Thur,24100,milk tea,1
2020/4/12 14:06,Sun,15000,milk tea,1
2020/4/17 16:30,Fri,16100,milk tea,1
2020/4/24 15:10,Fri,26000,milk tea,1
2020/4/27 11:56,Mon,22300,milk tea,1
2020/4/29 15:05,Wed,26800,milk tea,1
2019/7/17 14:16,Wed,23400,gateau chocolat,1
2019/7/20 11:40,Sat,22800,gateau chocolat,1
2019/7/21 11:07,Sun,18600,gateau chocolat,1
2019/7/21 15:21,Sun,15100,gateau chocolat,1
2019/7/22 15:37,Mon,19600,gateau chocolat,1
2019/7/22 16:54,Mon,18600,gateau chocolat,1
2019/7/25 11:49,Thur,18600,gateau chocolat,1
2019/7/25 13:05,Thur,17300,gateau chocolat,1
2019/7/25 15:57,Thur,15100,gateau chocolat,1
2019/7/26 14:52,Fri,22100,gateau chocolat,1
2019/7/27 12:00,Sat,18600,gateau chocolat,1
2019/7/27 12:07,Sat,33200,gateau chocolat,2
2019/7/27 14:05,Sat,32600,gateau chocolat,1
2019/7/29 13:25,Mon,18100,gateau chocolat,1
2019/7/31 11:44,Wed,30200,gateau chocolat,2
2019/7/31 13:29,Wed,16100,gateau chocolat,1
2019/7/31 13:54,Wed,15100,gateau chocolat,1
2019/8/1 12:24,Thur,32600,gateau chocolat,1
2019/8/2 11:04,Fri,14100,gateau chocolat,1
2019/8/2 12:31,Fri,19900,gateau chocolat,1
2019/8/3 11:05,Sat,29100,gateau chocolat,1
2019/8/3 11:08,Sat,22800,gateau chocolat,1
2019/8/3 11:20,Sat,16600,gateau chocolat,1
2019/8/4 12:39,Sun,17800,gateau chocolat,1
2019/8/5 11:18,Mon,31400,gateau chocolat,1
2019/8/7 12:17,Wed,15300,gateau chocolat,1
2019/8/7 13:28,Wed,17600,gateau chocolat,1
2019/8/8 13:36,Thur,33200,gateau chocolat,2
2019/8/8 13:55,Thur,22300,gateau chocolat,1
2019/8/9 12:31,Fri,18600,gateau chocolat,1
2019/8/9 15:30,Fri,15100,gateau chocolat,1
2019/8/10 11:03,Sat,19100,gateau chocolat,1
2019/8/10 13:15,Sat,16600,gateau chocolat,1
2019/8/12 11:05,Mon,28400,gateau chocolat,1
2019/8/12 14:08,Mon,32100,gateau chocolat,1
2019/8/14 11:16,Wed,65600,gateau chocolat,1
2019/8/15 11:49,Thur,15100,gateau chocolat,1
2019/8/15 12:00,Thur,18900,gateau chocolat,1
2019/8/19 12:34,Mon,23600,gateau chocolat,1
2019/8/19 15:14,Mon,15300,gateau chocolat,1
2019/8/21 13:26,Wed,15600,gateau chocolat,1
2019/8/23 12:42,Fri,14100,gateau chocolat,1
2019/8/24 11:09,Sat,20100,gateau chocolat,1
2019/8/24 11:13,Sat,25600,gateau chocolat,1
2019/8/24 11:55,Sat,20800,gateau chocolat,1
2019/8/25 12:48,Sun,15100,gateau chocolat,1
2019/8/29 16:46,Thur,15100,gateau chocolat,1
2019/8/31 11:15,Sat,18600,gateau chocolat,1
2019/9/1 12:25,Sun,22900,gateau chocolat,1
2019/9/1 13:56,Sun,14800,gateau chocolat,1
2019/9/1 14:05,Sun,33100,gateau chocolat,1
2019/9/4 12:06,Wed,18600,gateau chocolat,1
2019/9/4 12:31,Wed,18600,gateau chocolat,1
2019/9/4 13:42,Wed,27700,gateau chocolat,1
2019/9/4 14:52,Wed,25600,gateau chocolat,2
2019/9/5 12:12,Thur,19600,gateau chocolat,1
2019/9/5 13:49,Thur,20900,gateau chocolat,1
2019/9/6 15:06,Fri,15800,gateau chocolat,1
2019/9/6 16:29,Fri,39700,gateau chocolat,2
2019/9/7 11:06,Sat,18600,gateau chocolat,2
2019/9/7 11:57,Sat,22800,gateau chocolat,1
2019/9/7 12:05,Sat,18600,gateau chocolat,1
2019/9/7 15:22,Sat,26300,gateau chocolat,1
2019/9/7 16:12,Sat,27500,gateau chocolat,2
2019/9/9 11:12,Mon,23100,gateau chocolat,1
2019/9/11 14:57,Wed,24600,gateau chocolat,1
2019/9/11 15:30,Wed,15100,gateau chocolat,1
2019/9/14 11:18,Sat,22300,gateau chocolat,1
2019/9/15 14:54,Sun,15100,gateau chocolat,1
2019/9/15 15:28,Sun,57900,gateau chocolat,1
2019/9/20 12:59,Fri,15100,gateau chocolat,1
2019/9/21 11:19,Sat,23600,gateau chocolat,1
2019/9/21 11:39,Sat,21100,gateau chocolat,1
2019/9/21 12:28,Sat,37900,gateau chocolat,1
2019/9/22 11:09,Sun,14100,gateau chocolat,1
2019/9/22 11:18,Sun,30900,gateau chocolat,1
2019/9/25 15:18,Wed,26300,gateau chocolat,1
2019/9/28 13:52,Sat,27100,gateau chocolat,1
2019/9/29 11:03,Sun,24400,gateau chocolat,1
2019/9/29 15:05,Sun,19600,gateau chocolat,1
2019/10/3 14:44,Thur,19300,gateau chocolat,1
2019/10/3 14:50,Thur,15400,gateau chocolat,1
2019/10/6 11:08,Sun,15800,gateau chocolat,1
2019/10/7 13:31,Mon,15100,gateau chocolat,1
2019/10/11 12:38,Fri,15100,gateau chocolat,1
2019/10/11 15:00,Fri,14800,gateau chocolat,1
2019/10/13 11:20,Sun,25800,gateau chocolat,1
2019/10/13 13:07,Sun,17300,gateau chocolat,1
2019/10/13 14:32,Sun,15600,gateau chocolat,1
2019/10/13 14:54,Sun,27600,gateau chocolat,1
2019/10/19 16:20,Sat,15100,gateau chocolat,1
2019/10/24 11:06,Thur,15100,gateau chocolat,1
2019/11/1 11:10,Fri,14100,gateau chocolat,1
2019/11/2 14:19,Sat,22300,gateau chocolat,1
2019/11/3 12:01,Sun,33700,gateau chocolat,2
2019/11/7 13:43,Thur,27900,gateau chocolat,1
2019/11/9 11:36,Sat,19300,gateau chocolat,1
2019/11/9 11:36,Sat,21300,gateau chocolat,1
2019/11/10 11:27,Sun,15400,gateau chocolat,1
2019/11/13 17:22,Wed,15100,gateau chocolat,1
2019/11/27 14:00,Wed,14100,gateau chocolat,1
2019/12/2 13:06,Mon,20600,gateau chocolat,1
2019/12/5 13:00,Thur,25000,gateau chocolat,1
2019/12/6 15:25,Fri,13800,gateau chocolat,1
2019/12/12 17:22,Thur,21800,gateau chocolat,1
2019/12/16 12:07,Mon,14100,gateau chocolat,1
2019/12/18 11:22,Wed,52800,gateau chocolat,1
2019/12/18 15:23,Wed,51200,gateau chocolat,2
2019/12/19 13:21,Thur,14300,gateau chocolat,1
2019/12/21 11:04,Sat,15100,gateau chocolat,1
2019/12/21 14:43,Sat,30900,gateau chocolat,1
2019/12/24 13:14,Tues,19300,gateau chocolat,1
2019/12/26 15:18,Thur,15300,gateau chocolat,1
2019/12/29 13:03,Sun,19800,gateau chocolat,1
2020/1/3 16:06,Fri,17300,gateau chocolat,1
2020/1/3 16:25,Fri,15100,gateau chocolat,1
2020/1/4 16:02,Sat,15100,gateau chocolat,1
2020/1/6 12:50,Mon,17300,gateau chocolat,1
2020/1/9 13:44,Thur,21900,gateau chocolat,1
2020/1/11 13:11,Sat,15100,gateau chocolat,1
2020/1/12 12:16,Sun,44100,gateau chocolat,2
2020/1/19 11:09,Sun,31100,gateau chocolat,1
2020/1/19 13:17,Sun,24300,gateau chocolat,1
2020/1/19 14:18,Sun,23900,gateau chocolat,1
2020/1/19 14:23,Sun,15100,gateau chocolat,1
2020/1/22 11:50,Wed,18100,gateau chocolat,1
2020/1/22 16:14,Wed,15600,gateau chocolat,1
2020/1/23 11:37,Thur,14100,gateau chocolat,1
2020/1/29 12:23,Wed,14800,gateau chocolat,1
2020/2/1 13:50,Sat,23600,gateau chocolat,1
2020/2/2 17:29,Sun,19600,gateau chocolat,1
2020/2/5 11:56,Wed,27600,gateau chocolat,1
2020/2/5 12:32,Wed,16300,gateau chocolat,1
2020/2/7 12:44,Fri,29300,gateau chocolat,1
2020/2/7 12:56,Fri,17900,gateau chocolat,2
2020/2/12 11:03,Wed,16800,gateau chocolat,1
2020/2/12 17:21,Wed,21300,gateau chocolat,1
2020/2/14 12:58,Fri,23300,gateau chocolat,1
2020/2/17 15:25,Mon,36600,gateau chocolat,1
2020/2/22 14:14,Sat,15400,gateau chocolat,1
2020/2/22 15:00,Sat,24100,gateau chocolat,1
2020/2/23 11:10,Sun,26600,gateau chocolat,1
2020/2/23 11:13,Sun,27200,gateau chocolat,2
2020/2/23 12:27,Sun,23100,gateau chocolat,1
2020/2/23 14:21,Sun,24400,gateau chocolat,1
2020/2/23 16:42,Sun,17600,gateau chocolat,1
2020/2/24 12:09,Mon,17900,gateau chocolat,1
2020/2/24 14:32,Mon,26800,gateau chocolat,1
2020/2/26 11:18,Wed,15600,gateau chocolat,1
2020/2/27 11:26,Thur,20900,gateau chocolat,1
2020/2/27 12:04,Thur,14800,gateau chocolat,1
2020/2/28 16:33,Fri,15600,gateau chocolat,1
2020/2/29 16:31,Sat,23600,gateau chocolat,1
2020/3/1 15:16,Sun,20300,gateau chocolat,1
2020/3/2 17:05,Mon,18800,gateau chocolat,1
2020/3/7 13:53,Sat,28100,gateau chocolat,1
2020/3/12 14:32,Thur,16100,gateau chocolat,1
2020/3/13 12:35,Fri,18800,gateau chocolat,1
2020/3/13 15:49,Fri,15100,gateau chocolat,1
2020/3/14 11:03,Sat,15100,gateau chocolat,1
2020/3/15 11:40,Sun,18600,gateau chocolat,1
2020/3/15 14:15,Sun,19400,gateau chocolat,1
2020/3/18 14:30,Wed,15400,gateau chocolat,1
2020/3/19 11:16,Thur,28200,gateau chocolat,2
2020/3/19 12:25,Thur,23100,gateau chocolat,1
2020/3/19 14:38,Thur,17600,gateau chocolat,1
2020/3/19 14:47,Thur,15100,gateau chocolat,1
2020/3/21 12:11,Sat,20900,gateau chocolat,1
2020/3/21 15:14,Sat,19600,gateau chocolat,1
2020/3/23 13:58,Mon,24200,gateau chocolat,1
2020/3/26 11:04,Thur,15300,gateau chocolat,1
2020/3/26 14:44,Thur,31100,gateau chocolat,1
2020/3/28 15:14,Sat,16600,gateau chocolat,1
2020/3/29 12:02,Sun,29800,gateau chocolat,1
2020/3/29 12:59,Sun,24300,gateau chocolat,1
2020/4/1 13:29,Wed,32100,gateau chocolat,1
2020/4/2 13:12,Thur,23100,gateau chocolat,1
2020/4/2 16:21,Thur,29500,gateau chocolat,1
2020/4/5 13:05,Sun,24600,gateau chocolat,1
2020/4/5 14:56,Sun,14100,gateau chocolat,1
2020/4/6 15:55,Mon,27100,gateau chocolat,1
2020/4/8 17:09,Wed,16400,gateau chocolat,1
2020/4/9 11:05,Thur,18800,gateau chocolat,1
2020/4/9 11:10,Thur,26600,gateau chocolat,1
2020/4/9 16:44,Thur,24100,gateau chocolat,1
2020/4/10 14:55,Fri,14300,gateau chocolat,1
2020/4/10 16:13,Fri,31600,gateau chocolat,1
2020/4/11 15:01,Sat,19300,gateau chocolat,1
2020/4/15 14:22,Wed,14800,gateau chocolat,1
2020/4/15 15:17,Wed,29200,gateau chocolat,1
2020/4/16 11:51,Thur,18800,gateau chocolat,1
2020/4/18 14:12,Sat,30100,gateau chocolat,1
2020/4/20 14:46,Mon,64000,gateau chocolat,2
2020/4/27 15:10,Mon,25800,gateau chocolat,1
2020/4/27 16:00,Mon,18600,gateau chocolat,1
2020/4/30 11:43,Thur,18300,gateau chocolat,1
2019/7/20 12:08,Sat,15800,pandoro,1
2019/7/22 13:44,Mon,14800,pandoro,1
2019/7/25 13:40,Thur,19600,pandoro,1
2019/7/25 13:42,Thur,15300,pandoro,1
2019/7/25 14:12,Thur,16100,pandoro,1
2019/7/25 16:03,Thur,20000,pandoro,1
2019/7/26 11:23,Fri,73200,pandoro,1
2019/7/26 11:31,Fri,22800,pandoro,1
2019/7/26 11:36,Fri,1293000,pandoro,5
2019/7/26 14:56,Fri,16100,pandoro,1
2019/7/27 11:57,Sat,21800,pandoro,1
2019/7/27 12:43,Sat,16400,pandoro,1
2019/7/27 13:50,Sat,14800,pandoro,1
2019/7/28 12:10,Sun,14800,pandoro,1
2019/7/28 13:14,Sun,19500,pandoro,1
2019/7/28 11:14,Mon,15800,pandoro,1
2019/7/29 11:39,Mon,14800,pandoro,1
2019/7/29 13:36,Mon,28000,pandoro,1
2019/7/29 13:53,Mon,28000,pandoro,1
2019/7/31 11:25,Wed,30100,pandoro,1
2019/7/31 13:18,Wed,27300,pandoro,1
2019/7/31 13:29,Wed,16100,pandoro,1
2019/7/31 13:58,Wed,15800,pandoro,1
2019/8/1 11:03,Thur,14500,pandoro,1
2019/8/1 11:25,Thur,16100,pandoro,1
2019/8/1 12:02,Thur,21100,pandoro,1
2019/8/1 12:38,Thur,14500,pandoro,1
2019/8/2 11:06,Fri,18000,pandoro,1
2019/8/4 12:35,Sun,20600,pandoro,1
2019/8/5 11:18,Mon,31400,pandoro,1
2019/8/5 11:59,Mon,22300,pandoro,1
2019/8/5 12:14,Mon,14800,pandoro,1
2019/8/8 11:22,Thur,20300,pandoro,1
2019/8/8 12:56,Thur,16000,pandoro,1
2019/8/8 13:55,Thur,22300,pandoro,1
2019/8/8 14:11,Thur,16100,pandoro,1
2019/8/10 11:02,Sat,15300,pandoro,1
2019/8/10 11:03,Sat,19100,pandoro,1
2019/8/10 11:05,Sat,28600,pandoro,1
2019/8/10 11:27,Sat,36800,pandoro,1
2019/8/10 12:17,Sat,46200,pandoro,2
2019/8/11 11:01,Sun,21800,pandoro,1
2019/8/11 11:08,Sun,22800,pandoro,1
2019/8/11 11:37,Sun,15800,pandoro,1
2019/8/11 12:58,Sun,15800,pandoro,1
2019/8/11 13:14,Sun,19300,pandoro,1
2019/8/11 13:21,Sun,23100,pandoro,1
2019/8/12 12:41,Mon,15800,pandoro,1
2019/8/12 14:08,Mon,32100,pandoro,1
2019/8/14 11:03,Wed,41200,pandoro,1
2019/8/14 11:04,Wed,18300,pandoro,1
2019/8/14 11:16,Wed,65600,pandoro,2
2019/8/16 11:05,Fri,14800,pandoro,1
2019/8/17 11:30,Sat,24300,pandoro,1
2019/8/17 13:02,Sat,19800,pandoro,1
2019/8/18 11:06,Sun,36900,pandoro,2
2019/8/18 11:09,Sun,22800,pandoro,1
2019/8/18 12:04,Sun,20000,pandoro,1
2019/8/18 12:22,Sun,15000,pandoro,1
2019/8/18 12:50,Sun,23800,pandoro,1
2019/8/18 13:29,Sun,14800,pandoro,1
2019/8/19 12:08,Mon,21300,pandoro,1
2019/8/19 12:10,Mon,19300,pandoro,1
2019/8/19 12:21,Mon,15800,pandoro,1
2019/8/19 13:53,Mon,24300,pandoro,1
2019/8/19 14:16,Mon,23800,pandoro,1
2019/8/21 11:04,Wed,18800,pandoro,1
2019/8/21 12:19,Wed,16100,pandoro,1
2019/8/21 12:29,Wed,19300,pandoro,1
2019/8/22 12:12,Thur,15800,pandoro,1
2019/8/22 14:17,Thur,20600,pandoro,1
2019/8/22 15:24,Thur,26000,pandoro,1
2019/8/23 11:53,Fri,57700,pandoro,1
2019/8/24 12:28,Sat,15800,pandoro,1
2019/8/25 12:02,Sun,15800,pandoro,1
2019/8/26 11:16,Mon,17800,pandoro,1
2019/8/26 11:49,Mon,15500,pandoro,1
2019/8/26 14:25,Mon,15300,pandoro,1
2019/8/28 12:24,Wed,18000,pandoro,1
2019/8/28 13:42,Wed,14800,pandoro,1
2019/8/28 14:05,Wed,19300,pandoro,1
2019/8/29 16:45,Thur,24300,pandoro,1
2019/8/29 16:46,Thur,15100,pandoro,1
2019/8/30 14:13,Fri,16000,pandoro,1
2019/9/1 11:05,Sun,23300,pandoro,1
2019/9/1 14:35,Sun,14800,pandoro,1
2019/9/2 12:12,Mon,31400,pandoro,1
2019/9/2 14:30,Mon,24300,pandoro,1
2019/9/2 15:13,Mon,23500,pandoro,2
2019/9/2 15:24,Mon,15000,pandoro,1
2019/9/4 12:58,Wed,17000,pandoro,1
2019/9/6 13:46,Fri,19800,pandoro,1
2019/9/7 11:42,Sat,18800,pandoro,1
2019/9/7 12:05,Sat,18600,pandoro,1
2019/9/9 11:12,Mon,23100,pandoro,1
2019/9/9 13:01,Mon,14800,pandoro,1
2019/9/9 15:42,Mon,21800,pandoro,1
2019/9/11 11:13,Wed,42300,pandoro,1
2019/9/14 11:07,Sat,22800,pandoro,1
2019/9/14 11:15,Sat,19500,pandoro,1
2019/9/14 12:17,Sat,26300,pandoro,1
2019/9/15 11:36,Sun,17000,pandoro,1
2019/9/15 12:06,Sun,15800,pandoro,1
2019/9/15 15:28,Sun,57900,pandoro,1
2019/9/18 14:10,Wed,15300,pandoro,1
2019/9/18 14:44,Wed,15300,pandoro,1
2019/9/19 14:07,Thur,23300,pandoro,1
2019/9/19 16:33,Thur,16000,pandoro,1
2019/9/20 11:06,Fri,39700,pandoro,1
2019/9/21 11:19,Sat,23600,pandoro,1
2019/9/21 12:01,Sat,17000,pandoro,1
2019/9/21 12:08,Sat,15800,pandoro,1
2019/9/21 12:28,Sat,37900,pandoro,1
2019/9/21 13:38,Sat,18800,pandoro,1
2019/9/22 13:01,Sun,20000,pandoro,1
2019/9/28 12:23,Sat,18000,pandoro,1
2019/9/28 16:01,Sat,15300,pandoro,1
2019/9/29 12:13,Sun,23800,pandoro,1
2019/10/2 11:58,Wed,19300,pandoro,1
2019/10/3 12:28,Thur,15800,pandoro,1
2019/10/3 14:25,Thur,22800,pandoro,1
2019/10/3 15:53,Thur,16000,pandoro,1
2019/10/4 14:26,Fri,32900,pandoro,2
2019/10/7 12:24,Mon,17300,pandoro,1
2019/10/11 15:00,Fri,14800,pandoro,1
2019/10/13 13:15,Sun,41100,pandoro,1
2019/10/13 13:48,Sun,21500,pandoro,1
2019/10/14 13:22,Mon,14500,pandoro,1
2019/10/14 15:21,Mon,28500,pandoro,1
2019/10/16 11:09,Wed,22800,pandoro,1
2019/10/16 11:48,Wed,15500,pandoro,1
2019/10/16 14:31,Wed,20300,pandoro,1
2019/10/18 11:43,Fri,51900,pandoro,1
2019/10/19 11:24,Sat,16300,pandoro,1
2019/10/19 15:56,Sat,15800,pandoro,1
2019/10/21 11:58,Mon,47600,pandoro,3
2019/10/24 12:35,Thur,28300,pandoro,1
2019/10/24 14:06,Thur,15800,pandoro,1
2019/10/25 12:33,Fri,15000,pandoro,1
2019/10/25 13:45,Fri,17500,pandoro,1
2019/10/26 12:47,Sat,20600,pandoro,1
2019/10/27 13:20,Sun,15800,pandoro,1
2019/10/28 11:14,Mon,19800,pandoro,1
2019/10/28 11:40,Mon,15800,pandoro,1
2019/10/28 14:30,Mon,14800,pandoro,1
2019/11/1 11:46,Fri,21800,pandoro,1
2019/11/1 12:56,Fri,14800,pandoro,1
2019/11/3 15:06,Sun,14500,pandoro,1
2019/11/6 12:04,Wed,18300,pandoro,1
2019/11/7 13:43,Thur,27900,pandoro,1
2019/11/9 11:36,Sat,19300,pandoro,1
2019/11/9 11:36,Sat,26100,pandoro,1
2019/11/9 11:36,Sat,27300,pandoro,1
2019/11/9 11:36,Sat,18800,pandoro,1
2019/11/10 11:04,Sun,18000,pandoro,2
2019/11/11 11:32,Mon,26600,pandoro,1
2019/11/11 12:00,Mon,18600,pandoro,1
2019/11/13 11:46,Wed,15800,pandoro,1
2019/11/15 13:06,Fri,14800,pandoro,1
2019/11/15 13:44,Fri,18500,pandoro,1
2019/11/15 16:30,Fri,70700,pandoro,4
2019/11/16 13:38,Sat,21100,pandoro,1
2019/11/17 11:07,Sun,22300,pandoro,1
2019/11/17 12:01,Sun,19600,pandoro,1
2019/11/17 14:23,Sun,23500,pandoro,1
2019/11/20 11:08,Wed,28100,pandoro,1
2019/11/22 16:02,Fri,12800,pandoro,1
2019/11/24 13:53,Sun,19300,pandoro,1
2019/11/28 11:48,Thur,38600,pandoro,2
2019/11/29 13:23,Fri,19300,pandoro,1
2019/11/29 13:39,Fri,17300,pandoro,1
2019/11/29 15:30,Fri,14800,pandoro,1
2019/11/30 11:56,Sat,31400,pandoro,1
2019/11/30 13:01,Sat,38200,pandoro,1
2019/11/30 13:44,Sat,25100,pandoro,1
2019/12/1 11:54,Sun,15300,pandoro,1
2019/12/1 13:15,Sun,15800,pandoro,1
2019/12/2 13:06,Mon,20600,pandoro,1
2019/12/4 11:06,Wed,20300,pandoro,2
2019/12/5 11:05,Thur,57700,pandoro,2
2019/12/6 12:26,Fri,16300,pandoro,1
2019/12/8 11:50,Sun,18000,pandoro,1
2019/12/8 13:12,Sun,15800,pandoro,1
2019/12/8 13:22,Sun,15800,pandoro,1
2019/12/8 11:03,Sun,17100,pandoro,1
2019/12/18 15:23,Wed,51200,pandoro,2
2019/12/19 11:45,Thur,35300,pandoro,1
2019/12/22 11:33,Sun,46000,pandoro,1
2019/12/22 14:45,Sun,19000,pandoro,1
2019/12/28 12:09,Sat,22300,pandoro,2
2019/12/28 14:20,Sat,22000,pandoro,2
2019/12/29 13:34,Sun,14800,pandoro,1
2019/12/29 14:32,Sun,15000,pandoro,1
2019/12/30 12:23,Mon,91300,pandoro,2
2020/1/2 11:23,Thur,20300,pandoro,1
2020/1/2 11:33,Thur,42900,pandoro,1
2020/1/3 11:03,Fri,21600,pandoro,1
2020/1/3 11:14,Fri,15500,pandoro,1
2020/1/3 14:05,Fri,17000,pandoro,1
2020/1/3 14:17,Fri,43100,pandoro,2
2020/1/6 12:43,Mon,18300,pandoro,1
2020/1/9 11:12,Thur,35700,pandoro,1
2020/1/9 11:39,Thur,28300,pandoro,1
2020/1/9 15:42,Thur,19600,pandoro,1
2020/1/9 16:00,Thur,14800,pandoro,1
2020/1/9 17:00,Thur,14800,pandoro,1
2020/1/11 14:19,Sat,18300,pandoro,1
2020/1/11 15:42,Sat,15800,pandoro,2
2020/1/12 12:16,Sun,44100,pandoro,1
2020/1/12 12:30,Sun,16000,pandoro,1
2020/1/12 12:42,Sun,18000,pandoro,1
2020/1/13 12:23,Mon,19000,pandoro,2
2020/1/15 11:08,Wed,17300,pandoro,1
2020/1/15 11:28,Wed,116500,pandoro,3
2020/1/15 14:46,Wed,18800,pandoro,1
2020/1/17 12:26,Fri,16300,pandoro,1
2020/1/19 11:09,Sun,31100,pandoro,1
2020/1/19 11:18,Sun,20600,pandoro,1
2020/1/19 12:52,Sun,32100,pandoro,1
2020/1/19 13:17,Sun,24300,pandoro,1
2020/1/20 11:32,Mon,15000,pandoro,1
2020/1/22 14:17,Wed,18500,pandoro,1
2020/1/23 11:08,Thur,77100,pandoro,4
2020/1/23 11:17,Thur,58700,pandoro,1
2020/1/26 15:53,Sun,16800,pandoro,1
2020/1/27 13:29,Mon,26000,pandoro,1
2020/1/27 13:29,Mon,20100,pandoro,1
2020/1/27 13:31,Mon,20600,pandoro,1
2020/1/29 14:07,Wed,15800,pandoro,1
2020/1/31 11:11,Fri,16800,pandoro,1
2020/1/31 11:32,Fri,22500,pandoro,1
2020/2/2 11:34,Sun,15800,pandoro,1
2020/2/2 12:17,Sun,16800,pandoro,1
2020/2/2 14:58,Sun,16100,pandoro,1
2020/2/2 15:37,Sun,15800,pandoro,1
2020/2/2 16:13,Sun,16100,pandoro,1
2020/2/3 12:52,Mon,45500,pandoro,1
2020/2/5 11:48,Wed,34100,pandoro,2
2020/2/5 11:56,Wed,27600,pandoro,1
2020/2/6 13:13,Thur,21300,pandoro,1
2020/2/7 12:48,Fri,15800,pandoro,1
2020/2/7 13:41,Fri,18300,pandoro,1
2020/2/7 15:14,Fri,19300,pandoro,1
2020/2/8 12:24,Sat,22800,pandoro,1
2020/2/8 12:54,Sat,14800,pandoro,1
2020/2/8 13:01,Sat,24300,pandoro,1
2020/2/9 11:03,Sun,30000,pandoro,1
2020/2/9 11:09,Sun,18300,pandoro,1
2020/2/9 11:52,Sun,34300,pandoro,1
2020/2/9 13:47,Sun,16300,pandoro,1
2020/2/12 11:04,Wed,37600,pandoro,1
2020/2/12 12:10,Wed,19300,pandoro,1
2020/2/14 12:44,Fri,27300,pandoro,2
2020/2/14 13:12,Fri,20300,pandoro,1
2020/2/14 14:18,Fri,67000,pandoro,5
2020/2/15 12:31,Sat,16500,pandoro,1
2020/2/15 12:35,Sat,15500,pandoro,1
2020/2/16 12:07,Sun,41800,pandoro,1
2020/2/16 12:41,Sun,14800,pandoro,1
2020/2/20 11:11,Thur,23800,pandoro,1
2020/2/20 13:18,Thur,15800,pandoro,1
2020/2/22 11:09,Sat,28300,pandoro,2
2020/2/22 12:33,Sat,14500,pandoro,1
2020/2/22 13:51,Sat,21500,pandoro,1
2020/2/22 15:00,Sat,24100,pandoro,1
2020/2/23 11:04,Sun,35300,pandoro,1
2020/2/23 11:07,Sun,41300,pandoro,2
2020/2/23 11:32,Sun,24100,pandoro,1
2020/2/23 12:09,Sun,20300,pandoro,1
2020/2/23 12:27,Sun,23100,pandoro,1
2020/2/24 14:32,Mon,26800,pandoro,1
2020/2/26 12:01,Wed,23300,pandoro,1
2020/2/26 13:46,Wed,14500,pandoro,1
2020/2/28 11:13,Fri,20100,pandoro,1
2020/2/29 11:35,Sat,16300,pandoro,1
2020/2/29 12:49,Sat,18500,pandoro,1
2020/2/29 14:25,Sat,15300,pandoro,1
2020/2/29 14:55,Sat,18000,pandoro,1
2020/3/1 11:47,Sun,41800,pandoro,1
2020/3/1 12:19,Sun,20800,pandoro,1
2020/3/1 13:32,Sun,24800,pandoro,1
2020/3/2 12:26,Mon,31400,pandoro,1
2020/3/2 14:35,Mon,19000,pandoro,1
2020/3/5 11:36,Thur,37100,pandoro,1
2020/3/6 14:00,Fri,15800,pandoro,1
2020/3/6 14:34,Fri,18800,pandoro,1
2020/3/7 12:00,Sat,19300,pandoro,1
2020/3/7 12:58,Sat,23000,pandoro,1
2020/3/7 12:59,Sat,18300,pandoro,1
2020/3/7 13:07,Sat,19500,pandoro,1
2020/3/7 13:53,Sat,28100,pandoro,1
2020/3/8 12:13,Sun,15000,pandoro,1
2020/3/9 12:50,Mon,19000,pandoro,2
2020/3/9 13:20,Mon,18800,pandoro,1
2020/3/11 11:10,Wed,28600,pandoro,1
2020/3/11 12:05,Wed,26100,pandoro,1
2020/3/11 13:21,Wed,19000,pandoro,3
2020/3/12 11:20,Thur,34100,pandoro,1
2020/3/14 11:11,Sat,28300,pandoro,2
2020/3/14 11:45,Sat,18000,pandoro,1
2020/3/15 11:40,Sun,18600,pandoro,1
2020/3/15 13:45,Sun,28000,pandoro,1
2020/3/18 13:42,Wed,25700,pandoro,1
2020/3/21 12:34,Sat,14800,pandoro,1
2020/3/21 14:28,Sat,15800,pandoro,1
2020/3/23 12:04,Mon,15500,pandoro,2
2020/3/23 12:37,Mon,34100,pandoro,1
2020/3/25 11:13,Wed,15800,pandoro,1
2020/3/26 14:44,Thur,31100,pandoro,1
2020/3/28 11:14,Sat,19300,pandoro,1
2020/3/28 13:36,Sat,18000,pandoro,1
2020/3/29 13:04,Sun,29600,pandoro,1
2020/3/30 12:07,Mon,19300,pandoro,1
2020/4/1 11:54,Wed,16100,pandoro,1
2020/4/2 12:11,Thur,28800,pandoro,1
2020/4/3 11:24,Fri,24800,pandoro,1
2020/4/3 12:08,Fri,19300,pandoro,1
2020/4/4 13:02,Sat,27800,pandoro,2
2020/4/5 11:18,Sun,19000,pandoro,1
2020/4/5 13:05,Sun,24600,pandoro,1
2020/4/9 14:31,Thur,19500,pandoro,1
2020/4/10 17:14,Fri,15500,pandoro,1
2020/4/11 11:40,Sat,29800,pandoro,2
2020/4/11 12:34,Sat,21000,pandoro,1
2020/4/12 12:08,Sun,24300,pandoro,1
2020/4/12 14:30,Sun,15800,pandoro,1
2020/4/13 14:06,Mon,27000,pandoro,1
2020/4/15 11:20,Wed,19800,pandoro,1
2020/4/16 12:15,Thur,27600,pandoro,1
2020/4/18 11:39,Sat,20800,pandoro,1
2020/4/22 11:53,Wed,18000,pandoro,1
2020/4/22 13:07,Wed,25100,pandoro,2
2020/4/23 15:10,Thur,26000,pandoro,2
2020/4/23 15:14,Thur,19000,pandoro,2
2020/4/24 12:00,Fri,19500,pandoro,1
2020/4/25 11:16,Sat,30800,pandoro,2
2020/4/25 11:16,Sat,31200,pandoro,2
2020/4/25 11:42,Sat,36600,pandoro,1
2020/4/25 13:18,Sat,19300,pandoro,1
2020/4/25 13:30,Sat,28600,pandoro,2
2020/4/26 11:05,Sun,33300,pandoro,1
2020/4/29 12:24,Wed,23500,pandoro,1
2020/4/30 11:18,Thur,31300,pandoro,1
2019/10/26 12:52,Sat,20100,cheese cake,1
2019/10/31 11:05,Thur,55800,cheese cake,1
2019/11/2 11:27,Sat,16800,cheese cake,1
2019/11/2 14:35,Sat,15000,cheese cake,1
2019/11/2 16:40,Sat,28800,cheese cake,1
2019/11/6 11:07,Wed,16000,cheese cake,1
2019/11/6 11:47,Wed,24600,cheese cake,1
2019/11/8 15:12,Fri,30000,cheese cake,1
2019/11/10 11:20,Sun,32800,cheese cake,1
2019/11/10 13:09,Sun,23800,cheese cake,1
2019/11/13 12:29,Wed,15300,cheese cake,1
2019/11/17 11:09,Sun,15800,cheese cake,1
2019/11/17 14:23,Sun,23500,cheese cake,1
2019/11/24 12:21,Sun,20800,cheese cake,1
2019/11/24 12:56,Sun,33700,cheese cake,1
2019/11/25 11:31,Mon,54100,cheese cake,1
2019/11/28 13:15,Thur,25300,cheese cake,1
2019/11/29 15:27,Fri,15000,cheese cake,1
2019/12/1 14:29,Sun,20800,cheese cake,1
2019/12/6 12:23,Fri,15000,cheese cake,1
2019/12/8 12:11,Sun,15300,cheese cake,1
2019/12/12 17:22,Thur,21800,cheese cake,1
2019/12/15 13:41,Sun,15000,cheese cake,1
2019/12/23 11:31,Mon,26100,cheese cake,1
2019/12/23 13:05,Mon,25600,cheese cake,1
2019/12/24 13:14,Tues,19300,cheese cake,1
2019/12/25 14:47,Wed,20000,cheese cake,1
2019/12/26 12:18,Thur,26600,cheese cake,1
2019/12/28 14:20,Sat,22000,cheese cake,2
2019/12/28 14:58,Sat,24300,cheese cake,1
2019/12/28 16:38,Sat,21100,cheese cake,1
2019/12/29 12:52,Sun,23800,cheese cake,1
2019/12/29 13:43,Sun,15800,cheese cake,1
2020/1/4 12:51,Sat,24800,cheese cake,1
2020/1/5 11:23,Sun,18000,cheese cake,1
2020/1/12 17:05,Sun,21300,cheese cake,1
2020/1/15 11:24,Wed,15500,cheese cake,1
2020/1/15 12:19,Wed,16000,cheese cake,1
2020/1/17 14:15,Fri,17800,cheese cake,1
2020/1/18 14:36,Sat,16500,cheese cake,1
2020/1/19 13:17,Sun,24300,cheese cake,1
2020/1/20 11:25,Mon,23800,cheese cake,1
2020/1/22 16:14,Wed,15600,cheese cake,1
2020/1/24 11:37,Fri,23800,cheese cake,1
2020/1/26 12:36,Sun,28100,cheese cake,1
2020/1/27 12:57,Mon,20300,cheese cake,1
2020/1/27 13:29,Mon,26000,cheese cake,1
2020/1/30 12:15,Thur,34300,cheese cake,1
2020/1/31 11:21,Fri,19800,cheese cake,1
2020/1/31 16:45,Fri,15000,cheese cake,1
2020/2/5 12:07,Wed,21600,cheese cake,1
2020/2/5 15:58,Wed,17300,cheese cake,1
2020/2/6 13:31,Thur,18800,cheese cake,1
2020/2/7 11:14,Fri,16300,cheese cake,1
2020/2/7 12:44,Fri,29300,cheese cake,1
2020/2/8 13:01,Sat,24300,cheese cake,1
2020/2/9 16:07,Sun,16300,cheese cake,1
2020/2/21 13:32,Fri,18500,cheese cake,1
2020/2/22 11:03,Sat,14300,cheese cake,1
2020/2/23 12:49,Sun,32000,cheese cake,2
2020/2/26 11:18,Wed,15600,cheese cake,1
2020/2/26 13:08,Wed,15300,cheese cake,1
2020/2/27 11:15,Thur,23300,cheese cake,1
2020/2/27 12:20,Thur,19800,cheese cake,1
2020/2/28 11:02,Fri,33800,cheese cake,1
2020/2/28 16:33,Fri,15600,cheese cake,1
2020/2/29 16:31,Sat,23600,cheese cake,1
2020/3/1 14:17,Sun,20800,cheese cake,1
2020/3/1 14:27,Sun,27300,cheese cake,1
2020/3/2 16:40,Mon,16300,cheese cake,1
2020/3/2 17:05,Mon,18800,cheese cake,1
2020/3/6 12:21,Fri,16300,cheese cake,1
2020/3/6 14:05,Fri,16300,cheese cake,1
2020/3/8 11:38,Sun,16800,cheese cake,1
2020/3/8 12:13,Sun,15000,cheese cake,1
2020/3/8 13:48,Sun,18500,cheese cake,1
2020/3/13 12:35,Fri,18800,cheese cake,1
2020/3/25 16:17,Wed,20300,cheese cake,1
2020/3/27 13:00,Fri,19500,cheese cake,1
2020/3/28 15:14,Sat,16600,cheese cake,1
2020/4/4 13:02,Sat,27800,cheese cake,1
2020/4/6 11:24,Mon,19800,cheese cake,1
2020/4/8 11:22,Wed,16300,cheese cake,1
2020/4/9 11:05,Thur,18800,cheese cake,1
2020/4/11 15:01,Sat,19300,cheese cake,1
2020/4/12 15:24,Sun,21600,cheese cake,1
2020/4/13 14:06,Mon,27000,cheese cake,1
2020/4/18 11:22,Sat,16300,cheese cake,1
2020/5/2 11:37,Sat,19500,cheese cake,1
2020/5/2 13:45,Sat,15000,cheese cake,1
2019/7/15 16:21,Mon,15800,lemon ade,1
2019/7/26 13:24,Fri,28100,lemon ade,1
2019/7/26 14:52,Fri,22100,lemon ade,1
2019/7/27 12:20,Sat,22800,lemon ade,1
2019/7/27 14:05,Sat,32600,lemon ade,1
2019/8/5 12:49,Mon,49300,lemon ade,1
2019/8/14 11:25,Wed,27300,lemon ade,1
2019/8/21 12:29,Wed,19300,lemon ade,1
2019/8/21 13:26,Wed,15600,lemon ade,1
2019/8/30 15:25,Fri,28300,lemon ade,1
2019/9/8 11:37,Sun,26000,lemon ade,1
2019/10/3 14:34,Thur,14800,lemon ade,1
2019/10/6 13:51,Sun,19300,lemon ade,1
2019/10/13 14:42,Sun,22800,lemon ade,1
2019/10/19 12:49,Sat,14800,lemon ade,1
2019/11/8 13:12,Fri,36000,lemon ade,2
2019/11/11 12:59,Mon,15300,lemon ade,1
2019/11/16 12:21,Sat,18500,lemon ade,1
2019/11/23 15:23,Sat,14800,lemon ade,1
2019/11/29 16:12,Fri,28100,lemon ade,1
2019/12/18 13:51,Wed,19600,lemon ade,1
2020/1/4 11:03,Sat,23800,lemon ade,1
2020/1/11 15:10,Sat,15800,lemon ade,1
2020/1/30 14:26,Thur,23300,lemon ade,1
2020/2/7 12:44,Fri,29300,lemon ade,1
2020/2/15 13:38,Sat,17300,lemon ade,1
2020/2/15 14:03,Sat,32100,lemon ade,1
2020/2/20 15:41,Thur,25400,lemon ade,1
2020/3/2 17:05,Mon,18800,lemon ade,1
2020/3/6 12:27,Fri,18300,lemon ade,1
2020/3/8 12:28,Sun,32800,lemon ade,1
2020/3/28 11:09,Sat,26300,lemon ade,1
2020/4/1 13:44,Wed,22800,lemon ade,1
2020/4/8 11:53,Wed,28800,lemon ade,3
2020/4/18 11:22,Sat,16300,lemon ade,1
2019/7/11 16:10,Thur,15800,orange pound,1
2019/7/13 15:08,Sat,15800,orange pound,1
2019/7/14 11:59,Sun,19800,orange pound,1
2019/7/14 12:59,Sun,18300,orange pound,1
2019/7/14 14:06,Sun,23600,orange pound,1
2019/7/14 14:51,Sun,25600,orange pound,1
2019/7/14 15:02,Sun,19800,orange pound,1
2019/7/17 14:16,Wed,23400,orange pound,1
2019/7/19 12:11,Fri,15800,orange pound,1
2019/7/19 12:44,Fri,20600,orange pound,1
2019/7/20 11:19,Sat,15800,orange pound,1
2019/7/20 12:13,Sat,26300,orange pound,1
2019/7/20 12:55,Sat,15800,orange pound,1
2019/7/21 12:12,Sun,17800,orange pound,1
2019/7/21 12:29,Sun,16100,orange pound,1
2019/7/21 12:47,Sun,21000,orange pound,1
2019/7/22 12:16,Mon,19300,orange pound,1
2019/7/22 12:24,Mon,18300,orange pound,1
2019/7/24 11:56,Wed,27100,orange pound,1
2019/7/25 16:03,Thur,20000,orange pound,1
2019/7/26 11:26,Fri,25300,orange pound,1
2019/7/26 11:23,Fri,73200,orange pound,1
2019/7/26 11:31,Fri,22800,orange pound,1
2019/7/26 11:37,Fri,15000,orange pound,1
2019/7/26 13:24,Fri,28100,orange pound,1
2019/7/26 14:24,Fri,35000,orange pound,2
2019/7/27 14:05,Sat,32600,orange pound,1
2019/7/28 11:17,Sun,17300,orange pound,1
2019/7/29 11:12,Mon,24100,orange pound,1
2019/7/29 12:02,Mon,14800,orange pound,1
2019/7/29 12:15,Mon,18300,orange pound,1
2019/7/29 12:22,Mon,27900,orange pound,1
2019/7/29 12:54,Mon,15800,orange pound,1
2019/8/1 11:50,Thur,14800,orange pound,1
2019/8/1 12:15,Thur,20600,orange pound,1
2019/8/2 11:06,Fri,18000,orange pound,1
2019/8/2 12:31,Fri,19900,orange pound,1
2019/8/3 11:05,Sat,29100,orange pound,1
2019/8/3 12:44,Sat,19300,orange pound,1
2019/8/3 13:20,Sat,16300,orange pound,1
2019/8/4 11:04,Sun,31600,orange pound,1
2019/8/4 11:52,Sun,22100,orange pound,1
2019/8/4 12:27,Sun,14800,orange pound,1
2019/8/4 12:35,Sun,20600,orange pound,1
2019/8/5 11:16,Mon,23100,orange pound,1
2019/8/7 12:28,Wed,16100,orange pound,1
2019/8/7 14:05,Wed,15000,orange pound,1
2019/8/8 11:22,Thur,20300,orange pound,2
2019/8/8 13:57,Thur,32400,orange pound,2
2019/8/8 14:52,Thur,17000,orange pound,1
2019/8/9 11:34,Fri,17000,orange pound,1
2019/8/10 11:05,Sat,28600,orange pound,1
2019/8/10 12:17,Sat,46200,orange pound,1
2019/8/11 11:03,Sun,16000,orange pound,1
2019/8/11 11:08,Sun,22800,orange pound,1
2019/8/11 11:58,Sun,27900,orange pound,1
2019/8/12 12:41,Mon,15800,orange pound,1
2019/8/15 11:49,Thur,15100,orange pound,1
2019/8/15 11:53,Thur,15000,orange pound,1
2019/8/16 13:27,Fri,15800,orange pound,1
2019/8/17 11:30,Sat,24300,orange pound,1
2019/8/17 14:07,Sat,19000,orange pound,1
2019/8/18 11:09,Sun,26600,orange pound,1
2019/8/18 11:23,Sun,17800,orange pound,1
2019/8/18 12:04,Sun,20000,orange pound,1
2019/8/18 12:50,Sun,23800,orange pound,1
2019/8/18 14:39,Sun,23000,orange pound,1
2019/8/19 12:08,Mon,21300,orange pound,1
2019/8/19 12:10,Mon,19300,orange pound,1
2019/8/19 12:21,Mon,15800,orange pound,1
2019/8/19 14:16,Mon,23800,orange pound,1
2019/8/19 15:30,Mon,18800,orange pound,1
2019/8/21 12:13,Wed,18300,orange pound,1
2019/8/21 14:11,Wed,25000,orange pound,1
2019/8/21 14:38,Wed,23000,orange pound,1
2019/8/22 13:07,Thur,26600,orange pound,1
2019/8/22 15:24,Thur,26000,orange pound,1
2019/8/23 11:53,Fri,57700,orange pound,1
2019/8/23 12:47,Fri,19800,orange pound,1
2019/8/24 11:09,Sat,20100,orange pound,1
2019/8/24 12:28,Sat,15800,orange pound,1
2019/8/26 16:11,Mon,22800,orange pound,1
2019/8/29 14:31,Thur,15500,orange pound,1
2019/8/29 16:15,Thur,19000,orange pound,1
2019/8/30 11:18,Fri,39300,orange pound,1
2019/8/30 11:36,Fri,20600,orange pound,2
2019/8/30 15:00,Fri,23100,orange pound,1
2019/9/1 11:22,Sun,14800,orange pound,1
2019/9/1 12:39,Sun,28300,orange pound,2
2019/9/1 13:56,Sun,14800,orange pound,1
2019/9/1 15:04,Sun,16100,orange pound,1
2019/9/2 12:12,Mon,31400,orange pound,1
2019/9/4 11:49,Wed,23000,orange pound,1
2019/9/4 14:52,Wed,25600,orange pound,1
2019/9/5 11:27,Thur,21800,orange pound,1
2019/9/5 12:12,Thur,19600,orange pound,1
2019/9/6 16:29,Fri,39700,orange pound,1
2019/9/7 11:06,Sat,18600,orange pound,2
2019/9/7 11:18,Sat,14100,orange pound,1
2019/9/7 12:00,Sat,15300,orange pound,1
2019/9/7 15:22,Sat,26300,orange pound,1
2019/9/11 13:21,Wed,33400,orange pound,1
2019/9/11 14:22,Wed,15300,orange pound,1
2019/9/11 14:57,Wed,24600,orange pound,1
2019/9/12 13:51,Thur,27600,orange pound,1
2019/9/14 11:18,Sat,22300,orange pound,1
2019/9/14 12:17,Sat,26300,orange pound,1
2019/9/15 12:06,Sun,15800,orange pound,1
2019/9/15 12:13,Sun,32600,orange pound,1
2019/9/15 13:08,Sun,16100,orange pound,1
2019/9/15 15:28,Sun,57900,orange pound,1
2019/9/18 12:42,Wed,17500,orange pound,1
2019/9/19 12:23,Thur,20000,orange pound,1
2019/9/19 13:24,Thur,15300,orange pound,1
2019/9/19 16:27,Thur,34600,orange pound,1
2019/9/20 16:08,Fri,18000,orange pound,2
2019/9/21 11:08,Sat,39300,orange pound,1
2019/9/21 12:08,Sat,15800,orange pound,1
2019/9/21 12:28,Sat,37900,orange pound,1
2019/9/21 14:15,Sat,19300,orange pound,1
2019/9/22 13:01,Sun,20000,orange pound,1
2019/9/23 13:41,Mon,24600,orange pound,1
2019/9/23 16:13,Mon,22300,orange pound,1
2019/9/25 13:12,Wed,49700,orange pound,1
2019/9/26 14:23,Thur,24800,orange pound,2
2019/9/27 13:07,Fri,15800,orange pound,1
2019/9/28 14:07,Sat,25800,orange pound,1
2019/9/28 16:12,Sat,15800,orange pound,1
2019/9/29 12:00,Sun,14800,orange pound,1
2019/9/29 14:02,Sun,29900,orange pound,2
2019/9/29 15:05,Sun,19600,orange pound,1
2019/9/30 12:47,Mon,17300,orange pound,1
2019/9/30 13:43,Mon,27600,orange pound,1
2019/10/2 15:57,Wed,24500,orange pound,2
2019/10/3 12:17,Thur,28300,orange pound,1
2019/10/3 14:44,Thur,19300,orange pound,1
2019/10/5 12:39,Sat,31800,orange pound,1
2019/10/5 15:00,Sat,15500,orange pound,1
2019/10/5 11:03,Sat,20900,orange pound,1
2019/10/6 11:25,Sun,21300,orange pound,1
2019/10/6 11:58,Sun,18300,orange pound,1
2019/10/7 11:12,Mon,19800,orange pound,1
2019/10/11 14:09,Fri,20800,orange pound,1
2019/10/11 14:29,Fri,15500,orange pound,1
2019/10/11 15:00,Fri,14800,orange pound,1
2019/10/13 11:30,Sun,15000,orange pound,1
2019/10/13 13:07,Sun,17300,orange pound,1
2019/10/13 13:15,Sun,41100,orange pound,2
2019/10/13 14:42,Sun,22800,orange pound,1
2019/10/13 14:54,Sun,27600,orange pound,1
2019/10/14 11:08,Mon,26000,orange pound,1
2019/10/14 11:40,Mon,14800,orange pound,1
2019/10/16 11:12,Wed,28900,orange pound,1
2019/10/16 13:03,Wed,23300,orange pound,1
2019/10/20 14:24,Sun,16100,orange pound,1
2019/10/21 11:34,Mon,22800,orange pound,1
2019/10/21 11:27,Mon,17300,orange pound,1
2019/10/21 13:28,Mon,14800,orange pound,1
2019/10/24 11:18,Thur,18800,orange pound,1
2019/10/24 11:53,Thur,21800,orange pound,1
2019/10/24 16:35,Thur,15300,orange pound,1
2019/10/25 11:15,Fri,18300,orange pound,2
2019/10/25 11:16,Fri,27300,orange pound,1
2019/10/27 11:51,Sun,19800,orange pound,1
2019/10/27 11:57,Sun,22300,orange pound,1
2019/10/27 13:20,Sun,15800,orange pound,1
2019/10/28 11:17,Mon,14800,orange pound,1
2019/10/28 12:15,Mon,18300,orange pound,1
2019/10/28 14:20,Mon,34600,orange pound,2
2019/10/31 11:05,Thur,55800,orange pound,1
2019/10/31 12:18,Thur,14800,orange pound,1
2019/10/31 13:29,Thur,25000,orange pound,1
2019/11/2 16:40,Sat,28800,orange pound,1
2019/11/3 11:04,Sun,23100,orange pound,1
2019/11/3 11:16,Sun,19800,orange pound,1
2019/11/3 12:58,Sun,16100,orange pound,1
2019/11/4 11:53,Mon,15000,orange pound,1
2019/11/4 13:17,Mon,17500,orange pound,1
2019/11/6 16:53,Wed,16000,orange pound,1
2019/11/7 12:31,Thur,14800,orange pound,1
2019/11/7 13:43,Thur,27900,orange pound,1
2019/11/7 14:44,Thur,26800,orange pound,1
2019/11/8 11:36,Fri,22800,orange pound,1
2019/11/8 13:12,Fri,36000,orange pound,2
2019/11/8 15:02,Fri,27800,orange pound,1
2019/11/9 11:36,Sat,18300,orange pound,1
2019/11/9 11:36,Sat,27300,orange pound,1
2019/11/9 14:06,Sat,15800,orange pound,1
2019/11/9 16:23,Sat,14800,orange pound,1
2019/11/10 11:27,Sun,17000,orange pound,2
2019/11/10 11:29,Sun,19600,orange pound,1
2019/11/10 12:45,Sun,14800,orange pound,1
2019/11/10 13:10,Sun,19800,orange pound,1
2019/11/11 17:25,Mon,28300,orange pound,1
2019/11/13 14:45,Wed,14800,orange pound,1
2019/11/14 13:10,Thur,39300,orange pound,1
2019/11/15 11:50,Fri,18500,orange pound,1
2019/11/17 11:06,Sun,26300,orange pound,1
2019/11/17 11:07,Sun,23800,orange pound,1
2019/11/18 11:11,Mon,18000,orange pound,1
2019/11/20 12:46,Wed,17300,orange pound,1
2019/11/20 13:24,Wed,23800,orange pound,1
2019/11/20 15:52,Wed,15000,orange pound,1
2019/11/22 12:25,Fri,21000,orange pound,1
2019/11/23 15:54,Sat,19500,orange pound,1
2019/11/24 11:29,Sun,19800,orange pound,1
2019/11/24 12:21,Sun,20800,orange pound,2
2019/11/24 13:13,Sun,14800,orange pound,1
2019/11/24 13:34,Sun,39000,orange pound,1
2019/11/24 13:44,Sun,20300,orange pound,1
2019/11/24 16:32,Sun,19500,orange pound,1
2019/11/25 12:54,Mon,26300,orange pound,1
2019/11/25 14:00,Mon,14800,orange pound,1
2019/11/27 12:02,Wed,33400,orange pound,2
2019/11/27 12:59,Wed,15800,orange pound,1
2019/11/28 11:48,Thur,38600,orange pound,2
2019/11/30 17:04,Sat,27600,orange pound,1
2019/12/1 11:29,Sun,14800,orange pound,1
2019/12/1 12:55,Sun,19000,orange pound,1
2019/12/1 13:28,Sun,20300,orange pound,1
2019/12/2 13:06,Mon,20600,orange pound,1
2019/12/4 11:10,Wed,23300,orange pound,1
2019/12/4 13:30,Wed,19600,orange pound,1
2019/12/4 13:34,Wed,16000,orange pound,1
2019/12/4 13:51,Wed,15300,orange pound,1
2019/12/5 15:22,Thur,15800,orange pound,1
2019/12/6 12:51,Fri,16300,orange pound,1
2019/12/6 15:25,Fri,13800,orange pound,1
2019/12/7 12:02,Sat,14800,orange pound,1
2019/12/7 13:39,Sat,30800,orange pound,1
2019/12/7 13:50,Sat,14500,orange pound,1
2019/12/7 13:55,Sat,28600,orange pound,1
2019/12/8 11:11,Sun,27600,orange pound,2
2019/12/8 11:22,Sun,20500,orange pound,1
2019/12/8 12:33,Sun,23000,orange pound,1
2019/12/8 13:57,Sun,17000,orange pound,1
2019/12/8 14:08,Sun,19800,orange pound,1
2019/12/9 13:35,Mon,29800,orange pound,1
2019/12/11 12:09,Wed,21500,orange pound,1
2019/12/11 13:32,Wed,21500,orange pound,1
2019/12/11 14:26,Wed,32000,orange pound,2
2019/12/12 12:57,Thur,23300,orange pound,1
2019/12/15 13:41,Sun,15000,orange pound,1
2019/12/16 13:21,Mon,16800,orange pound,1
2019/12/16 14:31,Mon,23600,orange pound,1
2019/12/16 14:32,Mon,19500,orange pound,1
2019/12/18 11:22,Wed,52800,orange pound,1
2019/12/18 15:23,Wed,51200,orange pound,2
2019/12/19 11:45,Thur,35300,orange pound,1
2019/12/20 11:18,Fri,16800,orange pound,1
2019/12/20 14:29,Fri,19300,orange pound,1
2019/12/20 16:43,Fri,31100,orange pound,1
2019/12/21 11:52,Sat,14800,orange pound,1
2019/12/21 12:02,Sat,19800,orange pound,1
2019/12/21 14:28,Sat,18500,orange pound,1
2019/12/21 14:43,Sat,30900,orange pound,1
2019/12/22 11:33,Sun,46000,orange pound,1
2019/12/22 11:38,Sun,19300,orange pound,1
2019/12/22 14:17,Sun,20300,orange pound,1
2019/12/22 14:45,Sun,19000,orange pound,1
2019/12/23 13:37,Mon,27300,orange pound,1
2019/12/23 15:03,Mon,14000,orange pound,1
2019/12/25 11:29,Wed,24100,orange pound,1
2019/12/26 12:16,Thur,20500,orange pound,1
2019/12/26 15:18,Thur,15300,orange pound,1
2019/12/27 12:45,Fri,15800,orange pound,1
2019/12/28 12:04,Sat,17000,orange pound,1
2019/12/28 13:12,Sat,18800,orange pound,1
2019/12/29 12:11,Sun,15300,orange pound,1
2019/12/29 13:03,Sun,19800,orange pound,1
2019/12/29 16:02,Sun,25500,orange pound,1
2019/12/30 11:27,Mon,19800,orange pound,1
2019/12/30 14:35,Mon,53900,orange pound,2
2019/12/30 15:22,Mon,26100,orange pound,1
2020/1/2 11:23,Thur,20300,orange pound,1
2020/1/2 11:33,Thur,42900,orange pound,1
2020/1/2 12:50,Thur,29300,orange pound,1
2020/1/3 11:14,Fri,15500,orange pound,1
2020/1/3 11:17,Fri,20300,orange pound,1
2020/1/3 14:17,Fri,43100,orange pound,1
2020/1/3 14:18,Fri,18000,orange pound,1
2020/1/3 15:41,Fri,16100,orange pound,1
2020/1/3 16:25,Fri,15100,orange pound,1
2020/1/3 17:23,Fri,20600,orange pound,2
2020/1/4 12:51,Sat,24800,orange pound,1
2020/1/4 17:23,Sat,16500,orange pound,1
2020/1/5 11:03,Sun,16800,orange pound,1
2020/1/5 13:49,Sun,20300,orange pound,1
2020/1/5 14:06,Sun,23800,orange pound,1
2020/1/5 14:46,Sun,18300,orange pound,1
2020/1/5 16:54,Sun,15300,orange pound,1
2020/1/5 17:25,Sun,19600,orange pound,1
2020/1/6 12:30,Mon,30800,orange pound,1
2020/1/8 13:15,Wed,41400,orange pound,2
2020/1/8 16:33,Wed,26900,orange pound,1
2020/1/9 11:39,Thur,28300,orange pound,1
2020/1/9 12:27,Thur,28800,orange pound,1
2020/1/9 13:59,Thur,19800,orange pound,1
2020/1/9 15:22,Thur,23300,orange pound,1
2020/1/10 14:48,Fri,19300,orange pound,2
2020/1/11 15:10,Sat,15800,orange pound,1
2020/1/12 14:19,Sun,24400,orange pound,1
2020/1/12 16:05,Sun,14500,orange pound,1
2020/1/15 13:22,Wed,26300,orange pound,1
2020/1/17 11:46,Fri,14800,orange pound,1
2020/1/17 14:17,Fri,15300,orange pound,1
2020/1/19 11:05,Sun,19300,orange pound,1
2020/1/19 16:52,Sun,17800,orange pound,1
2020/1/20 12:46,Mon,14800,orange pound,1
2020/1/20 13:59,Mon,19300,orange pound,1
2020/1/22 16:08,Wed,14800,orange pound,1
2020/1/23 11:17,Thur,58700,orange pound,1
2020/1/23 15:53,Thur,14800,orange pound,1
2020/1/26 12:30,Sun,14800,orange pound,1
2020/1/27 12:17,Mon,27600,orange pound,1
2020/1/29 12:23,Wed,14800,orange pound,1
2020/1/30 11:54,Thur,42900,orange pound,2
2020/1/31 12:36,Fri,29900,orange pound,2
2020/1/31 13:39,Fri,15000,orange pound,1
2020/1/31 14:15,Fri,16800,orange pound,1
2020/1/31 16:45,Fri,15000,orange pound,1
2020/2/1 15:40,Sat,32400,orange pound,2
2020/2/2 11:05,Sun,19300,orange pound,1
2020/2/2 11:49,Sun,30800,orange pound,1
2020/2/2 13:31,Sun,14500,orange pound,1
2020/2/2 13:33,Sun,19300,orange pound,1
2020/2/2 15:37,Sun,15800,orange pound,1
2020/2/2 17:29,Sun,19600,orange pound,1
2020/2/3 14:26,Mon,16300,orange pound,1
2020/2/5 11:48,Wed,34100,orange pound,1
2020/2/5 15:58,Wed,17300,orange pound,1
2020/2/6 11:05,Thur,14500,orange pound,1
2020/2/6 11:16,Thur,20900,orange pound,1
2020/2/6 13:13,Thur,21300,orange pound,1
2020/2/6 14:58,Thur,20300,orange pound,1
2020/2/7 11:14,Fri,16300,orange pound,1
2020/2/7 12:39,Fri,33300,orange pound,1
2020/2/7 15:40,Fri,26300,orange pound,1
2020/2/7 16:41,Fri,21800,orange pound,1
2020/2/8 11:57,Sat,14800,orange pound,1
2020/2/8 13:01,Sat,24300,orange pound,1
2020/2/8 13:14,Sat,25600,orange pound,1
2020/2/8 15:24,Sat,20800,orange pound,1
2020/2/9 11:03,Sun,19300,orange pound,1
2020/2/9 14:34,Sun,14000,orange pound,1
2020/2/9 15:15,Sun,18500,orange pound,1
2020/2/9 16:07,Sun,16300,orange pound,1
2020/2/10 11:31,Mon,15300,orange pound,1
2020/2/10 11:41,Mon,19300,orange pound,1
2020/2/12 12:48,Wed,53600,orange pound,1
2020/2/12 16:21,Wed,22500,orange pound,1
2020/2/12 17:21,Wed,21300,orange pound,1
2020/2/13 15:22,Thur,31300,orange pound,1
2020/2/14 12:58,Fri,23300,orange pound,1
2020/2/14 13:12,Fri,20300,orange pound,1
2020/2/14 13:46,Fri,57500,orange pound,4
2020/2/15 11:07,Sat,25000,orange pound,1
2020/2/15 12:50,Sat,17500,orange pound,1
2020/2/15 12:55,Sat,20500,orange pound,1
2020/2/16 12:07,Sun,41800,orange pound,1
2020/2/16 14:46,Sun,16100,orange pound,1
2020/2/17 14:29,Mon,20300,orange pound,1
2020/2/19 11:34,Wed,14500,orange pound,1
2020/2/19 13:03,Wed,17100,orange pound,1
2020/2/19 22:13,Wed,15800,orange pound,1
2020/2/19 14:42,Wed,23000,orange pound,1
2020/2/20 11:11,Thur,23800,orange pound,1
2020/2/21 11:14,Fri,15300,orange pound,1
2020/2/21 13:20,Fri,20000,orange pound,1
2020/2/21 14:41,Fri,15800,orange pound,1
2020/2/22 13:10,Sat,22000,orange pound,1
2020/2/22 15:00,Sat,24100,orange pound,2
2020/2/22 17:20,Sat,15300,orange pound,1
2020/2/23 11:07,Sun,41300,orange pound,1
2020/2/23 11:47,Sun,23500,orange pound,1
2020/2/23 11:52,Sun,25500,orange pound,1
2020/2/23 12:27,Sun,23100,orange pound,1
2020/2/23 12:42,Sun,24300,orange pound,1
2020/2/23 15:07,Sun,15800,orange pound,1
2020/2/23 16:00,Sun,26600,orange pound,1
2020/2/23 16:29,Sun,30100,orange pound,1
2020/2/23 16:42,Sun,17600,orange pound,1
2020/2/24 12:26,Mon,29900,orange pound,1
2020/2/24 15:55,Mon,19300,orange pound,1
2020/2/26 11:07,Wed,15800,orange pound,2
2020/2/26 11:12,Wed,31600,orange pound,1
2020/2/26 11:20,Wed,18300,orange pound,1
2020/2/26 12:34,Wed,22000,orange pound,1
2020/2/26 12:49,Wed,14500,orange pound,1
2020/2/26 13:28,Wed,15800,orange pound,1
2020/2/27 11:23,Thur,23800,orange pound,1
2020/2/27 11:25,Thur,23100,orange pound,1
2020/2/27 14:22,Thur,22000,orange pound,1
2020/2/27 15:47,Thur,19600,orange pound,1
2020/2/28 12:28,Fri,51100,orange pound,2
2020/2/28 13:36,Fri,16100,orange pound,1
2020/2/28 16:58,Fri,20600,orange pound,2
2020/2/29 11:03,Sat,20600,orange pound,1
2020/2/29 11:14,Sat,16100,orange pound,1
2020/3/1 11:06,Sun,34100,orange pound,2
2020/3/1 11:26,Sun,14000,orange pound,1
2020/3/1 11:47,Sun,41800,orange pound,1
2020/3/1 12:13,Sun,14800,orange pound,1
2020/3/1 13:10,Sun,33400,orange pound,2
2020/3/1 13:32,Sun,24800,orange pound,1
2020/3/1 14:19,Sun,23500,orange pound,1
2020/3/1 15:16,Sun,20300,orange pound,1
2020/3/2 12:51,Mon,27800,orange pound,1
2020/3/2 13:00,Mon,15800,orange pound,1
2020/3/2 16:40,Mon,16300,orange pound,1
2020/3/5 13:36,Thur,25700,orange pound,1
2020/3/5 14:49,Thur,20800,orange pound,1
2020/3/5 15:29,Thur,15300,orange pound,1
2020/3/5 15:56,Thur,20600,orange pound,2
2020/3/6 12:02,Fri,16800,orange pound,1
2020/3/6 13:24,Fri,21100,orange pound,1
2020/3/7 11:16,Sat,14800,orange pound,1
2020/3/7 13:17,Sat,15500,orange pound,1
2020/3/8 13:26,Sun,20300,orange pound,1
2020/3/8 14:07,Sun,22300,orange pound,1
2020/3/8 15:35,Sun,18300,orange pound,1
2020/3/9 12:16,Mon,20500,orange pound,2
2020/3/12 11:20,Thur,34100,orange pound,1
2020/3/12 11:31,Thur,18000,orange pound,1
2020/3/12 11:42,Thur,27800,orange pound,1
2020/3/12 13:56,Thur,47000,orange pound,1
2020/3/12 15:17,Thur,22800,orange pound,1
2020/3/13 11:46,Fri,23800,orange pound,1
2020/3/13 12:37,Fri,25100,orange pound,1
2020/3/13 13:43,Fri,15300,orange pound,1
2020/3/13 14:37,Fri,22800,orange pound,1
2020/3/13 15:58,Fri,19600,orange pound,1
2020/3/13 16:25,Fri,17100,orange pound,1
2020/3/14 13:05,Sat,14500,orange pound,1
2020/3/14 14:36,Sat,16100,orange pound,1
2020/3/14 14:47,Sat,15800,orange pound,2
2020/3/15 11:13,Sun,19300,orange pound,1
2020/3/18 11:32,Wed,20100,orange pound,1
2020/3/18 12:08,Wed,14000,orange pound,1
2020/3/18 12:40,Wed,42400,orange pound,1
2020/3/18 12:53,Wed,20600,orange pound,2
2020/3/18 14:06,Wed,27900,orange pound,1
2020/3/19 11:16,Thur,28200,orange pound,2
2020/3/19 12:25,Thur,23100,orange pound,1
2020/3/19 14:47,Thur,15100,orange pound,1
2020/3/20 12:33,Fri,16100,orange pound,1
2020/3/20 12:34,Fri,17000,orange pound,1
2020/3/20 14:19,Fri,14800,orange pound,1
2020/3/20 15:40,Fri,14000,orange pound,1
2020/3/21 11:04,Sat,27800,orange pound,1
2020/3/21 11:33,Sat,20000,orange pound,1
2020/3/21 11:44,Sat,27600,orange pound,1
2020/3/21 13:32,Sat,19300,orange pound,1
2020/3/21 15:14,Sat,19600,orange pound,1
2020/3/23 11:06,Mon,14500,orange pound,1
2020/3/25 11:13,Wed,15800,orange pound,1
2020/3/25 14:38,Wed,14000,orange pound,1
2020/3/25 14:57,Wed,14500,orange pound,1
2020/3/25 16:17,Wed,20300,orange pound,1
2020/3/26 15:07,Thur,15800,orange pound,1
2020/3/28 13:36,Sat,18000,orange pound,1
2020/3/29 12:31,Sun,19300,orange pound,1
2020/3/29 12:59,Sun,24300,orange pound,1
2020/3/30 11:22,Mon,17300,orange pound,1
2020/3/30 13:38,Mon,14500,orange pound,1
2020/3/30 14:08,Mon,32400,orange pound,1
2020/4/1 11:15,Wed,29400,orange pound,2
2020/4/1 13:29,Wed,32100,orange pound,1
2020/4/1 14:28,Wed,18800,orange pound,1
2020/4/2 12:38,Thur,18000,orange pound,1
2020/4/2 13:12,Thur,15800,orange pound,1
2020/4/2 13:12,Thur,23100,orange pound,1
2020/4/3 13:29,Fri,44500,orange pound,2
2020/4/4 12:36,Sat,14800,orange pound,1
2020/4/4 14:07,Sat,19600,orange pound,1
2020/4/5 16:03,Sun,15000,orange pound,1
2020/4/6 14:41,Mon,14500,orange pound,1
2020/4/8 12:01,Wed,30300,orange pound,1
2020/4/9 11:05,Thur,18800,orange pound,1
2020/4/9 16:44,Thur,24100,orange pound,1
2020/4/10 14:55,Fri,14300,orange pound,1
2020/4/10 16:13,Fri,31600,orange pound,1
2020/4/11 12:34,Sat,21000,orange pound,1
2020/4/12 11:52,Sun,36900,orange pound,1
2020/4/12 12:35,Sun,18300,orange pound,1
2020/4/15 13:19,Wed,34000,orange pound,1
2020/4/15 15:01,Wed,16000,orange pound,1
2020/4/16 11:51,Thur,18800,orange pound,1
2020/4/16 12:15,Thur,27600,orange pound,1
2020/4/17 11:45,Fri,20100,orange pound,1
2020/4/17 12:12,Fri,19300,orange pound,1
2020/4/17 13:18,Fri,15500,orange pound,1
2020/4/17 13:38,Fri,20600,orange pound,1
2020/4/18 11:19,Sat,19300,orange pound,1
2020/4/18 14:12,Sat,30100,orange pound,1
2020/4/19 14:04,Sun,24600,orange pound,1
2020/4/20 11:17,Mon,25100,orange pound,1
2020/4/20 12:32,Mon,16500,orange pound,2
2020/4/20 14:46,Mon,64000,orange pound,2
2020/4/23 11:07,Thur,20900,orange pound,1
2020/4/23 11:40,Thur,28500,orange pound,1
2020/4/24 12:53,Fri,24800,orange pound,2
2020/4/24 14:03,Fri,14000,orange pound,1
2020/4/25 13:56,Sat,19000,orange pound,1
2020/4/25 14:25,Sat,22800,orange pound,1
2020/4/25 14:27,Sat,20800,orange pound,1
2020/4/25 16:13,Sat,15800,orange pound,1
2020/4/26 11:05,Sun,33300,orange pound,1
2020/4/26 11:51,Sun,28300,orange pound,1
2020/4/27 11:28,Mon,18300,orange pound,1
2020/4/27 12:08,Mon,14800,orange pound,1
2020/4/27 13:22,Mon,14500,orange pound,1
2020/4/29 12:24,Wed,23500,orange pound,1
2020/4/30 11:18,Thur,31300,orange pound,1
2020/4/30 15:01,Thur,18800,orange pound,1
2020/5/1 11:47,Fri,19800,orange pound,1
2020/5/1 12:00,Fri,30800,orange pound,1
2020/5/1 13:05,Fri,28400,orange pound,1
2020/5/2 14:45,Sat,24100,orange pound,1
2019/7/20 12:13,Sat,26300,wiener,1
2019/7/21 12:12,Sun,17800,wiener,1
2019/7/24 17:20,Wed,15000,wiener,2
2019/7/25 12:01,Thur,35000,wiener,6
2019/7/25 12:35,Thur,38000,wiener,2
2019/7/26 11:31,Fri,22800,wiener,1
2019/7/26 11:55,Fri,20800,wiener,2
2019/7/26 13:19,Fri,25900,wiener,2
2019/7/26 14:52,Fri,22100,wiener,1
2019/7/27 14:05,Sat,32600,wiener,1
2019/7/28 11:17,Sun,17300,wiener,1
2019/7/28 13:13,Sun,25600,wiener,1
2019/7/29 11:08,Mon,24800,wiener,3
2019/8/2 11:06,Fri,18000,wiener,1
2019/8/2 11:31,Fri,17300,wiener,1
2019/8/3 11:03,Sat,26100,wiener,3
2019/8/3 11:05,Sat,29100,wiener,1
2019/8/3 11:06,Sat,16800,wiener,2
2019/8/3 11:08,Sat,22800,wiener,4
2019/8/3 11:20,Sat,16600,wiener,1
2019/8/3 11:53,Sat,18800,wiener,2
2019/8/4 11:02,Sun,34800,wiener,1
2019/8/4 11:04,Sun,31600,wiener,2
2019/8/4 11:41,Sun,24300,wiener,1
2019/8/4 11:52,Sun,22100,wiener,1
2019/8/4 12:39,Sun,17800,wiener,1
2019/8/5 11:11,Mon,16300,wiener,2
2019/8/5 11:16,Mon,23100,wiener,1
2019/8/5 11:18,Mon,31400,wiener,1
2019/8/5 11:32,Mon,17000,wiener,1
2019/8/5 11:59,Mon,22300,wiener,1
2019/8/5 14:25,Mon,20800,wiener,1
2019/8/5 14:53,Mon,16300,wiener,1
2019/8/7 11:03,Wed,16300,wiener,1
2019/8/7 12:17,Wed,15300,wiener,1
2019/8/7 14:06,Wed,14100,wiener,1
2019/8/8 12:03,Thur,16500,wiener,1
2019/8/8 12:39,Thur,15300,wiener,2
2019/8/8 12:56,Thur,16000,wiener,1
2019/8/8 13:36,Thur,33200,wiener,2
2019/8/8 14:58,Thur,20500,wiener,3
2019/8/10 11:03,Sat,19100,wiener,1
2019/8/10 11:27,Sat,36800,wiener,2
2019/8/10 11:38,Sat,25300,wiener,1
2019/8/10 13:15,Sat,16600,wiener,1
2019/8/11 11:02,Sun,16800,wiener,1
2019/8/11 11:03,Sun,16000,wiener,1
2019/8/11 11:08,Sun,22800,wiener,1
2019/8/11 11:08,Sun,17800,wiener,1
2019/8/11 13:21,Sun,23100,wiener,1
2019/8/11 13:27,Sun,17300,wiener,1
2019/8/12 11:05,Mon,28400,wiener,1
2019/8/12 11:48,Mon,16300,wiener,1
2019/8/12 12:53,Mon,16300,wiener,2
2019/8/14 11:03,Wed,17800,wiener,1
2019/8/14 11:04,Wed,18300,wiener,1
2019/8/14 11:07,Wed,17300,wiener,1
2019/8/15 11:06,Thur,17300,wiener,1
2019/8/16 11:54,Fri,17800,wiener,1
2019/8/16 12:07,Fri,14100,wiener,1
2019/8/16 12:49,Fri,18300,wiener,1
2019/8/18 11:09,Sun,26600,wiener,1
2019/8/18 11:23,Sun,17800,wiener,1
2019/8/18 11:27,Sun,14100,wiener,1
2019/8/18 12:24,Sun,16000,wiener,1
2019/8/19 11:59,Mon,16800,wiener,1
2019/8/21 11:07,Wed,15300,wiener,2
2019/8/21 12:13,Wed,18300,wiener,1
2019/8/21 13:01,Wed,15800,wiener,2
2019/8/21 13:26,Wed,15600,wiener,1
2019/8/22 15:24,Thur,26000,wiener,1
2019/8/24 11:09,Sat,20100,wiener,2
2019/8/24 11:13,Sat,25600,wiener,1
2019/8/24 11:18,Sat,24900,wiener,2
2019/8/25 11:06,Sun,17300,wiener,1
2019/8/25 11:18,Sun,15300,wiener,2
2019/8/25 12:05,Sun,14100,wiener,1
2019/8/25 12:23,Sun,25300,wiener,1
2019/8/26 11:16,Mon,17800,wiener,1
2019/8/26 11:30,Mon,18000,wiener,2
2019/8/26 16:11,Mon,22800,wiener,1
2019/8/28 11:19,Wed,16300,wiener,1
2019/8/28 12:24,Wed,18000,wiener,1
2019/8/29 11:04,Thur,22300,wiener,2
2019/8/29 15:08,Thur,15000,wiener,2
2019/8/30 14:13,Fri,16000,wiener,1
2019/8/31 11:20,Sat,16300,wiener,1
2019/8/31 12:31,Sat,16300,wiener,1
2019/9/2 12:12,Mon,31400,wiener,1
2019/9/2 15:13,Mon,23500,wiener,1
2019/9/4 13:19,Wed,19300,wiener,2
2019/9/5 11:15,Thur,27700,wiener,1
2019/9/5 12:24,Thur,17600,wiener,1
2019/9/5 15:50,Thur,14100,wiener,1
2019/9/6 11:14,Fri,16300,wiener,1
2019/9/11 11:13,Wed,42300,wiener,1
2019/9/11 14:48,Wed,16300,wiener,1
2019/9/12 11:16,Thur,15800,wiener,2
2019/9/12 13:43,Thur,15800,wiener,2
2019/9/14 11:15,Sat,19500,wiener,1
2019/9/14 12:17,Sat,26300,wiener,1
2019/9/15 12:13,Sun,32600,wiener,2
2019/9/15 13:38,Sun,25300,wiener,2
2019/9/15 13:38,Sun,16300,wiener,1
2019/9/18 11:26,Wed,19800,wiener,2
2019/9/18 11:32,Wed,16500,wiener,1
2019/9/19 15:34,Thur,15000,wiener,2
2019/9/20 16:08,Fri,18000,wiener,1
2019/9/21 11:06,Sat,17800,wiener,1
2019/9/21 11:08,Sat,39300,wiener,1
2019/9/21 11:22,Sat,18300,wiener,1
2019/9/21 12:01,Sat,17000,wiener,1
2019/9/21 12:16,Sat,17600,wiener,1
2019/9/22 11:18,Sun,30900,wiener,1
2019/9/22 12:01,Sun,14100,wiener,1
2019/9/22 12:06,Sun,22300,wiener,2
2019/9/22 12:07,Sun,34100,wiener,2
2019/9/22 12:33,Sun,15300,wiener,2
2019/9/23 11:25,Mon,16300,wiener,1
2019/9/25 16:10,Wed,17300,wiener,1
2019/9/26 11:48,Thur,14500,wiener,2
2019/9/27 12:30,Fri,21300,wiener,2
2019/9/27 16:12,Fri,36100,wiener,1
2019/9/28 15:11,Sat,20100,wiener,3
2019/9/29 11:06,Sun,18800,wiener,2
2019/9/29 11:39,Sun,23100,wiener,1
2019/9/29 11:49,Sun,17300,wiener,1
2019/9/30 12:35,Mon,18600,wiener,1
2019/9/30 12:47,Mon,17300,wiener,1
2019/10/2 15:57,Wed,24500,wiener,2
2019/10/2 16:12,Wed,15000,wiener,1
2019/10/3 11:07,Thur,17800,wiener,1
2019/10/3 11:53,Thur,18300,wiener,1
2019/10/3 12:54,Thur,14300,wiener,2
2019/10/3 13:17,Thur,24000,wiener,2
2019/10/4 14:26,Fri,32900,wiener,3
2019/10/5 14:19,Sat,15800,wiener,2
2019/10/6 11:08,Sun,15800,wiener,1
2019/10/6 12:31,Sun,16300,wiener,1
2019/10/7 12:24,Mon,17300,wiener,1
2019/10/11 14:29,Fri,15500,wiener,2
2019/10/12 11:07,Sat,20500,wiener,1
2019/10/13 12:55,Sun,18500,wiener,2
2019/10/13 13:48,Sun,21500,wiener,1
2019/10/13 14:32,Sun,15600,wiener,2
2019/10/14 12:21,Mon,17300,wiener,1
2019/10/16 12:15,Wed,22000,wiener,1
2019/10/17 12:49,Thur,15300,wiener,2
2019/10/17 13:16,Thur,24800,wiener,1
2019/10/18 11:43,Fri,51900,wiener,1
2019/10/19 12:00,Sat,18300,wiener,1
2019/10/20 11:25,Sun,19800,wiener,1
2019/10/21 11:27,Mon,16300,wiener,1
2019/10/21 11:27,Mon,17300,wiener,1
2019/10/24 13:35,Thur,17300,wiener,1
2019/10/24 14:25,Thur,21000,wiener,1
2019/10/25 11:15,Fri,18300,wiener,1
2019/10/25 14:16,Fri,18600,wiener,1
2019/10/26 11:54,Sat,25800,wiener,1
2019/10/27 13:42,Sun,18500,wiener,2
2019/11/1 11:55,Fri,23000,wiener,2
2019/11/1 13:52,Fri,22000,wiener,1
2019/11/2 11:27,Sat,16800,wiener,2
2019/11/2 12:01,Sat,14100,wiener,1
2019/11/3 12:25,Sun,17800,wiener,1
2019/11/7 13:33,Thur,34800,wiener,3
2019/11/7 15:21,Thur,16800,wiener,1
2019/11/8 14:12,Fri,23300,wiener,1
2019/11/8 15:12,Fri,30000,wiener,1
2019/11/9 11:36,Sat,18300,wiener,1
2019/11/9 11:36,Sat,26100,wiener,2
2019/11/9 11:36,Sat,35700,wiener,1
2019/11/10 11:27,Sun,17000,wiener,1
2019/11/10 13:09,Sun,23800,wiener,3
2019/11/15 13:44,Fri,18500,wiener,2
2019/11/16 11:07,Sat,23800,wiener,1
2019/11/16 13:38,Sat,21100,wiener,2
2019/11/17 11:57,Sun,16300,wiener,1
2019/11/17 14:10,Sun,18100,wiener,1
2019/11/17 15:25,Sun,17300,wiener,1
2019/11/18 14:36,Mon,28800,wiener,2
2019/11/20 16:59,Wed,15500,wiener,1
2019/11/24 13:34,Sun,39000,wiener,1
2019/11/24 14:27,Sun,14100,wiener,1
2019/11/25 11:05,Mon,19800,wiener,1
2019/11/25 12:54,Mon,26300,wiener,1
2019/11/28 13:16,Thur,17500,wiener,1
2019/11/29 12:03,Fri,16300,wiener,1
2019/11/29 13:39,Fri,17300,wiener,1
2019/12/1 12:35,Sun,23000,wiener,2
2019/12/1 16:51,Sun,18300,wiener,1
2019/12/2 11:03,Mon,17500,wiener,2
2019/12/4 11:18,Wed,35000,wiener,2
2019/12/4 13:34,Wed,16000,wiener,1
2019/12/5 12:32,Thur,16000,wiener,1
2019/12/6 12:51,Fri,16300,wiener,2
2019/12/8 11:22,Sun,20500,wiener,1
2019/12/8 13:57,Sun,17000,wiener,2
2019/12/8 14:06,Sun,16100,wiener,1
2019/12/12 12:50,Thur,20600,wiener,1
2019/12/12 14:09,Thur,16300,wiener,1
2019/12/12 17:22,Thur,21800,wiener,1
2019/12/16 11:41,Mon,18900,wiener,1
2019/12/18 11:22,Wed,52800,wiener,1
2019/12/18 13:28,Wed,14100,wiener,1
2019/12/19 12:16,Thur,14300,wiener,1
2019/12/19 13:06,Thur,32500,wiener,1
2019/12/19 13:53,Thur,16600,wiener,2
2019/12/21 12:24,Sat,25300,wiener,1
2019/12/21 13:29,Sat,18500,wiener,1
2019/12/21 13:58,Sat,20000,wiener,1
2019/12/22 11:33,Sun,46000,wiener,1
2019/12/23 13:05,Mon,25600,wiener,2
2019/12/23 14:42,Mon,19500,wiener,2
2019/12/24 11:17,Tues,21400,wiener,2
2019/12/27 12:49,Fri,15000,wiener,1
2019/12/28 12:09,Sat,22300,wiener,1
2019/12/28 15:52,Sat,19300,wiener,2
2019/12/29 16:02,Sun,25500,wiener,2
2019/12/30 11:44,Mon,15300,wiener,1
2019/12/30 12:23,Mon,91300,wiener,1
2019/12/30 15:44,Mon,15800,wiener,2
2020/1/2 12:17,Thur,16500,wiener,1
2020/1/3 11:59,Fri,16300,wiener,2
2020/1/3 13:44,Fri,17300,wiener,1
2020/1/4 17:23,Sat,16500,wiener,4
2020/1/5 11:10,Sun,18600,wiener,1
2020/1/5 11:23,Sun,18000,wiener,1
2020/1/5 13:59,Sun,14500,wiener,2
2020/1/8 11:15,Wed,18100,wiener,1
2020/1/8 15:19,Wed,27200,wiener,2
2020/1/9 12:27,Thur,28800,wiener,2
2020/1/9 13:44,Thur,21900,wiener,1
2020/1/9 15:22,Thur,23300,wiener,2
2020/1/9 15:59,Thur,17600,wiener,1
2020/1/10 12:51,Fri,21800,wiener,1
2020/1/10 14:48,Fri,19300,wiener,1
2020/1/12 11:03,Sun,17300,wiener,1
2020/1/12 11:03,Sun,21800,wiener,1
2020/1/12 16:30,Sun,17000,wiener,1
2020/1/15 11:08,Wed,17300,wiener,1
2020/1/17 13:30,Fri,16300,wiener,1
2020/1/17 14:15,Fri,17800,wiener,2
2020/1/18 15:27,Sat,23600,wiener,2
2020/1/19 16:52,Sun,17800,wiener,1
2020/1/24 11:37,Fri,23800,wiener,2
2020/1/24 11:50,Fri,15300,wiener,1
2020/1/26 12:16,Sun,15000,wiener,2
2020/1/27 13:29,Mon,26000,wiener,1
2020/1/29 15:31,Wed,25900,wiener,2
2020/1/30 14:27,Thur,16000,wiener,1
2020/2/2 11:05,Sun,15000,wiener,1
2020/2/3 14:26,Mon,16300,wiener,2
2020/2/5 11:23,Wed,19800,wiener,2
2020/2/5 12:32,Wed,16300,wiener,1
2020/2/6 11:34,Thur,18600,wiener,1
2020/2/7 15:14,Fri,19300,wiener,1
2020/2/7 16:23,Fri,20000,wiener,1
2020/2/7 16:41,Fri,21800,wiener,1
2020/2/8 14:42,Sat,19800,wiener,1
2020/2/9 11:03,Sun,30000,wiener,1
2020/2/9 11:09,Sun,18300,wiener,1
2020/2/9 11:52,Sun,34300,wiener,1
2020/2/12 11:03,Wed,16800,wiener,1
2020/2/12 11:04,Wed,15000,wiener,1
2020/2/14 13:06,Fri,16300,wiener,1
2020/2/15 11:07,Sat,25000,wiener,1
2020/2/15 12:31,Sat,16500,wiener,1
2020/2/15 14:03,Sat,32100,wiener,1
2020/2/16 12:07,Sun,41800,wiener,2
2020/2/17 13:33,Mon,23300,wiener,2
2020/2/17 13:48,Mon,16800,wiener,1
2020/2/17 15:25,Mon,36600,wiener,3
2020/2/19 12:07,Wed,16000,wiener,1
2020/2/21 14:21,Fri,33500,wiener,2
2020/2/22 11:03,Sat,14300,wiener,1
2020/2/22 11:09,Sat,28300,wiener,1
2020/2/22 11:14,Sat,16300,wiener,1
2020/2/22 12:25,Sat,16300,wiener,1
2020/2/23 11:47,Sun,23500,wiener,1
2020/2/23 14:05,Sun,22300,wiener,1
2020/2/23 16:00,Sun,26600,wiener,1
2020/2/23 16:42,Sun,17600,wiener,1
2020/2/24 12:09,Mon,17900,wiener,1
2020/2/24 14:32,Mon,26800,wiener,2
2020/2/26 11:20,Wed,18300,wiener,1
2020/2/28 11:09,Fri,25100,wiener,2
2020/2/28 12:10,Fri,24500,wiener,1
2020/2/28 15:50,Fri,17800,wiener,1
2020/2/29 11:09,Sat,17300,wiener,1
2020/3/1 11:06,Sun,29800,wiener,1
2020/3/1 15:16,Sun,20300,wiener,1
2020/3/2 17:05,Mon,18800,wiener,1
2020/3/5 15:03,Thur,17300,wiener,1
2020/3/7 11:29,Sat,20800,wiener,1
2020/3/8 12:52,Sun,21300,wiener,1
2020/3/8 13:34,Sun,18000,wiener,2
2020/3/11 11:24,Wed,24300,wiener,1
2020/3/12 12:23,Thur,20800,wiener,1
2020/3/12 15:17,Thur,22800,wiener,1
2020/3/14 11:11,Sat,28300,wiener,1
2020/3/14 11:29,Sat,15300,wiener,2
2020/3/14 11:45,Sat,18000,wiener,1
2020/3/15 14:18,Sun,16000,wiener,1
2020/3/18 11:43,Wed,30500,wiener,2
2020/3/18 12:08,Wed,14000,wiener,1
2020/3/18 12:40,Wed,42400,wiener,1
2020/3/21 11:33,Sat,20000,wiener,1
2020/3/21 12:07,Sat,14300,wiener,1
2020/3/22 11:02,Sun,18500,wiener,2
2020/3/26 11:32,Thur,43200,wiener,1
2020/3/27 13:36,Fri,24800,wiener,2
2020/3/28 11:55,Sat,40300,wiener,1
2020/3/28 13:05,Sat,22600,wiener,1
2020/3/29 12:02,Sun,29800,wiener,2
2020/3/29 12:09,Sun,14100,wiener,1
2020/3/29 13:04,Sun,29600,wiener,1
2020/3/30 11:22,Mon,17300,wiener,2
2020/4/3 11:24,Fri,24800,wiener,2
2020/4/4 11:54,Sat,18300,wiener,1
2020/4/4 14:56,Sat,18800,wiener,2
2020/4/5 12:33,Sun,16300,wiener,1
2020/4/5 13:05,Sun,24600,wiener,1
2020/4/5 13:34,Sun,22300,wiener,1
2020/4/5 14:41,Sun,26300,wiener,1
2020/4/6 11:54,Mon,18300,wiener,1
2020/4/8 11:01,Wed,17300,wiener,1
2020/4/8 11:53,Wed,28800,wiener,2
2020/4/8 12:01,Wed,30300,wiener,1
2020/4/8 15:53,Wed,22300,wiener,1
2020/4/9 11:10,Thur,26600,wiener,1
2020/4/9 11:59,Thur,20300,wiener,2
2020/4/9 13:25,Thur,14100,wiener,1
2020/4/9 14:31,Thur,19500,wiener,1
2020/4/11 11:20,Sat,17300,wiener,1
2020/4/15 13:52,Wed,17300,wiener,1
2020/4/15 15:01,Wed,16000,wiener,1
2020/4/16 11:46,Thur,19300,wiener,1
2020/4/16 13:04,Thur,18300,wiener,1
2020/4/17 16:05,Fri,17000,wiener,1
2020/4/18 13:42,Sat,15000,wiener,1
2020/4/19 15:02,Sun,16500,wiener,1
2020/4/22 12:06,Wed,28600,wiener,1
2020/4/23 12:57,Thur,17500,wiener,1
2020/4/24 15:10,Fri,26000,wiener,2
2020/4/25 11:10,Sat,18300,wiener,1
2020/4/25 13:56,Sat,29300,wiener,2
2020/4/26 11:03,Sun,38900,wiener,4
2020/4/26 11:05,Sun,33300,wiener,1
2020/4/26 15:14,Sun,27300,wiener,2
2020/4/27 11:56,Mon,22300,wiener,1
2020/4/30 11:18,Thur,31300,wiener,1
2020/4/30 11:43,Thur,18300,wiener,1
2020/4/30 13:43,Thur,16800,wiener,1
2020/5/1 13:55,Fri,21300,wiener,1
2019/7/11 15:35,Thur,23800,vanila latte,1
2019/7/13 13:19,Sat,14800,vanila latte,1
2019/7/13 14:54,Sat,15800,vanila latte,1
2019/7/13 15:08,Sat,15800,vanila latte,1
2019/7/14 11:08,Sun,15300,vanila latte,1
2019/7/14 11:44,Sun,26300,vanila latte,1
2019/7/14 11:59,Sun,19800,vanila latte,1
2019/7/14 14:41,Sun,20100,vanila latte,1
2019/7/14 15:02,Sun,19800,vanila latte,1
2019/7/21 14:05,Sun,18300,vanila latte,1
2019/7/24 14:28,Wed,26300,vanila latte,1
2019/7/25 11:57,Thur,26800,vanila latte,1
2019/7/25 16:03,Thur,20000,vanila latte,1
2019/7/27 12:00,Sat,18600,vanila latte,1
2019/7/27 14:05,Sat,32600,vanila latte,1
2019/7/29 13:36,Mon,28000,vanila latte,1
2019/7/29 13:53,Mon,28000,vanila latte,1
2019/7/31 13:18,Wed,27300,vanila latte,1
2019/8/5 12:49,Mon,49300,vanila latte,3
2019/8/7 12:20,Wed,27300,vanila latte,1
2019/8/8 13:22,Thur,15800,vanila latte,1
2019/8/8 14:58,Thur,20500,vanila latte,1
2019/8/9 15:30,Fri,15100,vanila latte,1
2019/8/10 11:27,Sat,36800,vanila latte,1
2019/8/11 11:37,Sun,15800,vanila latte,1
2019/8/12 14:08,Mon,32100,vanila latte,1
2019/8/14 11:22,Wed,29000,vanila latte,1
2019/8/15 11:53,Thur,15000,vanila latte,1
2019/8/17 12:40,Sat,18800,vanila latte,1
2019/8/18 13:30,Sun,36100,vanila latte,3
2019/8/23 15:32,Fri,22000,vanila latte,1
2019/8/25 12:23,Sun,25300,vanila latte,1
2019/8/29 13:12,Thur,24000,vanila latte,2
2019/8/29 15:08,Thur,15000,vanila latte,1
2019/8/30 11:16,Fri,14800,vanila latte,1
2019/8/30 15:05,Fri,28800,vanila latte,1
2019/9/1 14:43,Sun,15800,vanila latte,1
2019/9/2 14:17,Mon,20300,vanila latte,1
2019/9/2 15:13,Mon,23500,vanila latte,1
2019/9/5 12:12,Thur,19600,vanila latte,1
2019/9/7 11:10,Sat,23600,vanila latte,1
2019/9/8 11:08,Sun,25100,vanila latte,2
2019/9/12 11:13,Thur,15000,vanila latte,1
2019/9/14 12:06,Sat,19300,vanila latte,1
2019/9/19 15:34,Thur,15000,vanila latte,1
2019/9/20 12:53,Fri,21000,vanila latte,1
2019/9/25 12:21,Wed,21500,vanila latte,2
2019/9/26 14:23,Thur,24800,vanila latte,1
2019/9/27 13:07,Fri,15800,vanila latte,1
2019/9/28 12:27,Sat,21800,vanila latte,1
2019/9/28 14:07,Sat,25800,vanila latte,1
2019/9/29 12:13,Sun,23800,vanila latte,1
2019/9/29 14:02,Sun,29900,vanila latte,1
2019/9/30 15:17,Mon,15500,vanila latte,1
2019/10/2 12:35,Wed,15500,vanila latte,1
2019/10/2 14:16,Wed,17000,vanila latte,1
2019/10/3 12:12,Thur,22300,vanila latte,1
2019/10/3 12:17,Thur,28300,vanila latte,1
2019/10/3 12:28,Thur,15800,vanila latte,1
2019/10/3 13:17,Thur,24000,vanila latte,1
2019/10/3 14:25,Thur,22800,vanila latte,1
2019/10/7 16:12,Mon,17300,vanila latte,1
2019/10/12 13:11,Sat,23800,vanila latte,2
2019/10/13 13:01,Sun,14800,vanila latte,1
2019/10/13 14:48,Sun,21300,vanila latte,1
2019/10/14 11:08,Mon,26000,vanila latte,1
2019/10/16 11:09,Wed,22800,vanila latte,1
2019/10/16 11:48,Wed,15500,vanila latte,1
2019/10/16 14:31,Wed,20300,vanila latte,1
2019/10/17 12:35,Thur,14800,vanila latte,1
2019/10/17 13:50,Thur,32300,vanila latte,2
2019/10/17 16:00,Thur,15800,vanila latte,2
2019/10/18 12:08,Fri,17000,vanila latte,1
2019/10/21 11:47,Mon,28600,vanila latte,2
2019/10/24 14:25,Thur,21000,vanila latte,1
2019/10/25 11:51,Fri,22800,vanila latte,1
2019/10/26 11:54,Sat,25800,vanila latte,1
2019/11/1 11:55,Fri,23000,vanila latte,1
2019/11/3 15:30,Sun,14800,vanila latte,1
2019/11/4 16:37,Mon,17000,vanila latte,1
2019/11/6 11:07,Wed,16000,vanila latte,1
2019/11/6 16:15,Wed,24800,vanila latte,1
2019/11/9 11:36,Sat,21300,vanila latte,1
2019/11/10 11:41,Sun,15800,vanila latte,1
2019/11/10 13:09,Sun,23800,vanila latte,1
2019/11/10 15:52,Sun,15800,vanila latte,1
2019/11/14 13:10,Thur,39300,vanila latte,1
2019/11/16 12:21,Sat,18500,vanila latte,1
2019/11/16 14:21,Sat,24800,vanila latte,1
2019/11/17 11:06,Sun,26300,vanila latte,1
2019/11/17 11:07,Sun,23800,vanila latte,1
2019/11/17 13:18,Sun,23300,vanila latte,1
2019/11/17 15:55,Sun,20600,vanila latte,2
2019/11/18 14:36,Mon,28800,vanila latte,1
2019/11/18 15:17,Mon,22800,vanila latte,1
2019/11/20 12:59,Wed,20300,vanila latte,1
2019/11/24 13:53,Sun,19300,vanila latte,1
2019/11/28 12:53,Thur,15300,vanila latte,1
2019/11/28 13:15,Thur,25300,vanila latte,1
2019/11/28 13:16,Thur,17500,vanila latte,1
2019/11/29 16:12,Fri,28100,vanila latte,1
2019/11/30 13:49,Sat,20300,vanila latte,1
2019/12/1 12:35,Sun,23000,vanila latte,1
2019/12/1 13:15,Sun,15800,vanila latte,1
2019/12/1 16:51,Sun,18300,vanila latte,1
2019/12/9 13:35,Mon,29800,vanila latte,2
2019/12/14 12:51,Sat,19300,vanila latte,1
2019/12/15 12:14,Sun,19300,vanila latte,1
2019/12/16 12:58,Mon,14800,vanila latte,1
2019/12/22 11:05,Sun,14800,vanila latte,1
2019/12/22 14:17,Sun,20300,vanila latte,1
2019/12/25 14:47,Wed,20000,vanila latte,1
2019/12/25 17:14,Wed,17000,vanila latte,1
2019/12/26 12:16,Thur,20500,vanila latte,1
2019/12/29 13:03,Sun,19800,vanila latte,1
2019/12/29 14:26,Sun,14800,vanila latte,1
2019/12/29 14:42,Sun,22800,vanila latte,1
2020/1/3 11:03,Fri,21600,vanila latte,1
2020/1/4 16:02,Sat,15100,vanila latte,1
2020/1/5 14:06,Sun,23800,vanila latte,1
2020/1/10 12:51,Fri,21800,vanila latte,1
2020/1/10 13:51,Fri,15800,vanila latte,1
2020/1/13 11:52,Mon,20300,vanila latte,1
2020/1/13 13:49,Mon,19300,vanila latte,1
2020/1/13 15:50,Mon,20500,vanila latte,1
2020/1/18 16:12,Sat,14500,vanila latte,1
2020/1/19 12:52,Sun,32100,vanila latte,1
2020/1/19 13:17,Sun,24300,vanila latte,1
2020/1/19 14:23,Sun,15100,vanila latte,1
2020/1/22 12:04,Wed,20300,vanila latte,1
2020/1/23 15:26,Thur,27500,vanila latte,2
2020/1/29 14:07,Wed,15800,vanila latte,1
2020/1/31 13:47,Fri,15000,vanila latte,1
2020/2/1 13:42,Sat,19300,vanila latte,1
2020/2/1 13:50,Sat,23600,vanila latte,1
2020/2/5 11:54,Wed,21500,vanila latte,1
2020/2/7 12:39,Fri,33300,vanila latte,2
2020/2/7 14:51,Fri,14800,vanila latte,1
2020/2/7 15:40,Fri,26300,vanila latte,1
2020/2/7 16:23,Fri,20000,vanila latte,1
2020/2/9 12:33,Sun,19800,vanila latte,1
2020/2/9 12:54,Sun,22300,vanila latte,1
2020/2/9 15:15,Sun,18500,vanila latte,1
2020/2/9 15:48,Sun,24400,vanila latte,1
2020/2/12 14:09,Wed,31600,vanila latte,4
2020/2/13 14:10,Thur,16100,vanila latte,1
2020/2/15 12:35,Sat,15500,vanila latte,1
2020/2/20 11:11,Thur,26800,vanila latte,4
2020/2/21 11:54,Fri,19800,vanila latte,1
2020/2/22 12:14,Sat,19300,vanila latte,1
2020/2/22 12:22,Sat,17100,vanila latte,1
2020/2/22 12:48,Sat,16100,vanila latte,1
2020/2/23 11:04,Sun,35300,vanila latte,1
2020/2/23 11:52,Sun,25500,vanila latte,3
2020/2/23 12:25,Sun,15300,vanila latte,1
2020/2/23 12:39,Sun,19800,vanila latte,1
2020/2/24 14:32,Mon,26800,vanila latte,1
2020/2/26 11:12,Wed,31600,vanila latte,1
2020/2/26 11:55,Wed,15300,vanila latte,1
2020/2/28 11:52,Fri,16500,vanila latte,1
2020/2/28 11:54,Fri,14800,vanila latte,1
2020/2/28 12:28,Fri,51100,vanila latte,4
2020/2/29 12:48,Sat,19000,vanila latte,1
2020/3/1 11:06,Sun,34100,vanila latte,1
2020/3/1 11:47,Sun,41800,vanila latte,1
2020/3/1 14:17,Sun,20800,vanila latte,2
2020/3/1 14:19,Sun,23500,vanila latte,1
2020/3/5 12:00,Thur,20500,vanila latte,1
2020/3/6 12:15,Fri,18500,vanila latte,1
2020/3/6 12:22,Fri,22800,vanila latte,1
2020/3/6 13:21,Fri,20600,vanila latte,1
2020/3/6 13:44,Fri,15800,vanila latte,1
2020/3/7 13:17,Sat,15500,vanila latte,1
2020/3/7 14:20,Sat,19800,vanila latte,1
2020/3/8 12:28,Sun,32800,vanila latte,1
2020/3/8 15:18,Sun,25400,vanila latte,1
2020/3/8 15:23,Sun,16100,vanila latte,1
2020/3/9 12:16,Mon,20500,vanila latte,1
2020/3/9 12:24,Mon,16000,vanila latte,1
2020/3/11 11:10,Wed,28600,vanila latte,1
2020/3/12 11:42,Thur,27800,vanila latte,2
2020/3/13 15:49,Fri,15100,vanila latte,1
2020/3/16 11:59,Mon,26800,vanila latte,1
2020/3/16 13:29,Mon,14800,vanila latte,1
2020/3/16 16:13,Mon,26800,vanila latte,4
2020/3/18 11:43,Wed,30500,vanila latte,1
2020/3/18 12:29,Wed,39100,vanila latte,1
2020/3/20 12:17,Fri,28800,vanila latte,1
2020/3/22 11:43,Sun,32900,vanila latte,1
2020/3/22 14:51,Sun,16100,vanila latte,1
2020/3/27 15:36,Fri,28800,vanila latte,1
2020/3/29 14:02,Sun,26300,vanila latte,1
2020/4/1 13:49,Wed,28800,vanila latte,1
2020/4/1 14:18,Wed,24300,vanila latte,2
2020/4/2 15:49,Thur,16100,vanila latte,1
2020/4/5 13:17,Sun,17100,vanila latte,1
2020/4/6 15:38,Mon,20600,vanila latte,1
2020/4/8 11:22,Wed,16300,vanila latte,1
2020/4/8 16:38,Wed,25000,vanila latte,1
2020/4/10 17:14,Fri,15500,vanila latte,1
2020/4/15 15:17,Wed,29200,vanila latte,1
2020/4/16 11:46,Thur,19300,vanila latte,1
2020/4/18 12:35,Sat,15800,vanila latte,1
2020/4/18 13:42,Sat,15000,vanila latte,1
2020/4/18 14:10,Sat,36000,vanila latte,1
2020/4/20 12:32,Mon,16500,vanila latte,1
2020/4/25 16:13,Sat,15800,vanila latte,1
2020/4/26 12:00,Sun,23300,vanila latte,1
2020/5/2 11:37,Sat,19500,vanila latte,1
2019/7/17 16:32,Wed,18100,berry ade,1
2019/7/19 12:11,Fri,15800,berry ade,1
2019/7/22 16:54,Mon,18600,berry ade,1
2019/7/25 13:05,Thur,17300,berry ade,1
2019/7/26 14:05,Fri,15800,berry ade,1
2019/7/28 13:14,Sun,19500,berry ade,1
2019/8/2 11:31,Fri,17300,berry ade,1
2019/8/5 12:49,Mon,49300,berry ade,1
2019/8/11 13:14,Sun,19300,berry ade,1
2019/8/16 12:49,Fri,18300,berry ade,1
2019/8/21 14:38,Wed,23000,berry ade,1
2019/8/22 14:17,Thur,20600,berry ade,1
2019/8/24 11:13,Sat,25600,berry ade,1
2019/8/29 13:12,Thur,24000,berry ade,2
2019/9/2 14:17,Mon,20300,berry ade,1
2019/9/15 15:28,Sun,57900,berry ade,1
2019/9/19 16:17,Thur,30500,berry ade,1
2019/9/21 13:56,Sat,25100,berry ade,1
2019/9/26 14:23,Thur,24800,berry ade,1
2019/10/12 11:07,Sat,20500,berry ade,1
2019/10/13 14:54,Sun,27600,berry ade,1
2019/11/10 11:20,Sun,32800,berry ade,1
2019/11/23 16:15,Sat,15300,berry ade,1
2019/12/9 13:54,Mon,15800,berry ade,1
2019/12/12 14:52,Thur,19500,berry ade,1
2019/12/15 14:46,Sun,21800,berry ade,1
2019/12/21 12:02,Sat,19800,berry ade,1
2020/1/12 12:42,Sun,18000,berry ade,1
2020/1/13 13:49,Mon,19300,berry ade,1
2020/1/13 15:50,Mon,20500,berry ade,1
2020/1/19 14:18,Sun,23900,berry ade,1
2020/1/26 13:09,Sun,18000,berry ade,1
2020/1/30 11:53,Thur,28800,berry ade,1
2020/1/31 11:11,Fri,16800,berry ade,1
2020/2/7 12:39,Fri,33300,berry ade,1
2020/2/7 12:44,Fri,29300,berry ade,1
2020/2/7 12:48,Fri,15800,berry ade,1
2020/2/9 11:03,Sun,19300,berry ade,1
2020/2/23 12:42,Sun,24300,berry ade,1
2020/2/23 14:21,Sun,24400,berry ade,1
2020/2/26 12:49,Wed,14500,berry ade,1
2020/2/28 12:28,Fri,51100,berry ade,1
2020/3/1 11:47,Sun,41800,berry ade,1
2020/3/5 13:48,Thur,27800,berry ade,1
2020/3/7 13:53,Sat,28100,berry ade,1
2020/3/11 13:03,Wed,16100,berry ade,1
2020/3/14 14:11,Sat,15300,berry ade,1
2020/3/21 11:04,Sat,27800,berry ade,1
2020/3/23 12:37,Mon,34100,berry ade,1
2020/3/25 14:08,Wed,18000,berry ade,1
2020/4/9 12:00,Thur,30800,berry ade,1
2020/4/13 15:19,Mon,26300,berry ade,1
2020/4/18 14:17,Sat,14500,berry ade,1
2020/5/2 11:39,Sat,19800,berry ade,1
2019/7/20 11:40,Sat,22800,tiramisu,1
2019/7/20 12:08,Sat,15800,tiramisu,1
2019/7/20 12:13,Sat,26300,tiramisu,1
2019/7/21 11:07,Sun,18600,tiramisu,1
2019/7/27 12:20,Sat,22800,tiramisu,1
2019/8/11 13:21,Sun,23100,tiramisu,1
2019/8/12 14:08,Mon,32100,tiramisu,1
2019/8/17 11:17,Sat,24100,merinque cookies,1
2019/8/17 14:07,Sat,19000,merinque cookies,2
2019/8/19 11:59,Mon,16800,merinque cookies,1
2019/8/19 15:30,Mon,18800,merinque cookies,1
2019/8/21 12:51,Wed,17500,merinque cookies,1
2019/8/21 14:38,Wed,23000,merinque cookies,1
2019/8/24 14:13,Sat,15300,merinque cookies,1
2019/8/29 16:15,Thur,19000,merinque cookies,1
2019/9/4 13:19,Wed,19300,merinque cookies,1
2019/9/7 16:23,Sat,27400,merinque cookies,1
2019/9/15 11:33,Sun,24600,merinque cookies,1
2019/9/15 15:28,Sun,57900,merinque cookies,1
2019/9/18 14:10,Wed,15300,merinque cookies,1
2019/9/18 14:44,Wed,15300,merinque cookies,1
2019/9/19 16:27,Thur,34600,merinque cookies,1
2019/9/29 15:31,Sun,14800,merinque cookies,1
2019/10/5 13:34,Sat,15300,merinque cookies,1
2019/10/24 11:18,Thur,18800,merinque cookies,1
2019/11/10 13:10,Sun,19800,merinque cookies,1
2019/11/23 12:00,Sat,36100,merinque cookies,1
2019/11/27 14:16,Wed,16500,merinque cookies,1
2019/12/19 13:02,Thur,15600,merinque cookies,1
2019/12/24 13:14,Tues,19300,merinque cookies,1
2019/12/30 15:44,Mon,15800,merinque cookies,1
2020/1/2 11:33,Thur,42900,merinque cookies,1
2020/1/16 11:28,Thur,18800,merinque cookies,1
2020/1/20 11:25,Mon,23800,merinque cookies,1
2020/1/30 11:43,Thur,23300,merinque cookies,1
2020/2/2 12:24,Sun,15300,merinque cookies,1
2020/2/8 15:24,Sat,20800,merinque cookies,1
2020/2/9 11:03,Sun,30000,merinque cookies,1
2020/2/14 12:58,Fri,23300,merinque cookies,1
2020/2/23 16:00,Sun,26600,merinque cookies,1
2020/2/28 12:28,Fri,51100,merinque cookies,1
2020/2/28 15:50,Fri,17800,merinque cookies,1
2020/3/1 14:27,Sun,27300,merinque cookies,1
2020/3/18 12:40,Wed,42400,merinque cookies,1
2020/3/23 12:37,Mon,34100,merinque cookies,1
2020/3/30 15:07,Mon,17800,merinque cookies,1
2020/4/8 13:20,Wed,17100,merinque cookies,1
2020/4/9 11:59,Thur,20300,merinque cookies,1
2020/4/12 15:24,Sun,21600,merinque cookies,1
2020/4/16 16:58,Thur,18800,merinque cookies,2
2020/4/18 11:39,Sat,20800,merinque cookies,1
2020/4/25 11:52,Sat,14800,merinque cookies,1
2020/4/26 11:51,Sun,28300,merinque cookies,1
2020/5/1 11:32,Fri,15000,merinque cookies,1
\.
analyze "falcon_db_11"."bakery_sales";
commit;
