\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_15";
drop table if exists "falcon_db_15"."credit_card_card_base" cascade;
create table "falcon_db_15"."credit_card_card_base" ("Card_Number" text, "Card_Family" text, "Credit_Limit" bigint, "Cust_ID" text);
copy "falcon_db_15"."credit_card_card_base" ("Card_Number", "Card_Family", "Credit_Limit", "Cust_ID") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
7586-6475-9618-3909,Gold,37000,CC51908
2640-5294-8252-8817,Platinum,197000,CC70762
7908-2695-7391-7499,Gold,34000,CC53797
5734-5619-8469-4044,Gold,36000,CC87306
5591-5619-8809-5454,Platinum,140000,CC79161
5145-7864-6575-8768,Platinum,100000,CC56879
1336-9200-1264-2551,Premium,280000,CC16420
8231-5519-1948-3400,Premium,661000,CC71365
7752-7762-8832-3142,Platinum,56000,CC37643
6321-2048-7733-8765,Premium,129000,CC81662
1661-3809-5334-2155,Gold,39000,CC61332
4246-1369-3659-8804,Platinum,105000,CC21111
8528-6154-7390-5081,Premium,686000,CC90833
8262-8743-6406-7105,Premium,331000,CC30400
3295-6390-4452-7199,Gold,6000,CC76008
1947-8602-1695-7503,Gold,10000,CC26034
2524-4184-5908-6750,Platinum,150000,CC69171
9873-6894-5872-1884,Premium,383000,CC32108
1947-8327-3848-6581,Platinum,113000,CC11690
\.
analyze "falcon_db_15"."credit_card_card_base";
drop table if exists "falcon_db_15"."credit_card_customer_base" cascade;
create table "falcon_db_15"."credit_card_customer_base" ("Cust_ID" text, "Age" bigint, "Customer_Segment" text, "Customer_Vintage_Group" text);
copy "falcon_db_15"."credit_card_customer_base" ("Cust_ID", "Age", "Customer_Segment", "Customer_Vintage_Group") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
CC30400,27,Diamond,VG1
CC69171,41,Diamond,VG1
CC90833,32,Diamond,VG1
CC37643,33,Diamond,VG1
CC32108,34,Diamond,VG1
CC61332,36,Gold,VG3
CC26034,42,Platinum,VG2
CC79161,34,Diamond,VG1
CC11690,24,Diamond,VG1
CC70762,48,Diamond,VG1
CC16420,22,Gold,VG3
CC81662,49,Platinum,VG2
CC71365,39,Platinum,VG2
CC56879,30,Platinum,VG2
CC21111,43,Platinum,VG2
CC53797,35,Diamond,VG1
CC51908,20,Diamond,VG1
CC87306,30,Diamond,VG1
CC76008,42,Diamond,VG1
\.
analyze "falcon_db_15"."credit_card_customer_base";
drop table if exists "falcon_db_15"."credit_card_fraud_base" cascade;
create table "falcon_db_15"."credit_card_fraud_base" ("Transaction_ID" text, "Fraud_Flag" bigint);
copy "falcon_db_15"."credit_card_fraud_base" ("Transaction_ID", "Fraud_Flag") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
CTID50558449,1
CTID55936882,1
CTID63762180,1
CTID76723439,1
CTID21246201,1
CTID26555772,1
CTID20567160,1
CTID54759604,1
CTID44626561,1
CTID73773088,1
CTID62499873,1
CTID70746134,1
CTID29266043,1
CTID97776833,1
CTID16281374,1
CTID81479835,1
CTID20456246,1
CTID28195227,1
CTID42582298,1
CTID90938173,1
\.
analyze "falcon_db_15"."credit_card_fraud_base";
drop table if exists "falcon_db_15"."credit_card_transaction_base" cascade;
create table "falcon_db_15"."credit_card_transaction_base" ("Transaction_ID" text, "Transaction_Date" text, "Credit_Card_ID" text, "Transaction_Value" bigint, "Transaction_Segment" text);
copy "falcon_db_15"."credit_card_transaction_base" ("Transaction_ID", "Transaction_Date", "Credit_Card_ID", "Transaction_Value", "Transaction_Segment") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
CTID50558449,2016-05-06,4246-1369-3659-8804,6984,SEG23
CTID55936882,2016-11-29,1336-9200-1264-2551,34367,SEG21
CTID63762180,2016-12-05,8528-6154-7390-5081,44550,SEG15
CTID76723439,2016-09-15,7908-2695-7391-7499,48275,SEG16
CTID21246201,2016-02-29,2524-4184-5908-6750,35751,SEG25
CTID26555772,2016-01-11,5734-5619-8469-4044,683,SEG22
CTID20567160,2016-10-08,3295-6390-4452-7199,49155,SEG16
CTID54759604,2016-09-07,8262-8743-6406-7105,48567,SEG20
CTID44626561,2016-02-20,6321-2048-7733-8765,12894,SEG14
CTID73773088,2016-03-30,1661-3809-5334-2155,8060,SEG21
CTID62499873,2016-10-25,7752-7762-8832-3142,17038,SEG12
CTID70746134,2016-07-06,9873-6894-5872-1884,32189,SEG13
CTID29266043,2016-10-12,1947-8602-1695-7503,21713,SEG14
CTID97776833,2016-02-04,2640-5294-8252-8817,23744,SEG14
CTID16281374,2016-09-06,1947-8327-3848-6581,34290,SEG21
CTID81479835,2016-01-16,3295-6390-4452-7199,41525,SEG17
CTID20456246,2016-11-24,5591-5619-8809-5454,13032,SEG11
CTID28195227,2016-03-10,8231-5519-1948-3400,16857,SEG17
CTID42582298,2016-07-24,5145-7864-6575-8768,34619,SEG11
CTID90938173,2016-05-01,7586-6475-9618-3909,20660,SEG16
\.
analyze "falcon_db_15"."credit_card_transaction_base";
commit;
