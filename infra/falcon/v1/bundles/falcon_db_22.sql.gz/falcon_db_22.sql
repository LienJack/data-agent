\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_22";
drop table if exists "falcon_db_22"."ufc_country_data" cascade;
create table "falcon_db_22"."ufc_country_data" ("country" text, "country_code" text, "avg_temperature_celsius" double precision, "avg_elevation_meters" double precision, "gdp_2023_billion_usd" double precision, "unemployment_rate_2023" double precision, "total_population" bigint, "female_pop_total_percent" double precision, "male_pop_total_percent" double precision, "population_growth_2023" double precision, "working_age_pop_percent" double precision, "percent_of_internet_users" double precision, "percent_of_internet_users_2022" double precision, "dependency_ratio_2023" double precision);
copy "falcon_db_22"."ufc_country_data" ("country", "country_code", "avg_temperature_celsius", "avg_elevation_meters", "gdp_2023_billion_usd", "unemployment_rate_2023", "total_population", "female_pop_total_percent", "male_pop_total_percent", "population_growth_2023", "working_age_pop_percent", "percent_of_internet_users", "percent_of_internet_users_2022", "dependency_ratio_2023") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
Angola,AGO,21.77,1112.0,84.8246544817249,__FALCON_NULL_8FF29CAA__,36749906,50.5258870594118,49.4741129405882,3.08065530722915,52.6162856035605,__FALCON_NULL_8FF29CAA__,39.2935,90.0552252752265
Argentina,ARG,16.3,595.0,646.075277525125,6.139,45538401,50.3781775380778,49.6218224619222,0.286976121920089,65.6063209158354,89.229,88.3754,52.4243366823125
Australia,AUS,22.05,330.0,1728.05731669561,3.668,26658948,50.385263386718,49.614736613282,2.4474661688131,64.5856920862796,__FALCON_NULL_8FF29CAA__,94.8762,54.8330553856093
Austria,AUT,7.44,910.0,511.68520384500096,5.264,9131761,50.7795854937375,49.2204145062625,0.989464653969154,65.5333445996897,95.3347,93.6141,52.5940837665189
Brazil,BRA,25.44,320.0,2173.66565593727,7.947,211140729,50.7849283782666,49.2150716217334,0.395928695574996,69.4304164782911,84.1506,80.5278,44.0290947589819
Canada,CAN,4.03,487.0,2142.47091440136,5.415,40097761,50.3409161694882,49.6590838305118,2.93227401162387,65.3373373940366,__FALCON_NULL_8FF29CAA__,94.0,53.0518429291958
China,CHN,7.59,1840.0,17794.783039552,__FALCON_NULL_8FF29CAA__,1410710000,49.020738784951,50.979261215049,-0.103794531589067,69.0943118083391,77.4827,75.6113,44.7297141014082
Czechia,CZE,8.0,600.0,343.20787455373403,2.58,10864042,50.6906332515458,49.3093667484542,1.78238907045946,63.7804637975688,85.9941,84.5401,56.7878159701296
Dominican Republic,DOM,24.55,424.0,121.444279313931,5.555,11331265,50.2744618297726,49.7255381702274,0.891159203732232,65.5051370917044,__FALCON_NULL_8FF29CAA__,84.3832,52.6597760530361
Ecuador,ECU,21.43,1117.0,118.844826,3.51,17980083,50.139546074398,49.860453925602,0.872456027022398,66.9024275360687,72.6943,69.7181,49.4714073657307
France,FRA,11.65,375.0,3051.83161138476,7.335,68287487,51.5309189487273,48.4690810512727,0.326319200823468,61.4660792751563,86.8364,85.3333,62.6913590841452
Georgia,GEO,9.01,1432.0,30.7778335854441,__FALCON_NULL_8FF29CAA__,3715483,53.3969605188927,46.6030394811072,0.0802640328443946,63.6417358197995,81.8842,78.7113,57.1296262620538
Germany,DEU,9.59,263.0,4525.70390362753,3.068,83280000,50.6248191047309,49.3751808952691,-0.620053754616789,63.2943857808214,92.4764,91.6298,57.9918971859761
"Iran, Islamic Rep.",IRN,19.0,1305.0,404.625655204619,__FALCON_NULL_8FF29CAA__,90608707,49.164265738438,50.835734261562,1.20408185634218,69.2451333622938,__FALCON_NULL_8FF29CAA__,81.717,44.414481053557
Iraq,IRQ,22.95,312.0,250.842782139464,__FALCON_NULL_8FF29CAA__,45074049,49.8289692146361,50.1710307853639,2.25148890849618,59.5119000735878,__FALCON_NULL_8FF29CAA__,78.7156,68.0336199589456
Ireland,IRL,9.73,118.0,551.3948893397779,4.288,5307600,50.4950803703399,49.5049196296601,2.70991347020317,65.4412571224043,__FALCON_NULL_8FF29CAA__,95.5905,52.8088076099224
Italy,ITA,13.02,538.0,2300.94115299181,7.627,58993475,51.1550921316873,48.8449078683127,-0.0342216578672275,63.6367816692365,87.0278,85.0607,57.1418243823663
Jamaica,JAM,25.91,340.0,19.4233554092316,3.022,2839786,50.5335261178131,49.4664738821869,0.0226098931571573,73.0037052087728,__FALCON_NULL_8FF29CAA__,85.1185,36.9793488070563
Japan,JPN,11.78,438.0,4204.49480243155,2.6,124516650,51.1944087713668,48.8055912286332,-0.487370782049143,58.7888993029413,__FALCON_NULL_8FF29CAA__,84.9234,70.1001399306642
Kazakhstan,KAZ,7.11,387.0,262.641892078524,__FALCON_NULL_8FF29CAA__,20330104,51.3182840244341,48.6817159755659,1.46415151694869,62.1527464886554,92.8785,92.2969,60.893935746271
Kyrgyz Republic,KGZ,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,13.9876279088381,__FALCON_NULL_8FF29CAA__,7099750,50.5575586455166,49.4424413544834,1.76957754134087,61.9012922216683,__FALCON_NULL_8FF29CAA__,79.7703,61.5475158691892
Mexico,MEX,21.31,1111.0,1789.11443484346,2.765,129739759,51.4981899149497,48.5018100850503,0.872178517508623,67.0953820717364,81.1832,78.6322,49.0415538480472
Moldova,MDA,10.89,139.0,16.539436547295,1.555,2457783,53.9751945668015,46.0248054331985,-2.84274212689094,64.3930689550613,__FALCON_NULL_8FF29CAA__,63.5349,55.2962072281666
Myanmar,MMR,23.82,702.0,66.757619,__FALCON_NULL_8FF29CAA__,54133798,50.2044258968201,49.7955741031799,0.698879396261223,68.3951241366357,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,46.2092542209052
New Zealand,NZL,10.46,388.0,252.175506110168,3.729,5223100,50.3268130531904,49.6731869468096,2.04836808947608,64.8266830806157,__FALCON_NULL_8FF29CAA__,95.7299,54.2574901903802
Nigeria,NGA,27.3,380.0,363.8463328346179,__FALCON_NULL_8FF29CAA__,227882945,49.4446888072295,50.5553111927705,2.09838916935738,55.4796081821744,__FALCON_NULL_8FF29CAA__,35.4563,80.2464063402127
Poland,POL,8.78,173.0,809.200697797088,2.743,36687353,51.5394458672847,48.4605541327153,-0.365658526875775,65.3423219583981,86.4147,86.9411,53.040171083641
Russian Federation,RUS,-2.0,600.0,2021.42147603542,3.076,143826130,53.5651475788027,46.4348524211973,-0.285217600763343,65.8803755973048,92.245,90.418,51.7902694468508
South Africa,ZAF,18.23,1034.0,380.699271814508,32.098,63212384,51.3537141709447,48.6462858290553,1.32810094082844,67.4000079430639,__FALCON_NULL_8FF29CAA__,74.703,48.3679344695214
Spain,ESP,13.07,660.0,1620.09073495689,12.179,48347910,50.9003376636713,49.0996623363287,1.22528044685694,66.0876417150889,95.4456,94.4855,51.3142215787847
Suriname,SUR,26.58,246.0,3.4551462808397497,__FALCON_NULL_8FF29CAA__,628886,50.0149470651279,49.9850529348721,0.914027369002208,66.4321514551127,__FALCON_NULL_8FF29CAA__,75.7614,50.5295811461931
Sweden,SWE,3.23,320.0,584.96047576732,7.611,10536632,49.6419274843923,50.3580725156077,0.472717863265105,62.2137917151827,95.7033,95.0097,60.7360556550349
Switzerland,CHE,6.47,1350.0,884.9404022304091,4.043,8888093,50.3388680828642,49.6611319171358,1.25678260643691,65.3776294419259,97.3444,96.8046,52.9575232432572
Ukraine,UKR,9.27,175.0,178.757021965008,__FALCON_NULL_8FF29CAA__,37732836,53.5037970641804,46.4962029358196,-8.42300777431605,67.1469283033341,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,48.927142092575
United Arab Emirates,ARE,28.17,149.0,514.130432653081,2.151,10483751,35.9876794773503,64.0123205226497,3.97717097504667,81.9654257470884,100.0,100.0,22.0026623838262
United Kingdom,GBR,9.24,162.0,3380.85452080954,4.025,68350000,50.7700410474435,49.2299589525565,0.821212039762055,63.3527288517877,__FALCON_NULL_8FF29CAA__,95.3412,57.8463977881644
United States,USA,9.46,760.0,27720.709,3.638,334914895,49.7525187498981,50.2474812501019,0.491924871690548,64.9735428685564,__FALCON_NULL_8FF29CAA__,97.1299,53.9087996868543
Uzbekistan,UZB,13.06,450.0,101.591769702343,__FALCON_NULL_8FF29CAA__,35652307,49.5622709632788,50.4377290367212,2.02114614047908,63.4338978400472,89.0136,83.9,57.6444238962333
\.
analyze "falcon_db_22"."ufc_country_data";
drop table if exists "falcon_db_22"."ufc_events_stats" cascade;
create table "falcon_db_22"."ufc_events_stats" ("event_category" text, "fighter_1" text, "fighter_2" text, "date" text, "venue" text, "city" text, "state_province" text, "country" text, "attendance" double precision);
copy "falcon_db_22"."ufc_events_stats" ("event_category", "fighter_1", "fighter_2", "date", "venue", "city", "state_province", "country", "attendance") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
UFC on ESPN, Covington , Buckley,"Dec 14, 2024",Amalie Arena,Tampa,Florida,United States,18625.0
UFC 310, Pantoja , Asakura,"Dec 7, 2024",T-Mobile Arena,Las Vegas,Nevada,United States,18648.0
UFC Fight Night, Yan , Figueiredo,"Nov 23, 2024",Galaxy Arena,Macau,SAR,China,12615.0
UFC 309, Jones , Miocic,"Nov 16, 2024",Madison Square Garden,New York City,New York,United States,20200.0
UFC Fight Night, Magny , Prates,"Nov 9, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Moreno , Albazi,"Nov 2, 2024",Rogers Place,Edmonton,Alberta,Canada,16439.0
UFC 308, Topuria , Holloway,"Oct 26, 2024",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Hernandez , Pereira,"Oct 19, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Royval , Taira,"Oct 12, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 307, Pereira , Rountree Jr.,"Oct 5, 2024",Delta Center,Salt Lake City,Utah,United States,17487.0
UFC Fight Night, Moicano , Saint Denis,"Sep 28, 2024",Accor Arena,Paris,__FALCON_NULL_8FF29CAA__,France,15449.0
UFC 306, O'Malley , Dvalishvili,"Sep 14, 2024",Sphere,Las Vegas,Nevada,United States,16024.0
UFC Fight Night, Burns , Brady,"Sep 7, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Cannonier , Borralho,"Aug 24, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 305, du Plessis , Adesanya,"Aug 18, 2024",RAC Arena,Perth,__FALCON_NULL_8FF29CAA__,Australia,14152.0
UFC on ESPN, Tybura , Spivac ,"Aug 10, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ABC, Sandhagen , Nurmagomedov,"Aug 3, 2024",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,__FALCON_NULL_8FF29CAA__
UFC 304, Edwards , Muhammad ,"Jul 27, 2024",Co-op Live,Manchester,England,United Kingdom,17907.0
UFC on ESPN, Lemos , Jandiroba,"Jul 20, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Namajunas , Cortez,"Jul 13, 2024",Ball Arena,Denver,Colorado,United States,16884.0
UFC 303, Pereira , Procházka ,"Jun 29, 2024",T-Mobile Arena,Las Vegas,Nevada,United States,18881.0
UFC on ABC, Whittaker , Aliskerov,"Jun 22, 2024",Kingdom Arena,Riyadh,__FALCON_NULL_8FF29CAA__,Saudi Arabia,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Perez , Taira,"Jun 15, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Cannonier , Imavov,"Jun 8, 2024",KFC Yum! Center,Louisville,Kentucky,United States,19578.0
UFC 302, Makhachev , Poirier,"Jun 1, 2024",Prudential Center,Newark,New Jersey,United States,17834.0
UFC Fight Night, Barboza , Murphy,"May 18, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Lewis , Nascimento,"May 11, 2024",Enterprise Center,St. Louis,Missouri,United States,15960.0
UFC 301, Pantoja , Erceg,"May 4, 2024",Farmasi Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,14514.0
UFC on ESPN, Nicolau , Perez,"Apr 27, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 300, Pereira , Hill,"Apr 13, 2024",T-Mobile Arena,Las Vegas,Nevada,United States,20067.0
UFC Fight Night, Allen , Curtis ,"Apr 6, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Blanchfield , Fiorot,"Mar 30, 2024",Boardwalk Hall,Atlantic City,New Jersey,United States,12198.0
UFC on ESPN, Ribas , Namajunas,"Mar 23, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Tuivasa , Tybura,"Mar 16, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 299, O'Malley , Vera ,"Mar 9, 2024",Kaseya Center,Miami,Florida,United States,19165.0
UFC Fight Night, Rozenstruik , Gaziev,"Mar 2, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Moreno , Royval ,"Feb 24, 2024",Arena CDMX,Mexico City,__FALCON_NULL_8FF29CAA__,Mexico,21546.0
UFC 298, Volkano,i vs. Topuria,"Feb 17, 2024",Honda Center,Anaheim,California,United States,18186.0
UFC Fight Night, Hermansson , Pyfer,"Feb 10, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Dolidze , Imavov,"Feb 3, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 297, Strickland , du Plessis,"Jan 20, 2024",Scotiabank Arena,Toronto,Ontario,Canada,18559.0
UFC Fight Night, Ankalaev , Walker ,"Jan 13, 2024",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 296, Edwards , Covington,"Dec 16, 2023",T-Mobile Arena,Las Vegas,Nevada,United States,19039.0
UFC Fight Night, Song , Gutiérrez,"Dec 9, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Dariush , Tsarukyan,"Dec 2, 2023",Moody Center,Austin,Texas,United States,14485.0
UFC Fight Night, Allen , Craig,"Nov 18, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 295, Procházka , Pereira,"Nov 11, 2023",Madison Square Garden,New York City,New York,United States,19039.0
UFC Fight Night, Almeida , Lewis,"Nov 4, 2023",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,10792.0
UFC 294, Makhachev , Volkanovski ,"Oct 21, 2023",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Yusuff , Barboza,"Oct 14, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Dawson , Green,"Oct 7, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Fiziev , Gamrot,"Sep 23, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Grasso , Shevchenko ,"Sep 16, 2023",T-Mobile Arena,Las Vegas,Nevada,United States,18766.0
UFC 293, Adesanya , Strickland,"Sep 10, 2023",Qudos Bank Arena,Sydney,__FALCON_NULL_8FF29CAA__,Australia,18168.0
UFC Fight Night, Gane , Spivac,"Sep 2, 2023",Accor Arena,Paris,__FALCON_NULL_8FF29CAA__,France,15610.0
UFC Fight Night, Holloway , The Korean Zombie,"Aug 26, 2023",Singapore Indoor Stadium,Kallang,__FALCON_NULL_8FF29CAA__,Singapore,10263.0
UFC 292, Sterling , O'Malley,"Aug 19, 2023",TD Garden,Boston,Massachusetts,United States,18293.0
UFC on ESPN, Luque , dos Anjos,"Aug 12, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Sandhagen , Font,"Aug 5, 2023",Bridgestone Arena,Nashville,Tennessee,United States,17792.0
UFC 291, Poirier , Gaethje ,"Jul 29, 2023",Delta Center,Salt Lake City,Utah,United States,18467.0
UFC Fight Night, Aspinall , Tybura,"Jul 22, 2023",The O2 Arena,London,England,United Kingdom,15078.0
UFC on ESPN, Holm , Bueno Silva,"Jul 15, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 290, Volkano,i vs. Rodríguez,"Jul 8, 2023",T-Mobile Arena,Las Vegas,Nevada,United States,19204.0
UFC on ESPN, Strickland , Magomedov,"Jul 1, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ABC, Emmett , Topuria,"Jun 24, 2023",VyStar Veterans Memorial Arena,Jacksonville,Florida,United States,14101.0
UFC on ESPN, Vettori , Cannonier,"Jun 17, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 289, Nunes , Aldana,"Jun 10, 2023",Rogers Arena,Vancouver,British Columbia,Canada,17628.0
UFC on ESPN, Kara-France , Albazi,"Jun 3, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Dern , Hill,"May 20, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ABC, Rozenstruik , Almeida,"May 13, 2023",Spectrum Center,Charlotte,North Carolina,United States,18712.0
UFC 288, Sterling , Cejudo,"May 6, 2023",Prudential Center,Newark,New Jersey,United States,17559.0
UFC on ESPN, Song , Simón,"Apr 29, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Pavlovich , Blaydes,"Apr 22, 2023",UFC Apex,Las Vegas,Nevada,United States,91.0
UFC on ESPN, Holloway , Allen,"Apr 15, 2023",T-Mobile Center,Kansas City,Missouri,United States,16234.0
UFC 287, Pereira , Adesanya ,"Apr 8, 2023",Kaseya Center,Miami,Florida,United States,19032.0
UFC on ESPN, Vera , Sandhagen,"Mar 25, 2023",Frost Bank Center,San Antonio,Texas,United States,16076.0
UFC 286, Edwards , Usman ,"Mar 18, 2023",The O2 Arena,London,England,United Kingdom,17588.0
UFC Fight Night, Yan , Dvalishvili,"Mar 11, 2023",The Theater at Virgin Hotels,Las Vegas,Nevada,United States,2361.0
UFC 285, Jones , Gane,"Mar 4, 2023",T-Mobile Arena,Las Vegas,Nevada,United States,19471.0
UFC Fight Night, Muniz , Allen,"Feb 25, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Andrade , Blanchfield,"Feb 18, 2023",UFC Apex,Las Vegas,Nevada,United States,99.0
UFC 284, Makhachev , Volkanovski,"Feb 12, 2023",RAC Arena,Perth,__FALCON_NULL_8FF29CAA__,Australia,14124.0
UFC Fight Night, Lewis , Spivac,"Feb 4, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 283, Teixeira , Hill,"Jan 21, 2023",Jeunesse Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,13604.0
UFC Fight Night, Strickland , Imavov,"Jan 14, 2023",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Cannonier , Strickland,"Dec 17, 2022",UFC Apex,Las Vegas,Nevada,United States,104.0
UFC 282, Błachowicz , Ankalaev,"Dec 10, 2022",T-Mobile Arena,Las Vegas,Nevada,United States,18455.0
UFC on ESPN, Thompson , Holland,"Dec 3, 2022",Kia Center,Orlando,Florida,United States,17065.0
UFC Fight Night, Nzechukwu , Cuțelaba,"Nov 19, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 281, Adesanya , Pereira,"Nov 12, 2022",Madison Square Garden,New York City,New York,United States,20845.0
UFC Fight Night, Rodriguez , Lemos,"Nov 5, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Kattar , Allen,"Oct 29, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 280, Oliveira , Makhachev,"Oct 22, 2022",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,13400.0
UFC Fight Night, Grasso , Araújo,"Oct 15, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Dern , Yan,"Oct 1, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Sandhagen , Song,"Sep 17, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 279, Diaz , Ferguson,"Sep 10, 2022",T-Mobile Arena,Las Vegas,Nevada,United States,19125.0
UFC Fight Night, Gane , Tuivasa,"Sep 3, 2022",Accor Arena,Paris,__FALCON_NULL_8FF29CAA__,France,15405.0
UFC 278, Usman , Edwards ,"Aug 20, 2022",Vivint Arena,Salt Lake City,Utah,United States,18321.0
UFC on ESPN, Vera , Cruz,"Aug 13, 2022",Pechanga Arena,San Diego,California,United States,12804.0
UFC on ESPN, Santos , Hill,"Aug 6, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 277, Peña , Nunes ,"Jul 30, 2022",American Airlines Center,Dallas,Texas,United States,19442.0
UFC Fight Night, Blaydes , Aspinall,"Jul 23, 2022",The O2 Arena,London,England,United Kingdom,17813.0
UFC on ABC, Ortega , Rodríguez,"Jul 16, 2022",UBS Arena,Hempstead,New York,United States,16979.0
UFC on ESPN, dos Anjos , Fiziev,"Jul 9, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 276, Adesanya , Cannonier,"Jul 2, 2022",T-Mobile Arena,Las Vegas,Nevada,United States,19649.0
UFC on ESPN, Tsarukyan , Gamrot,"Jun 25, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Kattar , Emmett,"Jun 18, 2022",Moody Center,Austin,Texas,United States,13689.0
UFC 275, Teixeira , Procházka,"Jun 12, 2022",Singapore Indoor Stadium,Kallang,__FALCON_NULL_8FF29CAA__,Singapore,10787.0
UFC Fight Night, Volkov , Rozenstruik,"Jun 4, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Holm , Vieira,"May 21, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Błachowicz , Rakić,"May 14, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 274, Oliveira , Gaethje,"May 7, 2022",Footprint Center,Phoenix,Arizona,United States,17232.0
UFC on ESPN, Font , Vera,"Apr 30, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Lemos , Andrade,"Apr 23, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Luque , Muhammad ,"Apr 16, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 273, Volkano,i vs. The Korean Zombie,"Apr 9, 2022",VyStar Veterans Memorial Arena,Jacksonville,Florida,United States,14605.0
UFC on ESPN, Blaydes , Daukaus,"Mar 26, 2022",Nationwide Arena,Columbus,Ohio,United States,18630.0
UFC Fight Night, Volkov , Aspinall,"Mar 19, 2022",The O2 Arena,London,England,United Kingdom,17081.0
UFC Fight Night, Santos , Ankalaev,"Mar 12, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 272, Covington , Masvidal,"Mar 5, 2022",T-Mobile Arena,Las Vegas,Nevada,United States,19425.0
UFC Fight Night, Makhachev , Green,"Feb 26, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Walker , Hill,"Feb 19, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 271, Adesanya , Whittaker ,"Feb 12, 2022",Toyota Center,Houston,Texas,United States,17872.0
UFC Fight Night, Hermansson , Strickland,"Feb 5, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 270, Ngannou , Gane,"Jan 22, 2022",Honda Center,Anaheim,California,United States,17387.0
UFC on ESPN, Kattar , Chikadze,"Jan 15, 2022",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Lewis , Daukaus,"Dec 18, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 269, Oliveira , Poirier,"Dec 11, 2021",T-Mobile Arena,Las Vegas,Nevada,United States,18471.0
UFC on ESPN, Font , Aldo,"Dec 4, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Vieira , Tate,"Nov 20, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Holloway , Rodríguez,"Nov 13, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 268, Usman , Covington ,"Nov 6, 2021",Madison Square Garden,New York City,New York,United States,20715.0
UFC 267, Błachowicz , Teixeira,"Oct 30, 2021",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,10171.0
UFC Fight Night, Costa , Vettori,"Oct 23, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Ladd , Dumont,"Oct 16, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Dern , Rodriguez,"Oct 9, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Santos , Walker,"Oct 2, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 266, Volkano,i vs. Ortega,"Sep 25, 2021",T-Mobile Arena,Las Vegas,Nevada,United States,19029.0
UFC Fight Night, Smith , Spann,"Sep 18, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Brunson , Till,"Sep 4, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Barboza , Chikadze,"Aug 28, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Cannonier , Gastelum,"Aug 21, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 265, Lewis , Gane,"Aug 7, 2021",Toyota Center,Houston,Texas,United States,16604.0
UFC on ESPN, Hall , Strickland,"Jul 31, 2021",UFC Apex,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Sandhagen , Dillashaw,"Jul 24, 2021",UFC Apex,Las Vegas,Nevada,United States,51.0
UFC on ESPN, Makhachev , Moisés,"Jul 17, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 264, Poirier , McGregor ,"Jul 10, 2021",T-Mobile Arena,Las Vegas,Nevada,United States,20062.0
UFC Fight Night, Gane , Volkov,"Jun 26, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, The Korean Zombie , Ige,"Jun 19, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 263, Adesanya , Vettori ,"Jun 12, 2021",Gila River Arena,Glendale,Arizona,United States,17208.0
UFC Fight Night, Rozenstruik , Sakai,"Jun 5, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Font , Garbrandt,"May 22, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 262, Oliveira , Chandler,"May 15, 2021",Toyota Center,Houston,Texas,United States,16005.0
UFC on ESPN, Rodriguez , Waterson,"May 8, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Reyes , Procházka,"May 1, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 261, Usman , Masvidal ,"Apr 24, 2021",VyStar Veterans Memorial Arena,Jacksonville,Florida,United States,15269.0
UFC on ESPN, Whittaker , Gastelum,"Apr 17, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ABC, Vettori , Holland,"Apr 10, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 260, Miocic , Ngannou ,"Mar 27, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Brunson , Holland,"Mar 20, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Edwards , Muhammad,"Mar 13, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 259, Błachowicz , Adesanya,"Mar 6, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Rozenstruik , Gane,"Feb 27, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Blaydes , Lewis,"Feb 20, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 258, Usman , Burns,"Feb 13, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Overeem , Volkov,"Feb 6, 2021",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 257, Poirier , McGregor ,"Jan 24, 2021",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,2600.0
UFC on ESPN, Chiesa , Magny,"Jan 20, 2021",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,2000.0
UFC on ABC, Holloway , Kattar,"Jan 16, 2021",Etihad Arena,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,2000.0
UFC Fight Night, Thompson , Neal,"Dec 19, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 256, Figueiredo , Moreno,"Dec 12, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Hermansson , Vettori,"Dec 5, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Smith , Clark,"Nov 28, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 255, Figueiredo , Perez,"Nov 21, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Felder , dos Anjos,"Nov 14, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Santos , Teixeira,"Nov 7, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Hall , Silva,"Oct 31, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 254, Khabib , Gaethje,"Oct 24, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC Fight Night, Ortega , The Korean Zombie,"Oct 18, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC Fight Night, Moraes , Sandhagen,"Oct 11, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC on ESPN, Holm , Aldana,"Oct 4, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC 253, Adesanya , Costa,"Sep 27, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC Fight Night, Covington , Woodley,"Sep 19, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Waterson , Hill,"Sep 12, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Overeem , Sakai,"Sep 5, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Smith , Rakić,"Aug 29, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Munhoz , Edgar,"Aug 22, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 252, Miocic , Cormier ,"Aug 15, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Lewis , Oleinik,"Aug 8, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC Fight Night, Brunson , Shahbazyan,"Aug 1, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Whittaker , Till,"Jul 26, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC Fight Night, Figueiredo , Benavidez ,"Jul 19, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC on ESPN, Kattar , Ige,"Jul 16, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC 251, Usman , Masvidal,"Jul 12, 2020",du Forum,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,0.0
UFC on ESPN, Poirier , Hooker,"Jun 27, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Blaydes , Volkov,"Jun 20, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Eye , Calvillo,"Jun 13, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC 250, Nunes , Spencer,"Jun 6, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Woodley , Burns,"May 30, 2020",UFC Apex,Las Vegas,Nevada,United States,0.0
UFC on ESPN, Overeem , Harris,"May 16, 2020",VyStar Veterans Memorial Arena,Jacksonville,Florida,United States,0.0
UFC Fight Night, Smith , Teixeira,"May 13, 2020",VyStar Veterans Memorial Arena,Jacksonville,Florida,United States,0.0
UFC 249, Ferguson , Gaethje,"May 9, 2020",VyStar Veterans Memorial Arena,Jacksonville,Florida,United States,0.0
UFC Fight Night, Hermansson , Weidman,"May 2, 2020",Chesapeake Energy Arena,Oklahoma City,Oklahoma,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Smith , Teixeira,"Apr 25, 2020",Pinnacle Bank Arena,Lincoln,Nebraska,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Overeem , Harris,"Apr 11, 2020",Moda Center,Portland,Oregon,United States,__FALCON_NULL_8FF29CAA__
UFC on ESPN, Ngannou , Rozenstruik,"Mar 28, 2020",Nationwide Arena,Columbus,Ohio,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Woodley , Edwards,"Mar 21, 2020",The O2 Arena,London,England,United Kingdom,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Lee , Oliveira,"Mar 14, 2020",Ginásio Nilson Nelson,Brasília,__FALCON_NULL_8FF29CAA__,Brazil,0.0
UFC 248, Adesanya , Romero,"Mar 7, 2020",T-Mobile Arena,Las Vegas,Nevada,United States,15077.0
UFC Fight Night, Benavidez , Figueiredo,"Feb 29, 2020",Chartway Arena,Norfolk,Virginia,United States,7098.0
UFC Fight Night, Felder , Hooker,"Feb 23, 2020",Spark Arena,Auckland,__FALCON_NULL_8FF29CAA__,New Zealand,10025.0
UFC Fight Night, Anderson , Błachowicz ,"Feb 15, 2020",Santa Ana Star Center,Rio Rancho,New Mexico,United States,6449.0
UFC 247, Jones , Reyes,"Feb 8, 2020",Toyota Center,Houston,Texas,United States,17401.0
UFC Fight Night, Blaydes , dos Santos,"Jan 25, 2020",PNC Arena,Raleigh,North Carolina,United States,14533.0
UFC 246, McGregor , Cowboy,"Jan 18, 2020",T-Mobile Arena,Las Vegas,Nevada,United States,19040.0
UFC Fight Night, Edgar , The Korean Zombie,"Dec 21, 2019",Sajik Arena,Busan,__FALCON_NULL_8FF29CAA__,South Korea,10651.0
UFC 245, Usman , Covington,"Dec 14, 2019",T-Mobile Arena,Las Vegas,Nevada,United States,16811.0
UFC on ESPN, Overeem , Rozenstruik,"Dec 7, 2019",Capital One Arena,Washington,D.C.,United States,10816.0
UFC Fight Night, Błachowicz , Jacaré,"Nov 16, 2019",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,10344.0
UFC Fight Night, Magomedsharipov , Kattar,"Nov 9, 2019",CSKA Arena,Moscow,__FALCON_NULL_8FF29CAA__,Russia,11305.0
UFC 244, Masvidal , Diaz,"Nov 2, 2019",Madison Square Garden,New York City,New York,United States,20143.0
UFC Fight Night, Maia , Askren,"Oct 26, 2019",Singapore Indoor Stadium,Kallang,__FALCON_NULL_8FF29CAA__,Singapore,7155.0
UFC on ESPN, Reyes , Weidman,"Oct 18, 2019",TD Garden,Boston,Massachusetts,United States,12066.0
UFC Fight Night, Joanna , Waterson,"Oct 12, 2019",Amalie Arena,Tampa,Florida,United States,10597.0
UFC 243, Whittaker , Adesanya,"Oct 5, 2019",Marvel Stadium,Melbourne,__FALCON_NULL_8FF29CAA__,Australia,57127.0
UFC Fight Night, Hermansson , Cannonier,"Sep 28, 2019",Royal Arena,Copenhagen,__FALCON_NULL_8FF29CAA__,Denmark,12767.0
UFC Fight Night, Rodríguez , Stephens,"Sep 21, 2019",Arena Ciudad de México,Mexico City,__FALCON_NULL_8FF29CAA__,Mexico,10112.0
UFC Fight Night, Cowboy , Gaethje,"Sep 14, 2019",Rogers Arena,Vancouver,British Columbia,Canada,15114.0
UFC 242, Khabib , Poirier,"Sep 7, 2019","The Arena, Yas Island",Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Andrade , Zhang,"Aug 31, 2019",Shenzhen Universiade Sports Centre,Shenzhen,__FALCON_NULL_8FF29CAA__,China,10302.0
UFC 241, Cormier , Miocic ,"Aug 17, 2019",Honda Center,Anaheim,California,United States,17304.0
UFC Fight Night, Shevchenko , Carmouche ,"Aug 10, 2019",Antel Arena,Montevideo,__FALCON_NULL_8FF29CAA__,Uruguay,9225.0
UFC on ESPN, Covington , Lawler,"Aug 3, 2019",Prudential Center,Newark,New Jersey,United States,10427.0
UFC 240, Holloway , Edgar,"Jul 27, 2019",Rogers Place,Edmonton,Alberta,Canada,12144.0
UFC on ESPN, dos Anjos , Edwards,"Jul 20, 2019",AT&T Center,San Antonio,Texas,United States,9255.0
UFC Fight Night, de Randamie , Ladd,"Jul 13, 2019",Golden 1 Center,Sacramento,California,United States,10306.0
UFC 239, Jones , Santos,"Jul 6, 2019",T-Mobile Arena,Las Vegas,Nevada,United States,18358.0
UFC on ESPN, Ngannou , dos Santos,"Jun 29, 2019",Target Center,Minneapolis,Minnesota,United States,10123.0
UFC Fight Night, Moicano , The Korean Zombie,"Jun 22, 2019",Bon Secours Wellness Arena,Greenville,South Carolina,United States,7682.0
UFC 238, Cejudo , Moraes,"Jun 8, 2019",United Center,Chicago,Illinois,United States,16083.0
UFC Fight Night, Gustafsson , Smith,"Jun 1, 2019",Avicii Arena,Stockholm,__FALCON_NULL_8FF29CAA__,Sweden,14319.0
UFC Fight Night, dos Anjos , Lee,"May 18, 2019",Blue Cross Arena,Rochester,New York,United States,8132.0
UFC 237, Namajunas , Andrade,"May 11, 2019",Jeunesse Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,15193.0
UFC Fight Night, Iaquinta , Cowboy,"May 4, 2019",Canadian Tire Centre,Ottawa,Ontario,Canada,10960.0
UFC Fight Night, Jacaré , Hermansson,"Apr 27, 2019",Amerat Bank Arena,Sunrise,Florida,United States,12754.0
UFC Fight Night, Overeem , Oleinik,"Apr 20, 2019",Yubileyny Sports Palace,Saint Petersburg,__FALCON_NULL_8FF29CAA__,Russia,7236.0
UFC 236, Holloway , Poirier ,"Apr 13, 2019",State Farm Arena,Atlanta,Georgia,United States,14297.0
UFC on ESPN, Barboza , Gaethje,"Mar 30, 2019",Wells Fargo Center,Philadelphia,Pennsylvania,United States,11123.0
UFC Fight Night, Thompson , Pettis,"Mar 23, 2019",Bridgestone Arena,Nashville,Tennessee,United States,10863.0
UFC Fight Night, Till , Masvidal,"Mar 16, 2019",The O2 Arena,London,England,United Kingdom,16602.0
UFC Fight Night, Lewis , dos Santos,"Mar 9, 2019",Intrust Bank Arena,Wichita,Kansas,United States,7265.0
UFC 235, Jones , Smith,"Mar 2, 2019",T-Mobile Arena,Las Vegas,Nevada,United States,14790.0
UFC Fight Night, Błachowicz , Santos,"Feb 23, 2019",O2 Arena,Prague,__FALCON_NULL_8FF29CAA__,Czech Republic,16583.0
UFC on ESPN, Ngannou , Velasquez,"Feb 17, 2019",Talking Stick Resort Arena,Phoenix,Arizona,United States,14269.0
UFC 234, Adesanya , Silva,"Feb 10, 2019",Rod Laver Arena,Melbourne,__FALCON_NULL_8FF29CAA__,Australia,15238.0
UFC Fight Night, Assunção , Moraes ,"Feb 2, 2019",Centro de Formação Olímpica do Nordeste,Fortaleza,__FALCON_NULL_8FF29CAA__,Brazil,10040.0
UFC 233, Cejudo , Dillashaw,"Jan 26, 2019",Honda Center,Anaheim,California,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Cejudo , Dillashaw,"Jan 19, 2019",Barclays Center,New York,New York,United States,12152.0
UFC 232, Jones , Gustafsson ,"Dec 29, 2018",The Forum,Inglewood,California,United States,15862.0
UFC on Fox, Lee , Iaquinta ,"Dec 15, 2018",Fiserv Forum,Milwaukee,Wisconsin,United States,9010.0
UFC 231, Holloway , Ortega,"Dec 8, 2018",Scotiabank Arena,Toronto,Ontario,Canada,19039.0
UFC Fight Night, dos Santos , Tuivasa,"Dec 2, 2018",Adelaide Entertainment Centre,Adelaide,__FALCON_NULL_8FF29CAA__,Australia,8652.0
The Ultimate Fighter, Heavy Hitters Finale,__FALCON_NULL_8FF29CAA__,"Nov 30, 2018",Pearl Theatre,Las Vegas,Nevada,United States,2020.0
UFC Fight Night, Blaydes , Ngannou ,"Nov 24, 2018",Cadillac Arena,Beijing,__FALCON_NULL_8FF29CAA__,China,10302.0
UFC Fight Night, Magny , Ponzinibbio,"Nov 17, 2018",Estadio Mary Terán de Weiss,Buenos Aires,__FALCON_NULL_8FF29CAA__,Argentina,10245.0
UFC Fight Night, The Korean Zombie , Rodríguez,"Nov 10, 2018",Pepsi Center,Denver,Colorado,United States,11426.0
UFC 230, Cormier , Lewis,"Nov 3, 2018",Madison Square Garden,New York City,New York,United States,17011.0
UFC Fight Night, Volkan , Smith,"Oct 27, 2018",Avenir Centre,Moncton,New Brunswick,Canada,6282.0
UFC 229, Khabib , McGregor,"Oct 6, 2018",T-Mobile Arena,Las Vegas,Nevada,United States,20034.0
UFC Fight Night, Santos , Anders,"Sep 22, 2018",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,9485.0
UFC Fight Night, Hunt , Oleinik,"Sep 15, 2018",Olimpiyskiy Stadium,Moscow,__FALCON_NULL_8FF29CAA__,Russia,22603.0
UFC 228, Woodley , Till,"Sep 8, 2018",American Airlines Center,Dallas,Texas,United States,14073.0
UFC Fight Night, Gaethje , Vick,"Aug 25, 2018",Pinnacle Bank Arena,Lincoln,Nebraska,United States,6409.0
UFC 227, Dillashaw , Garbrandt ,"Aug 4, 2018",Staples Center,Los Angeles,California,United States,17794.0
UFC on Fox, Alvarez , Poirier ,"Jul 28, 2018",Scotiabank Saddledome,Calgary,Alberta,Canada,10603.0
UFC Fight Night, Shogun , Smith,"Jul 22, 2018",Barclaycard Arena,Hamburg,__FALCON_NULL_8FF29CAA__,Germany,7798.0
UFC Fight Night, dos Santos , Ivanov,"Jul 14, 2018",CenturyLink Arena,Boise,Idaho,United States,5648.0
UFC 226, Miocic , Cormier,"Jul 7, 2018",T-Mobile Arena,Las Vegas,Nevada,United States,17464.0
The Ultimate Fighter, Undefeated Finale,__FALCON_NULL_8FF29CAA__,"Jul 6, 2018",Palms Casino Resort,Las Vegas,Nevada,United States,2123.0
UFC Fight Night, Cowboy , Edwards,"Jun 23, 2018",Singapore Indoor Stadium,Kallang,__FALCON_NULL_8FF29CAA__,Singapore,6419.0
UFC 225, Whittaker , Romero ,"Jun 9, 2018",United Center,Chicago,Illinois,United States,18117.0
UFC Fight Night, Rivera , Moraes,"Jun 1, 2018",Adirondack Bank Center,Utica,New York,United States,5063.0
UFC Fight Night, Thompson , Till,"May 27, 2018",Echo Arena,Liverpool,England,United Kingdom,8520.0
UFC Fight Night, Maia , Usman,"May 19, 2018",Movistar Arena,Santiago,__FALCON_NULL_8FF29CAA__,Chile,11082.0
UFC 224, Nunes , Pennington,"May 12, 2018",Jeunesse Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,10696.0
UFC Fight Night, Barboza , Lee,"Apr 21, 2018",Boardwalk Hall,Atlantic City,New Jersey,United States,9541.0
UFC on Fox, Poirier , Gaethje,"Apr 14, 2018",Gila River Arena,Glendale,Arizona,United States,11382.0
UFC 223, Khabib , Iaquinta,"Apr 7, 2018",Barclays Center,New York,New York,United States,17026.0
UFC Fight Night, Werdum , Volkov,"Mar 17, 2018",The O2 Arena,London,England,United Kingdom,16274.0
UFC 222, Cyborg , Kunitskaya,"Mar 3, 2018",T-Mobile Arena,Las Vegas,Nevada,United States,12041.0
UFC on Fox, Emmett , Stephens,"Feb 24, 2018",Amway Center,Orlando,Florida,United States,10124.0
UFC Fight Night, Cowboy , Medeiros,"Feb 18, 2018",Frank Erwin Center,Austin,Texas,United States,10502.0
UFC 221, Romero , Rockhold,"Feb 11, 2018",Perth Arena,Perth,__FALCON_NULL_8FF29CAA__,Australia,12437.0
UFC Fight Night, Machida , Anders,"Feb 3, 2018",Arena Guilherme Paraense,Belém,__FALCON_NULL_8FF29CAA__,Brazil,10144.0
UFC on Fox, Jacaré , Brunson ,"Jan 27, 2018",Spectrum Center,Charlotte,North Carolina,United States,10249.0
UFC 220, Miocic , Ngannou,"Jan 20, 2018",TD Garden,Boston,Massachusetts,United States,16015.0
UFC Fight Night, Stephens , Choi,"Jan 14, 2018",Scottrade Center,St. Louis,Missouri,United States,10052.0
UFC 219, Cyborg , Holm,"Dec 30, 2017",T-Mobile Arena,Las Vegas,Nevada,United States,13561.0
UFC on Fox, Lawler , dos Anjos,"Dec 16, 2017",Canada Life Centre,Winnipeg,Manitoba,Canada,8862.0
UFC Fight Night, Swanson , Ortega,"Dec 9, 2017",Save Mart Center,Fresno,California,United States,7605.0
UFC 218, Holloway , Aldo ,"Dec 2, 2017",Little Caesars Arena,Detroit,Michigan,United States,17587.0
The Ultimate Fighter, A New World Champion Finale,__FALCON_NULL_8FF29CAA__,"Dec 1, 2017",Park Theater,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Bisping , Gastelum,"Nov 25, 2017",Mercedes-Benz Arena,Shanghai,__FALCON_NULL_8FF29CAA__,China,15128.0
UFC Fight Night, Werdum , Tybura,"Nov 19, 2017",Qudos Bank Arena,Sydney,__FALCON_NULL_8FF29CAA__,Australia,10021.0
UFC Fight Night, Poirier , Pettis,"Nov 11, 2017",Ted Constant Convocation Center,Norfolk,Virginia,United States,8442.0
UFC 217, Bisping , St-Pierre,"Nov 4, 2017",Madison Square Garden,New York City,New York,United States,18201.0
UFC Fight Night, Brunson , Machida,"Oct 28, 2017",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,10265.0
UFC Fight Night, Cowboy , Till,"Oct 21, 2017",Ergo Arena,Gdańsk,__FALCON_NULL_8FF29CAA__,Poland,11138.0
UFC 216, Ferguson , Lee,"Oct 7, 2017",T-Mobile Arena,Las Vegas,Nevada,United States,10638.0
UFC Fight Night, Saint Preux , Okami,"Sep 23, 2017",Saitama Super Arena,Saitama,__FALCON_NULL_8FF29CAA__,Japan,8571.0
UFC Fight Night, Rockhold , Branch,"Sep 16, 2017",PPG Paints Arena,Pittsburgh,Pennsylvania,United States,7005.0
UFC 215, Nunes , Shevchenko ,"Sep 9, 2017",Rogers Place,Edmonton,Alberta,Canada,16232.0
UFC Fight Night, Volkov , Struve,"Sep 2, 2017",Rotterdam Ahoy,Rotterdam,__FALCON_NULL_8FF29CAA__,Netherlands,10224.0
UFC Fight Night, Pettis , Moreno,"Aug 5, 2017",Arena Ciudad de México,Mexico City,__FALCON_NULL_8FF29CAA__,Mexico,10172.0
UFC 214, Cormier , Jones ,"Jul 29, 2017",Honda Center,Anaheim,California,United States,16610.0
UFC on Fox, Weidman , Gastelum,"Jul 22, 2017",Nassau Veterans Memorial Coliseum,Hempstead,New York,United States,11198.0
UFC Fight Night, Nelson , Ponzinibbio,"Jul 16, 2017",The SSE Hydro,Glasgow,Scotland,United Kingdom,10589.0
UFC 213, Romero , Whittaker,"Jul 8, 2017",T-Mobile Arena,Las Vegas,Nevada,United States,12834.0
The Ultimate Fighter, Redemption Finale,__FALCON_NULL_8FF29CAA__,"Jul 7, 2017",T-Mobile Arena,Las Vegas,Nevada,United States,6308.0
UFC Fight Night, Chiesa , Lee,"Jun 25, 2017",Chesapeake Energy Arena,Oklahoma City,Oklahoma,United States,7605.0
UFC Fight Night, Holm , Correia,"Jun 17, 2017",Singapore Indoor Stadium,Kallang,__FALCON_NULL_8FF29CAA__,Singapore,8414.0
UFC Fight Night, Lewis , Hunt,"Jun 11, 2017",Spark Arena,Auckland,__FALCON_NULL_8FF29CAA__,New Zealand,8649.0
UFC 212, Aldo , Holloway,"Jun 3, 2017",Jeunesse Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,15412.0
UFC Fight Night, Gustafsson , Teixeira,"May 28, 2017",Ericsson Globe,Stockholm,__FALCON_NULL_8FF29CAA__,Sweden,12668.0
UFC 211, Miocic , dos Santos ,"May 13, 2017",American Airlines Center,Dallas,Texas,United States,17834.0
UFC Fight Night, Swanson , Lobov,"Apr 22, 2017",Bridgestone Arena,Nashville,Tennessee,United States,10144.0
UFC on Fox, Johnson , Reis,"Apr 15, 2017",Sprint Center,Kansas City,Missouri,United States,12171.0
UFC 210, Cormier , Johnson ,"Apr 8, 2017",KeyBank Center,Buffalo,New York,United States,17110.0
UFC Fight Night, Manuwa , Anderson,"Mar 18, 2017",The O2 Arena,London,England,United Kingdom,15761.0
UFC Fight Night, Belfort , Gastelum,"Mar 11, 2017",Centro de Formação Olímpica do Nordeste,Fortaleza,__FALCON_NULL_8FF29CAA__,Brazil,14069.0
UFC 209, Woodley , Thompson ,"Mar 4, 2017",T-Mobile Arena,Las Vegas,Nevada,United States,13150.0
UFC Fight Night, Lewis , Browne,"Feb 19, 2017",Scotiabank Centre,Halifax,Nova Scotia,Canada,8123.0
UFC 208, Holm , de Randamie,"Feb 11, 2017",Barclays Center,New York City,New York,United States,15628.0
UFC Fight Night, Bermudez , The Korean Zombie,"Feb 4, 2017",Toyota Center,Houston,Texas,United States,8119.0
UFC on Fox, Shevchenko , Peña,"Jan 28, 2017",Pepsi Center,Denver,Colorado,United States,13233.0
UFC Fight Night, Rodríguez , Penn,"Jan 15, 2017",Talking Stick Resort Arena,Phoenix,Arizona,United States,11589.0
UFC 207, Nunes , Rousey,"Dec 30, 2016",T-Mobile Arena,Las Vegas,Nevada,United States,18533.0
UFC on Fox, VanZant , Waterson,"Dec 17, 2016",Golden 1 Center,Sacramento,California,United States,13136.0
UFC 206, Holloway , Pettis,"Dec 10, 2016",Scotiabank Arena,Toronto,Ontario,Canada,18057.0
UFC Fight Night, Lewis , Abdurakhimov,"Dec 9, 2016",Times Union Center,Albany,New York,United States,6216.0
The Ultimate Fighter, Tournament of Champions Finale,__FALCON_NULL_8FF29CAA__,"Dec 3, 2016",Palms Casino Resort,Las Vegas,Nevada,United States,2044.0
UFC Fight Night, Whittaker , Brunson,"Nov 27, 2016",Rod Laver Arena,Melbourne,__FALCON_NULL_8FF29CAA__,Australia,13721.0
UFC Fight Night, Bader , Nogueira ,"Nov 19, 2016",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,9028.0
UFC Fight Night, Mousasi , Hall ,"Nov 19, 2016",The SSE Arena,Belfast,Northern Ireland,United Kingdom,7222.0
UFC 205, Alvarez , McGregor,"Nov 12, 2016",Madison Square Garden,New York City,New York,United States,20427.0
The Ultimate Fighter Latin America 3 Finale, dos Anjos , Ferguson,"Nov 5, 2016",Arena Ciudad de México,Mexico City,__FALCON_NULL_8FF29CAA__,Mexico,11460.0
UFC Fight Night, Lamas , Penn,"Oct 15, 2016",Mall of Asia Arena,Pasay,__FALCON_NULL_8FF29CAA__,Philippines,__FALCON_NULL_8FF29CAA__
UFC 204, Bisping , Henderson ,"Oct 8, 2016",AO Arena,Manchester,England,United Kingdom,16000.0
UFC Fight Night, Lineker , Dodson,"Oct 1, 2016",Moda Center,Portland,Oregon,United States,6240.0
UFC Fight Night, Cyborg , Länsberg,"Sep 24, 2016",Ginásio Nilson Nelson,Brasília,__FALCON_NULL_8FF29CAA__,Brazil,8410.0
UFC Fight Night, Poirier , Johnson,"Sep 17, 2016",State Farm Arena,Hidalgo,Texas,United States,5624.0
UFC 203, Miocic , Overeem,"Sep 10, 2016",Quicken Loans Arena,Cleveland,Ohio,United States,18875.0
UFC Fight Night, Arlo,i vs. Barnett,"Sep 3, 2016",Barclaycard Arena,Hamburg,__FALCON_NULL_8FF29CAA__,Germany,11763.0
UFC on Fox, Maia , Condit,"Aug 27, 2016",Rogers Arena,Vancouver,British Columbia,Canada,10533.0
UFC 202, Diaz , McGregor ,"Aug 20, 2016",T-Mobile Arena,Las Vegas,Nevada,United States,15539.0
UFC Fight Night, Rodríguez , Caceres,"Aug 6, 2016",Vivint Smart Home Arena,Salt Lake City,Utah,United States,6689.0
UFC 201, Lawler , Woodley,"Jul 30, 2016",Philips Arena,Atlanta,Georgia,United States,10240.0
UFC on Fox, Holm , Shevchenko,"Jul 23, 2016",United Center,Chicago,Illinois,United States,10287.0
UFC Fight Night, McDonald , Lineker,"Jul 13, 2016",Denny Sanford Premier Center,Sioux Falls,South Dakota,United States,5671.0
UFC 200, Tate , Nunes,"Jul 9, 2016",T-Mobile Arena,Las Vegas,Nevada,United States,18202.0
The Ultimate Fighter, Team Joanna , Team Cláudia Finale,"Jul 8, 2016",MGM Grand Garden Arena,Las Vegas,Nevada,United States,8115.0
UFC Fight Night, dos Anjos , Alvarez,"Jul 7, 2016",MGM Grand Garden Arena,Las Vegas,Nevada,United States,7760.0
UFC Fight Night, MacDonald , Thompson,"Jun 18, 2016",TD Place Arena,Ottawa,Ontario,Canada,10490.0
UFC 199, Rockhold , Bisping ,"Jun 4, 2016",The Forum,Inglewood,California,United States,15587.0
UFC Fight Night, Almeida , Garbrandt,"May 29, 2016",Mandalay Bay Events Center,Las Vegas,Nevada,United States,5193.0
UFC 198, Werdum , Miocic,"May 14, 2016",Arena da Baixada,Curitiba,__FALCON_NULL_8FF29CAA__,Brazil,45207.0
UFC Fight Night, Overeem , Arlovski,"May 8, 2016",Rotterdam Ahoy,Rotterdam,__FALCON_NULL_8FF29CAA__,Netherlands,10421.0
UFC 197, Jones , Saint Preux,"Apr 23, 2016",MGM Grand Garden Arena,Las Vegas,Nevada,United States,11352.0
UFC on Fox, Teixeira , Evans,"Apr 16, 2016",Amalie Arena,Tampa,Florida,United States,11273.0
UFC Fight Night, Rothwell , dos Santos,"Apr 10, 2016",Arena Zagreb,Zagreb,__FALCON_NULL_8FF29CAA__,Croatia,13177.0
UFC Fight Night, Hunt , Mir,"Mar 20, 2016",Brisbane Entertainment Centre,Brisbane,__FALCON_NULL_8FF29CAA__,Australia,9552.0
UFC 196, McGregor , Diaz,"Mar 5, 2016",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14898.0
UFC Fight Night, Silva , Bisping,"Feb 27, 2016",The O2 Arena,London,England,United Kingdom,16734.0
UFC Fight Night, Cowboy , Cowboy,"Feb 21, 2016",Consol Energy Center,Pittsburgh,Pennsylvania,United States,7330.0
UFC Fight Night, Hendricks , Thompson,"Feb 6, 2016",MGM Grand Garden Arena,Las Vegas,Nevada,United States,7422.0
UFC on Fox, Johnson , Bader,"Jan 30, 2016",Prudential Center,Newark,New Jersey,United States,10555.0
UFC Fight Night, Dillashaw , Cruz,"Jan 17, 2016",TD Garden,Boston,Massachusetts,United States,12022.0
UFC 195, Lawler , Condit,"Jan 2, 2016",MGM Grand Garden Arena,Las Vegas,Nevada,United States,10300.0
UFC on Fox, dos Anjos , Cowboy ,"Dec 19, 2015",Amway Center,Orlando,Florida,United States,14459.0
UFC 194, Aldo , McGregor,"Dec 12, 2015",MGM Grand Garden Arena,Las Vegas,Nevada,United States,16516.0
The Ultimate Fighter, Team McGregor , Team Faber Finale,"Dec 11, 2015",The Chelsea at The Cosmopolitan,Las Vegas,Nevada,United States,2566.0
UFC Fight Night, Namajunas , VanZant,"Dec 10, 2015",The Chelsea at The Cosmopolitan,Las Vegas,Nevada,United States,1643.0
UFC Fight Night, Henderson , Masvidal,"Nov 28, 2015",Olympic Gymnastics Arena,Seoul,__FALCON_NULL_8FF29CAA__,South Korea,12156.0
The Ultimate Fighter Latin America 2 Finale, Magny , Gastelum,"Nov 21, 2015",Arena Monterrey,Monterrey,__FALCON_NULL_8FF29CAA__,Mexico,10410.0
UFC 193, Rousey , Holm,"Nov 15, 2015",Marvel Stadium,Melbourne,__FALCON_NULL_8FF29CAA__,Australia,56214.0
UFC Fight Night, Belfort , Henderson ,"Nov 7, 2015",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,10628.0
UFC Fight Night, Holohan , Smolka,"Oct 24, 2015",3Arena,Dublin,__FALCON_NULL_8FF29CAA__,Ireland,9500.0
UFC 192, Cormier , Gustafsson,"Oct 3, 2015",Toyota Center,Houston,Texas,United States,14622.0
UFC Fight Night, Barnett , Nelson,"Sep 27, 2015",Saitama Super Arena,Saitama,__FALCON_NULL_8FF29CAA__,Japan,10137.0
UFC 191, Johnson , Dodson ,"Sep 5, 2015",MGM Grand Garden Arena,Las Vegas,Nevada,United States,10873.0
UFC Fight Night, Holloway , Oliveira,"Aug 23, 2015",SaskTel Centre,Saskatoon,Saskatchewan,Canada,7202.0
UFC Fight Night, Teixeira , Saint Preux,"Aug 8, 2015",Bridgestone Arena,Nashville,Tennessee,United States,7539.0
UFC 190, Rousey , Correia,"Aug 1, 2015",HSBC Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,14723.0
UFC on Fox, Dillashaw , Barão ,"Jul 25, 2015",United Center,Chicago,Illinois,United States,11663.0
UFC Fight Night, Bisping , Leites,"Jul 18, 2015",The SSE Hydro,Glasgow,Scotland,United Kingdom,10451.0
UFC Fight Night, Mir , Duffee,"Jul 15, 2015",Pechanga Arena,San Diego,California,United States,5471.0
The Ultimate Fighter, American Top Team , Blackzilians Finale,"Jul 12, 2015",MGM Grand Garden Arena,Las Vegas,Nevada,United States,4844.0
UFC 189, Mendes , McGregor,"Jul 11, 2015",MGM Grand Garden Arena,Las Vegas,Nevada,United States,16019.0
UFC Fight Night, Machida , Romero,"Jun 27, 2015",Seminole Hard Rock Hotel and Casino,Hollywood,Florida,United States,5604.0
UFC Fight Night, Jędrzejczyk , Penne,"Jun 20, 2015",Uber Arena,Berlin,__FALCON_NULL_8FF29CAA__,Germany,8155.0
UFC 188, Velasquez , Werdum,"Jun 13, 2015",Arena Ciudad de México,Mexico City,__FALCON_NULL_8FF29CAA__,Mexico,21036.0
UFC Fight Night, Boetsch , Henderson,"Jun 6, 2015",Smoothie King Center,New Orleans,Louisiana,United States,6231.0
UFC Fight Night, Condit , Alves,"May 30, 2015",Goiânia Arena,Goiânia,__FALCON_NULL_8FF29CAA__,Brazil,3500.0
UFC 187, Johnson , Cormier,"May 23, 2015",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12615.0
UFC Fight Night, Edgar , Faber,"May 16, 2015",Mall of Asia Arena,Pasay,__FALCON_NULL_8FF29CAA__,Philippines,13446.0
UFC Fight Night, Miocic , Hunt,"May 10, 2015",Adelaide Entertainment Centre,Adelaide,__FALCON_NULL_8FF29CAA__,Australia,7984.0
UFC 186, Johnson , Horiguchi,"Apr 25, 2015",Bell Centre,Montreal,Quebec,Canada,10154.0
UFC on Fox, Machida , Rockhold,"Apr 18, 2015",Prudential Center,Newark,New Jersey,United States,13306.0
UFC Fight Night, Gonzaga , Cro Cop ,"Apr 11, 2015",Tauron Arena Kraków,Kraków,__FALCON_NULL_8FF29CAA__,Poland,10000.0
UFC Fight Night, Mendes , Lamas,"Apr 4, 2015",Patriot Center,Fairfax,Virginia,United States,5417.0
UFC Fight Night, Maia , LaFlare,"Mar 21, 2015",Ginásio do Maracanãzinho,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,7707.0
UFC 185, Pettis , dos Anjos,"Mar 14, 2015",American Airlines Center,Dallas,Texas,United States,17160.0
UFC 184, Rousey , Zingano,"Feb 28, 2015",Staples Center,Los Angeles,California,United States,17654.0
UFC Fight Night, Bigfoot , Mir,"Feb 22, 2015",Ginásio Gigantinho,Porto Alegre,__FALCON_NULL_8FF29CAA__,Brazil,5080.0
UFC Fight Night, Henderson , Thatch,"Feb 14, 2015",1stBank Center,Broomfield,Colorado,United States,5807.0
UFC 183, Silva , Diaz,"Jan 31, 2015",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13114.0
UFC on Fox, Gustafsson , Johnson,"Jan 24, 2015",Tele2 Arena,Stockholm,__FALCON_NULL_8FF29CAA__,Sweden,30000.0
UFC Fight Night, McGregor , Siver,"Jan 18, 2015",TD Garden,Boston,Massachusetts,United States,13828.0
UFC 182, Jones , Cormier,"Jan 3, 2015",MGM Grand Garden Arena,Las Vegas,Nevada,United States,11575.0
UFC Fight Night, Machida , Dollaway,"Dec 20, 2014",Ginásio José Corrêa,Barueri,__FALCON_NULL_8FF29CAA__,Brazil,__FALCON_NULL_8FF29CAA__
UFC on Fox, dos Santos , Miocic,"Dec 13, 2014",U.S. Airways Center,Phoenix,Arizona,United States,15300.0
The Ultimate Fighter, A Champion Will Be Crowned Finale,__FALCON_NULL_8FF29CAA__,"Dec 12, 2014",Palms Casino Resort,Las Vegas,Nevada,United States,1800.0
UFC 181, Hendricks , Lawler II,"Dec 6, 2014",Mandalay Bay Events Center,Las Vegas,Nevada,United States,9617.0
UFC Fight Night, Edgar , Swanson,"Nov 22, 2014",Frank Erwin Center,Austin,Texas,United States,10131.0
UFC 180, Werdum , Hunt,"Nov 15, 2014",Arena Ciudad de México,Mexico City,__FALCON_NULL_8FF29CAA__,Mexico,21000.0
UFC Fight Night, Shogun , Saint Preux,"Nov 8, 2014",Ginásio Municipal Tancredo Neves,Uberlândia,__FALCON_NULL_8FF29CAA__,Brazil,5671.0
UFC Fight Night, Rockhold , Bisping,"Nov 8, 2014",Qudos Bank Arena,Sydney,__FALCON_NULL_8FF29CAA__,Australia,9904.0
UFC 179, Aldo , Mendes ,"Oct 25, 2014",Ginásio do Maracanãzinho,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,11415.0
UFC Fight Night, MacDonald , Saffiedine,"Oct 4, 2014",Scotiabank Centre,Halifax,Nova Scotia,Canada,10782.0
UFC Fight Night, Nelson , Story,"Oct 4, 2014",Avicii Arena,Stockholm,__FALCON_NULL_8FF29CAA__,Sweden,10026.0
UFC 178, Johnson , Cariaso,"Sep 27, 2014",MGM Grand Garden Arena,Las Vegas,Nevada,United States,10544.0
UFC Fight Night, Hunt , Nelson,"Sep 20, 2014",Saitama Super Arena,Saitama,__FALCON_NULL_8FF29CAA__,Japan,12395.0
UFC Fight Night, Bigfoot , Arlovski,"Sep 13, 2014",Ginásio Nilson Nelson,Brasília,__FALCON_NULL_8FF29CAA__,Brazil,8822.0
UFC Fight Night, Jacaré , Mousasi,"Sep 5, 2014",Foxwoods Resort Casino,Ledyard,Connecticut,United States,4086.0
UFC 177, Dillashaw , Soto,"Aug 30, 2014",Sleep Train Arena,Sacramento,California,United States,11100.0
UFC Fight Night, Henderson , dos Anjos,"Aug 23, 2014",BOK Center,Tulsa,Oklahoma,United States,7119.0
UFC Fight Night, Bisping , Le,"Aug 23, 2014",Cotai Arena,Macau,SAR,China,7022.0
UFC Fight Night, Bader , Saint Preux,"Aug 16, 2014",Cross Insurance Center,Bangor,Maine,United States,5329.0
UFC 176, Aldo , Mendes II,"Aug 2, 2014",Staples Center,Los Angeles,California,United States,__FALCON_NULL_8FF29CAA__
UFC on Fox, Lawler , Brown,"Jul 26, 2014",SAP Center,San Jose,California,United States,11482.0
UFC Fight Night, McGregor , Brandão,"Jul 19, 2014",3Arena,Dublin,__FALCON_NULL_8FF29CAA__,Ireland,9500.0
UFC Fight Night, Cowboy , Miller,"Jul 16, 2014",Revel Casino Hotel,Atlantic City,New Jersey,United States,4115.0
The Ultimate Fighter, Team Edgar , Team Penn Finale,"Jul 6, 2014",Mandalay Bay Events Center,Las Vegas,Nevada,United States,6500.0
UFC 175, Weidman , Machida,"Jul 5, 2014",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10088.0
UFC Fight Night, Swanson , Stephens,"Jun 28, 2014",AT&T Center,San Antonio,Texas,United States,9227.0
UFC Fight Night, Te Huna , Marquardt,"Jun 28, 2014",Vector Arena,Auckland,__FALCON_NULL_8FF29CAA__,New Zealand,8089.0
UFC 174, Johnson , Bagautinov,"Jun 14, 2014",Rogers Arena,Vancouver,British Columbia,Canada,13506.0
UFC Fight Night, Henderson , Khabilov,"Jun 7, 2014",Tingley Coliseum,Albuquerque,New Mexico,United States,8775.0
The Ultimate Fighter Brazil 3 Finale, Miocic , Maldonado,"May 31, 2014",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,8986.0
UFC Fight Night, Muñoz , Mousasi,"May 31, 2014",Uber Arena,Berlin,__FALCON_NULL_8FF29CAA__,Germany,8000.0
UFC 173, Barão , Dillashaw,"May 24, 2014",MGM Grand Garden Arena,Las Vegas,Nevada,United States,11036.0
UFC Fight Night, Brown , Silva,"May 10, 2014",U.S. Bank Arena,Cincinnati,Ohio,United States,6143.0
UFC 172, Jones , Teixeira,"Apr 26, 2014",Baltimore Arena,Baltimore,Maryland,United States,13485.0
UFC on Fox, Werdum , Browne,"Apr 19, 2014",Amway Center,Orlando,Florida,United States,17000.0
The Ultimate Fighter Nations Finale, Bisping , Kennedy,"Apr 16, 2014",Colisée Pepsi,Quebec City,Quebec,Canada,5029.0
UFC Fight Night, Nogueira , Nelson,"Apr 11, 2014",Etihad Park,Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,7963.0
UFC Fight Night, Shogun , Henderson ,"Mar 23, 2014",Ginásio Nélio Dias,Natal,__FALCON_NULL_8FF29CAA__,Brazil,6828.0
UFC 171, Hendricks , Lawler,"Mar 15, 2014",American Airlines Center,Dallas,Texas,United States,19324.0
UFC Fight Night, Gustafsson , Manuwa,"Mar 8, 2014",The O2 Arena,London,England,United Kingdom,14604.0
The Ultimate Fighter China Finale, Kim , Hathaway,"Mar 1, 2014",Cotai Arena,Macau,SAR,China,6000.0
UFC 170, Rousey , McMann,"Feb 22, 2014",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10217.0
UFC Fight Night, Machida , Mousasi,"Feb 15, 2014",Arena Jaraguá,Jaraguá do Sul,__FALCON_NULL_8FF29CAA__,Brazil,7511.0
UFC 169, Barão , Faber ,"Feb 1, 2014",Prudential Center,Newark,New Jersey,United States,14308.0
UFC on Fox, Henderson , Thomson,"Jan 25, 2014",United Center,Chicago,Illinois,United States,10895.0
UFC Fight Night, Rockhold , Philippou,"Jan 15, 2014",Arena at Gwinnett Center,Duluth,Georgia,United States,5822.0
UFC Fight Night, Saffiedine , Lim,"Jan 4, 2014",Marina Bay Sands,Marina Bay,__FALCON_NULL_8FF29CAA__,Singapore,5216.0
UFC 168, Weidman , Silva ,"Dec 28, 2013",MGM Grand Garden Arena,Las Vegas,Nevada,United States,15650.0
UFC on Fox, Johnson , Benavidez ,"Dec 14, 2013",Sleep Train Arena,Sacramento,California,United States,11573.0
UFC Fight Night, Hunt , Bigfoot,"Dec 7, 2013",Brisbane Entertainment Centre,Brisbane,__FALCON_NULL_8FF29CAA__,Australia,11393.0
The Ultimate Fighter, Team Rousey , Team Tate Finale,"Nov 30, 2013",Mandalay Bay Events Center,Las Vegas,Nevada,United States,4853.0
UFC 167, St-Pierre , Hendricks,"Nov 16, 2013",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14856.0
UFC Fight Night, Belfort , Henderson ,"Nov 9, 2013",Goiânia Arena,Goiânia,__FALCON_NULL_8FF29CAA__,Brazil,10565.0
UFC, Fight for the Troops ,__FALCON_NULL_8FF29CAA__,"Nov 6, 2013",Fort Campbell,Fort Campbell,Kentucky,United States,__FALCON_NULL_8FF29CAA__
UFC Fight Night, Machida , Muñoz,"Oct 26, 2013",Phones 4u Arena,Manchester,England,United Kingdom,10355.0
UFC 166, Velasquez , dos Santos III,"Oct 19, 2013",Toyota Center,Houston,Texas,United States,17238.0
UFC Fight Night, Maia , Shields,"Oct 9, 2013",Ginásio José Corrêa,Barueri,__FALCON_NULL_8FF29CAA__,Brazil,6621.0
UFC 165, Jones , Gustafsson,"Sep 21, 2013",Scotiabank Arena,Toronto,Ontario,Canada,15504.0
UFC Fight Night, Teixeira , Bader,"Sep 4, 2013",Mineirinho Arena,Belo Horizonte,__FALCON_NULL_8FF29CAA__,Brazil,5126.0
UFC 164, Henderson , Pettis ,"Aug 31, 2013",BMO Harris Bradley Center,Milwaukee,Wisconsin,United States,9178.0
UFC Fight Night, Condit , Kampmann ,"Aug 28, 2013",Bankers Life Fieldhouse,Indianapolis,Indiana,United States,6417.0
UFC Fight Night, Shogun , Sonnen,"Aug 17, 2013",TD Garden,Boston,Massachusetts,United States,14181.0
UFC 163, Aldo , Korean Zombie,"Aug 3, 2013",HSBC Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,13873.0
UFC on Fox, Johnson , Moraga,"Jul 27, 2013",Climate Pledge Arena,Seattle,Washington,United States,8967.0
UFC 162, Silva , Weidman,"Jul 6, 2013",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12964.0
UFC 161, Evans , Henderson,"Jun 15, 2013",Canada Life Centre,Winnipeg,Manitoba,Canada,14754.0
UFC on Fuel TV, Nogueira , Werdum,"Jun 8, 2013",Ginásio Paulo Sarasate,Fortaleza,__FALCON_NULL_8FF29CAA__,Brazil,6286.0
UFC 160, Velasquez , Bigfoot ,"May 25, 2013",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12380.0
UFC on FX, Belfort , Rockhold,"May 18, 2013",Arena Jaraguá,Jaraguá do Sul,__FALCON_NULL_8FF29CAA__,Brazil,7642.0
UFC 159, Jones , Sonnen,"Apr 27, 2013",Prudential Center,Newark,New Jersey,United States,15227.0
UFC on Fox, Henderson , Melendez,"Apr 20, 2013",SAP Center,San Jose,California,United States,13506.0
The Ultimate Fighter, Team Jones , Team Sonnen Finale,"Apr 13, 2013",Mandalay Bay Events Center,Las Vegas,Nevada,United States,5918.0
UFC on Fuel TV, Mousasi , Latifi,"Apr 6, 2013",Avicii Arena,Stockholm,__FALCON_NULL_8FF29CAA__,Sweden,14506.0
UFC 158, St-Pierre , Diaz,"Mar 16, 2013",Bell Centre,Montreal,Quebec,Canada,20145.0
UFC on Fuel TV, Silva , Stann,"Mar 3, 2013",Saitama Super Arena,Saitama,__FALCON_NULL_8FF29CAA__,Japan,14682.0
UFC 157, Rousey , Carmouche,"Feb 23, 2013",Honda Center,Anaheim,California,United States,13257.0
UFC on Fuel TV, Barão , McDonald,"Feb 16, 2013",Wembley Arena,London,England,United Kingdom,10349.0
UFC 156, Aldo , Edgar,"Feb 2, 2013",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10275.0
UFC on Fox, Johnson , Dodson,"Jan 26, 2013",United Center,Chicago,Illinois,United States,16091.0
UFC on FX, Belfort , Bisping,"Jan 19, 2013",Ginásio do Ibirapuera,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,9116.0
UFC 155, dos Santos , Velasquez ,"Dec 29, 2012",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13561.0
The Ultimate Fighter, Team Carwin , Team Nelson Finale,"Dec 15, 2012",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,2500.0
UFC on FX, Sotiropoulos , Pearson,"Dec 15, 2012",Gold Coast Convention and Exhibition Centre,Gold Coast,__FALCON_NULL_8FF29CAA__,Australia,5133.0
UFC on Fox, Henderson , Diaz,"Dec 8, 2012",Climate Pledge Arena,Seattle,Washington,United States,14387.0
UFC 154, St-Pierre , Condit,"Nov 17, 2012",Bell Centre,Montreal,Quebec,Canada,17249.0
UFC on Fuel TV, Franklin , Le,"Nov 10, 2012",Cotai Arena,Macau,SAR,China,8415.0
UFC 153, Silva , Bonnar,"Oct 13, 2012",Farmasi Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,16844.0
UFC on FX, Browne , Bigfoot,"Oct 5, 2012",Target Center,Minneapolis,Minnesota,United States,7049.0
UFC on Fuel TV, Struve , Miocic,"Sep 29, 2012",Motorpoint Arena,Nottingham,England,United Kingdom,7241.0
UFC 152, Jones , Belfort,"Sep 22, 2012",Scotiabank Arena,Toronto,Ontario,Canada,16800.0
UFC 151, Jones , Henderson,"Sep 1, 2012",Mandalay Bay Events Center,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 150, Henderson , Edgar II,"Aug 11, 2012",Ball Arena,Denver,Colorado,United States,13027.0
UFC on Fox, Shogun , Vera,"Aug 4, 2012",Crypto.com Arena,Los Angeles,California,United States,16080.0
UFC 149, Faber , Barão,"Jul 21, 2012",Scotiabank Saddledome,Calgary,Alberta,Canada,16089.0
UFC on Fuel TV, Muñoz , Weidman,"Jul 11, 2012",SAP Center,San Jose,California,United States,4250.0
UFC 148, Silva , Sonnen II,"Jul 7, 2012",MGM Grand Garden Arena,Las Vegas,Nevada,United States,15104.0
UFC 147, Silva , Franklin II,"Jun 23, 2012",Mineirinho Arena,Belo Horizonte,__FALCON_NULL_8FF29CAA__,Brazil,16643.0
UFC on FX, Maynard , Guida,"Jun 22, 2012",Revel Casino Hotel,Atlantic City,New Jersey,United States,4652.0
UFC on FX, Johnson , McCall ,"Jun 8, 2012",Amerant Bank Arena,Sunrise,Florida,United States,6635.0
The Ultimate Fighter, Live Finale,__FALCON_NULL_8FF29CAA__,"Jun 1, 2012",Palms Casino Resort,Las Vegas,Nevada,United States,1628.0
UFC 146, dos Santos , Mir,"May 26, 2012",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14674.0
UFC on Fuel TV, The Korean Zombie , Poirier,"May 15, 2012",EagleBank Arena,Fairfax,Virginia,United States,6668.0
UFC on Fox, Diaz , Miller,"May 5, 2012",Meadowlands Arena,East Rutherford,New Jersey,United States,10788.0
UFC 145, Jones , Evans,"Apr 21, 2012",Philips Arena,Atlanta,Georgia,United States,15545.0
UFC on Fuel TV, Gustafsson , Silva,"Apr 14, 2012",Avicii Arena,Stockholm,__FALCON_NULL_8FF29CAA__,Sweden,15428.0
UFC on FX, Alves , Kampmann,"Mar 3, 2012",Qudos Bank Arena,Sydney,__FALCON_NULL_8FF29CAA__,Australia,14537.0
UFC 144, Edgar , Henderson,"Feb 26, 2012",Saitama Super Arena,Saitama,__FALCON_NULL_8FF29CAA__,Japan,21000.0
UFC on Fuel TV, Sanchez , Ellenberger,"Feb 15, 2012",Omaha Civic Auditorium,Omaha,Nebraska,United States,6283.0
UFC 143, Diaz , Condit,"Feb 4, 2012",Mandalay Bay Events Center,Las Vegas,Nevada,United States,9015.0
UFC on Fox, Evans , Davis,"Jan 28, 2012",United Center,Chicago,Illinois,United States,16963.0
UFC on FX, Guillard , Miller,"Jan 20, 2012",Bridgestone Arena,Nashville,Tennessee,United States,7728.0
UFC 142, Aldo , Mendes,"Jan 14, 2012",HSBC Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,10605.0
UFC 141, Lesnar , Overeem,"Dec 30, 2011",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13793.0
UFC 140, Jones , Machida,"Dec 10, 2011",Scotiabank Arena,Toronto,Ontario,Canada,18303.0
The Ultimate Fighter, Team Bisping , Team Miller Finale,"Dec 3, 2011",Palms Casino Resort,Las Vegas,Nevada,United States,1909.0
UFC 139, Shogun , Henderson,"Nov 19, 2011",SAP Center,San Jose,California,United States,13832.0
UFC on Fox, Velasquez , dos Santos,"Nov 12, 2011",Honda Center,Anaheim,California,United States,11607.0
UFC 138, Leben , Muñoz,"Nov 5, 2011",LG Arena,Birmingham,England,United Kingdom,10823.0
UFC 137, Penn , Diaz,"Oct 29, 2011",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10313.0
UFC 136, Edgar , Maynard III,"Oct 8, 2011",Toyota Center,Houston,Texas,United States,16164.0
UFC Live, Cruz , Johnson,"Oct 1, 2011",Capital One Arena,Washington,D.C.,United States,9380.0
UFC 135, Jones , Rampage,"Sep 24, 2011",Pepsi Center,Denver,Colorado,United States,16344.0
UFC Fight Night, Shields , Ellenberger,"Sep 17, 2011",Ernest N. Morial Convention Center,New Orleans,Louisiana,United States,7112.0
UFC 134, Silva , Okami,"Aug 27, 2011",HSBC Arena,Rio de Janeiro,__FALCON_NULL_8FF29CAA__,Brazil,14000.0
UFC Live, Hardy , Lytle,"Aug 14, 2011",Bradley Center,Milwaukee,Wisconsin,United States,6751.0
UFC 133, Evans , Ortiz,"Aug 6, 2011",Wells Fargo Center,Philadelphia,Pennsylvania,United States,11583.0
UFC 132, Cruz , Faber,"Jul 2, 2011",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13109.0
UFC Live, Kongo , Barry,"Jun 26, 2011",Consol Energy Center,Pittsburgh,Pennsylvania,United States,7792.0
UFC 131, dos Santos , Carwin,"Jun 11, 2011",Rogers Arena,Vancouver,British Columbia,Canada,14685.0
The Ultimate Fighter, Team Lesnar , Team dos Santos Finale,"Jun 4, 2011",Palms Casino Resort,Las Vegas,Nevada,United States,2053.0
UFC 130, Rampage , Hamill,"May 28, 2011",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12753.0
UFC 129, St-Pierre , Shields,"Apr 30, 2011",Rogers Centre,Toronto,Ontario,Canada,55724.0
UFC Fight Night, Nogueira , Davis,"Mar 26, 2011",Climate Pledge Arena,Seattle,Washington,United States,13741.0
UFC 128, Shogun , Jones,"Mar 19, 2011",Prudential Center,Newark,New Jersey,United States,12619.0
UFC Live, Sanchez , Kampmann,"Mar 3, 2011",KFC Yum! Center,Louisville,Kentucky,United States,8319.0
UFC 127, Penn , Fitch,"Feb 27, 2011",Qudos Bank Arena,Sydney,__FALCON_NULL_8FF29CAA__,Australia,18186.0
UFC 126, Silva , Belfort,"Feb 5, 2011",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10893.0
UFC, Fight for the Troops ,__FALCON_NULL_8FF29CAA__,"Jan 22, 2011",Fort Hood,Fort Hood,Texas,United States,3200.0
UFC 125, Resolution,__FALCON_NULL_8FF29CAA__,"Jan 1, 2011",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12874.0
UFC 124, St-Pierre , Koscheck ,"Dec 11, 2010",Bell Centre,Montreal,Quebec,Canada,23152.0
The Ultimate Fighter, Team GSP , Team Koscheck Finale,"Dec 4, 2010",Palms Casino Resort,Las Vegas,Nevada,United States,1903.0
UFC 123, Rampage , Machida,"Nov 20, 2010",The Palace of Auburn Hills,Auburn Hills,Michigan,United States,16404.0
UFC 122, Marquardt , Okami,"Nov 13, 2010",Rudolf Weber-Arena,Oberhausen,__FALCON_NULL_8FF29CAA__,Germany,8421.0
UFC 121, Lesnar , Velasquez,"Oct 23, 2010",Honda Center,Anaheim,California,United States,14856.0
UFC 120, Bisping , Akiyama,"Oct 16, 2010",The O2 Arena,London,England,United Kingdom,17133.0
UFC 119, Mir , Cro Cop,"Sep 25, 2010",Conseco Fieldhouse,Indianapolis,Indiana,United States,15811.0
UFC Fight Night, Marquardt , Palhares,"Sep 15, 2010",Frank Erwin Center,Austin,Texas,United States,7724.0
UFC 118, Edgar , Penn ,"Aug 28, 2010",TD Garden,Boston,Massachusetts,United States,14168.0
UFC 117, Silva , Sonnen,"Aug 7, 2010",Oracle Arena,Oakland,California,United States,12971.0
UFC Live, Jones , Matyushenko,"Aug 1, 2010",Pechanga Arena,San Diego,California,United States,8132.0
UFC 116, Lesnar , Carwin,"Jul 3, 2010",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12740.0
The Ultimate Fighter, Team Liddell , Team Ortiz Finale,"Jun 19, 2010",Palms Casino Resort,Las Vegas,Nevada,United States,1708.0
UFC 115, Liddell , Franklin,"Jun 12, 2010",General Motors Place,Vancouver,British Columbia,Canada,17669.0
UFC 114, Rampage , Evans,"May 29, 2010",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14996.0
UFC 113, Machida , Shogun ,"May 8, 2010",Bell Centre,Montreal,Quebec,Canada,17647.0
UFC 112, Invincible,__FALCON_NULL_8FF29CAA__,"Apr 10, 2010","Concert Arena, Yas Island",Abu Dhabi,__FALCON_NULL_8FF29CAA__,United Arab Emirates,11008.0
UFC Fight Night, Florian , Gomi,"Mar 31, 2010",Bojangles Coliseum,Charlotte,North Carolina,United States,7700.0
UFC 111, St-Pierre , Hardy,"Mar 27, 2010",Prudential Center,Newark,New Jersey,United States,17000.0
UFC Live, Vera , Jones,"Mar 21, 2010",1stBank Center,Broomfield,Colorado,United States,6443.0
UFC 110, Nogueira , Velasquez,"Feb 21, 2010",Qudos Bank Arena,Sydney,__FALCON_NULL_8FF29CAA__,Australia,17831.0
UFC 109, Relentless,__FALCON_NULL_8FF29CAA__,"Feb 6, 2010",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10753.0
UFC Fight Night, Maynard , Diaz,"Jan 11, 2010",Patriot Center,Fairfax,Virginia,United States,8078.0
UFC 108, Evans , Silva,"Jan 2, 2010",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13529.0
UFC 107, Penn , Sanchez,"Dec 12, 2009",FedExForum,Memphis,Tennessee,United States,13896.0
The Ultimate Fighter, Heavyweights Finale,__FALCON_NULL_8FF29CAA__,"Dec 5, 2009",Palms Casino Resort,Las Vegas,Nevada,United States,1791.0
UFC 106, Ortiz , Griffin ,"Nov 21, 2009",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10529.0
UFC 105, Couture , Vera,"Nov 14, 2009",Manchester Evening News Arena,Manchester,England,United Kingdom,16693.0
UFC 104, Machida , Shogun,"Oct 24, 2009",Crypto.com Arena,Los Angeles,California,United States,14892.0
UFC 103, Franklin , Belfort,"Sep 19, 2009",American Airlines Center,Dallas,Texas,United States,17428.0
UFC Fight Night, Diaz , Guillard,"Sep 16, 2009",Cox Convention Center,Oklahoma City,Oklahoma,United States,9490.0
UFC 102, Couture , Nogueira,"Aug 29, 2009",Rose Garden,Portland,Oregon,United States,16088.0
UFC 101, Declaration,__FALCON_NULL_8FF29CAA__,"Aug 8, 2009",Wachovia Center,Philadelphia,Pennsylvania,United States,17411.0
UFC 100,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Jul 11, 2009",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10871.0
The Ultimate Fighter, United States , United Kingdom Finale,"Jun 20, 2009",Palms Casino Resort,Las Vegas,Nevada,United States,2217.0
UFC 99, The Comeback,__FALCON_NULL_8FF29CAA__,"Jun 13, 2009",Lanxess Arena,Cologne,__FALCON_NULL_8FF29CAA__,Germany,12854.0
UFC 98, Evans , Machida,"May 23, 2009",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12606.0
UFC 97, Redemption,__FALCON_NULL_8FF29CAA__,"Apr 18, 2009",Bell Centre,Montreal,Quebec,Canada,21451.0
UFC Fight Night, Condit , Kampmann,"Apr 1, 2009",Sommet Center,Nashville,Tennessee,United States,10267.0
UFC 96, Jackson , Jardine,"Mar 7, 2009",Nationwide Arena,Columbus,Ohio,United States,17033.0
UFC 95, Sanchez , Stevenson,"Feb 21, 2009",The O2 Arena,London,England,United Kingdom,13268.0
UFC Fight Night, Lauzon , Stephens,"Feb 7, 2009",USF Sun Dome,Tampa,Florida,United States,7596.0
UFC 94, St-Pierre , Penn ,"Jan 31, 2009",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14885.0
UFC 93, Franklin , Henderson,"Jan 17, 2009",3Arena,Dublin,__FALCON_NULL_8FF29CAA__,Ireland,9369.0
UFC 92, The Ultimate ,__FALCON_NULL_8FF29CAA__,"Dec 27, 2008",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14166.0
The Ultimate Fighter, Team Nogueira , Team Mir Finale,"Dec 13, 2008",Palms Casino Resort,Las Vegas,Nevada,United States,1853.0
UFC, Fight for the Troops,__FALCON_NULL_8FF29CAA__,"Dec 10, 2008",Crown Coliseum,Fayetteville,North Carolina,United States,8500.0
UFC 91, Couture , Lesnar,"Nov 15, 2008",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14272.0
UFC 90, Silva , Côté,"Oct 25, 2008",Allstate Arena,Rosemont,Illinois,United States,15359.0
UFC 89, Bisping , Leben,"Oct 18, 2008",National Indoor Arena,Birmingham,England,United Kingdom,9515.0
UFC Fight Night, Diaz , Neer,"Sep 17, 2008",Omaha Civic Auditorium,Omaha,Nebraska,United States,9103.0
UFC 88, Breakthrough,__FALCON_NULL_8FF29CAA__,"Sep 6, 2008",State Farm Arena,Atlanta,Georgia,United States,14736.0
UFC 87, Seek and Destroy,__FALCON_NULL_8FF29CAA__,"Aug 9, 2008",Target Center,Minneapolis,Minnesota,United States,15087.0
UFC Fight Night, Silva , Irvin,"Jul 19, 2008",Palms Casino Resort,Las Vegas,Nevada,United States,2071.0
UFC 86, Jackson , Griffin,"Jul 5, 2008",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10990.0
The Ultimate Fighter, Team Rampage , Team Forrest Finale,"Jun 21, 2008",Palms Casino Resort,Las Vegas,Nevada,United States,1853.0
UFC 85, Bedlam,__FALCON_NULL_8FF29CAA__,"Jun 7, 2008",The O2 Arena,London,England,United Kingdom,15327.0
UFC 84, Ill Will,__FALCON_NULL_8FF29CAA__,"May 24, 2008",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14773.0
UFC 83, Serra , St-Pierre ,"Apr 19, 2008",Bell Centre,Montreal,Quebec,Canada,21390.0
UFC Fight Night, Florian , Lauzon,"Apr 2, 2008",Broomfield Event Center,Broomfield,Colorado,United States,6742.0
UFC 82, Pride of a Champion,__FALCON_NULL_8FF29CAA__,"Mar 1, 2008",Nationwide Arena,Columbus,Ohio,United States,16431.0
UFC 81, Breaking Point,__FALCON_NULL_8FF29CAA__,"Feb 2, 2008",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10583.0
UFC Fight Night, Swick , Burkman,"Jan 23, 2008",Palms Casino Resort,Las Vegas,Nevada,United States,1900.0
UFC 80, Rapid Fire,__FALCON_NULL_8FF29CAA__,"Jan 19, 2008",Metro Radio Arena,Newcastle upon Tyne,England,United Kingdom,8412.0
UFC 79, Nemesis,__FALCON_NULL_8FF29CAA__,"Dec 29, 2007",Mandalay Bay Events Center,Las Vegas,Nevada,United States,11075.0
The Ultimate Fighter, Team Hughes , Team Serra Finale,"Dec 8, 2007",Palms Casino Resort,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 78, Validation,__FALCON_NULL_8FF29CAA__,"Nov 17, 2007",Prudential Center,Newark,New Jersey,United States,14071.0
UFC 77, Hostile Territory,__FALCON_NULL_8FF29CAA__,"Oct 20, 2007",U.S. Bank Arena,Cincinnati,Ohio,United States,16054.0
UFC 76, Knockout,__FALCON_NULL_8FF29CAA__,"Sep 22, 2007",Honda Center,Anaheim,California,United States,13770.0
UFC Fight Night, Thomas , Florian,"Sep 19, 2007",Palms Casino Resort,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 75, Champion , Champion,"Sep 8, 2007",The O2 Arena,London,England,United Kingdom,16235.0
UFC 74, Respect,__FALCON_NULL_8FF29CAA__,"Aug 25, 2007",Mandalay Bay Events Center,Las Vegas,Nevada,United States,11065.0
UFC 73, Stacked,__FALCON_NULL_8FF29CAA__,"Jul 7, 2007",ARCO Arena,Sacramento,California,United States,13183.0
The Ultimate Fighter, Team Pulver , Team Penn Finale,"Jun 23, 2007",Palms Casino Resort,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 72, Victory,__FALCON_NULL_8FF29CAA__,"Jun 16, 2007",The Odyssey,Belfast,Northern Ireland,United Kingdom,7850.0
UFC Fight Night, Stout , Fisher,"Jun 12, 2007",Seminole Hard Rock Hotel and Casino,Hollywood,Florida,United States,__FALCON_NULL_8FF29CAA__
UFC 71, Liddell , Jackson,"May 26, 2007",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14728.0
UFC 70, Nations Collide,__FALCON_NULL_8FF29CAA__,"Apr 21, 2007",Manchester Evening News Arena,Manchester,England,United Kingdom,15114.0
UFC 69, Shootout,__FALCON_NULL_8FF29CAA__,"Apr 7, 2007",Toyota Center,Houston,Texas,United States,15269.0
UFC Fight Night, Stevenson , Guillard,"Apr 5, 2007",Palms Casino Resort,Las Vegas,Nevada,United States,1734.0
UFC 68, The Uprising,__FALCON_NULL_8FF29CAA__,"Mar 3, 2007",Nationwide Arena,Columbus,Ohio,United States,19079.0
UFC 67, All or Nothing,__FALCON_NULL_8FF29CAA__,"Feb 3, 2007",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10787.0
UFC Fight Night, Evans , Salmon,"Jan 25, 2007",Seminole Hard Rock Hotel and Casino,Hollywood,Florida,United States,5287.0
UFC 66, Liddell , Ortiz,"Dec 30, 2006",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13671.0
UFC Fight Night, Sanchez , Riggs,"Dec 13, 2006",Marine Corps Air Station Miramar,San Diego,California,United States,3000.0
UFC 65, Bad Intentions,__FALCON_NULL_8FF29CAA__,"Nov 18, 2006",ARCO Arena,Sacramento,California,United States,14666.0
The Ultimate Fighter, The Comeback Finale,__FALCON_NULL_8FF29CAA__,"Nov 11, 2006",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,1000.0
UFC 64, Unstoppable,__FALCON_NULL_8FF29CAA__,"Oct 14, 2006",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10173.0
UFC Fight Night 6.5,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Oct 10, 2006",Seminole Hard Rock Hotel and Casino,Hollywood,Florida,United States,3510.0
UFC 63, Hughes , Penn,"Sep 23, 2006",Honda Center,Anaheim,California,United States,12604.0
UFC 62, Liddell , Sobral,"Aug 26, 2006",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10503.0
UFC Fight Night 6,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Aug 17, 2006",Red Rock Resort Spa and Casino,Summerlin,Nevada,United States,1412.0
UFC 61, Bitter Rivals,__FALCON_NULL_8FF29CAA__,"Jul 8, 2006",Mandalay Bay Events Center,Las Vegas,Nevada,United States,11167.0
UFC Ultimate Fight Night 5,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Jun 28, 2006",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,606.0
The Ultimate Fighter, Team Ortiz , Team Shamrock Finale,"Jun 24, 2006",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,849.0
UFC 60, Hughes , Gracie,"May 27, 2006",Crypto.com Arena,Los Angeles,California,United States,14765.0
UFC 59, Reality Check,__FALCON_NULL_8FF29CAA__,"Apr 15, 2006",Honda Center,Anaheim,California,United States,13814.0
UFC Ultimate Fight Night 4,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Apr 6, 2006",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,843.0
UFC 58, USA , Canada,"Mar 4, 2006",Mandalay Bay Events Center,Las Vegas,Nevada,United States,9569.0
UFC 57, Liddell , Couture ,"Feb 4, 2006",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10659.0
UFC Ultimate Fight Night 3,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Jan 16, 2006",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,1008.0
UFC 56, Full Force,__FALCON_NULL_8FF29CAA__,"Nov 19, 2005",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12000.0
The Ultimate Fighter, Team Hughes , Team Franklin Finale,"Nov 5, 2005",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 55, Fury,__FALCON_NULL_8FF29CAA__,"Oct 7, 2005",Mohegan Sun Arena,Montville,Connecticut,United States,8000.0
UFC Ultimate Fight Night 2,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Oct 3, 2005",Hard Rock Hotel and Casino,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 54, Boiling Point,__FALCON_NULL_8FF29CAA__,"Aug 20, 2005",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13520.0
UFC Ultimate Fight Night,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,"Aug 6, 2005",Cox Pavilion,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 53, Heavy Hitters,__FALCON_NULL_8FF29CAA__,"Jun 4, 2005",Boardwalk Hall,Atlantic City,New Jersey,United States,12000.0
UFC 52, Couture , Liddell,"Apr 16, 2005",MGM Grand Garden Arena,Las Vegas,Nevada,United States,14562.0
The Ultimate Fighter, Team Couture , Team Liddell Finale,"Apr 9, 2005",Cox Pavilion,Las Vegas,Nevada,United States,__FALCON_NULL_8FF29CAA__
UFC 51, Super Saturday,__FALCON_NULL_8FF29CAA__,"Feb 5, 2005",Mandalay Bay Events Center,Las Vegas,Nevada,United States,11072.0
UFC 50, The War of ',__FALCON_NULL_8FF29CAA__,"Oct 22, 2004",Boardwalk Hall,Atlantic City,New Jersey,United States,9000.0
UFC 49, Unfinished Business,__FALCON_NULL_8FF29CAA__,"Aug 21, 2004",MGM Grand Garden Arena,Las Vegas,Nevada,United States,12100.0
UFC 48, Payback,__FALCON_NULL_8FF29CAA__,"Jun 19, 2004",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10000.0
UFC 47, It's On!,__FALCON_NULL_8FF29CAA__,"Apr 2, 2004",Mandalay Bay Events Center,Las Vegas,Nevada,United States,11437.0
UFC 46, Supernatural,__FALCON_NULL_8FF29CAA__,"Jan 31, 2004",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10700.0
UFC 45, Revolution,__FALCON_NULL_8FF29CAA__,"Nov 21, 2003",Mohegan Sun Arena,Montville,Connecticut,United States,9200.0
UFC 44, Undisputed,__FALCON_NULL_8FF29CAA__,"Sep 26, 2003",Mandalay Bay Events Center,Las Vegas,Nevada,United States,10400.0
UFC 43, Meltdown,__FALCON_NULL_8FF29CAA__,"Jun 6, 2003",Thomas & Mack Center,Las Vegas,Nevada,United States,9800.0
UFC 42, Sudden Impact,__FALCON_NULL_8FF29CAA__,"Apr 25, 2003",Kaseya Center,Miami,Florida,United States,7500.0
UFC 41, Onslaught,__FALCON_NULL_8FF29CAA__,"Feb 28, 2003",Boardwalk Hall,Atlantic City,New Jersey,United States,11707.0
UFC 40, Vendetta,__FALCON_NULL_8FF29CAA__,"Nov 22, 2002",MGM Grand Garden Arena,Las Vegas,Nevada,United States,13770.0
UFC 39, The Warriors Return,__FALCON_NULL_8FF29CAA__,"Sep 27, 2002",Mohegan Sun Arena,Montville,Connecticut,United States,7800.0
UFC 38, Brawl at the Hall,__FALCON_NULL_8FF29CAA__,"Jul 13, 2002",Royal Albert Hall,London,England,United Kingdom,5000.0
UFC 37.5, As Real As It Gets,__FALCON_NULL_8FF29CAA__,"Jun 22, 2002",Bellagio,Las Vegas,Nevada,United States,3700.0
UFC 37, High Impact,__FALCON_NULL_8FF29CAA__,"May 10, 2002",CenturyTel Center,Bossier City,Louisiana,United States,7200.0
UFC 36, Worlds Collide,__FALCON_NULL_8FF29CAA__,"Mar 22, 2002",MGM Grand Garden Arena,Las Vegas,Nevada,United States,10000.0
UFC 35, Throwdown,__FALCON_NULL_8FF29CAA__,"Jan 11, 2002",Mohegan Sun Arena,Uncasville,Connecticut,United States,9600.0
UFC 34, High Voltage,__FALCON_NULL_8FF29CAA__,"Nov 2, 2001",MGM Grand Garden Arena,Las Vegas,Nevada,United States,9000.0
UFC 33, Victory in Vegas,__FALCON_NULL_8FF29CAA__,"Sep 28, 2001",Mandalay Bay Events Center,Las Vegas,Nevada,United States,9500.0
UFC 32, Showdown in the Meadowlands,__FALCON_NULL_8FF29CAA__,"Jun 29, 2001",Continental Airlines Arena,East Rutherford,New Jersey,United States,12500.0
UFC 31, Locked and Loaded,__FALCON_NULL_8FF29CAA__,"May 4, 2001",Etess Arena at Trump Taj Mahal,Atlantic City,New Jersey,United States,__FALCON_NULL_8FF29CAA__
UFC 30, Battle on the Boardwalk,__FALCON_NULL_8FF29CAA__,"Feb 23, 2001",Etess Arena at Trump Taj Mahal,Atlantic City,New Jersey,United States,3000.0
UFC 29, Defense of the Belts,__FALCON_NULL_8FF29CAA__,"Dec 16, 2000",Differ Ariake Arena,Tokyo,__FALCON_NULL_8FF29CAA__,Japan,1414.0
UFC 28, High Stakes,__FALCON_NULL_8FF29CAA__,"Nov 17, 2000",Etess Arena at Trump Taj Mahal,Atlantic City,New Jersey,United States,__FALCON_NULL_8FF29CAA__
UFC 27, Ultimate Bad Boyz,__FALCON_NULL_8FF29CAA__,"Sep 22, 2000",Lakefront Arena,New Orleans,Louisiana,United States,__FALCON_NULL_8FF29CAA__
UFC 26, Ultimate Field of Dreams,__FALCON_NULL_8FF29CAA__,"Jun 9, 2000",Five Seasons Events Center,Cedar Rapids,Iowa,United States,1100.0
UFC 25, Ultimate Japan ,__FALCON_NULL_8FF29CAA__,"Apr 14, 2000",Yoyogi National Gymnasium,Tokyo,__FALCON_NULL_8FF29CAA__,Japan,__FALCON_NULL_8FF29CAA__
UFC 24, First Defense,__FALCON_NULL_8FF29CAA__,"Mar 10, 2000",Lake Charles Civic Center,Lake Charles,Louisiana,United States,__FALCON_NULL_8FF29CAA__
UFC 23, Ultimate Japan ,__FALCON_NULL_8FF29CAA__,"Nov 19, 1999",Tokyo Bay NK Hall,Chiba,__FALCON_NULL_8FF29CAA__,Japan,__FALCON_NULL_8FF29CAA__
UFC 22, Only One Can be Champion,__FALCON_NULL_8FF29CAA__,"Sep 24, 1999",Lake Charles Civic Center,Lake Charles,Louisiana,United States,__FALCON_NULL_8FF29CAA__
UFC 21, Return of the Champions,__FALCON_NULL_8FF29CAA__,"Jul 16, 1999",Five Seasons Events Center,Cedar Rapids,Iowa,United States,__FALCON_NULL_8FF29CAA__
UFC 20, Battle for the Gold,__FALCON_NULL_8FF29CAA__,"May 7, 1999",Boutwell Memorial Auditorium,Birmingham,Alabama,United States,__FALCON_NULL_8FF29CAA__
UFC 19, Ultimate Young Guns,__FALCON_NULL_8FF29CAA__,"Mar 5, 1999",Casino Magic Bay St. Louis,Bay St. Louis,Mississippi,United States,__FALCON_NULL_8FF29CAA__
UFC 18, The Road to the Heavyweight Title,__FALCON_NULL_8FF29CAA__,"Jan 8, 1999",Pontchartrain Center,New Orleans,Louisiana,United States,__FALCON_NULL_8FF29CAA__
UFC Brazil, Ultimate Brazil,__FALCON_NULL_8FF29CAA__,"Oct 16, 1998",Ginásio da Portuguesa,São Paulo,__FALCON_NULL_8FF29CAA__,Brazil,__FALCON_NULL_8FF29CAA__
UFC 17, Redemption,__FALCON_NULL_8FF29CAA__,"May 15, 1998",Mobile Civic Center,Mobile,Alabama,United States,__FALCON_NULL_8FF29CAA__
UFC 16, Battle in the Bayou,__FALCON_NULL_8FF29CAA__,"Mar 13, 1998",Pontchartrain Center,New Orleans,Louisiana,United States,4600.0
UFC Japan, Ultimate Japan,__FALCON_NULL_8FF29CAA__,"Dec 21, 1997",Yokohama Arena,Yokohama,__FALCON_NULL_8FF29CAA__,Japan,5000.0
UFC 15, Collision Course,__FALCON_NULL_8FF29CAA__,"Oct 17, 1997",Casino Magic Bay St. Louis,Bay St. Louis,Mississippi,United States,__FALCON_NULL_8FF29CAA__
UFC 14, Showdown,__FALCON_NULL_8FF29CAA__,"Jul 27, 1997",Boutwell Memorial Auditorium,Birmingham,Alabama,United States,5000.0
UFC 13, The Ultimate Force,__FALCON_NULL_8FF29CAA__,"May 30, 1997",Augusta Civic Center,Augusta,Georgia,United States,5100.0
UFC 12, Judgement Day,__FALCON_NULL_8FF29CAA__,"Feb 7, 1997",Dothan Civic Center,Dothan,Alabama,United States,3100.0
UFC, The Ultimate Ultimate ,__FALCON_NULL_8FF29CAA__,"Dec 7, 1996",Fair Park Arena,Birmingham,Alabama,United States,6000.0
UFC 11, The Proving Ground,__FALCON_NULL_8FF29CAA__,"Sep 20, 1996",Augusta Civic Center,Augusta,Georgia,United States,4500.0
UFC 10, The Tournament,__FALCON_NULL_8FF29CAA__,"Jul 12, 1996",Fair Park Arena,Birmingham,Alabama,United States,4300.0
UFC 9, Motor City Madness,__FALCON_NULL_8FF29CAA__,"May 17, 1996",Cobo Arena,Detroit,Michigan,United States,10000.0
UFC 8, David , Goliath,"Feb 16, 1996",Coliseo Rubén Rodríguez,Bayamón,__FALCON_NULL_8FF29CAA__,Puerto Rico,13000.0
UFC, The Ultimate Ultimate,__FALCON_NULL_8FF29CAA__,"Dec 16, 1995",Mammoth Gardens,Denver,Colorado,United States,2800.0
UFC 7, The Brawl in Buffalo,__FALCON_NULL_8FF29CAA__,"Sep 8, 1995",Buffalo Memorial Auditorium,Buffalo,New York,United States,9000.0
UFC 6, Clash of the Titans,__FALCON_NULL_8FF29CAA__,"Jul 14, 1995",Casper Events Center,Casper,Wyoming,United States,2700.0
UFC 5, The Return of the Beast,__FALCON_NULL_8FF29CAA__,"Apr 7, 1995",Independence Arena,Charlotte,North Carolina,United States,6000.0
UFC 4, Revenge of the Warriors,__FALCON_NULL_8FF29CAA__,"Dec 16, 1994",Expo Square Pavilion,Tulsa,Oklahoma,United States,5857.0
UFC 3, The American Dream,__FALCON_NULL_8FF29CAA__,"Sep 9, 1994",Grady Cole Center,Charlotte,North Carolina,United States,3000.0
UFC 2, No Way Out,__FALCON_NULL_8FF29CAA__,"Mar 11, 1994",Mammoth Gardens,Denver,Colorado,United States,2000.0
UFC 1, The Beginning,__FALCON_NULL_8FF29CAA__,"Nov 12, 1993",McNichols Sports Arena,Denver,Colorado,United States,7800.0
\.
analyze "falcon_db_22"."ufc_events_stats";
drop table if exists "falcon_db_22"."ufc_fighters_stats" cascade;
create table "falcon_db_22"."ufc_fighters_stats" ("first_name" text, "last_name" text, "nickname" text, "city" text, "country" text, "age" bigint, "wins" bigint, "losses" bigint, "draws" bigint, "win_percent" double precision, "lose_percent" double precision, "num_of_fights" bigint, "weight_division" text, "height_ft" double precision, "weight_lbs" double precision, "arm_reach_inch" double precision, "leg_reach_inch" double precision, "fighting_style" text, "debut" text);
copy "falcon_db_22"."ufc_fighters_stats" ("first_name", "last_name", "nickname", "city", "country", "age", "wins", "losses", "draws", "win_percent", "lose_percent", "num_of_fights", "weight_division", "height_ft", "weight_lbs", "arm_reach_inch", "leg_reach_inch", "fighting_style", "debut") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
Islam,Makhachev,__FALCON_NULL_8FF29CAA__,Dagestan Republic,Russia,33,26,1,0,96.29629629629628,3.7037037037037033,27,Lightweight Division,5.833333333333333,155.0,70.5,40.5,Sambo,2015-05-23
Jon,Jones,Bones,Rochester,United States,37,28,1,0,96.55172413793105,3.4482758620689653,29,Heavyweight Division,6.333333333333333,237.6,84.5,45.0,__FALCON_NULL_8FF29CAA__,2008-08-09
Alex,Pereira,Poatan,São Bernardo do Campo,Brazil,37,12,2,0,85.71428571428571,14.285714285714285,14,Light Heavyweight Division,6.333333333333333,205.0,79.0,44.0,Kickboxer,2021-11-06
Ilia,Topuria,El  Matador,__FALCON_NULL_8FF29CAA__,Germany,27,16,0,0,100.0,0.0,16,Featherweight Division,5.583333333333333,145.0,69.0,37.0,Brazilian Jiu-Jitsu,2020-10-10
Belal,Muhammad,Remember The Name,Chicago,United States,36,24,3,0,88.88888888888889,11.11111111111111,27,Welterweight Division,5.916666666666667,169.0,72.0,40.0,__FALCON_NULL_8FF29CAA__,2016-07-07
Dricus,Du Plessis,Stillknocks,Welkom,South Africa,30,22,2,0,91.66666666666666,8.333333333333332,24,Middleweight Division,6.083333333333333,185.0,76.0,43.0,MMA,2020-10-10
Merab,Dvalishvili,The Machine,Tbilisi,Georgia,33,18,4,0,81.81818181818183,18.181818181818183,22,Bantamweight Division,5.5,134.0,68.0,38.0,Freestyle,2017-12-09
Tom,Aspinall,__FALCON_NULL_8FF29CAA__,Salford,United Kingdom,31,15,3,0,83.33333333333334,16.666666666666664,18,Heavyweight Division,6.416666666666667,255.0,78.0,44.0,Freestyle,2020-03-21
Alexandre,Pantoja,The Cannibal,__FALCON_NULL_8FF29CAA__,Brazil,34,29,5,0,85.29411764705883,14.705882352941178,34,Flyweight Division,5.416666666666667,124.5,67.0,36.5,MMA,2017-01-29
Leon,Edwards,Rocky,Kingston,Jamaica,33,22,4,0,84.61538461538461,15.384615384615383,26,Welterweight Division,6.0,170.0,74.0,43.0,MMA,2014-11-09
Alexander,Volkanovski,The Great,Wollongong,Australia,36,26,4,0,86.66666666666667,13.333333333333334,30,Featherweight Division,5.5,144.5,71.5,36.0,__FALCON_NULL_8FF29CAA__,2016-10-15
Max,Holloway,Blessed,Oahu,United States,32,26,8,0,76.47058823529412,23.52941176470588,34,Featherweight Division,5.916666666666667,145.0,69.0,42.0,Muay Thai,2012-02-04
Sean,O'Malley,Suga,Helena,United States,30,18,2,0,90.0,10.0,20,Bantamweight Division,5.916666666666667,135.0,72.0,40.0,__FALCON_NULL_8FF29CAA__,2017-07-18
Sean,Strickland,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,United States,33,29,6,0,82.85714285714286,17.142857142857142,35,Middleweight Division,6.083333333333333,185.0,76.0,41.5,MMA,2014-03-15
Charles,Oliveira,Do Bronxs,State of São Paulo,Brazil,35,35,10,0,77.77777777777779,22.22222222222222,45,Lightweight Division,5.833333333333333,155.6,74.0,41.0,Jiu-Jitsu,2010-08-01
Brandon,Royval,Raw Dawg,Denver,United States,32,17,7,0,70.83333333333334,29.166666666666668,24,Flyweight Division,5.75,125.5,68.0,38.5,Brawler,2020-05-30
Brandon,Moreno,The Assassin Baby,Tijuana,Mexico,30,22,8,2,73.33333333333333,26.666666666666668,30,Flyweight Division,5.583333333333333,135.0,70.0,38.0,Jiu-Jitsu,2016-10-02
Amir,Albazi,The Prince,Baghdad,Iraq,31,17,2,0,89.47368421052632,10.526315789473683,19,Flyweight Division,5.416666666666667,125.5,68.0,38.0,Jiu-Jitsu,2020-07-18
Kai,Kara-France,Don't Blink,Auckland,New Zealand,31,25,11,0,69.44444444444444,30.555555555555557,36,Flyweight Division,5.333333333333333,125.0,69.0,37.0,Kickboxer,2018-12-02
Tatsuro,Taira,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Japan,24,16,1,0,94.11764705882352,5.88235294117647,17,Flyweight Division,5.583333333333333,125.5,70.0,38.0,__FALCON_NULL_8FF29CAA__,2022-04-30
Manel,Kape,StarBoy,__FALCON_NULL_8FF29CAA__,Angola,31,20,7,0,74.07407407407408,25.925925925925924,27,Flyweight Division,5.416666666666667,125.0,68.0,39.0,MMA,2021-02-06
Alex,Perez,__FALCON_NULL_8FF29CAA__,Hanford,United States,32,25,9,0,73.52941176470588,26.47058823529412,34,Flyweight Division,5.5,126.0,65.5,38.0,Freestyle,2017-08-08
Asu,Almabayev ,Zulfikar,__FALCON_NULL_8FF29CAA__,Kazakhstan,30,21,2,0,91.30434782608695,8.695652173913043,23,Flyweight Division,5.333333333333333,125.5,65.0,36.0,__FALCON_NULL_8FF29CAA__,2023-08-05
Steve,Erceg,Astroboy,Perth,Australia,29,12,3,0,80.0,20.0,15,Flyweight Division,5.666666666666667,125.5,68.0,38.0,MMA,2023-05-20
Tim,Elliott,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,United States,37,21,13,1,61.76470588235294,38.23529411764706,34,Bantamweight Division,5.583333333333333,136.0,66.0,38.0,Freestyle,2012-05-05
Tagir,Ulanbekov,__FALCON_NULL_8FF29CAA__,Dagestan,Russia,33,16,2,0,88.88888888888889,11.11111111111111,18,Flyweight Division,5.583333333333333,129.5,70.0,39.0,Grappler,2020-10-10
Charles,Johnson,Inner G,Topeka,United States,33,17,6,0,73.91304347826086,26.08695652173913,23,Flyweight Division,5.75,126.0,70.0,40.0,__FALCON_NULL_8FF29CAA__,2022-07-23
Bruno,Silva,Bulldog,Piracicaba,Brazil,34,14,6,2,70.0,30.0,20,Flyweight Division,5.333333333333333,126.0,65.0,35.0,Grappler,2019-09-07
Joshua,Van,The Fearless,Hakha ,Myanmar (Burma),23,12,2,0,85.71428571428571,14.285714285714285,14,Flyweight Division,5.416666666666667,126.0,65.0,35.0,Freestyle,2023-06-24
Umar,Nurmagomedov,__FALCON_NULL_8FF29CAA__,Republic of Dagestan,Russia,28,18,0,0,100.0,0.0,18,Bantamweight Division,5.666666666666667,135.0,69.0,39.0,MMA,2021-01-20
Petr,Yan,No Mercy,Krasnoyarsk Krai,Russia,31,18,5,0,78.26086956521739,21.73913043478261,23,Bantamweight Division,5.625,135.5,67.0,38.0,Boxer,2018-06-23
Cory,Sandhagen,__FALCON_NULL_8FF29CAA__,Aurora,United States,32,17,5,0,77.27272727272727,22.727272727272727,22,Bantamweight Division,5.916666666666667,136.0,70.0,40.0,MMA,2018-01-28
Deiveson,Figueiredo,Deus da Guerra,Soure,Brazil,37,24,4,1,85.71428571428571,14.285714285714285,28,Bantamweight Division,5.416666666666667,135.0,68.0,38.0,Boxing,2017-06-03
Marlon,Vera,Chito,Chone,Ecuador,32,23,10,1,69.6969696969697,30.303030303030305,33,Bantamweight Division,5.666666666666667,136.0,70.5,40.5,Grappler,2014-11-15
Henry,Cejudo,Triple C,Los Angeles,United States,37,16,4,0,80.0,20.0,20,Bantamweight Division,5.333333333333333,135.0,64.0,37.0,Wrestling,2014-12-13
Song,Yadong,Kung Fu Kid,Heilongjiang,China,27,21,8,1,72.41379310344827,27.58620689655172,29,Bantamweight Division,5.666666666666667,136.0,67.0,38.0,Boxer,2017-11-25
Rob,Font,__FALCON_NULL_8FF29CAA__,Leominster,United States,37,21,8,0,72.41379310344827,27.58620689655172,29,Bantamweight Division,5.666666666666667,135.5,71.5,38.5,Striker,2014-07-05
Mario,Bautista,__FALCON_NULL_8FF29CAA__,Winnemucca,United States,31,15,2,0,88.23529411764706,11.76470588235294,17,Bantamweight Division,5.75,136.0,72.0,39.0,Freestyle,2019-01-19
Kyler,Phillips,The Matrix,Torrance,United States,29,12,3,0,80.0,20.0,15,Bantamweight Division,5.666666666666667,135.5,72.0,38.0,__FALCON_NULL_8FF29CAA__,2017-08-01
Aiemann,Zahabi,__FALCON_NULL_8FF29CAA__,Laval,Canada,37,12,2,0,85.71428571428571,14.285714285714285,14,Bantamweight Division,5.666666666666667,135.5,68.5,38.0,MMA,2017-02-20
Marcus,McGhee,The Maniac,Detroit,United States,34,10,1,0,90.9090909090909,9.090909090909092,11,Bantamweight Division,5.666666666666667,135.6,69.0,38.0,Brazilian Jiu-Jitsu,2023-04-29
Montel,Jackson,Quik,Milwaukee,United States,32,15,2,0,88.23529411764706,11.76470588235294,17,Bantamweight Division,5.833333333333333,135.0,75.5,41.0,MMA,2018-08-04
Diego,Lopes,__FALCON_NULL_8FF29CAA__,Manaus,Brazil,29,26,6,0,81.25,18.75,32,Featherweight Division,5.916666666666667,145.0,72.5,41.0,Jiu-Jitsu,2023-05-06
Movsar,Evloev,__FALCON_NULL_8FF29CAA__,Ingushetia,Russia,30,19,0,0,100.0,0.0,19,Featherweight Division,5.583333333333333,145.5,72.5,36.0,Freestyle,2019-04-20
Yair,Rodriguez,El Pantera,Hidalgo Del Parral,Mexico,32,16,5,0,76.19047619047619,23.809523809523807,21,Featherweight Division,5.916666666666667,146.0,71.0,41.5,Freestyle,2014-11-15
Brian,Ortega,T-City,Carson,United States,33,16,4,0,80.0,20.0,20,Featherweight Division,5.666666666666667,146.0,69.0,39.0,Jiu-Jitsu,2014-07-26
Arnold,Allen,Almighty,Ipswich,United Kingdom,30,20,3,0,86.95652173913044,13.043478260869565,23,Featherweight Division,5.666666666666667,145.0,70.0,39.0,MMA,2015-06-20
Josh,Emmett,CC0 (C-C-OH),Phoenix,United States,39,19,4,0,82.6086956521739,17.391304347826086,23,Featherweight Division,5.541666666666667,146.0,70.0,39.5,Freestyle,2016-05-08
Aljamain,Sterling,Funk Master,__FALCON_NULL_8FF29CAA__,United States,35,24,5,0,82.75862068965517,17.24137931034483,29,Featherweight Division,5.583333333333333,145.5,71.0,39.0,Kickboxer,2014-02-22
Calvin,Kattar,__FALCON_NULL_8FF29CAA__,Methuen,United States,36,23,8,0,74.19354838709677,25.806451612903224,31,Featherweight Division,5.916666666666667,145.5,72.0,40.0,Freestyle,2017-07-29
Lerone,Murphy,The Miracle,Manchester,United Kingdom,33,15,0,1,100.0,0.0,15,Featherweight Division,5.75,145.5,73.5,39.0,Kickboxer,2019-09-07
Giga,Chikadze,Ninja,Tbilisi,Georgia,36,15,4,0,78.94736842105263,21.052631578947366,19,Featherweight Division,6.0,146.0,74.0,40.5,Karate,2019-09-28
Bryce,Mitchell,Thug Nasty,Texarkana,United States,30,17,3,0,85.0,15.0,20,Featherweight Division,5.833333333333333,146.0,70.0,40.0,MMA,2018-07-06
Dan,Ige,50K,San Clemente,United States,33,18,9,0,66.66666666666666,33.33333333333333,27,Featherweight Division,5.583333333333333,146.0,71.0,38.0,Jiu-Jitsu,2017-07-25
Edson,Barboza,Junior,Nova Friburgo,Brazil,38,24,12,0,66.66666666666666,33.33333333333333,36,Featherweight Division,5.916666666666667,145.5,75.0,41.0,Striker,2010-11-21
Arman,Tsarukyan,Ahalkalakets,__FALCON_NULL_8FF29CAA__,Georgia,28,22,3,0,88.0,12.0,25,Lightweight Division,5.583333333333333,156.0,72.5,39.5,Kickboxer,2019-04-20
Justin,Gaethje,The Highlight,Tucson,United States,36,26,5,0,83.87096774193549,16.129032258064516,31,Lightweight Division,5.916666666666667,156.0,70.0,40.0,MMA,2017-07-08
Dustin,Poirier,The Diamond,Lafayette,United States,35,30,9,0,76.92307692307693,23.076923076923077,39,Lightweight Division,5.75,155.0,72.0,40.5,Jiu-Jitsu,2011-01-02
Dan,Hooker,The Hangman,Aukland,New Zealand,34,24,12,0,66.66666666666666,33.33333333333333,36,Lightweight Division,6.0,155.5,75.0,42.5,MMA,2014-06-28
Michael,Chandler,Iron,High Ridge,United States,38,23,9,0,71.875,28.125,32,Lightweight Division,5.666666666666667,155.6,71.5,37.5,Wrestler,2021-01-23
Mateusz,Gamrot,Gamer,Bielsko,Poland,34,24,3,0,88.88888888888889,11.11111111111111,27,Lightweight Division,5.833333333333333,156.0,70.5,39.0,Wrestling,2020-10-17
Beneil,Dariush,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Iran,35,22,6,1,78.57142857142857,21.428571428571427,28,Lightweight Division,5.833333333333333,156.0,72.0,40.5,MMA,2014-01-15
Renato,Moicano,__FALCON_NULL_8FF29CAA__,Brasilia,Brazil,35,20,5,1,80.0,20.0,25,Lightweight Division,5.916666666666667,156.0,72.0,42.5,Jiu-Jitsu,2014-12-20
Rafael,Fiziev,Ataman,__FALCON_NULL_8FF29CAA__,Kyrgyzstan,31,12,3,0,80.0,20.0,15,Lightweight Division,5.666666666666667,156.0,71.5,40.0,Muay Thai,2019-04-20
Benoît,Saint Denis ,God of War,Nîmes,France,29,13,3,0,81.25,18.75,16,Lightweight Division,5.916666666666667,156.0,73.0,40.0,MMA,2021-10-30
Paddy,Pimblett,The Baddy,Liverpool,United Kingdom,29,22,3,0,88.0,12.0,25,Lightweight Division,5.833333333333333,156.0,73.0,40.0,__FALCON_NULL_8FF29CAA__,2021-09-04
Jalin,Turner,The Tarantula,Los Angeles,United States,29,14,8,0,63.63636363636363,36.36363636363637,22,Lightweight Division,6.25,155.5,77.0,46.0,MMA,2018-10-07
Joel,Álvarez,El Fenomeno,Gijón,Spain,31,22,3,0,88.0,12.0,25,Lightweight Division,6.166666666666667,156.0,77.0,42.0,Striker,2019-02-23
Shavkat,Rakhmonov,Nomad,__FALCON_NULL_8FF29CAA__,Uzbekistan,30,19,0,0,100.0,0.0,19,Welterweight Division,6.083333333333333,171.0,77.0,42.0,Sambo,2020-03-21
Kamaru,Usman,Nigerian Nightmare,Auchi,Nigeria,37,20,4,0,83.33333333333334,16.666666666666664,24,Middleweight Division,6.0,184.5,76.0,41.0,Freestyle,2015-07-12
Jack,Della Maddalena,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Australia,28,17,2,0,89.47368421052632,10.526315789473683,19,Welterweight Division,5.916666666666667,170.0,73.0,40.5,MMA,2022-01-22
Sean,Brady,__FALCON_NULL_8FF29CAA__,Philadelphia,United States,32,17,1,0,94.44444444444444,5.555555555555555,18,Welterweight Division,5.833333333333333,171.0,72.0,40.0,Brazilian Jiu-Jitsu,2019-10-18
Joaquin,Buckley,New Mansa,__FALCON_NULL_8FF29CAA__,United States,30,21,6,0,77.77777777777779,22.22222222222222,27,Welterweight Division,5.833333333333333,171.0,76.0,40.0,Freestyle,2020-08-08
Ian,Machado Garry,The Future,Dublin,Ireland,27,15,1,0,93.75,6.25,16,Welterweight Division,6.25,171.0,74.5,42.0,__FALCON_NULL_8FF29CAA__,2021-11-06
Gilbert,Burns,Durinho,Niterói,Brazil,38,22,8,0,73.33333333333333,26.666666666666668,30,Welterweight Division,5.833333333333333,171.0,71.0,40.0,Brazilian Jiu-Jitsu,2014-07-26
Colby,Covington,Chaos,__FALCON_NULL_8FF29CAA__,United States,36,17,5,0,77.27272727272727,22.727272727272727,22,Welterweight Division,5.916666666666667,171.0,72.0,41.0,Wrestling,2014-08-23
Geoff,Neal,Handz of Steel,Austin,United States,34,16,6,0,72.72727272727273,27.27272727272727,22,Welterweight Division,5.916666666666667,171.0,75.0,41.0,Striker,2018-02-18
Stephen,Thompson,Wonderboy,Greenville,United States,41,17,8,1,68.0,32.0,25,Welterweight Division,6.0,171.0,75.0,42.0,Karate,2012-02-04
Michael,Morales,__FALCON_NULL_8FF29CAA__,Pasaje,Ecuador,25,17,0,0,100.0,0.0,17,Welterweight Division,6.0,171.0,79.0,41.0,Striker,2022-01-22
Carlos,Prates,The Nightmare,State of São Paulo,Brazil,31,21,6,0,77.77777777777779,22.22222222222222,27,Welterweight Division,6.083333333333333,170.5,78.0,43.5,Striker,2024-02-10
Vicente,Luque,The Silent Assassin,Westwood,United States,33,23,10,1,69.6969696969697,30.303030303030305,33,Welterweight Division,5.916666666666667,170.5,75.5,38.0,Muay Thai,2015-07-12
Israel,Adesanya,The Last Stylebender,Lagos,Nigeria,35,24,4,0,85.71428571428571,14.285714285714285,28,Middleweight Division,6.333333333333333,184.0,80.0,44.5,Freestyle,2018-02-11
Khamzat,Chimaev,Borz,__FALCON_NULL_8FF29CAA__,Russia,29,14,0,0,100.0,0.0,14,Middleweight Division,6.166666666666667,185.0,75.0,40.0,Wrestler,2020-07-15
Robert,Whittaker,The Reaper,Otahuhu,Australia,33,27,8,0,77.14285714285715,22.857142857142858,35,Middleweight Division,6.0,185.5,73.5,43.0,Brazilian Jiu-Jitsu,2012-12-16
Nassourdine,Imavov,The Sniper,__FALCON_NULL_8FF29CAA__,Russia,29,15,4,0,78.94736842105263,21.052631578947366,19,Middleweight Division,6.25,186.0,75.0,42.0,Striker,2020-10-03
Caio,Borralho,The Natural,State of Maranhão,Brazil,31,17,1,0,94.44444444444444,5.555555555555555,18,Middleweight Division,6.125,186.0,75.0,42.0,MMA,2022-04-16
Marvin,Vettori,The Italian Dream,Trento,Italy,31,19,7,1,73.07692307692307,26.923076923076923,26,Middleweight Division,6.0,185.5,74.0,41.0,MMA,2016-08-21
Jared,Cannonier,Tha Killa Gorilla,Dallas,United States,40,17,8,0,68.0,32.0,25,Middleweight Division,5.916666666666667,184.0,77.5,41.5,Striker,2015-01-03
Brendan,Allen,All In,Beaufort,United States,28,24,6,0,80.0,20.0,30,Middleweight Division,6.166666666666667,186.0,75.0,42.0,MMA,2019-10-18
Roman,Dolidze,__FALCON_NULL_8FF29CAA__,Batumi,Georgia,36,14,3,0,82.35294117647058,17.647058823529413,17,Middleweight Division,6.166666666666667,185.5,76.0,41.0,MMA,2020-07-18
Paulo,Costa,The Eraser,State of Minas Gerais,Brazil,33,14,4,0,77.77777777777779,22.22222222222222,18,Middleweight Division,6.083333333333333,185.0,72.0,39.5,Striker,2017-03-12
Jack,Hermansson,The Joker,Uddevalla,Sweden,36,24,8,0,75.0,25.0,32,Middleweight Division,6.083333333333333,185.0,77.5,46.5,MMA,2016-09-03
Anthony,Hernandez,Fluffy,Oakland,United States,31,13,2,0,86.66666666666667,13.333333333333334,15,Middleweight Division,6.0,185.5,75.0,40.0,Striker,2019-02-02
Shara,Magomedov,Bullet,Republic of Dagestan,Russia,30,15,0,0,100.0,0.0,15,Middleweight Division,6.166666666666667,185.0,73.0,41.5,__FALCON_NULL_8FF29CAA__,2023-10-21
Michel,Pereira,Demolidor,Marabá,Brazil,31,31,12,0,72.09302325581395,27.906976744186046,43,Middleweight Division,6.083333333333333,185.5,73.0,42.0,Striker,2019-05-18
Magomed,Ankalaev,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Russia,32,20,1,1,95.23809523809524,4.761904761904762,21,Light Heavyweight Division,6.25,204.5,75.0,46.0,MMA,2018-03-17
Jiří,Procházka ,__FALCON_NULL_8FF29CAA__,Hostěradice,Czechia,32,30,5,1,85.71428571428571,14.285714285714285,35,Light Heavyweight Division,6.25,204.5,80.0,45.0,Muay Thai,2020-07-11
Jamahal,Hill,Sweet Dreams,Chicago,United States,33,12,2,0,85.71428571428571,14.285714285714285,14,Light Heavyweight Division,6.333333333333333,205.0,79.0,43.5,MMA,2020-01-25
Jan,Błachowicz,__FALCON_NULL_8FF29CAA__,Cieszyn,Poland,41,29,10,1,74.35897435897436,25.64102564102564,39,Light Heavyweight Division,6.166666666666667,205.0,78.0,44.0,MMA,2014-10-04
Aleksandar,Rakić,Rocket,Vienna,Austria,32,14,5,0,73.68421052631578,26.31578947368421,19,Light Heavyweight Division,6.333333333333333,206.0,78.0,46.0,Freestyle,2017-09-02
Carlos,Ulberg,Black Jag,Auckland,New Zealand,34,12,1,0,92.3076923076923,7.6923076923076925,13,Light Heavyweight Division,6.333333333333333,205.5,77.0,43.5,Kickboxer,2021-03-06
Khalil,Rountree Jr.,__FALCON_NULL_8FF29CAA__,Los Angeles,United States,34,14,6,0,70.0,30.0,20,Light Heavyweight Division,6.083333333333333,205.0,76.5,44.0,MMA,2016-07-09
Nikita,Krylov,The Miner,__FALCON_NULL_8FF29CAA__,Ukraine,32,30,9,0,76.92307692307693,23.076923076923077,39,Light Heavyweight Division,6.25,213.0,77.5,44.5,Karate,2013-09-01
Volkan,Oezdemir,No Time,Fribourg,Switzerland,35,20,8,0,71.42857142857143,28.57142857142857,28,Light Heavyweight Division,6.166666666666667,206.0,75.0,40.5,Striker,2017-02-05
Johnny,Walker,__FALCON_NULL_8FF29CAA__,Belford Roxo,Brazil,32,21,9,0,70.0,30.0,30,Light Heavyweight Division,6.5,206.0,82.0,44.5,MMA,2018-11-17
Dominick,Reyes,The Devastator,Apple Valley,United States,34,14,4,0,77.77777777777779,22.22222222222222,18,Light Heavyweight Division,6.333333333333333,205.0,77.0,43.5,Kickboxer,2017-06-26
Azamat,Murzakanov,Professional,Nalchik,Russia,35,14,0,0,100.0,0.0,14,Light Heavyweight Division,5.833333333333333,205.0,71.5,41.0,MMA,2021-11-20
Bogdan,Guskov,Czarevitch,Tashkent,Uzbekistan,32,16,3,0,84.21052631578947,15.789473684210526,19,Light Heavyweight Division,6.25,204.5,76.0,41.0,MMA,2023-09-02
Anthony,Smith,Lionheart,Corpus Christi,United States,36,38,21,0,64.40677966101694,35.59322033898305,59,Light Heavyweight Division,6.333333333333333,205.5,76.0,44.0,Freestyle,2012-08-19
Alonzo,Menifield,Atomic,Los Angeles,United States,37,15,5,1,75.0,25.0,20,Light Heavyweight Division,6.0,205.0,76.0,41.0,Freestyle,2019-01-19
Ciryl,Gane,Bon Gamin,La Roche-sur-Yon,France,34,13,2,0,86.66666666666667,13.333333333333334,15,Heavyweight Division,6.333333333333333,245.5,81.0,42.0,Muay Thai,2019-08-10
Alexander,Volkov,Drago,Moscow,Russia,36,38,11,0,77.55102040816327,22.448979591836736,49,Heavyweight Division,6.583333333333333,254.5,80.0,47.5,Brazilian Jiu-Jitsu,2016-11-19
Sergei,Pavlovich,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Russia,32,18,3,0,85.71428571428571,14.285714285714285,21,Heavyweight Division,6.25,260.0,84.0,45.0,MMA,2018-11-24
Curtis,Blaydes,Razor,Naperville,United States,33,18,5,0,78.26086956521739,21.73913043478261,23,Heavyweight Division,6.333333333333333,256.0,80.0,46.0,MMA,2016-04-10
Jailton,Almeida,Malhadinho,__FALCON_NULL_8FF29CAA__,Brazil,33,21,3,0,87.5,12.5,24,Heavyweight Division,6.25,241.0,79.0,43.5,Boxing,2021-11-13
Serghei,Spivac,Polar Bear,Chisinau,Moldova,29,17,4,0,80.95238095238095,19.047619047619047,21,Heavyweight Division,6.25,260.0,78.0,44.0,Sambo,2019-05-04
Marcin,Tybura,Tybur,Uniejow,Poland,39,26,9,0,74.28571428571429,25.71428571428571,35,Heavyweight Division,6.25,251.0,78.0,46.0,MMA,2016-04-10
Jairzinho,Rozenstruik,Bigi Boy,Paramaribo,Suriname,36,15,5,0,75.0,25.0,20,Heavyweight Division,6.166666666666667,259.0,78.0,41.0,MMA,2019-02-02
Derrick,Lewis,The Black Beast,New Orleans,United States,39,28,12,0,70.0,30.0,40,Heavyweight Division,6.25,266.0,79.0,43.5,Brawler,2014-04-19
Tai,Tuivasa,Bam Bam,Kingswood,Australia,31,15,8,0,65.21739130434783,34.78260869565217,23,Heavyweight Division,6.166666666666667,265.0,75.0,39.5,__FALCON_NULL_8FF29CAA__,2017-11-18
Marcos,Rogerio de Lima,Pezao,__FALCON_NULL_8FF29CAA__,Brazil,39,22,10,1,68.75,31.25,32,Heavyweight Division,6.083333333333333,261.0,75.0,43.0,Striker,2014-05-31
Waldo,Cortes Acosta,Salsa Boy,__FALCON_NULL_8FF29CAA__,Dominican Republic,33,12,1,0,92.3076923076923,7.6923076923076925,13,Heavyweight Division,6.333333333333333,262.0,70.0,43.5,Striker,2022-10-29
Shamil,Gaziev,__FALCON_NULL_8FF29CAA__,Dagestan,Russia,34,13,1,0,92.85714285714286,7.142857142857142,14,Heavyweight Division,6.333333333333333,262.0,78.5,45.0,MMA,2023-12-16
Mick,Parkin,__FALCON_NULL_8FF29CAA__,Sunderland,United Kingdom,29,10,0,0,100.0,0.0,10,Heavyweight Division,6.333333333333333,265.0,79.0,43.0,MMA,2023-07-22
Valentina,Shevchenko,Bullet,Bishkek,Kyrgyzstan,36,24,4,1,85.71428571428571,14.285714285714285,28,Women's Flyweight Division,5.416666666666667,125.0,67.0,38.0,Muay Thai,2015-12-19
Zhang,Weili,Magnum,Hebei,China,35,25,3,0,89.28571428571429,10.714285714285714,28,Women's Strawweight Division,5.333333333333333,115.0,63.0,36.0,Muay Thai,2018-08-04
Alexa,Grasso,__FALCON_NULL_8FF29CAA__,Guadalajara,Mexico,31,16,4,1,80.0,20.0,20,Women's Flyweight Division,5.416666666666667,124.0,66.0,37.5,MMA,2016-11-06
Julianna,Peña,The Venezuelan Vixen,Spokane,United States,35,13,5,0,72.22222222222221,27.77777777777778,18,Women's Bantamweight Division,5.5,134.5,69.0,39.0,__FALCON_NULL_8FF29CAA__,2013-12-01
Manon,Fiorot,The Beast,Nice,France,34,12,1,0,92.3076923076923,7.6923076923076925,13,Women's Flyweight Division,5.583333333333333,124.5,65.0,38.0,Karate,2021-01-20
Erin,Blanchfield,Cold Blooded,__FALCON_NULL_8FF29CAA__,United States,25,13,2,0,86.66666666666667,13.333333333333334,15,Women's Flyweight Division,5.333333333333333,125.5,66.0,36.0,Jiu-Jitsu,2021-09-18
Rose,Namajunas,Thug,Milwaukee,United States,32,14,7,0,66.66666666666666,33.33333333333333,21,Women's Flyweight Division,5.416666666666667,125.0,65.0,39.5,MMA,2014-12-12
Raquel,Pennington,Rocky,Colorado Springs,United States,36,16,10,0,61.53846153846154,38.46153846153847,26,Women's Bantamweight Division,5.583333333333333,135.0,67.5,37.0,Freestyle,2013-12-01
Tatiana,Suarez,__FALCON_NULL_8FF29CAA__,Bellflower,United States,33,11,0,0,100.0,0.0,11,Women's Strawweight Division,5.416666666666667,115.5,66.0,39.0,MMA,2016-07-09
Yan,Xiaonan,__FALCON_NULL_8FF29CAA__,Liaoning,China,35,19,4,0,82.6086956521739,17.391304347826086,23,Women's Strawweight Division,5.416666666666667,116.0,63.0,37.0,Striker,2017-11-25
Virna,Jandiroba,Carcara,State of Bahia,Brazil,36,21,3,0,87.5,12.5,24,Women's Strawweight Division,5.25,115.5,64.0,37.0,Jiu-Jitsu,2019-04-27
Jéssica,Andrade ,Bate Estaca,Umuarama,Brazil,33,26,13,0,66.66666666666666,33.33333333333333,39,Women's Flyweight Division,5.125,124.5,62.0,35.0,Muay Thai,2013-07-27
Natalia,Silva,__FALCON_NULL_8FF29CAA__,Timóteo,Brazil,27,18,5,1,78.26086956521739,21.73913043478261,23,Women's Flyweight Division,5.333333333333333,125.5,65.0,36.0,Taekwondo,2022-06-18
Maycee,Barber,The Future,Greeley,United States,26,14,2,0,87.5,12.5,16,Women's Flyweight Division,5.416666666666667,125.0,65.0,38.0,Freestyle,2018-11-10
Amanda,Lemos,__FALCON_NULL_8FF29CAA__,Belém,Brazil,37,14,4,1,77.77777777777779,22.22222222222222,18,Women's Strawweight Division,5.333333333333333,116.0,65.0,36.0,Boxing,2017-07-16
Mackenzie,Dern,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,United States,31,14,5,0,73.68421052631578,26.31578947368421,19,Women's Strawweight Division,5.333333333333333,115.5,63.0,37.5,Brazilian Jiu-Jitsu,2018-03-03
Iasmin,Lucindo,__FALCON_NULL_8FF29CAA__,Fortaleza,Brazil,22,17,5,0,77.27272727272727,22.727272727272727,22,Women's Strawweight Division,5.25,116.0,66.0,36.0,Striker,2022-08-13
Amanda,Ribas,__FALCON_NULL_8FF29CAA__,Varginha,Brazil,31,12,5,0,70.58823529411765,29.411764705882355,17,Women's Strawweight Division,5.333333333333333,125.5,66.0,37.0,Judo,2019-06-29
Marina,Rodriguez,__FALCON_NULL_8FF29CAA__,State of Rio Grande do Sul,Brazil,37,17,5,2,77.27272727272727,22.727272727272727,22,Women's Strawweight Division,5.5,115.5,65.0,38.5,Muay Thai,2018-09-23
Tabatha,Ricci,Baby Shark,State of São Paulo,Brazil,29,11,3,0,78.57142857142857,21.428571428571427,14,Women's Strawweight Division,5.083333333333333,115.5,61.0,36.0,Judo,2021-06-05
Loopy,Godinez,__FALCON_NULL_8FF29CAA__,Aguascalientes,Mexico,31,12,5,0,70.58823529411765,29.411764705882355,17,Women's Strawweight Division,5.166666666666667,115.5,61.0,35.0,__FALCON_NULL_8FF29CAA__,2021-04-17
Gillian,Robertson,The Savage,Niagara Falls,Canada,29,15,8,0,65.21739130434783,34.78260869565217,23,Women's Strawweight Division,5.416666666666667,116.0,63.0,35.5,MMA,2017-12-01
Angela,Hill,Overkill,Clinton,United States,39,17,14,0,54.83870967741935,45.16129032258064,31,Women's Strawweight Division,5.25,115.5,64.5,38.5,Muay Thai,2014-12-12
Luana,Pinheiro,__FALCON_NULL_8FF29CAA__,João Pessoa,Brazil,32,11,4,0,73.33333333333333,26.666666666666668,15,Women's Strawweight Division,5.208333333333333,115.5,62.5,38.0,Judo,2021-03-27
Tecia,Pennington,Tiny Tornado,Fall River,United States,35,14,7,0,66.66666666666666,33.33333333333333,21,Women's Strawweight Division,5.083333333333333,115.0,60.5,35.0,Kickboxer,2014-12-12
Viviane,Araújo,Vivi,Brasília,Brazil,38,13,6,0,68.42105263157895,31.57894736842105,19,Women's Flyweight Division,5.333333333333333,125.6,68.0,36.5,MMA,2019-05-11
Tracy,Cortez,__FALCON_NULL_8FF29CAA__,Phoenix,United States,31,11,2,0,84.61538461538461,15.384615384615383,13,Women's Flyweight Division,5.416666666666667,126.0,65.5,38.5,MMA,2019-11-16
Jasmine,Jasudavicius,__FALCON_NULL_8FF29CAA__,St. Catharines,Canada,35,12,3,0,80.0,20.0,15,Women's Flyweight Division,5.583333333333333,125.0,68.0,38.0,Brawler,2022-01-22
Karine,Silva,Killer,Dourados,Brazil,31,18,5,0,78.26086956521739,21.73913043478261,23,Women's Flyweight Division,5.416666666666667,125.8,67.0,37.0,Brazilian Jiu-Jitsu,2022-06-04
Ariane,da Silva ,The Queen,Curitiba,Brazil,30,17,10,0,62.96296296296296,37.03703703703704,27,Women's Flyweight Division,5.5,125.0,67.0,38.5,Striker,2019-01-19
Miranda,Maverick,Fear The,Jefferson City,United States,27,17,5,0,77.27272727272727,22.727272727272727,22,Women's Flyweight Division,5.291666666666667,126.0,65.5,38.0,Jiu-Jitsu,2020-06-27
Ketlen,Vieira,Fenomeno,State of Amazonas,Brazil,33,14,4,0,77.77777777777779,22.22222222222222,18,Women's Bantamweight Division,5.666666666666667,136.0,68.0,39.5,Judo,2016-10-02
Norma,Dumont,The Immortal,Belo Horizonte,Brazil,34,12,2,0,85.71428571428571,14.285714285714285,14,Women's Bantamweight Division,5.583333333333333,136.0,67.0,38.5,__FALCON_NULL_8FF29CAA__,2020-02-29
Macy,Chiasson,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,United States,33,11,3,0,78.57142857142857,21.428571428571427,14,Women's Bantamweight Division,5.916666666666667,135.5,72.0,42.0,MMA,2018-11-30
Irene,Aldana,__FALCON_NULL_8FF29CAA__,Culiacán,Mexico,36,15,8,0,65.21739130434783,34.78260869565217,23,Women's Bantamweight Division,5.75,136.0,68.5,38.5,Striker,2016-12-18
Mayra,Bueno Silva,Sheetara,Uberlândia,Brazil,33,10,4,1,71.42857142857143,28.57142857142857,14,Women's Flyweight Division,5.5,136.0,66.5,39.0,Striker,2018-09-23
Holly,Holm,The Preacher's Daughter,Albuquerque,United States,43,15,7,0,68.18181818181817,31.818181818181817,22,Women's Bantamweight Division,5.666666666666667,136.0,69.0,38.0,Kickboxer,2015-02-28
Karol,Rosa,__FALCON_NULL_8FF29CAA__,Vila Velha,Brazil,29,18,6,0,75.0,25.0,24,Women's Bantamweight Division,5.416666666666667,135.5,67.5,36.0,Muay Thai,2019-08-31
Yana,Santos,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Russia,35,15,8,0,65.21739130434783,34.78260869565217,23,Women's Bantamweight Division,5.5,135.5,68.5,40.0,MMA,2018-03-03
Julia,Avila,Raging Panda,Los Angeles,United States,36,9,3,0,75.0,25.0,12,Women's Bantamweight Division,5.583333333333333,135.5,68.0,38.0,__FALCON_NULL_8FF29CAA__,2019-07-06
Ailin,Perez,Fiona,CABA,Argentina,30,11,2,0,84.61538461538461,15.384615384615383,13,Women's Bantamweight Division,5.416666666666667,136.5,66.0,36.0,Kung Fu,2022-09-03
Jacqueline,Cavalcanti,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Brazil,27,8,1,0,88.88888888888889,11.11111111111111,9,Women's Bantamweight Division,5.666666666666667,135.0,70.0,41.0,Striker,2023-09-02
Chelsea,Chandler,__FALCON_NULL_8FF29CAA__,Stockton,United States,34,6,3,0,66.66666666666666,33.33333333333333,9,Women's Bantamweight Division,5.708333333333333,141.0,68.0,40.0,MMA,2022-10-01
\.
analyze "falcon_db_22"."ufc_fighters_stats";
commit;
