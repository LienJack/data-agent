\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_16";
drop table if exists "falcon_db_16"."school_marks" cascade;
create table "falcon_db_16"."school_marks" ("MarkID" bigint, "StudentID" bigint, "SubjectID" bigint, "TeacherID" bigint, "MarkObtained" bigint, "ExamDate" text);
copy "falcon_db_16"."school_marks" ("MarkID", "StudentID", "SubjectID", "TeacherID", "MarkObtained", "ExamDate") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,1,1,1,85,2023-11-22
2,1,2,2,78,2023-11-22
3,1,3,3,92,2023-11-22
4,1,4,4,88,2023-11-22
5,1,5,5,95,2023-11-22
6,1,6,6,80,2023-11-22
7,1,7,7,75,2023-11-22
8,1,8,8,89,2023-11-22
9,1,9,9,91,2023-11-22
10,1,10,10,93,2023-11-22
11,2,1,1,76,2023-11-22
12,2,2,2,82,2023-11-22
13,2,3,3,88,2023-11-22
14,2,4,4,79,2023-11-22
15,2,5,5,94,2023-11-22
16,2,6,6,85,2023-11-22
17,2,7,7,71,2023-11-22
18,2,8,8,90,2023-11-22
19,2,9,9,87,2023-11-22
20,2,10,10,96,2023-11-22
\.
analyze "falcon_db_16"."school_marks";
drop table if exists "falcon_db_16"."school_students" cascade;
create table "falcon_db_16"."school_students" ("StudentID" bigint, "FirstName" text, "LastName" text, "DateOfBirth" text, "Address" text, "ContactNumber" bigint, "Email" text);
copy "falcon_db_16"."school_students" ("StudentID", "FirstName", "LastName", "DateOfBirth", "Address", "ContactNumber", "Email") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,John,Makori,1998-05-15,"Nairobi, Kenya",254712345678,john.makori@example.com
2,Amina,Njoroge,1999-08-22,"Nakuru, Kenya",254723456789,amina.njoroge@example.com
\.
analyze "falcon_db_16"."school_students";
drop table if exists "falcon_db_16"."school_subjects" cascade;
create table "falcon_db_16"."school_subjects" ("SubjectID" bigint, "SubjectName" text);
copy "falcon_db_16"."school_subjects" ("SubjectID", "SubjectName") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,Mathematics
2,English
3,Science
4,History
5,Geography
6,Computer Science
7,Swahili
8,Physics
9,Chemistry
10,Biology
\.
analyze "falcon_db_16"."school_subjects";
drop table if exists "falcon_db_16"."school_teachers" cascade;
create table "falcon_db_16"."school_teachers" ("TeacherID" bigint, "FirstName" text, "LastName" text, "DateOfBirth" text, "Address" text, "ContactNumber" bigint, "Email" text);
copy "falcon_db_16"."school_teachers" ("TeacherID", "FirstName", "LastName", "DateOfBirth", "Address", "ContactNumber", "Email") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,David,Mwangi,1980-03-15,"Nairobi, Kenya",254720123456,david.mwangi@example.com
2,Grace,Kimani,1985-06-22,"Kampala, Uganda",256755678901,grace.kimani@example.com
3,Mohammed,Abdi,1978-11-05,"Mogadishu, Somalia",252634567890,mohammed.abdi@example.com
4,Alice,Wambua,1982-02-28,"Dar es Salaam, Tanzania",255712345678,alice.wambua@example.com
5,Peter,Njoroge,1987-09-18,"Nakuru, Kenya",254723456789,peter.njoroge@example.com
6,Amina,Omar,1980-01-25,"Djibouti City, Djibouti",25366123456,amina.omar@example.com
7,Joseph,Kassim,1985-04-14,"Addis Ababa, Ethiopia",251911234567,joseph.kassim@example.com
8,Wanjiru,Kamau,1982-07-02,"Kigali, Rwanda",250782345678,wanjiru.kamau@example.com
9,Moses,Tewolde,1987-10-11,"Asmara, Eritrea",291712345678,moses.tewolde@example.com
10,Aisha,Said,1980-05-20,"Zanzibar, Tanzania",255765432109,aisha.said@example.com
\.
analyze "falcon_db_16"."school_teachers";
commit;
