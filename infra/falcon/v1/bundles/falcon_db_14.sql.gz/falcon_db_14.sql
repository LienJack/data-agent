\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_14";
drop table if exists "falcon_db_14"."toy_inventory" cascade;
create table "falcon_db_14"."toy_inventory" ("Store_ID" bigint, "Product_ID" bigint, "Stock_On_Hand" bigint);
copy "falcon_db_14"."toy_inventory" ("Store_ID", "Product_ID", "Stock_On_Hand") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
20,21,0
12,7,11
11,9,13
9,31,6
3,11,13
14,14,4
19,17,5
19,35,14
16,30,49
6,18,11
12,3,44
6,21,36
6,25,62
3,23,13
4,26,10
10,24,20
12,1,16
5,33,17
3,8,44
1,11,19
\.
analyze "falcon_db_14"."toy_inventory";
drop table if exists "falcon_db_14"."toy_products" cascade;
create table "falcon_db_14"."toy_products" ("Product_ID" bigint, "Product_Name" text, "Product_Category" text, "Product_Cost" text, "Product_Price" text);
copy "falcon_db_14"."toy_products" ("Product_ID", "Product_Name", "Product_Category", "Product_Cost", "Product_Price") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,Action Figure,Toys,$9.99 ,$15.99 
18,Lego Bricks,Toys,$34.99 ,$39.99 
16,Jenga,Games,$2.99 ,$9.99 
2,Animal Figures,Toys,$9.99 ,$12.99 
9,Dino Egg,Toys,$9.99 ,$10.99 
6,Colorbuds,Electronics,$6.99 ,$14.99 
12,Foam Disk Launcher,Sports & Outdoors,$8.99 ,$11.99 
4,Chutes & Ladders,Games,$9.99 ,$12.99 
19,Magic Sand,Art & Crafts,$13.99 ,$15.99 
17,Kids Makeup Kit,Art & Crafts,$13.99 ,$19.99 
14,Glass Marbles,Games,$5.99 ,$10.99 
3,Barrel O' Slime,Art & Crafts,$1.99 ,$3.99 
10,Dinosaur Figures,Toys,$10.99 ,$14.99 
20,Mini Basketball Hoop,Sports & Outdoors,$8.99 ,$24.99 
5,Classic Dominoes,Games,$7.99 ,$9.99 
13,Gamer Headphones,Electronics,$14.99 ,$20.99 
8,Deck Of Cards,Games,$3.99 ,$6.99 
11,Etch A Sketch,Art & Crafts,$10.99 ,$20.99 
15,Hot Wheels 5-Pack,Toys,$3.99 ,$5.99 
7,Dart Gun,Sports & Outdoors,$11.99 ,$15.99 
\.
analyze "falcon_db_14"."toy_products";
drop table if exists "falcon_db_14"."toy_sales" cascade;
create table "falcon_db_14"."toy_sales" ("Sale_ID" bigint, "Date" text, "Store_ID" bigint, "Product_ID" bigint, "Units" bigint);
copy "falcon_db_14"."toy_sales" ("Sale_ID", "Date", "Store_ID", "Product_ID", "Units") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
707914,2018-07-07,16,7,1
44788,2017-02-15,16,33,1
111895,2017-04-20,6,6,1
122566,2017-04-29,14,18,1
457020,2018-01-27,15,30,1
676349,2018-06-17,17,19,1
489526,2018-02-18,13,18,1
76712,2017-03-18,8,17,1
378838,2017-12-04,4,30,1
315958,2017-10-17,12,13,1
1120,2017-01-01,5,8,1
309215,2017-10-12,18,30,1
451062,2018-01-22,7,24,1
357881,2017-11-19,10,18,1
786466,2018-08-31,8,11,1
714891,2018-07-11,13,8,1
179677,2017-06-15,17,18,3
397811,2017-12-17,10,23,1
374836,2017-12-02,6,19,2
782957,2018-08-28,14,24,1
\.
analyze "falcon_db_14"."toy_sales";
drop table if exists "falcon_db_14"."toy_stores" cascade;
create table "falcon_db_14"."toy_stores" ("Store_ID" bigint, "Store_Name" text, "Store_City" text, "Store_Location" text, "Store_Open_Date" text);
copy "falcon_db_14"."toy_stores" ("Store_ID", "Store_Name", "Store_City", "Store_Location", "Store_Open_Date") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,Maven Toys Guadalajara 1,Guadalajara,Residential,1992-09-18
2,Maven Toys Monterrey 1,Monterrey,Residential,1995-04-27
3,Maven Toys Guadalajara 2,Guadalajara,Commercial,1999-12-27
4,Maven Toys Saltillo 1,Saltillo,Downtown,2000-01-01
5,Maven Toys La Paz 1,La Paz,Downtown,2001-05-31
6,Maven Toys Mexicali 1,Mexicali,Commercial,2003-12-13
7,Maven Toys Monterrey 2,Monterrey,Downtown,2003-12-25
8,Maven Toys Pachuca 1,Pachuca,Downtown,2004-10-14
9,Maven Toys Ciudad de Mexico 1,Cuidad de Mexico,Downtown,2004-10-15
10,Maven Toys Campeche 1,Campeche,Downtown,2005-01-14
11,Maven Toys Cuernavaca 1,Cuernavaca,Downtown,2005-04-19
12,Maven Toys Chetumal 1,Chetumal,Downtown,2006-05-05
13,Maven Toys Mexicali 2,Mexicali,Downtown,2006-08-30
14,Maven Toys Guanajuato 1,Guanajuato,Downtown,2007-01-31
15,Maven Toys Tuxtla Gutierrez 1,Tuxtla Gutierrez,Downtown,2007-03-05
16,Maven Toys San Luis Potosi 1,San Luis Potosi,Downtown,2007-05-19
17,Maven Toys Toluca 1,Toluca,Downtown,2007-12-09
18,Maven Toys Merida 1,Merida,Downtown,2008-08-22
19,Maven Toys Puebla 1,Puebla,Commercial,2008-12-16
20,Maven Toys Zacatecas 1,Zacatecas,Downtown,2009-05-29
\.
analyze "falcon_db_14"."toy_stores";
commit;
