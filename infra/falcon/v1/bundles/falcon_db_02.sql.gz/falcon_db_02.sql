\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_02";
drop table if exists "falcon_db_02"."finance_loan_approval_prediction_data" cascade;
create table "falcon_db_02"."finance_loan_approval_prediction_data" ("Loan_ID" text, "Gender" text, "Married" text, "Dependents" text, "Education" text, "Self_Employed" text, "ApplicantIncome" bigint, "CoapplicantIncome" double precision, "LoanAmount" double precision, "Loan_Amount_Term" double precision, "Credit_History" double precision, "Property_Area" text, "Loan_Status" text);
copy "falcon_db_02"."finance_loan_approval_prediction_data" ("Loan_ID", "Gender", "Married", "Dependents", "Education", "Self_Employed", "ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term", "Credit_History", "Property_Area", "Loan_Status") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
LP001002,Male,No,0,Graduate,No,5849,0.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Urban,Y
LP001003,Male,Yes,1,Graduate,No,4583,1508.0,128.0,360.0,1.0,Rural,N
LP001005,Male,Yes,0,Graduate,Yes,3000,0.0,66.0,360.0,1.0,Urban,Y
LP001006,Male,Yes,0,Not Graduate,No,2583,2358.0,120.0,360.0,1.0,Urban,Y
LP001008,Male,No,0,Graduate,No,6000,0.0,141.0,360.0,1.0,Urban,Y
LP001011,Male,Yes,2,Graduate,Yes,5417,4196.0,267.0,360.0,1.0,Urban,Y
LP001013,Male,Yes,0,Not Graduate,No,2333,1516.0,95.0,360.0,1.0,Urban,Y
LP001014,Male,Yes,3+,Graduate,No,3036,2504.0,158.0,360.0,0.0,Semiurban,N
LP001018,Male,Yes,2,Graduate,No,4006,1526.0,168.0,360.0,1.0,Urban,Y
LP001020,Male,Yes,1,Graduate,No,12841,10968.0,349.0,360.0,1.0,Semiurban,N
LP001024,Male,Yes,2,Graduate,No,3200,700.0,70.0,360.0,1.0,Urban,Y
LP001027,Male,Yes,2,Graduate,__FALCON_NULL_8FF29CAA__,2500,1840.0,109.0,360.0,1.0,Urban,Y
LP001028,Male,Yes,2,Graduate,No,3073,8106.0,200.0,360.0,1.0,Urban,Y
LP001029,Male,No,0,Graduate,No,1853,2840.0,114.0,360.0,1.0,Rural,N
LP001030,Male,Yes,2,Graduate,No,1299,1086.0,17.0,120.0,1.0,Urban,Y
LP001032,Male,No,0,Graduate,No,4950,0.0,125.0,360.0,1.0,Urban,Y
LP001034,Male,No,1,Not Graduate,No,3596,0.0,100.0,240.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP001036,Female,No,0,Graduate,No,3510,0.0,76.0,360.0,0.0,Urban,N
LP001038,Male,Yes,0,Not Graduate,No,4887,0.0,133.0,360.0,1.0,Rural,N
LP001041,Male,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,2600,3500.0,115.0,__FALCON_NULL_8FF29CAA__,1.0,Urban,Y
LP001043,Male,Yes,0,Not Graduate,No,7660,0.0,104.0,360.0,0.0,Urban,N
LP001046,Male,Yes,1,Graduate,No,5955,5625.0,315.0,360.0,1.0,Urban,Y
LP001047,Male,Yes,0,Not Graduate,No,2600,1911.0,116.0,360.0,0.0,Semiurban,N
LP001050,__FALCON_NULL_8FF29CAA__,Yes,2,Not Graduate,No,3365,1917.0,112.0,360.0,0.0,Rural,N
LP001052,Male,Yes,1,Graduate,__FALCON_NULL_8FF29CAA__,3717,2925.0,151.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,N
LP001066,Male,Yes,0,Graduate,Yes,9560,0.0,191.0,360.0,1.0,Semiurban,Y
LP001068,Male,Yes,0,Graduate,No,2799,2253.0,122.0,360.0,1.0,Semiurban,Y
LP001073,Male,Yes,2,Not Graduate,No,4226,1040.0,110.0,360.0,1.0,Urban,Y
LP001086,Male,No,0,Not Graduate,No,1442,0.0,35.0,360.0,1.0,Urban,N
LP001087,Female,No,2,Graduate,__FALCON_NULL_8FF29CAA__,3750,2083.0,120.0,360.0,1.0,Semiurban,Y
LP001091,Male,Yes,1,Graduate,__FALCON_NULL_8FF29CAA__,4166,3369.0,201.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,N
LP001095,Male,No,0,Graduate,No,3167,0.0,74.0,360.0,1.0,Urban,N
LP001097,Male,No,1,Graduate,Yes,4692,0.0,106.0,360.0,1.0,Rural,N
LP001098,Male,Yes,0,Graduate,No,3500,1667.0,114.0,360.0,1.0,Semiurban,Y
LP001100,Male,No,3+,Graduate,No,12500,3000.0,320.0,360.0,1.0,Rural,N
LP001106,Male,Yes,0,Graduate,No,2275,2067.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Urban,Y
LP001109,Male,Yes,0,Graduate,No,1828,1330.0,100.0,__FALCON_NULL_8FF29CAA__,0.0,Urban,N
LP001112,Female,Yes,0,Graduate,No,3667,1459.0,144.0,360.0,1.0,Semiurban,Y
LP001114,Male,No,0,Graduate,No,4166,7210.0,184.0,360.0,1.0,Urban,Y
LP001116,Male,No,0,Not Graduate,No,3748,1668.0,110.0,360.0,1.0,Semiurban,Y
LP001119,Male,No,0,Graduate,No,3600,0.0,80.0,360.0,1.0,Urban,N
LP001120,Male,No,0,Graduate,No,1800,1213.0,47.0,360.0,1.0,Urban,Y
LP001123,Male,Yes,0,Graduate,No,2400,0.0,75.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP001131,Male,Yes,0,Graduate,No,3941,2336.0,134.0,360.0,1.0,Semiurban,Y
LP001136,Male,Yes,0,Not Graduate,Yes,4695,0.0,96.0,__FALCON_NULL_8FF29CAA__,1.0,Urban,Y
LP001137,Female,No,0,Graduate,No,3410,0.0,88.0,__FALCON_NULL_8FF29CAA__,1.0,Urban,Y
LP001138,Male,Yes,1,Graduate,No,5649,0.0,44.0,360.0,1.0,Urban,Y
LP001144,Male,Yes,0,Graduate,No,5821,0.0,144.0,360.0,1.0,Urban,Y
LP001146,Female,Yes,0,Graduate,No,2645,3440.0,120.0,360.0,0.0,Urban,N
LP001151,Female,No,0,Graduate,No,4000,2275.0,144.0,360.0,1.0,Semiurban,Y
LP001155,Female,Yes,0,Not Graduate,No,1928,1644.0,100.0,360.0,1.0,Semiurban,Y
LP001157,Female,No,0,Graduate,No,3086,0.0,120.0,360.0,1.0,Semiurban,Y
LP001164,Female,No,0,Graduate,No,4230,0.0,112.0,360.0,1.0,Semiurban,N
LP001179,Male,Yes,2,Graduate,No,4616,0.0,134.0,360.0,1.0,Urban,N
LP001186,Female,Yes,1,Graduate,Yes,11500,0.0,286.0,360.0,0.0,Urban,N
LP001194,Male,Yes,2,Graduate,No,2708,1167.0,97.0,360.0,1.0,Semiurban,Y
LP001195,Male,Yes,0,Graduate,No,2132,1591.0,96.0,360.0,1.0,Semiurban,Y
LP001197,Male,Yes,0,Graduate,No,3366,2200.0,135.0,360.0,1.0,Rural,N
LP001198,Male,Yes,1,Graduate,No,8080,2250.0,180.0,360.0,1.0,Urban,Y
LP001199,Male,Yes,2,Not Graduate,No,3357,2859.0,144.0,360.0,1.0,Urban,Y
LP001205,Male,Yes,0,Graduate,No,2500,3796.0,120.0,360.0,1.0,Urban,Y
LP001206,Male,Yes,3+,Graduate,No,3029,0.0,99.0,360.0,1.0,Urban,Y
LP001207,Male,Yes,0,Not Graduate,Yes,2609,3449.0,165.0,180.0,0.0,Rural,N
LP001213,Male,Yes,1,Graduate,No,4945,0.0,__FALCON_NULL_8FF29CAA__,360.0,0.0,Rural,N
LP001222,Female,No,0,Graduate,No,4166,0.0,116.0,360.0,0.0,Semiurban,N
LP001225,Male,Yes,0,Graduate,No,5726,4595.0,258.0,360.0,1.0,Semiurban,N
LP001228,Male,No,0,Not Graduate,No,3200,2254.0,126.0,180.0,0.0,Urban,N
LP001233,Male,Yes,1,Graduate,No,10750,0.0,312.0,360.0,1.0,Urban,Y
LP001238,Male,Yes,3+,Not Graduate,Yes,7100,0.0,125.0,60.0,1.0,Urban,Y
LP001241,Female,No,0,Graduate,No,4300,0.0,136.0,360.0,0.0,Semiurban,N
LP001243,Male,Yes,0,Graduate,No,3208,3066.0,172.0,360.0,1.0,Urban,Y
LP001245,Male,Yes,2,Not Graduate,Yes,1875,1875.0,97.0,360.0,1.0,Semiurban,Y
LP001248,Male,No,0,Graduate,No,3500,0.0,81.0,300.0,1.0,Semiurban,Y
LP001250,Male,Yes,3+,Not Graduate,No,4755,0.0,95.0,__FALCON_NULL_8FF29CAA__,0.0,Semiurban,N
LP001253,Male,Yes,3+,Graduate,Yes,5266,1774.0,187.0,360.0,1.0,Semiurban,Y
LP001255,Male,No,0,Graduate,No,3750,0.0,113.0,480.0,1.0,Urban,N
LP001256,Male,No,0,Graduate,No,3750,4750.0,176.0,360.0,1.0,Urban,N
LP001259,Male,Yes,1,Graduate,Yes,1000,3022.0,110.0,360.0,1.0,Urban,N
LP001263,Male,Yes,3+,Graduate,No,3167,4000.0,180.0,300.0,0.0,Semiurban,N
LP001264,Male,Yes,3+,Not Graduate,Yes,3333,2166.0,130.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP001265,Female,No,0,Graduate,No,3846,0.0,111.0,360.0,1.0,Semiurban,Y
LP001266,Male,Yes,1,Graduate,Yes,2395,0.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Semiurban,Y
LP001267,Female,Yes,2,Graduate,No,1378,1881.0,167.0,360.0,1.0,Urban,N
LP001273,Male,Yes,0,Graduate,No,6000,2250.0,265.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,N
LP001275,Male,Yes,1,Graduate,No,3988,0.0,50.0,240.0,1.0,Urban,Y
LP001279,Male,No,0,Graduate,No,2366,2531.0,136.0,360.0,1.0,Semiurban,Y
LP001280,Male,Yes,2,Not Graduate,No,3333,2000.0,99.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP001282,Male,Yes,0,Graduate,No,2500,2118.0,104.0,360.0,1.0,Semiurban,Y
LP001289,Male,No,0,Graduate,No,8566,0.0,210.0,360.0,1.0,Urban,Y
LP001310,Male,Yes,0,Graduate,No,5695,4167.0,175.0,360.0,1.0,Semiurban,Y
LP001316,Male,Yes,0,Graduate,No,2958,2900.0,131.0,360.0,1.0,Semiurban,Y
LP001318,Male,Yes,2,Graduate,No,6250,5654.0,188.0,180.0,1.0,Semiurban,Y
LP001319,Male,Yes,2,Not Graduate,No,3273,1820.0,81.0,360.0,1.0,Urban,Y
LP001322,Male,No,0,Graduate,No,4133,0.0,122.0,360.0,1.0,Semiurban,Y
LP001325,Male,No,0,Not Graduate,No,3620,0.0,25.0,120.0,1.0,Semiurban,Y
LP001326,Male,No,0,Graduate,__FALCON_NULL_8FF29CAA__,6782,0.0,__FALCON_NULL_8FF29CAA__,360.0,__FALCON_NULL_8FF29CAA__,Urban,N
LP001327,Female,Yes,0,Graduate,No,2484,2302.0,137.0,360.0,1.0,Semiurban,Y
LP001333,Male,Yes,0,Graduate,No,1977,997.0,50.0,360.0,1.0,Semiurban,Y
LP001334,Male,Yes,0,Not Graduate,No,4188,0.0,115.0,180.0,1.0,Semiurban,Y
LP001343,Male,Yes,0,Graduate,No,1759,3541.0,131.0,360.0,1.0,Semiurban,Y
LP001345,Male,Yes,2,Not Graduate,No,4288,3263.0,133.0,180.0,1.0,Urban,Y
LP001349,Male,No,0,Graduate,No,4843,3806.0,151.0,360.0,1.0,Semiurban,Y
LP001350,Male,Yes,__FALCON_NULL_8FF29CAA__,Graduate,No,13650,0.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Urban,Y
LP001356,Male,Yes,0,Graduate,No,4652,3583.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Semiurban,Y
LP001357,Male,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Graduate,No,3816,754.0,160.0,360.0,1.0,Urban,Y
LP001367,Male,Yes,1,Graduate,No,3052,1030.0,100.0,360.0,1.0,Urban,Y
LP001369,Male,Yes,2,Graduate,No,11417,1126.0,225.0,360.0,1.0,Urban,Y
LP001370,Male,No,0,Not Graduate,__FALCON_NULL_8FF29CAA__,7333,0.0,120.0,360.0,1.0,Rural,N
LP001379,Male,Yes,2,Graduate,No,3800,3600.0,216.0,360.0,0.0,Urban,N
LP001384,Male,Yes,3+,Not Graduate,No,2071,754.0,94.0,480.0,1.0,Semiurban,Y
LP001385,Male,No,0,Graduate,No,5316,0.0,136.0,360.0,1.0,Urban,Y
LP001387,Female,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,2929,2333.0,139.0,360.0,1.0,Semiurban,Y
LP001391,Male,Yes,0,Not Graduate,No,3572,4114.0,152.0,__FALCON_NULL_8FF29CAA__,0.0,Rural,N
LP001392,Female,No,1,Graduate,Yes,7451,0.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Semiurban,Y
LP001398,Male,No,0,Graduate,__FALCON_NULL_8FF29CAA__,5050,0.0,118.0,360.0,1.0,Semiurban,Y
LP001401,Male,Yes,1,Graduate,No,14583,0.0,185.0,180.0,1.0,Rural,Y
LP001404,Female,Yes,0,Graduate,No,3167,2283.0,154.0,360.0,1.0,Semiurban,Y
LP001405,Male,Yes,1,Graduate,No,2214,1398.0,85.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP001421,Male,Yes,0,Graduate,No,5568,2142.0,175.0,360.0,1.0,Rural,N
LP001422,Female,No,0,Graduate,No,10408,0.0,259.0,360.0,1.0,Urban,Y
LP001426,Male,Yes,__FALCON_NULL_8FF29CAA__,Graduate,No,5667,2667.0,180.0,360.0,1.0,Rural,Y
LP001430,Female,No,0,Graduate,No,4166,0.0,44.0,360.0,1.0,Semiurban,Y
LP001431,Female,No,0,Graduate,No,2137,8980.0,137.0,360.0,0.0,Semiurban,Y
LP001432,Male,Yes,2,Graduate,No,2957,0.0,81.0,360.0,1.0,Semiurban,Y
LP001439,Male,Yes,0,Not Graduate,No,4300,2014.0,194.0,360.0,1.0,Rural,Y
LP001443,Female,No,0,Graduate,No,3692,0.0,93.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP001448,__FALCON_NULL_8FF29CAA__,Yes,3+,Graduate,No,23803,0.0,370.0,360.0,1.0,Rural,Y
LP001449,Male,No,0,Graduate,No,3865,1640.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Rural,Y
LP001451,Male,Yes,1,Graduate,Yes,10513,3850.0,160.0,180.0,0.0,Urban,N
LP001465,Male,Yes,0,Graduate,No,6080,2569.0,182.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,N
LP001469,Male,No,0,Graduate,Yes,20166,0.0,650.0,480.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP001473,Male,No,0,Graduate,No,2014,1929.0,74.0,360.0,1.0,Urban,Y
LP001478,Male,No,0,Graduate,No,2718,0.0,70.0,360.0,1.0,Semiurban,Y
LP001482,Male,Yes,0,Graduate,Yes,3459,0.0,25.0,120.0,1.0,Semiurban,Y
LP001487,Male,No,0,Graduate,No,4895,0.0,102.0,360.0,1.0,Semiurban,Y
LP001488,Male,Yes,3+,Graduate,No,4000,7750.0,290.0,360.0,1.0,Semiurban,N
LP001489,Female,Yes,0,Graduate,No,4583,0.0,84.0,360.0,1.0,Rural,N
LP001491,Male,Yes,2,Graduate,Yes,3316,3500.0,88.0,360.0,1.0,Urban,Y
LP001492,Male,No,0,Graduate,No,14999,0.0,242.0,360.0,0.0,Semiurban,N
LP001493,Male,Yes,2,Not Graduate,No,4200,1430.0,129.0,360.0,1.0,Rural,N
LP001497,Male,Yes,2,Graduate,No,5042,2083.0,185.0,360.0,1.0,Rural,N
LP001498,Male,No,0,Graduate,No,5417,0.0,168.0,360.0,1.0,Urban,Y
LP001504,Male,No,0,Graduate,Yes,6950,0.0,175.0,180.0,1.0,Semiurban,Y
LP001507,Male,Yes,0,Graduate,No,2698,2034.0,122.0,360.0,1.0,Semiurban,Y
LP001508,Male,Yes,2,Graduate,No,11757,0.0,187.0,180.0,1.0,Urban,Y
LP001514,Female,Yes,0,Graduate,No,2330,4486.0,100.0,360.0,1.0,Semiurban,Y
LP001516,Female,Yes,2,Graduate,No,14866,0.0,70.0,360.0,1.0,Urban,Y
LP001518,Male,Yes,1,Graduate,No,1538,1425.0,30.0,360.0,1.0,Urban,Y
LP001519,Female,No,0,Graduate,No,10000,1666.0,225.0,360.0,1.0,Rural,N
LP001520,Male,Yes,0,Graduate,No,4860,830.0,125.0,360.0,1.0,Semiurban,Y
LP001528,Male,No,0,Graduate,No,6277,0.0,118.0,360.0,0.0,Rural,N
LP001529,Male,Yes,0,Graduate,Yes,2577,3750.0,152.0,360.0,1.0,Rural,Y
LP001531,Male,No,0,Graduate,No,9166,0.0,244.0,360.0,1.0,Urban,N
LP001532,Male,Yes,2,Not Graduate,No,2281,0.0,113.0,360.0,1.0,Rural,N
LP001535,Male,No,0,Graduate,No,3254,0.0,50.0,360.0,1.0,Urban,Y
LP001536,Male,Yes,3+,Graduate,No,39999,0.0,600.0,180.0,0.0,Semiurban,Y
LP001541,Male,Yes,1,Graduate,No,6000,0.0,160.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP001543,Male,Yes,1,Graduate,No,9538,0.0,187.0,360.0,1.0,Urban,Y
LP001546,Male,No,0,Graduate,__FALCON_NULL_8FF29CAA__,2980,2083.0,120.0,360.0,1.0,Rural,Y
LP001552,Male,Yes,0,Graduate,No,4583,5625.0,255.0,360.0,1.0,Semiurban,Y
LP001560,Male,Yes,0,Not Graduate,No,1863,1041.0,98.0,360.0,1.0,Semiurban,Y
LP001562,Male,Yes,0,Graduate,No,7933,0.0,275.0,360.0,1.0,Urban,N
LP001565,Male,Yes,1,Graduate,No,3089,1280.0,121.0,360.0,0.0,Semiurban,N
LP001570,Male,Yes,2,Graduate,No,4167,1447.0,158.0,360.0,1.0,Rural,Y
LP001572,Male,Yes,0,Graduate,No,9323,0.0,75.0,180.0,1.0,Urban,Y
LP001574,Male,Yes,0,Graduate,No,3707,3166.0,182.0,__FALCON_NULL_8FF29CAA__,1.0,Rural,Y
LP001577,Female,Yes,0,Graduate,No,4583,0.0,112.0,360.0,1.0,Rural,N
LP001578,Male,Yes,0,Graduate,No,2439,3333.0,129.0,360.0,1.0,Rural,Y
LP001579,Male,No,0,Graduate,No,2237,0.0,63.0,480.0,0.0,Semiurban,N
LP001580,Male,Yes,2,Graduate,No,8000,0.0,200.0,360.0,1.0,Semiurban,Y
LP001581,Male,Yes,0,Not Graduate,__FALCON_NULL_8FF29CAA__,1820,1769.0,95.0,360.0,1.0,Rural,Y
LP001585,__FALCON_NULL_8FF29CAA__,Yes,3+,Graduate,No,51763,0.0,700.0,300.0,1.0,Urban,Y
LP001586,Male,Yes,3+,Not Graduate,No,3522,0.0,81.0,180.0,1.0,Rural,N
LP001594,Male,Yes,0,Graduate,No,5708,5625.0,187.0,360.0,1.0,Semiurban,Y
LP001603,Male,Yes,0,Not Graduate,Yes,4344,736.0,87.0,360.0,1.0,Semiurban,N
LP001606,Male,Yes,0,Graduate,No,3497,1964.0,116.0,360.0,1.0,Rural,Y
LP001608,Male,Yes,2,Graduate,No,2045,1619.0,101.0,360.0,1.0,Rural,Y
LP001610,Male,Yes,3+,Graduate,No,5516,11300.0,495.0,360.0,0.0,Semiurban,N
LP001616,Male,Yes,1,Graduate,No,3750,0.0,116.0,360.0,1.0,Semiurban,Y
LP001630,Male,No,0,Not Graduate,No,2333,1451.0,102.0,480.0,0.0,Urban,N
LP001633,Male,Yes,1,Graduate,No,6400,7250.0,180.0,360.0,0.0,Urban,N
LP001634,Male,No,0,Graduate,No,1916,5063.0,67.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,N
LP001636,Male,Yes,0,Graduate,No,4600,0.0,73.0,180.0,1.0,Semiurban,Y
LP001637,Male,Yes,1,Graduate,No,33846,0.0,260.0,360.0,1.0,Semiurban,N
LP001639,Female,Yes,0,Graduate,No,3625,0.0,108.0,360.0,1.0,Semiurban,Y
LP001640,Male,Yes,0,Graduate,Yes,39147,4750.0,120.0,360.0,1.0,Semiurban,Y
LP001641,Male,Yes,1,Graduate,Yes,2178,0.0,66.0,300.0,0.0,Rural,N
LP001643,Male,Yes,0,Graduate,No,2383,2138.0,58.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP001644,__FALCON_NULL_8FF29CAA__,Yes,0,Graduate,Yes,674,5296.0,168.0,360.0,1.0,Rural,Y
LP001647,Male,Yes,0,Graduate,No,9328,0.0,188.0,180.0,1.0,Rural,Y
LP001653,Male,No,0,Not Graduate,No,4885,0.0,48.0,360.0,1.0,Rural,Y
LP001656,Male,No,0,Graduate,No,12000,0.0,164.0,360.0,1.0,Semiurban,N
LP001657,Male,Yes,0,Not Graduate,No,6033,0.0,160.0,360.0,1.0,Urban,N
LP001658,Male,No,0,Graduate,No,3858,0.0,76.0,360.0,1.0,Semiurban,Y
LP001664,Male,No,0,Graduate,No,4191,0.0,120.0,360.0,1.0,Rural,Y
LP001665,Male,Yes,1,Graduate,No,3125,2583.0,170.0,360.0,1.0,Semiurban,N
LP001666,Male,No,0,Graduate,No,8333,3750.0,187.0,360.0,1.0,Rural,Y
LP001669,Female,No,0,Not Graduate,No,1907,2365.0,120.0,__FALCON_NULL_8FF29CAA__,1.0,Urban,Y
LP001671,Female,Yes,0,Graduate,No,3416,2816.0,113.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP001673,Male,No,0,Graduate,Yes,11000,0.0,83.0,360.0,1.0,Urban,N
LP001674,Male,Yes,1,Not Graduate,No,2600,2500.0,90.0,360.0,1.0,Semiurban,Y
LP001677,Male,No,2,Graduate,No,4923,0.0,166.0,360.0,0.0,Semiurban,Y
LP001682,Male,Yes,3+,Not Graduate,No,3992,0.0,__FALCON_NULL_8FF29CAA__,180.0,1.0,Urban,N
LP001688,Male,Yes,1,Not Graduate,No,3500,1083.0,135.0,360.0,1.0,Urban,Y
LP001691,Male,Yes,2,Not Graduate,No,3917,0.0,124.0,360.0,1.0,Semiurban,Y
LP001692,Female,No,0,Not Graduate,No,4408,0.0,120.0,360.0,1.0,Semiurban,Y
LP001693,Female,No,0,Graduate,No,3244,0.0,80.0,360.0,1.0,Urban,Y
LP001698,Male,No,0,Not Graduate,No,3975,2531.0,55.0,360.0,1.0,Rural,Y
LP001699,Male,No,0,Graduate,No,2479,0.0,59.0,360.0,1.0,Urban,Y
LP001702,Male,No,0,Graduate,No,3418,0.0,127.0,360.0,1.0,Semiurban,N
LP001708,Female,No,0,Graduate,No,10000,0.0,214.0,360.0,1.0,Semiurban,N
LP001711,Male,Yes,3+,Graduate,No,3430,1250.0,128.0,360.0,0.0,Semiurban,N
LP001713,Male,Yes,1,Graduate,Yes,7787,0.0,240.0,360.0,1.0,Urban,Y
LP001715,Male,Yes,3+,Not Graduate,Yes,5703,0.0,130.0,360.0,1.0,Rural,Y
LP001716,Male,Yes,0,Graduate,No,3173,3021.0,137.0,360.0,1.0,Urban,Y
LP001720,Male,Yes,3+,Not Graduate,No,3850,983.0,100.0,360.0,1.0,Semiurban,Y
LP001722,Male,Yes,0,Graduate,No,150,1800.0,135.0,360.0,1.0,Rural,N
LP001726,Male,Yes,0,Graduate,No,3727,1775.0,131.0,360.0,1.0,Semiurban,Y
LP001732,Male,Yes,2,Graduate,__FALCON_NULL_8FF29CAA__,5000,0.0,72.0,360.0,0.0,Semiurban,N
LP001734,Female,Yes,2,Graduate,No,4283,2383.0,127.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP001736,Male,Yes,0,Graduate,No,2221,0.0,60.0,360.0,0.0,Urban,N
LP001743,Male,Yes,2,Graduate,No,4009,1717.0,116.0,360.0,1.0,Semiurban,Y
LP001744,Male,No,0,Graduate,No,2971,2791.0,144.0,360.0,1.0,Semiurban,Y
LP001749,Male,Yes,0,Graduate,No,7578,1010.0,175.0,__FALCON_NULL_8FF29CAA__,1.0,Semiurban,Y
LP001750,Male,Yes,0,Graduate,No,6250,0.0,128.0,360.0,1.0,Semiurban,Y
LP001751,Male,Yes,0,Graduate,No,3250,0.0,170.0,360.0,1.0,Rural,N
LP001754,Male,Yes,__FALCON_NULL_8FF29CAA__,Not Graduate,Yes,4735,0.0,138.0,360.0,1.0,Urban,N
LP001758,Male,Yes,2,Graduate,No,6250,1695.0,210.0,360.0,1.0,Semiurban,Y
LP001760,Male,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Graduate,No,4758,0.0,158.0,480.0,1.0,Semiurban,Y
LP001761,Male,No,0,Graduate,Yes,6400,0.0,200.0,360.0,1.0,Rural,Y
LP001765,Male,Yes,1,Graduate,No,2491,2054.0,104.0,360.0,1.0,Semiurban,Y
LP001768,Male,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,3716,0.0,42.0,180.0,1.0,Rural,Y
LP001770,Male,No,0,Not Graduate,No,3189,2598.0,120.0,__FALCON_NULL_8FF29CAA__,1.0,Rural,Y
LP001776,Female,No,0,Graduate,No,8333,0.0,280.0,360.0,1.0,Semiurban,Y
LP001778,Male,Yes,1,Graduate,No,3155,1779.0,140.0,360.0,1.0,Semiurban,Y
LP001784,Male,Yes,1,Graduate,No,5500,1260.0,170.0,360.0,1.0,Rural,Y
LP001786,Male,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,5746,0.0,255.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,N
LP001788,Female,No,0,Graduate,Yes,3463,0.0,122.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP001790,Female,No,1,Graduate,No,3812,0.0,112.0,360.0,1.0,Rural,Y
LP001792,Male,Yes,1,Graduate,No,3315,0.0,96.0,360.0,1.0,Semiurban,Y
LP001798,Male,Yes,2,Graduate,No,5819,5000.0,120.0,360.0,1.0,Rural,Y
LP001800,Male,Yes,1,Not Graduate,No,2510,1983.0,140.0,180.0,1.0,Urban,N
LP001806,Male,No,0,Graduate,No,2965,5701.0,155.0,60.0,1.0,Urban,Y
LP001807,Male,Yes,2,Graduate,Yes,6250,1300.0,108.0,360.0,1.0,Rural,Y
LP001811,Male,Yes,0,Not Graduate,No,3406,4417.0,123.0,360.0,1.0,Semiurban,Y
LP001813,Male,No,0,Graduate,Yes,6050,4333.0,120.0,180.0,1.0,Urban,N
LP001814,Male,Yes,2,Graduate,No,9703,0.0,112.0,360.0,1.0,Urban,Y
LP001819,Male,Yes,1,Not Graduate,No,6608,0.0,137.0,180.0,1.0,Urban,Y
LP001824,Male,Yes,1,Graduate,No,2882,1843.0,123.0,480.0,1.0,Semiurban,Y
LP001825,Male,Yes,0,Graduate,No,1809,1868.0,90.0,360.0,1.0,Urban,Y
LP001835,Male,Yes,0,Not Graduate,No,1668,3890.0,201.0,360.0,0.0,Semiurban,N
LP001836,Female,No,2,Graduate,No,3427,0.0,138.0,360.0,1.0,Urban,N
LP001841,Male,No,0,Not Graduate,Yes,2583,2167.0,104.0,360.0,1.0,Rural,Y
LP001843,Male,Yes,1,Not Graduate,No,2661,7101.0,279.0,180.0,1.0,Semiurban,Y
LP001844,Male,No,0,Graduate,Yes,16250,0.0,192.0,360.0,0.0,Urban,N
LP001846,Female,No,3+,Graduate,No,3083,0.0,255.0,360.0,1.0,Rural,Y
LP001849,Male,No,0,Not Graduate,No,6045,0.0,115.0,360.0,0.0,Rural,N
LP001854,Male,Yes,3+,Graduate,No,5250,0.0,94.0,360.0,1.0,Urban,N
LP001859,Male,Yes,0,Graduate,No,14683,2100.0,304.0,360.0,1.0,Rural,N
LP001864,Male,Yes,3+,Not Graduate,No,4931,0.0,128.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,N
LP001865,Male,Yes,1,Graduate,No,6083,4250.0,330.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP001868,Male,No,0,Graduate,No,2060,2209.0,134.0,360.0,1.0,Semiurban,Y
LP001870,Female,No,1,Graduate,No,3481,0.0,155.0,36.0,1.0,Semiurban,N
LP001871,Female,No,0,Graduate,No,7200,0.0,120.0,360.0,1.0,Rural,Y
LP001872,Male,No,0,Graduate,Yes,5166,0.0,128.0,360.0,1.0,Semiurban,Y
LP001875,Male,No,0,Graduate,No,4095,3447.0,151.0,360.0,1.0,Rural,Y
LP001877,Male,Yes,2,Graduate,No,4708,1387.0,150.0,360.0,1.0,Semiurban,Y
LP001882,Male,Yes,3+,Graduate,No,4333,1811.0,160.0,360.0,0.0,Urban,Y
LP001883,Female,No,0,Graduate,__FALCON_NULL_8FF29CAA__,3418,0.0,135.0,360.0,1.0,Rural,N
LP001884,Female,No,1,Graduate,No,2876,1560.0,90.0,360.0,1.0,Urban,Y
LP001888,Female,No,0,Graduate,No,3237,0.0,30.0,360.0,1.0,Urban,Y
LP001891,Male,Yes,0,Graduate,No,11146,0.0,136.0,360.0,1.0,Urban,Y
LP001892,Male,No,0,Graduate,No,2833,1857.0,126.0,360.0,1.0,Rural,Y
LP001894,Male,Yes,0,Graduate,No,2620,2223.0,150.0,360.0,1.0,Semiurban,Y
LP001896,Male,Yes,2,Graduate,No,3900,0.0,90.0,360.0,1.0,Semiurban,Y
LP001900,Male,Yes,1,Graduate,No,2750,1842.0,115.0,360.0,1.0,Semiurban,Y
LP001903,Male,Yes,0,Graduate,No,3993,3274.0,207.0,360.0,1.0,Semiurban,Y
LP001904,Male,Yes,0,Graduate,No,3103,1300.0,80.0,360.0,1.0,Urban,Y
LP001907,Male,Yes,0,Graduate,No,14583,0.0,436.0,360.0,1.0,Semiurban,Y
LP001908,Female,Yes,0,Not Graduate,No,4100,0.0,124.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP001910,Male,No,1,Not Graduate,Yes,4053,2426.0,158.0,360.0,0.0,Urban,N
LP001914,Male,Yes,0,Graduate,No,3927,800.0,112.0,360.0,1.0,Semiurban,Y
LP001915,Male,Yes,2,Graduate,No,2301,985.7999878,78.0,180.0,1.0,Urban,Y
LP001917,Female,No,0,Graduate,No,1811,1666.0,54.0,360.0,1.0,Urban,Y
LP001922,Male,Yes,0,Graduate,No,20667,0.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Rural,N
LP001924,Male,No,0,Graduate,No,3158,3053.0,89.0,360.0,1.0,Rural,Y
LP001925,Female,No,0,Graduate,Yes,2600,1717.0,99.0,300.0,1.0,Semiurban,N
LP001926,Male,Yes,0,Graduate,No,3704,2000.0,120.0,360.0,1.0,Rural,Y
LP001931,Female,No,0,Graduate,No,4124,0.0,115.0,360.0,1.0,Semiurban,Y
LP001935,Male,No,0,Graduate,No,9508,0.0,187.0,360.0,1.0,Rural,Y
LP001936,Male,Yes,0,Graduate,No,3075,2416.0,139.0,360.0,1.0,Rural,Y
LP001938,Male,Yes,2,Graduate,No,4400,0.0,127.0,360.0,0.0,Semiurban,N
LP001940,Male,Yes,2,Graduate,No,3153,1560.0,134.0,360.0,1.0,Urban,Y
LP001945,Female,No,__FALCON_NULL_8FF29CAA__,Graduate,No,5417,0.0,143.0,480.0,0.0,Urban,N
LP001947,Male,Yes,0,Graduate,No,2383,3334.0,172.0,360.0,1.0,Semiurban,Y
LP001949,Male,Yes,3+,Graduate,__FALCON_NULL_8FF29CAA__,4416,1250.0,110.0,360.0,1.0,Urban,Y
LP001953,Male,Yes,1,Graduate,No,6875,0.0,200.0,360.0,1.0,Semiurban,Y
LP001954,Female,Yes,1,Graduate,No,4666,0.0,135.0,360.0,1.0,Urban,Y
LP001955,Female,No,0,Graduate,No,5000,2541.0,151.0,480.0,1.0,Rural,N
LP001963,Male,Yes,1,Graduate,No,2014,2925.0,113.0,360.0,1.0,Urban,N
LP001964,Male,Yes,0,Not Graduate,No,1800,2934.0,93.0,360.0,0.0,Urban,N
LP001972,Male,Yes,__FALCON_NULL_8FF29CAA__,Not Graduate,No,2875,1750.0,105.0,360.0,1.0,Semiurban,Y
LP001974,Female,No,0,Graduate,No,5000,0.0,132.0,360.0,1.0,Rural,Y
LP001977,Male,Yes,1,Graduate,No,1625,1803.0,96.0,360.0,1.0,Urban,Y
LP001978,Male,No,0,Graduate,No,4000,2500.0,140.0,360.0,1.0,Rural,Y
LP001990,Male,No,0,Not Graduate,No,2000,0.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Urban,N
LP001993,Female,No,0,Graduate,No,3762,1666.0,135.0,360.0,1.0,Rural,Y
LP001994,Female,No,0,Graduate,No,2400,1863.0,104.0,360.0,0.0,Urban,N
LP001996,Male,No,0,Graduate,No,20233,0.0,480.0,360.0,1.0,Rural,N
LP001998,Male,Yes,2,Not Graduate,No,7667,0.0,185.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP002002,Female,No,0,Graduate,No,2917,0.0,84.0,360.0,1.0,Semiurban,Y
LP002004,Male,No,0,Not Graduate,No,2927,2405.0,111.0,360.0,1.0,Semiurban,Y
LP002006,Female,No,0,Graduate,No,2507,0.0,56.0,360.0,1.0,Rural,Y
LP002008,Male,Yes,2,Graduate,Yes,5746,0.0,144.0,84.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP002024,__FALCON_NULL_8FF29CAA__,Yes,0,Graduate,No,2473,1843.0,159.0,360.0,1.0,Rural,N
LP002031,Male,Yes,1,Not Graduate,No,3399,1640.0,111.0,180.0,1.0,Urban,Y
LP002035,Male,Yes,2,Graduate,No,3717,0.0,120.0,360.0,1.0,Semiurban,Y
LP002036,Male,Yes,0,Graduate,No,2058,2134.0,88.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002043,Female,No,1,Graduate,No,3541,0.0,112.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP002050,Male,Yes,1,Graduate,Yes,10000,0.0,155.0,360.0,1.0,Rural,N
LP002051,Male,Yes,0,Graduate,No,2400,2167.0,115.0,360.0,1.0,Semiurban,Y
LP002053,Male,Yes,3+,Graduate,No,4342,189.0,124.0,360.0,1.0,Semiurban,Y
LP002054,Male,Yes,2,Not Graduate,No,3601,1590.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Rural,Y
LP002055,Female,No,0,Graduate,No,3166,2985.0,132.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP002065,Male,Yes,3+,Graduate,No,15000,0.0,300.0,360.0,1.0,Rural,Y
LP002067,Male,Yes,1,Graduate,Yes,8666,4983.0,376.0,360.0,0.0,Rural,N
LP002068,Male,No,0,Graduate,No,4917,0.0,130.0,360.0,0.0,Rural,Y
LP002082,Male,Yes,0,Graduate,Yes,5818,2160.0,184.0,360.0,1.0,Semiurban,Y
LP002086,Female,Yes,0,Graduate,No,4333,2451.0,110.0,360.0,1.0,Urban,N
LP002087,Female,No,0,Graduate,No,2500,0.0,67.0,360.0,1.0,Urban,Y
LP002097,Male,No,1,Graduate,No,4384,1793.0,117.0,360.0,1.0,Urban,Y
LP002098,Male,No,0,Graduate,No,2935,0.0,98.0,360.0,1.0,Semiurban,Y
LP002100,Male,No,__FALCON_NULL_8FF29CAA__,Graduate,No,2833,0.0,71.0,360.0,1.0,Urban,Y
LP002101,Male,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,63337,0.0,490.0,180.0,1.0,Urban,Y
LP002103,__FALCON_NULL_8FF29CAA__,Yes,1,Graduate,Yes,9833,1833.0,182.0,180.0,1.0,Urban,Y
LP002106,Male,Yes,__FALCON_NULL_8FF29CAA__,Graduate,Yes,5503,4490.0,70.0,__FALCON_NULL_8FF29CAA__,1.0,Semiurban,Y
LP002110,Male,Yes,1,Graduate,__FALCON_NULL_8FF29CAA__,5250,688.0,160.0,360.0,1.0,Rural,Y
LP002112,Male,Yes,2,Graduate,Yes,2500,4600.0,176.0,360.0,1.0,Rural,Y
LP002113,Female,No,3+,Not Graduate,No,1830,0.0,__FALCON_NULL_8FF29CAA__,360.0,0.0,Urban,N
LP002114,Female,No,0,Graduate,No,4160,0.0,71.0,360.0,1.0,Semiurban,Y
LP002115,Male,Yes,3+,Not Graduate,No,2647,1587.0,173.0,360.0,1.0,Rural,N
LP002116,Female,No,0,Graduate,No,2378,0.0,46.0,360.0,1.0,Rural,N
LP002119,Male,Yes,1,Not Graduate,No,4554,1229.0,158.0,360.0,1.0,Urban,Y
LP002126,Male,Yes,3+,Not Graduate,No,3173,0.0,74.0,360.0,1.0,Semiurban,Y
LP002128,Male,Yes,2,Graduate,__FALCON_NULL_8FF29CAA__,2583,2330.0,125.0,360.0,1.0,Rural,Y
LP002129,Male,Yes,0,Graduate,No,2499,2458.0,160.0,360.0,1.0,Semiurban,Y
LP002130,Male,Yes,__FALCON_NULL_8FF29CAA__,Not Graduate,No,3523,3230.0,152.0,360.0,0.0,Rural,N
LP002131,Male,Yes,2,Not Graduate,No,3083,2168.0,126.0,360.0,1.0,Urban,Y
LP002137,Male,Yes,0,Graduate,No,6333,4583.0,259.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP002138,Male,Yes,0,Graduate,No,2625,6250.0,187.0,360.0,1.0,Rural,Y
LP002139,Male,Yes,0,Graduate,No,9083,0.0,228.0,360.0,1.0,Semiurban,Y
LP002140,Male,No,0,Graduate,No,8750,4167.0,308.0,360.0,1.0,Rural,N
LP002141,Male,Yes,3+,Graduate,No,2666,2083.0,95.0,360.0,1.0,Rural,Y
LP002142,Female,Yes,0,Graduate,Yes,5500,0.0,105.0,360.0,0.0,Rural,N
LP002143,Female,Yes,0,Graduate,No,2423,505.0,130.0,360.0,1.0,Semiurban,Y
LP002144,Female,No,__FALCON_NULL_8FF29CAA__,Graduate,No,3813,0.0,116.0,180.0,1.0,Urban,Y
LP002149,Male,Yes,2,Graduate,No,8333,3167.0,165.0,360.0,1.0,Rural,Y
LP002151,Male,Yes,1,Graduate,No,3875,0.0,67.0,360.0,1.0,Urban,N
LP002158,Male,Yes,0,Not Graduate,No,3000,1666.0,100.0,480.0,0.0,Urban,N
LP002160,Male,Yes,3+,Graduate,No,5167,3167.0,200.0,360.0,1.0,Semiurban,Y
LP002161,Female,No,1,Graduate,No,4723,0.0,81.0,360.0,1.0,Semiurban,N
LP002170,Male,Yes,2,Graduate,No,5000,3667.0,236.0,360.0,1.0,Semiurban,Y
LP002175,Male,Yes,0,Graduate,No,4750,2333.0,130.0,360.0,1.0,Urban,Y
LP002178,Male,Yes,0,Graduate,No,3013,3033.0,95.0,300.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002180,Male,No,0,Graduate,Yes,6822,0.0,141.0,360.0,1.0,Rural,Y
LP002181,Male,No,0,Not Graduate,No,6216,0.0,133.0,360.0,1.0,Rural,N
LP002187,Male,No,0,Graduate,No,2500,0.0,96.0,480.0,1.0,Semiurban,N
LP002188,Male,No,0,Graduate,No,5124,0.0,124.0,__FALCON_NULL_8FF29CAA__,0.0,Rural,N
LP002190,Male,Yes,1,Graduate,No,6325,0.0,175.0,360.0,1.0,Semiurban,Y
LP002191,Male,Yes,0,Graduate,No,19730,5266.0,570.0,360.0,1.0,Rural,N
LP002194,Female,No,0,Graduate,Yes,15759,0.0,55.0,360.0,1.0,Semiurban,Y
LP002197,Male,Yes,2,Graduate,No,5185,0.0,155.0,360.0,1.0,Semiurban,Y
LP002201,Male,Yes,2,Graduate,Yes,9323,7873.0,380.0,300.0,1.0,Rural,Y
LP002205,Male,No,1,Graduate,No,3062,1987.0,111.0,180.0,0.0,Urban,N
LP002209,Female,No,0,Graduate,__FALCON_NULL_8FF29CAA__,2764,1459.0,110.0,360.0,1.0,Urban,Y
LP002211,Male,Yes,0,Graduate,No,4817,923.0,120.0,180.0,1.0,Urban,Y
LP002219,Male,Yes,3+,Graduate,No,8750,4996.0,130.0,360.0,1.0,Rural,Y
LP002223,Male,Yes,0,Graduate,No,4310,0.0,130.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP002224,Male,No,0,Graduate,No,3069,0.0,71.0,480.0,1.0,Urban,N
LP002225,Male,Yes,2,Graduate,No,5391,0.0,130.0,360.0,1.0,Urban,Y
LP002226,Male,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,3333,2500.0,128.0,360.0,1.0,Semiurban,Y
LP002229,Male,No,0,Graduate,No,5941,4232.0,296.0,360.0,1.0,Semiurban,Y
LP002231,Female,No,0,Graduate,No,6000,0.0,156.0,360.0,1.0,Urban,Y
LP002234,Male,No,0,Graduate,Yes,7167,0.0,128.0,360.0,1.0,Urban,Y
LP002236,Male,Yes,2,Graduate,No,4566,0.0,100.0,360.0,1.0,Urban,N
LP002237,Male,No,1,Graduate,__FALCON_NULL_8FF29CAA__,3667,0.0,113.0,180.0,1.0,Urban,Y
LP002239,Male,No,0,Not Graduate,No,2346,1600.0,132.0,360.0,1.0,Semiurban,Y
LP002243,Male,Yes,0,Not Graduate,No,3010,3136.0,__FALCON_NULL_8FF29CAA__,360.0,0.0,Urban,N
LP002244,Male,Yes,0,Graduate,No,2333,2417.0,136.0,360.0,1.0,Urban,Y
LP002250,Male,Yes,0,Graduate,No,5488,0.0,125.0,360.0,1.0,Rural,Y
LP002255,Male,No,3+,Graduate,No,9167,0.0,185.0,360.0,1.0,Rural,Y
LP002262,Male,Yes,3+,Graduate,No,9504,0.0,275.0,360.0,1.0,Rural,Y
LP002263,Male,Yes,0,Graduate,No,2583,2115.0,120.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002265,Male,Yes,2,Not Graduate,No,1993,1625.0,113.0,180.0,1.0,Semiurban,Y
LP002266,Male,Yes,2,Graduate,No,3100,1400.0,113.0,360.0,1.0,Urban,Y
LP002272,Male,Yes,2,Graduate,No,3276,484.0,135.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP002277,Female,No,0,Graduate,No,3180,0.0,71.0,360.0,0.0,Urban,N
LP002281,Male,Yes,0,Graduate,No,3033,1459.0,95.0,360.0,1.0,Urban,Y
LP002284,Male,No,0,Not Graduate,No,3902,1666.0,109.0,360.0,1.0,Rural,Y
LP002287,Female,No,0,Graduate,No,1500,1800.0,103.0,360.0,0.0,Semiurban,N
LP002288,Male,Yes,2,Not Graduate,No,2889,0.0,45.0,180.0,0.0,Urban,N
LP002296,Male,No,0,Not Graduate,No,2755,0.0,65.0,300.0,1.0,Rural,N
LP002297,Male,No,0,Graduate,No,2500,20000.0,103.0,360.0,1.0,Semiurban,Y
LP002300,Female,No,0,Not Graduate,No,1963,0.0,53.0,360.0,1.0,Semiurban,Y
LP002301,Female,No,0,Graduate,Yes,7441,0.0,194.0,360.0,1.0,Rural,N
LP002305,Female,No,0,Graduate,No,4547,0.0,115.0,360.0,1.0,Semiurban,Y
LP002308,Male,Yes,0,Not Graduate,No,2167,2400.0,115.0,360.0,1.0,Urban,Y
LP002314,Female,No,0,Not Graduate,No,2213,0.0,66.0,360.0,1.0,Rural,Y
LP002315,Male,Yes,1,Graduate,No,8300,0.0,152.0,300.0,0.0,Semiurban,N
LP002317,Male,Yes,3+,Graduate,No,81000,0.0,360.0,360.0,0.0,Rural,N
LP002318,Female,No,1,Not Graduate,Yes,3867,0.0,62.0,360.0,1.0,Semiurban,N
LP002319,Male,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,6256,0.0,160.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002328,Male,Yes,0,Not Graduate,No,6096,0.0,218.0,360.0,0.0,Rural,N
LP002332,Male,Yes,0,Not Graduate,No,2253,2033.0,110.0,360.0,1.0,Rural,Y
LP002335,Female,Yes,0,Not Graduate,No,2149,3237.0,178.0,360.0,0.0,Semiurban,N
LP002337,Female,No,0,Graduate,No,2995,0.0,60.0,360.0,1.0,Urban,Y
LP002341,Female,No,1,Graduate,No,2600,0.0,160.0,360.0,1.0,Urban,N
LP002342,Male,Yes,2,Graduate,Yes,1600,20000.0,239.0,360.0,1.0,Urban,N
LP002345,Male,Yes,0,Graduate,No,1025,2773.0,112.0,360.0,1.0,Rural,Y
LP002347,Male,Yes,0,Graduate,No,3246,1417.0,138.0,360.0,1.0,Semiurban,Y
LP002348,Male,Yes,0,Graduate,No,5829,0.0,138.0,360.0,1.0,Rural,Y
LP002357,Female,No,0,Not Graduate,No,2720,0.0,80.0,__FALCON_NULL_8FF29CAA__,0.0,Urban,N
LP002361,Male,Yes,0,Graduate,No,1820,1719.0,100.0,360.0,1.0,Urban,Y
LP002362,Male,Yes,1,Graduate,No,7250,1667.0,110.0,__FALCON_NULL_8FF29CAA__,0.0,Urban,N
LP002364,Male,Yes,0,Graduate,No,14880,0.0,96.0,360.0,1.0,Semiurban,Y
LP002366,Male,Yes,0,Graduate,No,2666,4300.0,121.0,360.0,1.0,Rural,Y
LP002367,Female,No,1,Not Graduate,No,4606,0.0,81.0,360.0,1.0,Rural,N
LP002368,Male,Yes,2,Graduate,No,5935,0.0,133.0,360.0,1.0,Semiurban,Y
LP002369,Male,Yes,0,Graduate,No,2920,16.12000084,87.0,360.0,1.0,Rural,Y
LP002370,Male,No,0,Not Graduate,No,2717,0.0,60.0,180.0,1.0,Urban,Y
LP002377,Female,No,1,Graduate,Yes,8624,0.0,150.0,360.0,1.0,Semiurban,Y
LP002379,Male,No,0,Graduate,No,6500,0.0,105.0,360.0,0.0,Rural,N
LP002386,Male,No,0,Graduate,__FALCON_NULL_8FF29CAA__,12876,0.0,405.0,360.0,1.0,Semiurban,Y
LP002387,Male,Yes,0,Graduate,No,2425,2340.0,143.0,360.0,1.0,Semiurban,Y
LP002390,Male,No,0,Graduate,No,3750,0.0,100.0,360.0,1.0,Urban,Y
LP002393,Female,__FALCON_NULL_8FF29CAA__,__FALCON_NULL_8FF29CAA__,Graduate,No,10047,0.0,__FALCON_NULL_8FF29CAA__,240.0,1.0,Semiurban,Y
LP002398,Male,No,0,Graduate,No,1926,1851.0,50.0,360.0,1.0,Semiurban,Y
LP002401,Male,Yes,0,Graduate,No,2213,1125.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Urban,Y
LP002403,Male,No,0,Graduate,Yes,10416,0.0,187.0,360.0,0.0,Urban,N
LP002407,Female,Yes,0,Not Graduate,Yes,7142,0.0,138.0,360.0,1.0,Rural,Y
LP002408,Male,No,0,Graduate,No,3660,5064.0,187.0,360.0,1.0,Semiurban,Y
LP002409,Male,Yes,0,Graduate,No,7901,1833.0,180.0,360.0,1.0,Rural,Y
LP002418,Male,No,3+,Not Graduate,No,4707,1993.0,148.0,360.0,1.0,Semiurban,Y
LP002422,Male,No,1,Graduate,No,37719,0.0,152.0,360.0,1.0,Semiurban,Y
LP002424,Male,Yes,0,Graduate,No,7333,8333.0,175.0,300.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP002429,Male,Yes,1,Graduate,Yes,3466,1210.0,130.0,360.0,1.0,Rural,Y
LP002434,Male,Yes,2,Not Graduate,No,4652,0.0,110.0,360.0,1.0,Rural,Y
LP002435,Male,Yes,0,Graduate,__FALCON_NULL_8FF29CAA__,3539,1376.0,55.0,360.0,1.0,Rural,N
LP002443,Male,Yes,2,Graduate,No,3340,1710.0,150.0,360.0,0.0,Rural,N
LP002444,Male,No,1,Not Graduate,Yes,2769,1542.0,190.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,N
LP002446,Male,Yes,2,Not Graduate,No,2309,1255.0,125.0,360.0,0.0,Rural,N
LP002447,Male,Yes,2,Not Graduate,No,1958,1456.0,60.0,300.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002448,Male,Yes,0,Graduate,No,3948,1733.0,149.0,360.0,0.0,Rural,N
LP002449,Male,Yes,0,Graduate,No,2483,2466.0,90.0,180.0,0.0,Rural,Y
LP002453,Male,No,0,Graduate,Yes,7085,0.0,84.0,360.0,1.0,Semiurban,Y
LP002455,Male,Yes,2,Graduate,No,3859,0.0,96.0,360.0,1.0,Semiurban,Y
LP002459,Male,Yes,0,Graduate,No,4301,0.0,118.0,360.0,1.0,Urban,Y
LP002467,Male,Yes,0,Graduate,No,3708,2569.0,173.0,360.0,1.0,Urban,N
LP002472,Male,No,2,Graduate,No,4354,0.0,136.0,360.0,1.0,Rural,Y
LP002473,Male,Yes,0,Graduate,No,8334,0.0,160.0,360.0,1.0,Semiurban,N
LP002478,__FALCON_NULL_8FF29CAA__,Yes,0,Graduate,Yes,2083,4083.0,160.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP002484,Male,Yes,3+,Graduate,No,7740,0.0,128.0,180.0,1.0,Urban,Y
LP002487,Male,Yes,0,Graduate,No,3015,2188.0,153.0,360.0,1.0,Rural,Y
LP002489,Female,No,1,Not Graduate,__FALCON_NULL_8FF29CAA__,5191,0.0,132.0,360.0,1.0,Semiurban,Y
LP002493,Male,No,0,Graduate,No,4166,0.0,98.0,360.0,0.0,Semiurban,N
LP002494,Male,No,0,Graduate,No,6000,0.0,140.0,360.0,1.0,Rural,Y
LP002500,Male,Yes,3+,Not Graduate,No,2947,1664.0,70.0,180.0,0.0,Urban,N
LP002501,__FALCON_NULL_8FF29CAA__,Yes,0,Graduate,No,16692,0.0,110.0,360.0,1.0,Semiurban,Y
LP002502,Female,Yes,2,Not Graduate,__FALCON_NULL_8FF29CAA__,210,2917.0,98.0,360.0,1.0,Semiurban,Y
LP002505,Male,Yes,0,Graduate,No,4333,2451.0,110.0,360.0,1.0,Urban,N
LP002515,Male,Yes,1,Graduate,Yes,3450,2079.0,162.0,360.0,1.0,Semiurban,Y
LP002517,Male,Yes,1,Not Graduate,No,2653,1500.0,113.0,180.0,0.0,Rural,N
LP002519,Male,Yes,3+,Graduate,No,4691,0.0,100.0,360.0,1.0,Semiurban,Y
LP002522,Female,No,0,Graduate,Yes,2500,0.0,93.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002524,Male,No,2,Graduate,No,5532,4648.0,162.0,360.0,1.0,Rural,Y
LP002527,Male,Yes,2,Graduate,Yes,16525,1014.0,150.0,360.0,1.0,Rural,Y
LP002529,Male,Yes,2,Graduate,No,6700,1750.0,230.0,300.0,1.0,Semiurban,Y
LP002530,__FALCON_NULL_8FF29CAA__,Yes,2,Graduate,No,2873,1872.0,132.0,360.0,0.0,Semiurban,N
LP002531,Male,Yes,1,Graduate,Yes,16667,2250.0,86.0,360.0,1.0,Semiurban,Y
LP002533,Male,Yes,2,Graduate,No,2947,1603.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Urban,N
LP002534,Female,No,0,Not Graduate,No,4350,0.0,154.0,360.0,1.0,Rural,Y
LP002536,Male,Yes,3+,Not Graduate,No,3095,0.0,113.0,360.0,1.0,Rural,Y
LP002537,Male,Yes,0,Graduate,No,2083,3150.0,128.0,360.0,1.0,Semiurban,Y
LP002541,Male,Yes,0,Graduate,No,10833,0.0,234.0,360.0,1.0,Semiurban,Y
LP002543,Male,Yes,2,Graduate,No,8333,0.0,246.0,360.0,1.0,Semiurban,Y
LP002544,Male,Yes,1,Not Graduate,No,1958,2436.0,131.0,360.0,1.0,Rural,Y
LP002545,Male,No,2,Graduate,No,3547,0.0,80.0,360.0,0.0,Rural,N
LP002547,Male,Yes,1,Graduate,No,18333,0.0,500.0,360.0,1.0,Urban,N
LP002555,Male,Yes,2,Graduate,Yes,4583,2083.0,160.0,360.0,1.0,Semiurban,Y
LP002556,Male,No,0,Graduate,No,2435,0.0,75.0,360.0,1.0,Urban,N
LP002560,Male,No,0,Not Graduate,No,2699,2785.0,96.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP002562,Male,Yes,1,Not Graduate,No,5333,1131.0,186.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002571,Male,No,0,Not Graduate,No,3691,0.0,110.0,360.0,1.0,Rural,Y
LP002582,Female,No,0,Not Graduate,Yes,17263,0.0,225.0,360.0,1.0,Semiurban,Y
LP002585,Male,Yes,0,Graduate,No,3597,2157.0,119.0,360.0,0.0,Rural,N
LP002586,Female,Yes,1,Graduate,No,3326,913.0,105.0,84.0,1.0,Semiurban,Y
LP002587,Male,Yes,0,Not Graduate,No,2600,1700.0,107.0,360.0,1.0,Rural,Y
LP002588,Male,Yes,0,Graduate,No,4625,2857.0,111.0,12.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002600,Male,Yes,1,Graduate,Yes,2895,0.0,95.0,360.0,1.0,Semiurban,Y
LP002602,Male,No,0,Graduate,No,6283,4416.0,209.0,360.0,0.0,Rural,N
LP002603,Female,No,0,Graduate,No,645,3683.0,113.0,480.0,1.0,Rural,Y
LP002606,Female,No,0,Graduate,No,3159,0.0,100.0,360.0,1.0,Semiurban,Y
LP002615,Male,Yes,2,Graduate,No,4865,5624.0,208.0,360.0,1.0,Semiurban,Y
LP002618,Male,Yes,1,Not Graduate,No,4050,5302.0,138.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,N
LP002619,Male,Yes,0,Not Graduate,No,3814,1483.0,124.0,300.0,1.0,Semiurban,Y
LP002622,Male,Yes,2,Graduate,No,3510,4416.0,243.0,360.0,1.0,Rural,Y
LP002624,Male,Yes,0,Graduate,No,20833,6667.0,480.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002625,__FALCON_NULL_8FF29CAA__,No,0,Graduate,No,3583,0.0,96.0,360.0,1.0,Urban,N
LP002626,Male,Yes,0,Graduate,Yes,2479,3013.0,188.0,360.0,1.0,Urban,Y
LP002634,Female,No,1,Graduate,No,13262,0.0,40.0,360.0,1.0,Urban,Y
LP002637,Male,No,0,Not Graduate,No,3598,1287.0,100.0,360.0,1.0,Rural,N
LP002640,Male,Yes,1,Graduate,No,6065,2004.0,250.0,360.0,1.0,Semiurban,Y
LP002643,Male,Yes,2,Graduate,No,3283,2035.0,148.0,360.0,1.0,Urban,Y
LP002648,Male,Yes,0,Graduate,No,2130,6666.0,70.0,180.0,1.0,Semiurban,N
LP002652,Male,No,0,Graduate,No,5815,3666.0,311.0,360.0,1.0,Rural,N
LP002659,Male,Yes,3+,Graduate,No,3466,3428.0,150.0,360.0,1.0,Rural,Y
LP002670,Female,Yes,2,Graduate,No,2031,1632.0,113.0,480.0,1.0,Semiurban,Y
LP002682,Male,Yes,__FALCON_NULL_8FF29CAA__,Not Graduate,No,3074,1800.0,123.0,360.0,0.0,Semiurban,N
LP002683,Male,No,0,Graduate,No,4683,1915.0,185.0,360.0,1.0,Semiurban,N
LP002684,Female,No,0,Not Graduate,No,3400,0.0,95.0,360.0,1.0,Rural,N
LP002689,Male,Yes,2,Not Graduate,No,2192,1742.0,45.0,360.0,1.0,Semiurban,Y
LP002690,Male,No,0,Graduate,No,2500,0.0,55.0,360.0,1.0,Semiurban,Y
LP002692,Male,Yes,3+,Graduate,Yes,5677,1424.0,100.0,360.0,1.0,Rural,Y
LP002693,Male,Yes,2,Graduate,Yes,7948,7166.0,480.0,360.0,1.0,Rural,Y
LP002697,Male,No,0,Graduate,No,4680,2087.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Semiurban,N
LP002699,Male,Yes,2,Graduate,Yes,17500,0.0,400.0,360.0,1.0,Rural,Y
LP002705,Male,Yes,0,Graduate,No,3775,0.0,110.0,360.0,1.0,Semiurban,Y
LP002706,Male,Yes,1,Not Graduate,No,5285,1430.0,161.0,360.0,0.0,Semiurban,Y
LP002714,Male,No,1,Not Graduate,No,2679,1302.0,94.0,360.0,1.0,Semiurban,Y
LP002716,Male,No,0,Not Graduate,No,6783,0.0,130.0,360.0,1.0,Semiurban,Y
LP002717,Male,Yes,0,Graduate,No,1025,5500.0,216.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP002720,Male,Yes,3+,Graduate,No,4281,0.0,100.0,360.0,1.0,Urban,Y
LP002723,Male,No,2,Graduate,No,3588,0.0,110.0,360.0,0.0,Rural,N
LP002729,Male,No,1,Graduate,No,11250,0.0,196.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,N
LP002731,Female,No,0,Not Graduate,Yes,18165,0.0,125.0,360.0,1.0,Urban,Y
LP002732,Male,No,0,Not Graduate,__FALCON_NULL_8FF29CAA__,2550,2042.0,126.0,360.0,1.0,Rural,Y
LP002734,Male,Yes,0,Graduate,No,6133,3906.0,324.0,360.0,1.0,Urban,Y
LP002738,Male,No,2,Graduate,No,3617,0.0,107.0,360.0,1.0,Semiurban,Y
LP002739,Male,Yes,0,Not Graduate,No,2917,536.0,66.0,360.0,1.0,Rural,N
LP002740,Male,Yes,3+,Graduate,No,6417,0.0,157.0,180.0,1.0,Rural,Y
LP002741,Female,Yes,1,Graduate,No,4608,2845.0,140.0,180.0,1.0,Semiurban,Y
LP002743,Female,No,0,Graduate,No,2138,0.0,99.0,360.0,0.0,Semiurban,N
LP002753,Female,No,1,Graduate,__FALCON_NULL_8FF29CAA__,3652,0.0,95.0,360.0,1.0,Semiurban,Y
LP002755,Male,Yes,1,Not Graduate,No,2239,2524.0,128.0,360.0,1.0,Urban,Y
LP002757,Female,Yes,0,Not Graduate,No,3017,663.0,102.0,360.0,__FALCON_NULL_8FF29CAA__,Semiurban,Y
LP002767,Male,Yes,0,Graduate,No,2768,1950.0,155.0,360.0,1.0,Rural,Y
LP002768,Male,No,0,Not Graduate,No,3358,0.0,80.0,36.0,1.0,Semiurban,N
LP002772,Male,No,0,Graduate,No,2526,1783.0,145.0,360.0,1.0,Rural,Y
LP002776,Female,No,0,Graduate,No,5000,0.0,103.0,360.0,0.0,Semiurban,N
LP002777,Male,Yes,0,Graduate,No,2785,2016.0,110.0,360.0,1.0,Rural,Y
LP002778,Male,Yes,2,Graduate,Yes,6633,0.0,__FALCON_NULL_8FF29CAA__,360.0,0.0,Rural,N
LP002784,Male,Yes,1,Not Graduate,No,2492,2375.0,__FALCON_NULL_8FF29CAA__,360.0,1.0,Rural,Y
LP002785,Male,Yes,1,Graduate,No,3333,3250.0,158.0,360.0,1.0,Urban,Y
LP002788,Male,Yes,0,Not Graduate,No,2454,2333.0,181.0,360.0,0.0,Urban,N
LP002789,Male,Yes,0,Graduate,No,3593,4266.0,132.0,180.0,0.0,Rural,N
LP002792,Male,Yes,1,Graduate,No,5468,1032.0,26.0,360.0,1.0,Semiurban,Y
LP002794,Female,No,0,Graduate,No,2667,1625.0,84.0,360.0,__FALCON_NULL_8FF29CAA__,Urban,Y
LP002795,Male,Yes,3+,Graduate,Yes,10139,0.0,260.0,360.0,1.0,Semiurban,Y
LP002798,Male,Yes,0,Graduate,No,3887,2669.0,162.0,360.0,1.0,Semiurban,Y
LP002804,Female,Yes,0,Graduate,No,4180,2306.0,182.0,360.0,1.0,Semiurban,Y
LP002807,Male,Yes,2,Not Graduate,No,3675,242.0,108.0,360.0,1.0,Semiurban,Y
LP002813,Female,Yes,1,Graduate,Yes,19484,0.0,600.0,360.0,1.0,Semiurban,Y
LP002820,Male,Yes,0,Graduate,No,5923,2054.0,211.0,360.0,1.0,Rural,Y
LP002821,Male,No,0,Not Graduate,Yes,5800,0.0,132.0,360.0,1.0,Semiurban,Y
LP002832,Male,Yes,2,Graduate,No,8799,0.0,258.0,360.0,0.0,Urban,N
LP002833,Male,Yes,0,Not Graduate,No,4467,0.0,120.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,Y
LP002836,Male,No,0,Graduate,No,3333,0.0,70.0,360.0,1.0,Urban,Y
LP002837,Male,Yes,3+,Graduate,No,3400,2500.0,123.0,360.0,0.0,Rural,N
LP002840,Female,No,0,Graduate,No,2378,0.0,9.0,360.0,1.0,Urban,N
LP002841,Male,Yes,0,Graduate,No,3166,2064.0,104.0,360.0,0.0,Urban,N
LP002842,Male,Yes,1,Graduate,No,3417,1750.0,186.0,360.0,1.0,Urban,Y
LP002847,Male,Yes,__FALCON_NULL_8FF29CAA__,Graduate,No,5116,1451.0,165.0,360.0,0.0,Urban,N
LP002855,Male,Yes,2,Graduate,No,16666,0.0,275.0,360.0,1.0,Urban,Y
LP002862,Male,Yes,2,Not Graduate,No,6125,1625.0,187.0,480.0,1.0,Semiurban,N
LP002863,Male,Yes,3+,Graduate,No,6406,0.0,150.0,360.0,1.0,Semiurban,N
LP002868,Male,Yes,2,Graduate,No,3159,461.0,108.0,84.0,1.0,Urban,Y
LP002872,__FALCON_NULL_8FF29CAA__,Yes,0,Graduate,No,3087,2210.0,136.0,360.0,0.0,Semiurban,N
LP002874,Male,No,0,Graduate,No,3229,2739.0,110.0,360.0,1.0,Urban,Y
LP002877,Male,Yes,1,Graduate,No,1782,2232.0,107.0,360.0,1.0,Rural,Y
LP002888,Male,No,0,Graduate,__FALCON_NULL_8FF29CAA__,3182,2917.0,161.0,360.0,1.0,Urban,Y
LP002892,Male,Yes,2,Graduate,No,6540,0.0,205.0,360.0,1.0,Semiurban,Y
LP002893,Male,No,0,Graduate,No,1836,33837.0,90.0,360.0,1.0,Urban,N
LP002894,Female,Yes,0,Graduate,No,3166,0.0,36.0,360.0,1.0,Semiurban,Y
LP002898,Male,Yes,1,Graduate,No,1880,0.0,61.0,360.0,__FALCON_NULL_8FF29CAA__,Rural,N
LP002911,Male,Yes,1,Graduate,No,2787,1917.0,146.0,360.0,0.0,Rural,N
LP002912,Male,Yes,1,Graduate,No,4283,3000.0,172.0,84.0,1.0,Rural,N
LP002916,Male,Yes,0,Graduate,No,2297,1522.0,104.0,360.0,1.0,Urban,Y
LP002917,Female,No,0,Not Graduate,No,2165,0.0,70.0,360.0,1.0,Semiurban,Y
LP002925,__FALCON_NULL_8FF29CAA__,No,0,Graduate,No,4750,0.0,94.0,360.0,1.0,Semiurban,Y
LP002926,Male,Yes,2,Graduate,Yes,2726,0.0,106.0,360.0,0.0,Semiurban,N
LP002928,Male,Yes,0,Graduate,No,3000,3416.0,56.0,180.0,1.0,Semiurban,Y
LP002931,Male,Yes,2,Graduate,Yes,6000,0.0,205.0,240.0,1.0,Semiurban,N
LP002933,__FALCON_NULL_8FF29CAA__,No,3+,Graduate,Yes,9357,0.0,292.0,360.0,1.0,Semiurban,Y
LP002936,Male,Yes,0,Graduate,No,3859,3300.0,142.0,180.0,1.0,Rural,Y
LP002938,Male,Yes,0,Graduate,Yes,16120,0.0,260.0,360.0,1.0,Urban,Y
LP002940,Male,No,0,Not Graduate,No,3833,0.0,110.0,360.0,1.0,Rural,Y
LP002941,Male,Yes,2,Not Graduate,Yes,6383,1000.0,187.0,360.0,1.0,Rural,N
LP002943,Male,No,__FALCON_NULL_8FF29CAA__,Graduate,No,2987,0.0,88.0,360.0,0.0,Semiurban,N
LP002945,Male,Yes,0,Graduate,Yes,9963,0.0,180.0,360.0,1.0,Rural,Y
LP002948,Male,Yes,2,Graduate,No,5780,0.0,192.0,360.0,1.0,Urban,Y
LP002949,Female,No,3+,Graduate,__FALCON_NULL_8FF29CAA__,416,41667.0,350.0,180.0,__FALCON_NULL_8FF29CAA__,Urban,N
LP002950,Male,Yes,0,Not Graduate,__FALCON_NULL_8FF29CAA__,2894,2792.0,155.0,360.0,1.0,Rural,Y
LP002953,Male,Yes,3+,Graduate,No,5703,0.0,128.0,360.0,1.0,Urban,Y
LP002958,Male,No,0,Graduate,No,3676,4301.0,172.0,360.0,1.0,Rural,Y
LP002959,Female,Yes,1,Graduate,No,12000,0.0,496.0,360.0,1.0,Semiurban,Y
LP002960,Male,Yes,0,Not Graduate,No,2400,3800.0,__FALCON_NULL_8FF29CAA__,180.0,1.0,Urban,N
LP002961,Male,Yes,1,Graduate,No,3400,2500.0,173.0,360.0,1.0,Semiurban,Y
LP002964,Male,Yes,2,Not Graduate,No,3987,1411.0,157.0,360.0,1.0,Rural,Y
LP002974,Male,Yes,0,Graduate,No,3232,1950.0,108.0,360.0,1.0,Rural,Y
LP002978,Female,No,0,Graduate,No,2900,0.0,71.0,360.0,1.0,Rural,Y
LP002979,Male,Yes,3+,Graduate,No,4106,0.0,40.0,180.0,1.0,Rural,Y
LP002983,Male,Yes,1,Graduate,No,8072,240.0,253.0,360.0,1.0,Urban,Y
LP002984,Male,Yes,2,Graduate,No,7583,0.0,187.0,360.0,1.0,Urban,Y
LP002990,Female,No,0,Graduate,Yes,4583,0.0,133.0,360.0,0.0,Semiurban,N
\.
analyze "falcon_db_02"."finance_loan_approval_prediction_data";
commit;
