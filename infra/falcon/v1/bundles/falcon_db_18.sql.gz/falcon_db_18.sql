\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_18";
drop table if exists "falcon_db_18"."world_economic_corruption" cascade;
create table "falcon_db_18"."world_economic_corruption" ("country" text, "annual_income" bigint, "corruption_index" bigint);
copy "falcon_db_18"."world_economic_corruption" ("country", "annual_income", "corruption_index") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
Denmark,68110,12
Finland,53660,12
New Zealand,45340,12
Norway,84090,15
Singapore,64010,15
Sweden,58890,15
Switzerland,90360,16
Netherlands,56370,18
Luxembourg,81110,19
Germany,51040,20
United Kingdom,45380,22
Hong Kong,54450,24
Austria,52210,26
Canada,48310,26
Estonia,25970,26
Iceland,64410,26
Ireland,74520,26
Australia,56760,27
Belgium,50510,27
Japan,42620,27
France,43880,29
United Arab Emirates,39410,31
United States,70430,33
Qatar,57120,37
Portugal,23730,38
South Korea,34980,38
Spain,29740,39
Israel,49560,41
Italy,35710,44
Poland,16670,44
Saudi Arabia,22270,47
Greece,20140,51
Malaysia,10930,52
China,11890,55
Romania,14170,55
South Africa,6440,56
India,2170,60
Vietnam,3560,61
Argentina,10050,62
Brazil,7720,62
Indonesia,4140,62
Turkey,9830,62
Sri Lanka,3820,63
Ecuador,5930,64
Thailand,7260,65
El Salvador,4140,66
Sierra Leone,510,66
Algeria,3660,67
Egypt,3510,67
Nepal,1230,67
Philippines,3640,67
Zambia,1040,67
Eswatini,3680,68
Ukraine,4120,68
Gabon,7100,69
Mexico,9380,69
Niger,590,69
Papua New Guinea,2790,69
Azerbaijan,4880,70
Bolivia,3360,70
Djibouti,3300,70
Dominican Republic,8220,70
Kenya,2010,70
Laos,2520,70
Paraguay,5340,70
Togo,980,70
Angola,1770,71
Liberia,620,71
Mali,870,71
Russia,11600,71
Burma,1140,72
Mauritania,1730,72
Pakistan,1500,72
Uzbekistan,1960,72
Cameroon,1590,73
Kyrgyzstan,1180,73
Uganda,840,73
Bangladesh,2620,74
Madagascar,500,74
Mozambique,480,74
Guatemala,4940,75
Guinea,1010,75
Iran,3370,75
Tajikistan,1150,75
Central Africa,530,76
Lebanon,3450,76
Nigeria,2100,76
Cambodia,1550,77
Honduras,2540,77
Iraq,5040,77
Zimbabwe,1400,77
Eritrea,600,78
Cape Verde,3330,79
Congo,1630,79
Chad,650,80
Comoros,1460,80
Haiti,1420,80
Nicaragua,2010,80
Sudan,670,80
Burundi,240,81
Congo (Dem. Republic),580,81
Turkmenistan,7220,81
Equatorial Guinea,5810,83
Libya,8430,83
Afghanistan,500,84
Yemen,670,84
Venezuela,13080,86
Somalia,450,87
Syria,1170,87
South Sudan,460,89
\.
analyze "falcon_db_18"."world_economic_corruption";
drop table if exists "falcon_db_18"."world_economic_cost_of_living" cascade;
create table "falcon_db_18"."world_economic_cost_of_living" ("country" text, "cost_index" double precision, "monthly_income" bigint, "purchasing_power_index" double precision);
copy "falcon_db_18"."world_economic_cost_of_living" ("country", "cost_index", "monthly_income", "purchasing_power_index") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
Bermuda,157.6,9712,105.0
Switzerland,142.4,7530,90.1
Cayman Islands,137.9,5281,65.2
Israel,130.2,4130,54.1
Iceland,128.0,5368,71.5
New Caledonia,125.8,1101,14.9
Turks and Caicos Islands,124.6,1967,26.9
Norway,124.6,7008,95.9
Barbados,121.5,1393,19.5
Denmark,119.9,5676,80.6
Ireland,119.8,6210,88.3
Australia,118.0,4730,68.3
New Zealand,117.2,3778,54.9
Luxembourg,113.1,6759,101.8
Sweden,109.3,4908,76.5
Finland,108.0,4472,70.6
United Kingdom,107.9,3782,59.7
Canada,105.6,4026,64.9
Japan,101.9,3552,59.4
United States,100.0,5869,100.0
Netherlands,99.0,4698,80.8
Belgium,97.0,4209,74.0
France,96.2,3657,64.7
Austria,95.9,4351,77.3
Germany,92.3,4253,78.5
South Korea,87.0,2915,57.1
Italy,86.2,2976,58.8
Spain,82.9,2478,50.9
Hong Kong,77.9,4538,99.2
Portugal,76.4,1978,44.1
Malta,75.7,2547,57.3
Singapore,75.0,5334,121.1
Macao,75.0,3894,88.5
Greece,74.7,1678,38.3
Estonia,74.0,2164,49.8
United Arab Emirates,72.3,3284,77.3
Qatar,71.4,4760,113.6
Czechia,68.1,2006,50.2
Iran,67.6,281,7.1
China,63.2,991,26.7
Chile,62.9,1250,33.8
Croatia,60.8,1429,40.1
Haiti,60.1,118,3.4
Costa Rica,57.7,1026,30.3
Hungary,57.3,1478,44.0
Equatorial Guinea,55.9,484,14.8
Mexico,54.7,782,24.4
Albania,52.0,509,16.7
Ecuador,51.9,494,16.2
Serbia,51.2,703,23.4
Montenegro,51.2,775,25.8
Poland,51.1,1389,46.3
Bahrain,49.0,1661,57.7
Brunei,48.9,2626,91.4
Bulgaria,47.5,893,32.0
Romania,47.4,1181,42.4
South Africa,47.1,537,19.4
Brazil,46.9,643,23.4
Morocco,45.0,279,10.6
Saudi Arabia,44.5,1856,71.1
Mauritius,43.3,905,35.6
Ivory Coast,42.7,204,8.2
Kenya,42.3,168,6.7
Cameroon,41.9,133,5.4
Timor-Leste,41.9,162,6.6
Colombia,41.9,513,20.9
Nigeria,41.8,175,7.1
Kosovo,41.0,414,17.2
Philippines,40.9,303,12.6
Lesotho,39.3,106,4.6
Bangladesh,39.0,218,9.5
Malaysia,38.8,911,40.0
Paraguay,38.6,445,19.6
Moldova,38.5,455,20.1
Thailand,38.4,605,26.8
Benin,37.5,114,5.2
Ghana,37.3,197,9.0
Russia,36.9,967,44.7
Iraq,36.8,420,19.5
Cambodia,36.6,129,6.0
Bolivia,36.2,280,13.2
Nicaragua,35.8,168,8.0
Indonesia,35.4,345,16.6
Mongolia,35.3,313,15.1
Suriname,35.0,370,18.0
Vietnam,34.4,297,14.7
Turkey,34.4,819,40.6
Tanzania,34.1,95,4.7
Armenia,33.8,380,19.2
Laos,33.5,210,10.7
Kazakhstan,33.1,727,37.4
Georgia,32.2,395,20.9
Zambia,31.7,87,4.7
Tunisia,30.9,303,16.7
Sri Lanka,30.4,318,17.8
Bhutan,30.0,237,13.4
Ukraine,29.9,343,19.6
Algeria,29.9,305,17.4
Azerbaijan,29.8,407,23.3
India,28.8,181,10.7
Nepal,28.1,103,6.2
Egypt,27.2,293,18.3
Burma,27.0,95,6.0
Pakistan,25.8,125,8.3
Kyrgyzstan,25.3,98,6.6
Angola,23.0,148,10.9
Tajikistan,22.8,96,7.2
\.
analyze "falcon_db_18"."world_economic_cost_of_living";
drop table if exists "falcon_db_18"."world_economic_richest_countries" cascade;
create table "falcon_db_18"."world_economic_richest_countries" ("country" text, "gdp_per_capita" bigint);
copy "falcon_db_18"."world_economic_richest_countries" ("country", "gdp_per_capita") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
Luxembourg,134754
Singapore,116486
Ireland,106456
Qatar,93521
Bermuda,85192
Norway,79201
Switzerland,77324
Macao,73802
United States,69288
Brunei,66620
Hong Kong,65973
Denmark,64651
Netherlands,63767
Sweden,59324
Belgium,58931
Austria,58427
Germany,57928
Iceland,57646
Australia,55807
Finland,55007
Canada,52085
France,50729
United Kingdom,49675
Saudi Arabia,49551
Malta,47714
South Korea,46918
New Zealand,46420
Italy,45936
Bahrain,45411
Czechia,44261
Israel,43722
Slovenia,43625
Japan,42940
Lithuania,42665
Estonia,42192
Spain,40775
Poland,37503
Hungary,36753
Portugal,35888
Romania,35414
Latvia,34469
Bahamas,34108
Croatia,33801
Russia,33361
Slovakia,33010
Panama,31680
Cyprus,31509
Greece,31295
Turkey,30472
Oman,30422
\.
analyze "falcon_db_18"."world_economic_richest_countries";
drop table if exists "falcon_db_18"."world_economic_tourism" cascade;
create table "falcon_db_18"."world_economic_tourism" ("country" text, "tourists_in_millions" double precision, "receipts_in_billions" double precision, "receipts_per_tourist" bigint, "percentage_of_gdp" double precision);
copy "falcon_db_18"."world_economic_tourism" ("country", "tourists_in_millions", "receipts_in_billions", "receipts_per_tourist", "percentage_of_gdp") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
France,117.1,35.96,307,1.2
Mexico,51.1,11.45,224,0.9
United States,45.0,84.21,1870,0.4
Italy,38.4,20.46,533,1.0
Hungary,31.6,4.22,133,2.3
Croatia,21.6,5.63,261,8.3
Turkey,16.0,13.77,862,1.7
Austria,15.1,15.36,1018,3.2
Germany,12.4,58.37,4689,1.4
Virgin Islands,8.6,0.69,80,16.3
United Arab Emirates,8.1,24.62,3045,6.9
Greece,7.4,6.19,836,2.9
Netherlands,7.3,10.93,1504,1.1
Russia,6.4,4.96,780,0.3
Macao,5.9,9.44,1601,31.6
Romania,5.0,1.61,321,0.6
Bulgaria,5.0,1.79,360,2.2
Malaysia,4.3,3.39,781,0.9
Portugal,4.2,10.52,2500,4.2
Japan,4.1,11.4,2769,0.2
Indonesia,4.1,3.53,872,0.3
South Africa,3.9,2.72,699,0.6
Puerto Rico,3.9,2.92,752,2.8
Vietnam,3.8,3.23,842,0.9
Belarus,3.6,0.54,151,0.8
Hong Kong,3.6,32.7,9161,8.9
Ukraine,3.4,0.69,203,0.3
Morocco,2.8,4.51,1611,3.4
Albania,2.7,1.24,468,6.8
Belgium,2.6,7.45,2882,1.2
South Korea,2.5,11.78,4675,0.7
Australia,1.8,26.23,14351,1.7
Philippines,1.5,2.77,1867,0.7
Norway,1.4,2.2,1572,0.5
Cambodia,1.3,1.12,857,4.2
Qatar,0.6,14.32,24601,8.0
Luxembourg,0.5,4.45,8484,5.1
Ethiopia,0.5,2.28,4405,2.1
Serbia,0.4,1.42,3188,2.3
Bermuda,0.1,0.09,1829,1.3
Moldova,0.0,0.35,12207,2.6
\.
analyze "falcon_db_18"."world_economic_tourism";
drop table if exists "falcon_db_18"."world_economic_unemployment" cascade;
create table "falcon_db_18"."world_economic_unemployment" ("country" text, "unemployment_rate" double precision);
copy "falcon_db_18"."world_economic_unemployment" ("country", "unemployment_rate") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
Marshall Islands,36.0
South Africa,33.6
Kiribati,30.6
Kosovo,30.5
American Samoa,29.8
Djibouti,28.4
Eswatini,25.8
Greece,14.8
Spain,14.7
Brazil,14.4
Turkey,13.4
Italy,9.8
Nigeria,9.8
Egypt,9.3
Ukraine,8.9
Sweden,8.7
France,8.1
Canada,7.5
Saudi Arabia,7.4
Bermuda,7.0
Ireland,6.6
Ecuador,6.4
India,6.0
United States,5.5
Sri Lanka,5.4
Hong Kong,5.3
Switzerland,5.3
Bangladesh,5.2
Luxembourg,5.2
Romania,5.2
Australia,5.1
Norway,5.0
Russia,5.0
China,4.8
Denmark,4.8
Malaysia,4.6
United Kingdom,4.5
Indonesia,4.4
Mexico,4.4
Pakistan,4.4
Netherlands,4.0
Taiwan,3.7
Singapore,3.6
South Korea,3.5
Germany,3.5
Poland,3.4
Macao,3.0
Japan,2.8
Philippines,2.4
Vietnam,2.2
Principality of Monaco,2.0
Bahrain,1.9
Chad,1.9
Burundi,1.8
Benin,1.6
Thailand,1.4
Laos,1.3
Guernsey,1.2
Isle of Man,1.1
Gibraltar,1.0
Niger,0.8
Cambodia,0.6
Qatar,0.3
Cocos (Keeling) Islands,0.1
\.
analyze "falcon_db_18"."world_economic_unemployment";
commit;
