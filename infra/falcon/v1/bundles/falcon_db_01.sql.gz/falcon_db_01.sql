\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_01";
drop table if exists "falcon_db_01"."finance_data" cascade;
create table "falcon_db_01"."finance_data" ("gender" text, "age" bigint, "investment_avenues" text, "mutual_funds" bigint, "equity_market" bigint, "debentures" bigint, "government_bonds" bigint, "fixed_deposits" bigint, "ppf" bigint, "gold" bigint, "stock_marktet" text, "factor" text, "objective" text, "purpose" text, "duration" text, "invest_monitor" text, "expect" text, "avenue" text, "what_are_your_savings_objectives" text, "reason_equity" text, "reason_mutual" text, "reason_bonds" text, "reason_fd" text, "source" text);
copy "falcon_db_01"."finance_data" ("gender", "age", "investment_avenues", "mutual_funds", "equity_market", "debentures", "government_bonds", "fixed_deposits", "ppf", "gold", "stock_marktet", "factor", "objective", "purpose", "duration", "invest_monitor", "expect", "avenue", "what_are_your_savings_objectives", "reason_equity", "reason_mutual", "reason_bonds", "reason_fd", "source") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
Female,34,Yes,1,2,5,3,7,6,4,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Safe Investment,Fixed Returns,Newspapers and Magazines
Female,23,Yes,4,3,2,1,5,6,7,No,Locking Period,Capital Appreciation,Wealth Creation,More than 5 years,Weekly,20%-30%,Mutual Fund,Health Care,Dividend,Better Returns,Safe Investment,High Interest Rates,Financial Consultants
Male,30,Yes,3,6,4,2,5,1,7,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Daily,20%-30%,Equity,Retirement Plan,Capital Appreciation,Tax Benefits,Assured Returns,Fixed Returns,Television
Male,22,Yes,2,1,3,7,6,4,5,Yes,Returns,Income,Wealth Creation,Less than 1 year,Daily,10%-20%,Equity,Retirement Plan,Dividend,Fund Diversification,Tax Incentives,High Interest Rates,Internet
Female,24,No,2,1,3,6,4,5,7,No,Returns,Income,Wealth Creation,Less than 1 year,Daily,20%-30%,Equity,Retirement Plan,Capital Appreciation,Better Returns,Safe Investment,Risk Free,Internet
Female,24,No,7,5,4,6,3,1,2,No,Risk,Capital Appreciation,Wealth Creation,1-3 years,Daily,30%-40%,Mutual Fund,Retirement Plan,Liquidity,Fund Diversification,Safe Investment,Risk Free,Internet
Female,27,Yes,3,6,4,2,5,1,7,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Equity,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,High Interest Rates,Financial Consultants
Male,21,Yes,2,3,7,4,6,1,5,Yes,Risk,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Newspapers and Magazines
Male,35,Yes,2,4,7,5,3,1,6,Yes,Returns,Growth,Savings for Future,1-3 years,Weekly,20%-30%,Equity,Retirement Plan,Capital Appreciation,Fund Diversification,Safe Investment,Fixed Returns,Television
Male,31,Yes,1,3,7,4,5,2,6,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,30%-40%,Fixed Deposits,Retirement Plan,Capital Appreciation,Fund Diversification,Assured Returns,Fixed Returns,Newspapers and Magazines
Female,35,Yes,2,4,7,5,3,1,6,Yes,Risk,Growth,Savings for Future,3-5 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Financial Consultants
Male,29,Yes,2,5,7,6,3,1,4,Yes,Risk,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Fund Diversification,Assured Returns,Fixed Returns,Financial Consultants
Female,21,No,1,2,3,4,5,6,7,No,Returns,Capital Appreciation,Savings for Future,1-3 years,Weekly,20%-30%,Mutual Fund,Education,Dividend,Better Returns,Safe Investment,Risk Free,Internet
Female,28,Yes,2,3,7,4,5,1,6,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Fund Diversification,Assured Returns,Risk Free,Newspapers and Magazines
Female,25,Yes,2,3,7,5,4,1,6,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Fixed Deposits,Health Care,Dividend,Better Returns,Assured Returns,Risk Free,Financial Consultants
Male,27,Yes,2,3,7,5,4,1,6,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Mutual Fund,Health Care,Capital Appreciation,Fund Diversification,Assured Returns,Risk Free,Newspapers and Magazines
Female,28,Yes,3,2,7,5,4,1,6,Yes,Risk,Growth,Wealth Creation,1-3 years,Monthly,20%-30%,Fixed Deposits,Health Care,Capital Appreciation,Fund Diversification,Assured Returns,Risk Free,Television
Male,27,Yes,3,2,7,4,5,1,6,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Financial Consultants
Male,29,Yes,3,2,7,4,5,1,6,Yes,Risk,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Newspapers and Magazines
Male,26,Yes,3,4,6,5,1,2,7,Yes,Risk,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Fixed Deposits,Health Care,Capital Appreciation,Fund Diversification,Assured Returns,Risk Free,Newspapers and Magazines
Male,29,Yes,2,4,7,5,3,1,6,Yes,Returns,Growth,Wealth Creation,3-5 years,Weekly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Fixed Returns,Financial Consultants
Female,24,Yes,2,4,5,6,3,1,7,Yes,Risk,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Equity,Health Care,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Newspapers and Magazines
Male,27,Yes,3,4,6,5,2,1,7,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Financial Consultants
Male,25,Yes,2,4,6,5,3,1,7,Yes,Risk,Growth,Savings for Future,3-5 years,Weekly,20%-30%,Public Provident Fund,Health Care,Liquidity,Better Returns,Assured Returns,Risk Free,Financial Consultants
Female,26,Yes,2,3,7,5,4,1,6,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,30%-40%,Public Provident Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Newspapers and Magazines
Female,32,Yes,3,4,7,5,1,2,6,Yes,Risk,Growth,Wealth Creation,3-5 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Fixed Returns,Financial Consultants
Male,26,Yes,3,4,6,5,1,2,7,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Mutual Fund,Retirement Plan,Dividend,Fund Diversification,Assured Returns,Fixed Returns,Financial Consultants
Male,31,Yes,2,3,7,6,4,1,5,Yes,Risk,Growth,Savings for Future,1-3 years,Monthly,20%-30%,Fixed Deposits,Health Care,Capital Appreciation,Fund Diversification,Safe Investment,Fixed Returns,Television
Male,29,Yes,2,3,6,5,1,4,7,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Equity,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Television
Female,34,Yes,5,4,3,2,7,1,6,Yes,Returns,Income,Returns,3-5 years,Monthly,10%-20%,Mutual Fund,Retirement Plan,Capital Appreciation,Tax Benefits,Safe Investment,Fixed Returns,Newspapers and Magazines
Male,27,Yes,4,5,1,2,7,3,6,No,Returns,Growth,Wealth Creation,1-3 years,Monthly,10%-20%,Mutual Fund,Education,Capital Appreciation,Tax Benefits,Safe Investment,Fixed Returns,Television
Female,31,Yes,2,4,7,6,3,1,5,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Fixed Deposits,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Fixed Returns,Financial Consultants
Male,27,Yes,2,4,7,5,1,3,6,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,30%-40%,Equity,Health Care,Capital Appreciation,Fund Diversification,Assured Returns,Fixed Returns,Newspapers and Magazines
Male,26,Yes,2,3,6,4,1,5,7,Yes,Returns,Capital Appreciation,Returns,1-3 years,Monthly,20%-30%,Fixed Deposits,Education,Dividend,Better Returns,Safe Investment,Risk Free,Newspapers and Magazines
Male,27,Yes,2,3,6,5,4,1,7,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Weekly,20%-30%,Mutual Fund,Health Care,Capital Appreciation,Better Returns,Safe Investment,Fixed Returns,Financial Consultants
Male,30,Yes,1,4,6,5,3,2,7,Yes,Risk,Growth,Wealth Creation,3-5 years,Monthly,20%-30%,Fixed Deposits,Health Care,Capital Appreciation,Better Returns,Assured Returns,Fixed Returns,Financial Consultants
Male,30,Yes,2,4,7,5,1,3,6,Yes,Returns,Capital Appreciation,Wealth Creation,1-3 years,Monthly,20%-30%,Equity,Retirement Plan,Capital Appreciation,Better Returns,Assured Returns,Risk Free,Newspapers and Magazines
Male,25,Yes,5,4,7,6,1,2,3,Yes,Risk,Growth,Savings for Future,3-5 years,Monthly,30%-40%,Public Provident Fund,Health Care,Capital Appreciation,Better Returns,Safe Investment,Fixed Returns,Financial Consultants
Male,31,Yes,2,4,7,5,3,1,6,Yes,Risk,Growth,Wealth Creation,1-3 years,Weekly,20%-30%,Equity,Health Care,Dividend,Fund Diversification,Assured Returns,Fixed Returns,Newspapers and Magazines
Male,29,Yes,4,3,5,7,2,1,6,Yes,Returns,Capital Appreciation,Wealth Creation,3-5 years,Monthly,20%-30%,Fixed Deposits,Retirement Plan,Dividend,Better Returns,Safe Investment,Fixed Returns,Financial Consultants
\.
analyze "falcon_db_01"."finance_data";
commit;
