\set ON_ERROR_STOP on
begin;
create schema if not exists "falcon_db_12";
drop table if exists "falcon_db_12"."google_merchandise_events" cascade;
create table "falcon_db_12"."google_merchandise_events" ("user_id" bigint, "ga_session_id" bigint, "country" text, "device" text, "type" text, "item_id" bigint, "date" text);
copy "falcon_db_12"."google_merchandise_events" ("user_id", "ga_session_id", "country", "device", "type", "item_id", "date") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
2133,16909,US,mobile,purchase,94,2020-11-01 00:27:14
2133,16909,US,mobile,purchase,425,2020-11-01 00:27:14
5789,16908,SE,desktop,purchase,1,2020-11-01 01:44:44
5789,16908,SE,desktop,purchase,62,2020-11-01 01:44:44
5808,4267,US,mobile,add_to_cart,842,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,951,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,950,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,1068,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,862,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,1119,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,252,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,1085,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,1074,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,1045,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,953,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,1058,2020-11-01 03:06:29
5808,4267,US,mobile,add_to_cart,862,2020-11-01 03:09:47
5808,4267,US,mobile,add_to_cart,1119,2020-11-01 03:09:47
5808,4267,US,mobile,add_to_cart,1044,2020-11-01 03:09:47
5808,4267,US,mobile,add_to_cart,950,2020-11-01 03:09:47
\.
analyze "falcon_db_12"."google_merchandise_events";
drop table if exists "falcon_db_12"."google_merchandise_items" cascade;
create table "falcon_db_12"."google_merchandise_items" ("id" bigint, "name" text, "brand" text, "variant" text, "category" text, "price_in_usd" bigint);
copy "falcon_db_12"."google_merchandise_items" ("id", "name", "brand", "variant", "category", "price_in_usd") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
1,Google KeepCup,Google,Single Option Only,New,28
62,Google Mini Kick Ball,Google,Single Option Only,Fun,2
94,Google Large Tote White,Google,Single Option Only,Bags,10
252,Android Iconic Hat Black,Android,Single Option Only,Clearance,9
425,Google Heather Green Speckled Tee,Google, XL,Apparel,21
842,Google Infant Hero Onesie Grey,Google,__FALCON_NULL_8FF29CAA__,Apparel,25
862,Google Land & Sea French Terry Sweatshirt,Google,__FALCON_NULL_8FF29CAA__,Shop by Brand,55
950,Google Navy Speckled Tee,Google,__FALCON_NULL_8FF29CAA__,Apparel,30
951,YouTube Icon Tee Grey,YouTube,__FALCON_NULL_8FF29CAA__,Apparel,22
953,Google Land & Sea Cotton Cap,Google,__FALCON_NULL_8FF29CAA__,Apparel,17
1044,Android Iconic Hat White,Android,__FALCON_NULL_8FF29CAA__,New,16
1045,Android Iconic Hat Black,Android,__FALCON_NULL_8FF29CAA__,Clearance,16
1058,Google Heather Green Speckled Tee,Google,__FALCON_NULL_8FF29CAA__,Apparel,30
1068,Google Eco Tee Black,Google,__FALCON_NULL_8FF29CAA__,Apparel,22
1074,Super G Unisex Joggers,Google,__FALCON_NULL_8FF29CAA__,Shop by Brand,37
1085,Google F/C Long Sleeve Tee Charcoal,Google,__FALCON_NULL_8FF29CAA__,Apparel,30
1119,Google Crew Socks,Google,__FALCON_NULL_8FF29CAA__,Apparel,16
\.
analyze "falcon_db_12"."google_merchandise_items";
drop table if exists "falcon_db_12"."google_merchandise_users" cascade;
create table "falcon_db_12"."google_merchandise_users" ("id" bigint, "ltv" bigint, "date" text);
copy "falcon_db_12"."google_merchandise_users" ("id", "ltv", "date") from stdin with (format csv, null '__FALCON_NULL_8FF29CAA__');
2133,34,2020-11-01 00:09:55
5789,72,2020-10-14 00:26:03
5808,0,2020-08-18 03:44:52
\.
analyze "falcon_db_12"."google_merchandise_users";
commit;
